from pathlib import Path
import json,re,collections,sys
from itertools import chain
root=Path(__file__).resolve().parents[1];v=json.loads((root/'work/structure.json').read_text(encoding='utf8'));all_ans=set(v['solutions']);seen=set(); errors=[]; report=[]
for sec,src in v['sections'].items():
 c,n=map(int,sec.split('.'));p=root/'chapters'/f'c{c:02d}s{n:02d}.tex';s=p.read_text(encoding='utf8') if p.exists() else ''
 if '--links' in sys.argv and s:
  s=s.replace(r'\subsection*{习题}',r'\boschexercises');s=re.sub(r'\\label\{ex:([\d.]+)\}(?!\\anslink)',lambda m:m[0]+(r'\anslink{'+m[1]+'}' if m[1] in all_ans else ''),s);p.write_text(s,encoding='utf8')
 for typ,rows,stem in [('条目',src['items'],'obj'),('习题',src['ex'],'ex')]:
  expect=[str(a[0]) for a in rows]; actual=re.findall(r'\\label\{'+stem+':'+re.escape(sec)+r'\.(\d+)\}',s)
  if expect!=actual:errors.append((sec,typ,expect,actual))
 seen.update(re.findall(r'\\anslink\{([\d.]+)\}',s)); report.append((sec,src['page'],len(src['items']),len(src['ex'])))
solutions=[]
for p in sorted(root.glob('solutions-*.tex')):solutions.extend('.'.join(x) for x in re.findall(r'\\solutionto\{(\d+)\}\{(\d+)\}\{(\d+)\}',p.read_text(encoding='utf8')))
if solutions!=v['solutions']:errors.append(('解答编号或次序',))
if seen!=all_ans:errors.append(('缺解答链接',sorted(all_ans-seen)))
print('sections',len(report),'items',sum(i[2] for i in report),'exercises',sum(i[3] for i in report),'answers',len(solutions),'backlinks',len(seen));print(*errors,sep='\n');sys.exit(bool(errors))
