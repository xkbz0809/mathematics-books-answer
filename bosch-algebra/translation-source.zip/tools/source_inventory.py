"""Read Bosch's PDF outline and font geometry to check statements, exercises and the index."""
import collections
import json
from pathlib import Path
import re
import unicodedata
import pymupdf

root = Path(__file__).resolve().parents[1]
source = root.parent / "Algebra bosch2018.pdf"
pdf = pymupdf.open(source)
work = root / "work"
work.mkdir(exist_ok=True)
def lines(page):
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            spans = line["spans"]
            text = unicodedata.normalize("NFKC", "".join(s["text"] for s in spans)).strip()
            yield line["bbox"][0], line["bbox"][1], spans, text

index = []
for i in range(362,369):
    page_rows = []
    for x,y,spans,txt in lines(pdf[i]):
        if y<55 or txt=="Index" or (i==362 and y>605):
            continue
        margin = 50.36 if x < 225 else 229.48
        indent = x-margin
        if indent>10 and page_rows and not txt.startswith("–"):
            last = page_rows[-1]
            if last["source"].endswith("-"):
                last["source"] = last["source"][:-1] + txt
            else:
                last["source"] += " " + txt
        else:
            level = 0 if not txt.startswith("–") else (2 if indent>4 else 1)
            page_rows.append(dict(page=i+1, level=level, source=txt.removeprefix("–").strip()))
    index.extend(page_rows)
(work/"index-source.json").write_text(json.dumps(index,ensure_ascii=False,indent=1),encoding="utf-8")

sections = {}
current,exercises = None,False
types = r"Proposition and Definition|Definition|Remark|Proposition|Lemma|Theorem|Corollary|Examples?|Observation"
for i in range(16,326):
    for x,y,spans,txt in sorted(lines(pdf[i]),key=lambda t:(round(t[1]),t[0])):
        if y<51 or x>80 or not txt: continue
        bold = "".join(s["text"] for s in spans if "CMBX" in s["font"])
        heading = unicodedata.normalize("NFKC",bold).strip()
        if match:=re.match(r"^([1-7]\.\d+)\s",heading):
            current=match[1]
            sections.setdefault(current,dict(page=i+1,items=[],ex=[]))
            exercises=False
        if current:
            if match:=re.match(r"^("+types+r")\s+(\d+)\b",heading):
                sections[current]["items"].append([int(match[2]),match[1],i+1])
            if heading=="Exercises": exercises=True
            if exercises and (match:=re.fullmatch(r"(\d+)\.",spans[0]["text"].strip())) and "CMR10" in spans[0]["font"]:
                entries = sections[current]["ex"]
                # The line break in 6.4, Exercise 1 puts the numeral in "a power of 2."
                # at the left margin. Only the actual exercise number has a hanging indent.
                if not (current == "6.4" and "In particular" in txt):
                    entries.append([int(match[1]),i+1])
solutions=[]
for i in range(326,358):
    for x,y,spans,txt in lines(pdf[i]):
        if match:=re.match(r"^(\d+)\.(\d+), Exercise (\d+)\.",txt):
            solutions.append(".".join(match.groups()))
(work/"structure.json").write_text(json.dumps(dict(sections=sections,solutions=solutions),indent=1),encoding="utf-8")
print("sections",len(sections),"statements",sum(len(s["items"]) for s in sections.values()),"exercises",sum(len(s["ex"]) for s in sections.values()),"solutions",len(solutions),"index entries",len(index))
for i in range(363,370):
    print(i, " | ".join(s["source"] for s in index if s["page"]==i))
