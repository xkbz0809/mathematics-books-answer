"""Build the Chinese edition with XeLaTeX and Biber, including chapter files in reading order."""
from pathlib import Path
import os
import subprocess
import sys

project = Path(__file__).resolve().parents[1]
os.chdir(project)
parts = []
for chapter, section_count in enumerate((3, 9, 9, 11, 4, 4, 4), 1):
    for section in range(section_count + 1):
        path = Path(f"chapters/c{chapter:02}s{section:02}.tex")
        if not path.is_file():
            raise FileNotFoundError(path)
        parts.append(r"\input{" + path.as_posix() + "}")
parts.append(r"\input{appendix}")
Path("contents-files.tex").write_text("\n".join(parts) + "\n", encoding="utf-8")
build = Path("build")
build.mkdir(exist_ok=True)
if "--clean" in sys.argv:
    for suffix in ("aux", "toc", "out", "bcf", "bbl", "run.xml"):
        (build / ("main." + suffix)).unlink(missing_ok=True)
xe = ["xelatex", "-halt-on-error", "-interaction=nonstopmode", "-file-line-error", "-output-directory=build", "main.tex"]
for number, cmd in enumerate((xe, xe, ["biber", "--input-directory", "build", "--output-directory", "build", "main"], xe, xe), 1):
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (build / f"pass-{number}.txt").write_bytes(result.stdout)
    if result.returncode:
        print(result.stdout[-4500:].decode("utf-8", "replace"))
        sys.exit(result.returncode)
print(build / "main.pdf")
