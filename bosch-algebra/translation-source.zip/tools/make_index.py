"""Typeset the book's alphabetical index with its original page locators."""
import json
import re
from pathlib import Path
import pymupdf

root=Path(__file__).resolve().parents[1]
pdf=pymupdf.open(root.parent/"Algebra bosch2018.pdf")
page_by_label={p.get_label():p.number+1 for p in pdf}
def link(page):
    return r"\href[page="+str(page_by_label[page])+r"]{../Algebra bosch2018.pdf}{"+page+"}"

rows=json.loads((root/"work/index-source.json").read_text(encoding="utf-8"))
translations=(root/"work/index-zh.txt").read_text(encoding="utf-8").strip().splitlines()
result=[r"\MTFrontChapter{原书索引}",
        "中英词目沿用原书的英文排列次序. 末栏为英文版印刷页码，点击数字可打开同目录上一级的原书 PDF.",
        r"\begingroup\small\setlength{\tabcolsep}{3pt}\raggedright",
        r"\begin{longtable}{@{}p{.36\linewidth}p{.37\linewidth}p{.22\linewidth}@{}}",
        r"\toprule 中文词目 & 英文词目 & 原书页 \\ \midrule \endhead"]
fix={"Poincar ́e":"Poincaré","Schr ̈oder":"Schröder","Vi`ete":"Viète","l-adic":r"$\ell$-adic","σ-linear":r"$\sigma$-linear","φ-function":r"$\varphi$-function"}
for p,line in enumerate(translations,363):
    for row,cn in zip([r for r in rows if r["page"]==p], line.split("|"),strict=True):
        english=row["source"]; see=""
        if ". see " in english:
            english,see=english.split(". see ",1)
            see=" (see "+see+")"
        match=re.match(r"^(.*?),\s*(\d+(?:[–,\s\d]*))$",english)
        pages=""
        if match:
            english,pages=match.groups()
            pages=re.sub(r"\d+",lambda m:link(m[0]),pages).replace("–","--")
        for before,after in fix.items():
            english=english.replace(before,after)
        depth=row["level"]
        indent = (r"\hspace*{.7em}" if depth==1 else r"\hspace*{1.4em}") if depth else ""
        if not depth: cn=r"\textbf{"+cn+"}"
        result.append(indent+cn+" & "+english+see+" & "+pages+r" \\")
result.extend([r"\bottomrule\end{longtable}\endgroup"])
(root/"subject-index.tex").write_text("\n".join(result)+"\n",encoding="utf-8")
notation=root/"notation.tex"
data=notation.read_text(encoding="utf-8")
data=re.sub(r" & (\d+) (\\\\)",lambda m:" & "+link(m[1])+" "+m[2],data)
notation.write_text(data,encoding="utf-8")
