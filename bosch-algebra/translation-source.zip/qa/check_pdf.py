from pathlib import Path
import json,pymupdf as f,re
root=Path(__file__).resolve().parents[1]; src=f.open(root.parent/'Algebra bosch2018.pdf');pdf=f.open(root/'build/main.pdf');v=json.loads((root/'work/structure.json').read_text(encoding='utf8'))
from collections import Counter
outline=pdf.get_toc(simple=False); lt=Counter(); external=0; errors=[]; found=set(); landmarks=[]
for p in pdf:
 t=p.get_text();
 if '\ufffd' in t:errors.append(f'replacement character p{p.number+1}')
 for link in p.get_links():
  lt[link['kind']]+=1
  if link['kind']==f.LINK_GOTOR:
   dest=link.get('page',-1);xr=pdf.xref_object(link['xref']);
   if '../Algebra bosch2018.pdf' not in xr or dest<0 or dest>=len(src):errors.append(f'index destination {dest}')
   else:
    box=f.Rect(link['from']);box.y0-=2;box.y1+=2
    words=[w[4] for w in p.get_text('words',clip=box)];printed=''.join(words).strip('–—-, ');
    if printed!=src[dest].get_label(): errors.append(f'index p{p.number+1}: {printed} -> {src[dest].get_label()}')
   external+=1
  elif link['kind'] in (f.LINK_GOTO,f.LINK_NAMED) and not 0<=link.get('page',-1)<len(pdf):errors.append(f'bad internal destination {p.number+1}')
for level,title,page,detail in outline:
 m=re.match(r'^(\d+\.\d+)\s',title)
 if m:found.add(m[1]);landmarks.append((m[1],page))
 if not 1<=page<=len(pdf):errors.append(f'outline {title}')
for target in v['sections']:
 if target not in found:errors.append(f'missing outline {target}')
log=(root/'build/main.log').read_text(encoding='utf8',errors='replace'); warnings=[line for line in log.splitlines() if re.search(r'undefined|multiply defined|Missing character|Overfull \\[hv]box|destination with the same identifier|Token not allowed',line,re.I)]
result=dict(pages=len(pdf),outlines=len(outline),chapters=sum(bool(re.match(r'第\s*\d+\s*章',x[1])) for x in outline),sections=len(found),exercise_bookmarks=sum(x[1]=='习题' for x in outline),links=dict(lt),original_page_links=external,diagnostics=warnings,errors=errors,section_pages=dict(landmarks));print(json.dumps(result,ensure_ascii=False,indent=1));(root/'qa/PDF核验.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
