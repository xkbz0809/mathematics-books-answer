"""Independent integer checks of polynomial coefficients and degree formulas in the translation."""
from functools import cache
from itertools import combinations, permutations
from math import gcd, lcm, prod
from pathlib import Path
import re

@cache
def cyclotomic(n):
    coeff = [-1] + [0]*(n-1) + [1]
    for d in range(1,n):
        if n%d: continue
        div = cyclotomic(d)
        quot = [0]*(len(coeff)-len(div)+1)
        for k in reversed(range(len(quot))):
            quot[k] = coeff[k+len(div)-1]
            for j,c in enumerate(div): coeff[k+j] -= quot[k]*c
        assert not any(coeff)
        coeff = quot
    return tuple(coeff)

def parse_polynomial(s):
    s=s.replace('{','').replace('}','').replace(' ','').replace('&','').replace('\\','').replace('\n','').strip('.,')
    terms=re.findall(r'[+-]?[^+-]+',s);coeff={}
    for t in terms:
        m=re.fullmatch(r'([+-]?)(\d*)(X(?:\^(\d+))?)?',t);assert m,t
        sign,mag,x,exp=m.groups(); degree=int(exp or 1) if x else 0
        assert degree not in coeff,t
        coeff[degree]=(-1 if sign=='-' else 1)*int(mag or '1')
    return tuple(coeff.get(i,0) for i in range(max(coeff)+1))

root=Path(__file__).resolve().parents[1];s=(root/'chapters/c04s05.tex').read_text(encoding='utf8')
for n in (*range(1,13),105):
    pat=r'\\Phi_(?:'+str(n)+r'|\{'+str(n)+r'\})\s*&?=\s*(?:\{\})?&?(.*?)(?=,&|,\\\\|\.\s*\\end|\n\\end)'
    section=s[s.index('前十二个分圆'):];m=re.search(pat,section,re.S);assert m,n
    assert parse_polynomial(m[1])==cyclotomic(n),n
assert [i for i in range(1,211) if max(map(abs,cyclotomic(i)))>1]==[105,165,195,210]
assert cyclotomic(15)[5]==1 and cyclotomic(105)[7]==-2
phi=lambda n:sum(gcd(i,n)==1 for i in range(1,n+1))
for m in range(1,51):
 for n in range(1,51):
    assert (phi(lcm(m,n))==phi(m)*phi(n))==(gcd(m,n) in (1,2))
# Vandermonde product and resolvent, for all depressed integral quartics in this sample.
count=0
for x in combinations(range(-9,10),4):
    if sum(x): continue
    a,b,c,d=x; P=sum(a*b for a,b in combinations(x,2));Q=-sum(a*b*c for a,b,c in combinations(x,3));R=prod(x)
    z=((a+b)*(c+d),(a+c)*(b+d),(a+d)*(b+c))
    assert all(v**3-2*P*v*v+(P*P-4*R)*v+Q*Q==0 for v in z)
    assert (a+b)*(a+c)*(a+d)==-Q
    assert prod((a-b)**2 for a,b in combinations(z,2))==prod((a-b)**2 for a,b in combinations(x,2));count+=1
assert 144-128-4+16-27+256==257
print('Cyclotomic coefficients: 1 through 12 and 105 exact. First four nonflat indices verified through 210. Phi15[X^5]=1. Phi105[X^7]=-2.')
print('Cyclotomic degree equivalence: 2500 pairs. Quartic resolvent, sign and discriminant:',count,'quartics. Discriminant example: 257.')
