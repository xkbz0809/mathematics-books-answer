from pathlib import Path
import collections, hashlib, re, sys
import pymupdf
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
source = root / 'build/main.pdf'
draft = '--draft' in sys.argv
out = root / ('work/visual-draft' if draft else 'work/visual-final')
out.mkdir(exist_ok=True)
pdfbytes = source.read_bytes()
doc = pymupdf.open(stream=pdfbytes, filetype='pdf')
toc = doc.get_toc()
sections = {m[1]: n for level, title, n in toc if (m := re.match(r'^(\d+\.\d+)\s', title))}
assert draft or len(sections) == 44, f'{len(sections)} section bookmarks'
text = [''.join(page.get_text().split()) for page in doc]
selection = collections.defaultdict(list)
def add(page, title):
    if not 1 <= page <= len(doc):
        raise ValueError((page,title))
    selection[page].append(title)
def heading(fragment):
    return next(n for _,t,n in toc if fragment in t and n > 0)
add(1,'cover'); add(next(i+1 for i,t in enumerate(text) if t.startswith('目录')),'contents')
for sec, extra, name in [('1.2',1,'quotient groups'),('2.9',2,'elementary divisors'),('3.5',1,'extensions'),('4.5',1,'roots of unity'),('4.10',1,'Kummer'),('5.3',1,'permutations'),('6.2',1,'cubic equations'),('7.2',1,'tensor products'),('7.4',3,'differentials')]:
    add(sections[sec]+extra,name)
for i in range(sections['4.10']-1,heading('第5章')-1):
    if ('Witt' in text[i] or '维特' in text[i]) and '向量' in text[i]: add(i+1,'Witt vectors')
for i in range(sections['6.4']-1,heading('第7章')-1):
    if doc[i].get_images(): add(i+1,'geometry figure')
for title in ['附录','参考文献','记号表','原书索引','术语索引']:
    hits=[n for _,t,n in toc if title in t and n>0]
    if hits: add(hits[0], title)
    elif title=='术语索引':
        h=next((i+1 for i in range(heading('原书索引'),len(doc)) if text[i].startswith(('术语索引','中英文术语索引'))),None)
        if h: add(h,title+' inferred')
        elif not draft: raise ValueError('无术语索引实际页或可用书签')
add(len(doc),'last page')
# Select a displayed matrix from its actual text, independently of section offsets.
for match,name in [('的矩阵，其中','Smith normal form'),('的初等因子.','matrix exercise')]:
    hits=[i+1 for i in range(sections['2.9']-1,sections['3.1']-1) if match in text[i]]
    if hits: add(hits[-1] if name=='matrix exercise' else hits[0],name)
rows = sorted(selection); print('PDF',len(doc),'pages;',len(rows),'samples;',hashlib.sha256(pdfbytes).hexdigest());print([(i,selection[i]) for i in rows]);
for start in range(0,len(rows),4):
    sheet=Image.new('RGB',(1120,1550),'#d8d8d8');draw=ImageDraw.Draw(sheet)
    for k,i in enumerate(rows[start:start+4]):
        pg=doc[i-1];pix=pg.get_pixmap(matrix=pymupdf.Matrix(1.6,1.6),alpha=False);path=out/f'{i:03}.png';pix.save(path);im=Image.open(path).convert('RGB');im.thumbnail((550,740));x=k%2*560;y=k//2*775;sheet.paste(im,(x,y+25));draw.text((x+10,y+3),'PDF '+str(i),fill='black')
    sheet.save(out/f'sheet-{start//4+1}.jpg',quality=92)
