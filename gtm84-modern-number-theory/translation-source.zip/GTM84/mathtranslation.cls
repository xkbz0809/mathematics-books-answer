\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{mathtranslation}[2026/11/12 Book adaptation of MathTranslations 2026/09/11]

\LoadClass[UTF8,12pt,fontset=none,oneside,openany]{ctexbook}

% ---------- 页面、字体与数学 ----------
\RequirePackage[paper=a4paper,left=2.5cm,right=2.5cm,top=2.8cm,bottom=2.8cm]{geometry}
\RequirePackage{fontspec}
\RequirePackage{xeCJK}
\RequirePackage{amsmath,amsthm,amssymb,mathrsfs,mathtools}
\RequirePackage{graphicx,tikz,tikz-cd}
\graphicspath{{graphics/}}
\RequirePackage{array,booktabs,longtable}
\RequirePackage{etoolbox}
\RequirePackage[dvipsnames]{xcolor}
\RequirePackage[
    backend=biber,
    style=numeric,
    sorting=none,
    maxalphanames=2,
    maxbibnames=99,
    giveninits=true
]{biblatex}
\RequirePackage[
    colorlinks=true,
    bookmarksnumbered=true,
    linkcolor=MidnightBlue,
    citecolor=BrickRed, % 文献引用使用砖红色，与普通交叉引用区分
    urlcolor=MidnightBlue,
    linktoc=all
]{hyperref}

% 与模板内置 logo.pdf 的 PDF 版本保持一致，避免 xdvipdfmx 的版本警告。
\AtBeginDocument{\special{pdf:minorversion 7}}

% 英文：Computer Modern Unicode Serif
\setmainfont{cmunrm.otf}[
  BoldFont=cmunbx.otf,
  ItalicFont=cmunti.otf,
  BoldItalicFont=cmunbi.otf
]

% 中文：正文宋体；专用术语楷体；定理类环境仿宋
% 使用 TeX Live 自带 Fandol，避免依赖 macOS / Windows 专有字体.
\setCJKmainfont{FandolSong-Regular.otf}[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolKai-Regular.otf]
\newCJKfontfamily\songfont{FandolSong-Regular.otf}[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolKai-Regular.otf]
\newCJKfontfamily\termfont{FandolKai-Regular.otf}
\newCJKfontfamily\theoremfont[AutoFakeBold=2,ItalicFont=FandolKai-Regular.otf]{FandolFang-Regular.otf}
\setCJKsansfont{FandolHei-Regular.otf}[BoldFont=FandolHei-Bold.otf]
\setCJKmonofont{FandolFang-Regular.otf}

\pagestyle{plain}
\setlength{\parindent}{2em}
\setlength{\parskip}{0pt}
\linespread{1.16}

% ---------- 译本元信息：实际使用时只需修改这里 ----------
% 封面标题：中文译名 + 原书名
% 右下角只显示：版次 · 出版社 · 年份 / 译者 翻译及重排 / 使用模型 / 更新时间
\newcommand{\BookTitleCN}{代数学}
\newcommand{\BookTitleEN}{Algebra}
\newcommand{\OriginalAuthor}{Serge Lang}
\newcommand{\OriginalEdition}{3rd edition}
\newcommand{\OriginalPublisher}{Springer}
\newcommand{\OriginalYear}{2002}
\newcommand{\Translator}{数译}
\newcommand{\ModelUsed}{GPT-5.6 Sol}
\newcommand{\TranslationDate}{17 Aug 2026}


% ================================================================
%                         封面
% ================================================================
\newcommand{\makecover}{%
  \hypersetup{pageanchor=false}%
  \begin{titlepage}
    \thispagestyle{empty}
    \flushleft

    \rule{\textwidth}{1.2pt} \\[0.1cm]
    \rule{\textwidth}{0.8pt} \\[1.5cm]

    {\fontsize{32pt}{42pt}\selectfont \bfseries \BookTitleCN} \\[0.8cm]
    {\fontsize{19pt}{25pt}\selectfont \textit{\BookTitleEN}} \\[1.5cm]

    \rule{\textwidth}{0.6pt} \\[2cm]

    {\Large \textsc{\OriginalAuthor}} \\[2cm]

    \vfill

    \noindent
    \begin{minipage}[b]{0.46\textwidth}
      \raggedright
      \includegraphics[width=5.7cm]{logo.pdf}
    \end{minipage}
    \hfill
    \begin{minipage}[b]{0.50\textwidth}
      \raggedleft
      {\small \OriginalEdition · \OriginalPublisher · \OriginalYear} \\[0.25cm]
      {\normalsize \Translator\ 翻译及重排} \\[0.25cm]
      {\small Model: \ModelUsed} \\
      {\small Updated: \TranslationDate}
    \end{minipage}

    \vspace*{1cm}
  \end{titlepage}%
  \hypersetup{pageanchor=true}%
}

% ================================================================
%                         术语系统
% ================================================================
% \newterm{唯一键}{中文术语}{英文术语}
% 用于“新概念第一次出现”的位置.
% 示例：\newterm{scheme}{概型}{scheme}
% 输出：楷体“概型”（scheme）
% 同时自动记录术语索引中的中文、英文与第一次出现页码.
%
% 后续再出现“概型”时，直接正常输入“概型”即可，不要再次调用 \newterm.
% \termcn{...} 仅用于少数确有必要的术语强调，不自动进入索引.

\newcommand{\termcn}[1]{{\termfont #1}}

\makeatletter
\newcommand{\MTTermList}{}
\newcommand{\MTRegisterTerm}[3]{%
  \g@addto@macro\MTTermList{\MTTermRow{#1}{#2}{#3}}%
}
\newcommand{\MTTermRow}[3]{%
  {\termfont #1} & #2 & \hyperref[#3]{\pageref*{#3}} \\
}

\newcommand{\newterm}[3]{%
  \@ifundefined{MT@seen@#1}{%
    \expandafter\gdef\csname MT@seen@#1\endcsname{}%
    \phantomsection
    \label{term:#1}%
    \protected@write\@auxout{}{%
      \string\MTRegisterTerm{\unexpanded{#2}}{\unexpanded{#3}}{term:#1}%
    }%
  }{}%
  {\termfont #2}（#3）%
}
\makeatother

% 文末自动生成术语索引.
% 表中顺序就是术语在正文中第一次出现的顺序.
\newcommand{\printterminology}{%
  \clearpage
  \MTFrontChapter{术语索引}

  \vspace{0.5cm}
  \begingroup
  \renewcommand{\arraystretch}{1.28}
  \begin{longtable}{>{\raggedright\arraybackslash}p{0.28\textwidth}>{\raggedright\arraybackslash}p{0.49\textwidth}>{\centering\arraybackslash}p{0.12\textwidth}}
    \toprule
    \textbf{中文术语} & \textbf{英文术语} & \textbf{页码} \\
    \midrule
    \endfirsthead
    \toprule
    \textbf{中文术语} & \textbf{英文术语} & \textbf{页码} \\
    \midrule
    \endhead
    \MTTermList
    \bottomrule
  \end{longtable}
  \endgroup
}

% ================================================================
%                       定理类环境
% ================================================================
% 定义、引理、定理、推论、命题、注：仿宋正文
% 例、问题：宋体正文
% 定理类环境标题后使用英文句点；proof 标题仍保留中文冒号.

\newtheoremstyle{mtfang}%
  {6pt}{6pt}% 上下间距
  {\theoremfont}% 正文字体
  {0pt}% 缩进
  {\songfont\bfseries}% 标题字体统一为宋体粗体，与“例”“证明”一致
  {.}% 标题后的英文句点
  {0.5em}% 标题与正文间距
  {}%

\newtheoremstyle{mtsong}%
  {6pt}{6pt}%
  {\songfont}%
  {0pt}%
  {\songfont\bfseries}%
  {.}%
  {0.5em}%
  {}%

\newcounter{statement}[section]
\renewcommand{\thestatement}{\arabic{section}.\arabic{statement}}
\providecommand{\theHstatement}{\theHsection.\arabic{statement}}
\theoremstyle{mtfang}
\newtheorem{definition}[statement]{定义}
\newtheorem{lemma}[statement]{引理}
\newtheorem{theorem}[statement]{定理}
\newtheorem{corollary}[statement]{推论}
\newtheorem{proposition}[statement]{命题}
\newtheorem{remark}[statement]{注}

\theoremstyle{mtsong}
\newtheorem{example}[statement]{例}
\newtheorem{problem}[statement]{问题}

% autoref 名称
\providecommand{\definitionautorefname}{定义}
\renewcommand{\definitionautorefname}{定义}
\providecommand{\lemmaautorefname}{引理}
\renewcommand{\lemmaautorefname}{引理}
\providecommand{\theoremautorefname}{定理}
\renewcommand{\theoremautorefname}{定理}
\providecommand{\corollaryautorefname}{推论}
\renewcommand{\corollaryautorefname}{推论}
\providecommand{\propositionautorefname}{命题}
\renewcommand{\propositionautorefname}{命题}
\providecommand{\exampleautorefname}{例}
\renewcommand{\exampleautorefname}{例}
\providecommand{\remarkautorefname}{注}
\renewcommand{\remarkautorefname}{注}
\providecommand{\problemautorefname}{问题}
\renewcommand{\problemautorefname}{问题}
\providecommand{\exerciseautorefname}{习题}
\renewcommand{\exerciseautorefname}{习题}

% 只有“例”和“注”以菱形表示环境结束.
\newcommand{\envenddiamond}{%
  \ifhmode
    \unskip\nobreak\hfill\ensuremath{\diamond}%
  \else
    \noindent\hfill\ensuremath{\diamond}%
  \fi
  \par
}
\AtEndEnvironment{example}{\envenddiamond}
\AtEndEnvironment{remark}{\envenddiamond}

% ---------- proof 样式：宋体正文，以方块结束 ----------
\makeatletter
\renewcommand{\proofname}{证明}
\renewenvironment{proof}[1][\proofname]{\par
  \pushQED{\qed}%
  \normalfont\songfont
  \topsep6\p@\@plus6\p@\relax
  \trivlist
  % 保留 amsthm 原来的标签位置；仅把证明正文向全角冒号靠近。
  \item[\hskip\labelsep\normalfont\songfont\bfseries #1：]\hspace*{-0.50em}\ignorespaces
}{%
  \popQED\endtrivlist\@endpefalse
}
\makeatother
\renewcommand{\qedsymbol}{\ensuremath{\square}}

% ================================================================
%                     长证明双向链接
% ================================================================
% 正文：\longprooflink{唯一键}{按钮文字}
% 小节末、习题前：\begin{longproof}{唯一键}{所证明结果的名称} ... \end{longproof}

\newcommand{\longprooflink}[2]{%
  \par\smallskip
  \hypertarget{longproof-source:#1}{}%
  \begin{flushright}
    \fbox{\hyperref[longproof:#1]{\textcolor{MidnightBlue}{#2（第~\pageref*{longproof:#1}~页）}}}%
  \end{flushright}
  \smallskip
}

\newenvironment{longproof}[2]{%
  \def\CurrentLongProofKey{#1}%
  \phantomsection
  \hypertarget{longproof:#1}{}%
  \label{longproof:#1}%
  \begin{proof}[证明（#2）]
}{%
  \end{proof}
  \begin{flushright}
    \fbox{\hyperlink{longproof-source:\CurrentLongProofKey}{\textcolor{MidnightBlue}{返回原处}}}%
  \end{flushright}
  \medskip
}

% ================================================================
%                     习题与答案双向链接
% ================================================================
\newcounter{exercise}[subsection]
\renewcommand{\theexercise}{\thesubsection.\arabic{exercise}}
\providecommand{\theHexercise}{\theexercise}
\newlength{\exerciseLabelWidth}
\newlength{\answerLabelWidth}
\newcounter{answeritem}

\makeatletter
\newcommand{\maybehyperref}[2]{\@ifundefined{r@#1}{#2}{\hyperref[#1]{#2}}}

\newcommand{\exercise@item}{%
  \par\smallskip
  \refstepcounter{exercise}%
  \edef\exercise@number{\theexercise}%
  \edef\exercise@label{exe:\exercise@number}%
  \edef\exercise@answerlabel{ans:\exercise@number}%
  \expandafter\label\expandafter{\exercise@label}%
  \settowidth{\exerciseLabelWidth}{\textbf{\theexercise.}\enspace}%
  \hangindent=\exerciseLabelWidth
  \hangafter=1
  \noindent
  \maybehyperref{\exercise@answerlabel}{\textbf{\theexercise.}}\enspace
  \ignorespaces
}

\newenvironment{exercises}{%
  \par\medskip
  \noindent{\large\bfseries 习题}\par\smallskip
  \begingroup
  \setlength{\parindent}{0pt}
  \renewcommand{\item}{\exercise@item}%
}{%
  \par\endgroup\medskip
}

\newcommand{\answer@item}{%
  \par\smallskip
  \stepcounter{answeritem}%
  \edef\answer@number{\answer@prefix.\arabic{answeritem}}%
  \edef\answer@label{ans:\answer@number}%
  \edef\answer@exerciselabel{exe:\answer@number}%
  \phantomsection
  \protected@edef\@currentlabel{\answer@number}%
  \expandafter\label\expandafter{\answer@label}%
  \settowidth{\answerLabelWidth}{\textbf{\answer@number.}\enspace}%
  \hangindent=\answerLabelWidth
  \hangafter=1
  \noindent
  \maybehyperref{\answer@exerciselabel}{\textbf{\answer@number.}}\enspace
  \ignorespaces
}

\newenvironment{answers}[1]{%
  \par\medskip
  \def\answer@prefix{#1}%
  \setcounter{answeritem}{0}%
  \begingroup
  \setlength{\parindent}{0pt}
  \renewcommand{\item}{\answer@item}%
}{%
  \par\endgroup\medskip
}
\makeatother

% ---------- 参考文献 ----------
% Anchor inside the heading: verified against PDF geometry in nav_probe.
% A phantomsection after chapter* lands below the heading in this class.
\newcommand{\MTFrontChapter}[1]{%
  \chapter*{\texorpdfstring{\phantomsection}{}#1}%
  \addcontentsline{toc}{chapter}{#1}%
}
\newcommand{\makebibliography}{%
  \MTFrontChapter{参考文献}%
  \printbibliography[heading=none]%
}

% 参考文献标题仍由普通 \chapter*{参考文献}\phantomsection\addcontentsline{toc}{chapter}{参考文献} 控制；
% \printbibliography[heading=none] 只负责输出条目，因此可以保留原来的页面样式。
\setlength{\bibitemsep}{0.5\baselineskip}


\newcommand{\makecontents}{\tableofcontents\clearpage}
\RequirePackage{enumitem}
\ctexset{chapter={number=\Roman{chapter},format=\Huge\bfseries},section={format=\Large\bfseries}}
\renewcommand{\thechapter}{\Roman{chapter}}
\renewcommand{\thesection}{\thechapter.\arabic{section}}
\AtBeginDocument{\renewcommand{\theHstatement}{\theHsection.\arabic{statement}}}
