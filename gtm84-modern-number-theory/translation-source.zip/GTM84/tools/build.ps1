$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)
New-Item -ItemType Directory -Force -Path build,build/chapters | Out-Null
1..2 | ForEach-Object { & xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex; if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed" } }
& biber --input-directory=build --output-directory=build main
if ($LASTEXITCODE -ne 0) { throw "Biber failed" }
1..2 | ForEach-Object { & xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex; if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed" } }
