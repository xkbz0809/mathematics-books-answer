#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Optional machine-specific environment setup; not required by a normal TeX Live installation.
if [[ -n "${GTM_TEX_ENV:-}" ]]; then source "$GTM_TEX_ENV"; fi
OUT="${1:-build}"
mkdir -p "$OUT/chapters"
for n in 1 2; do xelatex -interaction=nonstopmode -halt-on-error -output-directory="$OUT" main.tex > "$OUT/pass$n.txt" 2>&1; done
"${BIBER:-biber}" --input-directory="$OUT" --output-directory="$OUT" main > "$OUT/biber.txt" 2>&1
for n in 3 4; do xelatex -interaction=nonstopmode -halt-on-error -output-directory="$OUT" main.tex > "$OUT/pass$n.txt" 2>&1; done
printf '%s\n' "$OUT/main.pdf"
