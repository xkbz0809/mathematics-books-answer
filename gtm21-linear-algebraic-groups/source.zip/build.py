"""Compile the standalone Chinese solutions volume."""
from pathlib import Path
import sys,subprocess
root=Path(__file__).resolve().parent
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'build'
out.mkdir(parents=True,exist_ok=True)
for i in range(3):
    with (out/'build-transcript.txt').open("ab") as log:
        result=subprocess.run(["xelatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","-file-line-error","-output-directory="+str(out),"main.tex"],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:raise SystemExit("XeLaTeX failed. See "+str(out/'build-transcript.txt'))
print(out/'main.pdf')
