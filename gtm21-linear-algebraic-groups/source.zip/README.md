# 《线性代数群》全书节末习题解答

本工程对应 Humphreys, *Linear Algebraic Groups*, GTM 21（1975 年第一版）。共有 33 个节末题组、236 道题。每个题号对应一段中文题干和一份解答。第 0、34、35 节和附录没有节末题组。

在含中文支持的 TeX Live 环境中运行 `python build.py`，输出为 `build/main.pdf`。主文件是 `main.tex`，题干在 `questions.tex`，解答按原书节号分别存放在 `answers/`。工程可在独立目录编译。
