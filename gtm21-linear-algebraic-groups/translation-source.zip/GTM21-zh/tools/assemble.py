"""Assemble the available source. Use --full for release, which requires every unit."""
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
chaps=[(0,6,"代数几何"),(7,8,"仿射代数群"),(9,10,"李代数"),(11,12,"齐性空间"),
       (13,14,"特征零的理论"),(15,16,"半单元素与幺幂元素"),(17,20,"可解群"),
       (21,23,"Borel 子群"),(24,26,"环面的中心化子"),(27,30,"约化群的结构"),
       (31,33,"半单群的表示与分类"),(34,35,"有理性性质概述")]
extras=["appendix","bibliog1","bibliog2","termindex","symindex"]
have=[s for s in range(36) if (root/f"chapters/s{s:02}.tex").is_file()]
extra=[x for x in extras if (root/(x+".tex")).is_file()]
full=(len(have)==36 and len(extra)==5)
if "--full" in sys.argv and not full:
    raise SystemExit("Missing sections or back matter: "+str((sorted(set(range(36))-set(have)),set(extras)-set(extra))))
lines=[r"\documentclass{mathtranslation}",r"\input{preamble}",r"\begin{document}"]
lines.insert(0, "% !TeX program = xelatex")
if not full: lines.append(r"\renewcommand{\OriginalEdition}{第一版，部分译稿}")
lines.extend([r"\makecover",r"\frontmatter",r"\input{front}",r"\makecontents",r"\mainmatter"])
for c,(start,end,title) in enumerate(chaps,1):
    subset=[s for s in have if start<=s<=end]
    if not subset: continue
    lines.extend([rf"\setcounter{{chapter}}{{{c-1}}}",rf"\chapter{{{title}}}\label{{ch:{c}}}"])
    for s in subset:
        lines+= [rf"\setcounter{{section}}{{{s-1}}}",rf"\input{{chapters/s{s:02}}}"]
if "appendix" in extra: lines.append(r"\input{appendix}")
if "bibliog1" in extra and "bibliog2" in extra:
    lines.append(r"\makebibliography")
for key,title in [("termindex","原书术语索引"),("symindex","原书符号索引")]:
    if key in extra: lines.extend([rf"\MTFrontChapter{{{title}}}",r"\noindent 页码沿用英文原书印页.\par",rf"\input{{{key}}}"])
lines.extend([r"\printterminology",r"\end{document}"])
(root/"main.tex").write_text("\n".join(lines)+"\n",encoding="utf-8")
print("Included sections",have,"back matter",extra)

