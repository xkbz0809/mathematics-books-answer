"""Build the Chinese edition in a fresh or existing output directory."""
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here/"build"
out.mkdir(parents=True,exist_ok=True)
xe=["xelatex","-no-shell-escape","-interaction=nonstopmode","-halt-on-error","-file-line-error",f"-output-directory={out}","main.tex"]
for cmd in [xe,xe,["biber","--input-directory",str(out),"--output-directory",str(out),"main"],xe,xe]:
    with (out/"build-transcript.txt").open("ab") as log:
        result=subprocess.run(cmd,cwd=here,stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit("Build failed: "+str(cmd[0])+"; see "+str(out/"build-transcript.txt"))
print(out/"main.pdf")

