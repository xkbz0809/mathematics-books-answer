#!/usr/bin/env sh
set -eu
case "${1:-full}" in
  full) exec python "$(dirname "$0")/build.py" ;;
  *) echo 'usage: sh tools/build.sh full' >&2; exit 2 ;;
esac
