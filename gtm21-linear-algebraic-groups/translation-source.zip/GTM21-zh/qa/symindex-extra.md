# 原页复核 symindex

FIX

原印页 245，页码栏 2、7、10、48、52。原图中用作域记号的 \(K,L,E,F\) 为直立无衬线字母。超越次数条目的 \(K\) 为下标，范数条目的整个 \(E/F\) 为下标。

<<<OLD
$\operatorname{tr.\,deg.}_{K}L$ & 超越次数 & 2 \\
$N_{E/F}$ & 范数 & 2 \\
<<<NEW
$\operatorname{tr.\,deg.}_{\mathsf{K}}\mathsf{L}$ & 超越次数 & 2 \\
$N_{\mathsf{E}/\mathsf{F}}$ & 范数 & 2 \\
<<<END

<<<OLD
$\mathrm{GL}(n,K)$ & 一般线性群 & 7, 51 \\
$K[X]$ & $X$ 的仿射代数 & 10 \\
$K(X)$ & $X$ 的函数域 & 10 \\
<<<NEW
$\mathrm{GL}(n,\mathsf{K})$ & 一般线性群 & 7, 51 \\
$\mathsf{K}[X]$ & $X$ 的仿射代数 & 10 \\
$\mathsf{K}(X)$ & $X$ 的函数域 & 10 \\
<<<END

<<<OLD
$\mathrm{PGL}(2,K)$ & $\mathrm{GL}(2,K)/K^{*}$ & 48 \\
<<<NEW
$\mathrm{PGL}(2,\mathsf{K})$ & $\mathrm{GL}(2,\mathsf{K})/\mathsf{K}^{*}$ & 48 \\
<<<END

<<<OLD
$\mathrm{T}(n,K)$ & 上三角群 & 52 \\
$\mathrm{D}(n,K)$ & 对角群 & 52 \\
$\mathrm{U}(n,K)$ & 上三角幺幂群 & 52 \\
$\mathrm{SL}(n,K)$ & 特殊线性群 & 52 \\
$\mathrm{Sp}(n,K)$ & 辛群 & 52 \\
$\mathrm{SO}(n,K)$ & 特殊正交群 & 52 \\
<<<NEW
$\mathrm{T}(n,\mathsf{K})$ & 上三角群 & 52 \\
$\mathrm{D}(n,\mathsf{K})$ & 对角群 & 52 \\
$\mathrm{U}(n,\mathsf{K})$ & 上三角幺幂群 & 52 \\
$\mathrm{SL}(n,\mathsf{K})$ & 特殊线性群 & 52 \\
$\mathrm{Sp}(n,\mathsf{K})$ & 辛群 & 52 \\
$\mathrm{SO}(n,\mathsf{K})$ & 特殊正交群 & 52 \\
<<<END

原印页 246，页码栏 65、66、69、99。一般线性李代数及四个矩阵群的李代数沿用相同的域记号。原图「right convolution by x」及页码栏 99 的两个星号条目均用直立无衬线的 \(x\)，可与同页页码栏 96、99 的斜体 \(x_s,x_u\) 直接比对。对应行一并删去「的 李代数」中的多余空格。

<<<OLD
$\mathscr{L}(G)$ & $G$ 的 李代数 & 65 \\
<<<NEW
$\mathscr{L}(G)$ & $G$ 的李代数 & 65 \\
<<<END

<<<OLD
$\mathfrak{gl}(n,K)$ & 一般线性代数 & 65 \\
<<<NEW
$\mathfrak{gl}(n,\mathsf{K})$ & 一般线性代数 & 65 \\
<<<END

<<<OLD
$*\mathbf{x}$ & 与 $\mathbf{x}$ 的右卷积 & 66 \\
$\mathfrak{t}(n,K)$ & $\mathrm{T}(n,K)$ 的 李代数 & 69 \\
$\mathfrak{d}(n,K)$ & $\mathrm{D}(n,K)$ 的 李代数 & 69 \\
$\mathfrak{n}(n,K)$ & $\mathrm{U}(n,K)$ 的 李代数 & 69 \\
$\mathfrak{sl}(n,K)$ & $\mathrm{SL}(n,K)$ 的 李代数 & 69 \\
<<<NEW
$*\mathsf{x}$ & 与 $\mathsf{x}$ 的右卷积 & 66 \\
$\mathfrak{t}(n,\mathsf{K})$ & $\mathrm{T}(n,\mathsf{K})$ 的李代数 & 69 \\
$\mathfrak{d}(n,\mathsf{K})$ & $\mathrm{D}(n,\mathsf{K})$ 的李代数 & 69 \\
$\mathfrak{n}(n,\mathsf{K})$ & $\mathrm{U}(n,\mathsf{K})$ 的李代数 & 69 \\
$\mathfrak{sl}(n,\mathsf{K})$ & $\mathrm{SL}(n,\mathsf{K})$ 的李代数 & 69 \\
<<<END

<<<OLD
$*\mathbf{x}_{s}$ & $\mathbf{x}$ 的半单部分 & 99 \\
$*\mathbf{x}_{n}$ & $\mathbf{x}$ 的幂零部分 & 99 \\
<<<NEW
$*\mathsf{x}_{s}$ & $\mathsf{x}$ 的半单部分 & 99 \\
$*\mathsf{x}_{n}$ & $\mathsf{x}$ 的幂零部分 & 99 \\
<<<END

原印页 246，页码栏 116。原图「conjugacy class of \(s\) in \(G\)」一行左栏的 \(Cl\) 用斜体。

<<<OLD
$\operatorname{Cl}_{G}(s)$ & $s$ 在 $G$ 中的共轭类 & 116 \\
<<<NEW
$Cl_{G}(s)$ & $s$ 在 $G$ 中的共轭类 & 116 \\
<<<END

原印页 246，页码栏 150。原图「regular 1–psg’s」一行的 \(Y\) 为直立字形，与页码栏 103 的斜体 \(Y(G)\) 有别。下标 \(reg\) 为斜体。

<<<OLD
$Y(T)_{\mathrm{reg}}$ & 正则单参数乘法子群 & 150 \\
<<<NEW
$\mathrm{Y}(T)_{reg}$ & 正则单参数乘法子群 & 150 \\
<<<END

原印页 247，页码栏 220。「\(k\)-roots」和「\(k\)-Weyl group」两行的左栏与释义均用直立无衬线的 \(k\)。上标依次为 \(\Phi\) 和 \(W\)。

<<<OLD
$k^{\Phi}$ & $k$-根 & 220 \\
$k^{W}$ & $k$-Weyl 群 & 220 \\
<<<NEW
$\mathsf{k}^{\Phi}$ & $\mathsf{k}$-根 & 220 \\
$\mathsf{k}^{W}$ & $\mathsf{k}$-Weyl 群 & 220 \\
<<<END

逐页复核范围

- 原印页 245（PDF 第 257 页），从 ACC 到 \(\rho_x\)，共 49 条。核对了各条释义和页码，以及反态射的星号、商群分母的星号、半直积符号方向和左右平移的对应关系。
- 原印页 246（PDF 第 258 页），从 \(\mathscr L(G)\) 到 \(\pi(G)\)，共 53 条。核对了右卷积、伴随不动点、半单与幂零部分的下标、正负上标及各条页码。\(I(T)\) 的跨行释义仍为一条，保留 149、158 两个页码。
- 原印页 247（PDF 第 259 页），从权格与根格到 Cartan 整数，共 5 条。核对了最高权、两个域相关符号的上标及各条页码。
- 三页共 107 条，未见漏项、串项、未译释义或页码遗漏。所附三页均为符号索引，无证明、习题、提示、脚注或作者引文。

仍待人工判定

- 原印页 245，页码栏 16、17。局部环及正则函数两条中的花体 \(O\)，以及局部环条目中的 \(m\)，可用项目实排字形与原图比对，以确定现有 `\mathcal{O}` 和 `\mathfrak{m}` 是否最贴合原印字形。
