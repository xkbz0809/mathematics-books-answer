# 原页复核 s05

FIX

原书印页 37，§5.1 首段。原文 “the tangent (or tangents)” 明确保留了可能有多条切线的情形。译稿漏译了括注。

<<<OLD
那么我们将 $x=(x_1,x_2)$ 处的切线描述为线性多项式
<<<NEW
那么我们将 $x=(x_1,x_2)$ 处的一条或多条切线描述为线性多项式
<<<END

原书印页 38，§5.1 的公式 $(*)$。原图在右端的 $\delta(g)$ 后有句点。

<<<OLD
\delta(fg)=\delta(f)\cdot g(x)+f(x)\cdot\delta(g).
\tag{*}
<<<NEW
\delta(fg)=\delta(f)\cdot g(x)+f(x)\cdot\delta(g).
\tag{*}
<<<END

原书印页 39，§5.1 的证明末尾及 §5.2 第二段。原文分别为 “cf. Proposition 2.4” 和 “Proposition 5.1 … (cf. Proposition 3.1)”。保留命题称谓，将所指小节号改用 `\subref`。

<<<OLD
参见命题 2.4.
<<<NEW
参见命题~\subref{2.4}.
<<<END

<<<OLD
由命题 5.1 可知，光滑簇的乘积是光滑的（参见命题 3.1）.
<<<NEW
由命题~\subref{5.1} 可知，光滑簇的乘积是光滑的（参见命题~\subref{3.1}）.
<<<END

原书印页 40，§5.2 定理的证明。原文为 “the remarks in (2.3) and Proposition 4.7” 及 “upper semicontinuity of dimension” 后的 “(Proposition 4.4)”。这两处命题引文也应使用小节引用宏。

<<<OLD
由 \subref{2.3} 中的评述及命题 4.7 可知
<<<NEW
由 \subref{2.3} 中的评述及命题~\subref{4.7} 可知
<<<END

<<<OLD
（命题 4.4）
<<<NEW
（命题~\subref{4.4}）
<<<END

原书印页 41–42，§5.3 定理 B 的证明。印页 42 的 “contradicting the choice of \(k\)” 用到了印页 41 末尾已经建立的 \(PR_P=(1/g)R_P\)。由此，\(f/g^{k-1}\in R_P\) 确实蕴含 \(P^{k-1}f\subset R_P\)，与 \(k\) 的最小性矛盾。现有译注孤立地比较单个元素与整个理想，容易让读者误以为这里存在证明缺口。保留正文，删去该译注。

<<<OLD
（与 $k$ 的选择矛盾）.\footnote{译注：原文此处由 $f/g^{k-1}\in R_P$ 直接声称与 $k$ 的最小性矛盾，论证有所省略；所选 $k$ 的条件是整个集合 $P^kf$ 包含于 $R_P$，而不是单个元素 $f/g^k$ 属于 $R_P$.} 因此
<<<NEW
（与 $k$ 的选择矛盾）. 因此
<<<END

原书印页 43，§5.5 第二段。原文先限定 “dominant morphisms … of irreducible varieties”，并以函数域扩张定义可分性，随后才说 “all morphisms are therefore separable”。中文宜显明这一上下文限定。该段的 “cf. Theorem 4.6” 也应使用小节引用宏。

<<<OLD
（参见定理 4.6）
<<<NEW
（参见定理~\subref{4.6}）
<<<END

<<<OLD
因此，在特征 $0$ 时，所有态射都是可分的.
<<<NEW
因此，在特征 $0$ 时，所有这类态射都是可分的.
<<<END

原书印页 43，§5.5 第三段。原文 “a finite field extension” 中，有限性修饰扩张，指扩张次数有限。“有限域扩张”容易读成有限域之间的扩张。

<<<OLD
有限域扩张的可分性，可以通过检验某些域元素的极小多项式是否具有重根来判定；对此，导数判别法是适用的.
<<<NEW
有限的域扩张是否可分，可以用导数判别法检验某些域元素的极小多项式是否有重根来判定.
<<<END

原书印页 44，§5.5 的交换图。原图两条水平箭头均向右，两条竖直虚线均有上下两个箭头尖端，译稿方向正确。现有 `tikzcd` 放在 `align*` 内，裸 `&` 会被外层数学对齐环境预先读入。指定 `ampersand replacement` 并替换两个列分隔符。

<<<OLD
\begin{tikzcd}[column sep=large,row sep=large]
\operatorname{Der}(K(X),K(X))
  \arrow[r,"\delta\varphi"]
  \arrow[d,dotted,<->]
&
\operatorname{Der}(\varphi^*K(Y),K(X))
  \arrow[d,dotted,<->]
\\
K(X)\otimes\mathscr T(X)_x
  \arrow[r,"1\otimes d\varphi_x"]
&
K(X)\otimes\mathscr T(Y)_{\varphi(x)}
\end{tikzcd}
<<<NEW
\begin{tikzcd}[ampersand replacement=\&,column sep=large,row sep=large]
\operatorname{Der}(K(X),K(X))
  \arrow[r,"\delta\varphi"]
  \arrow[d,dotted,<->]
\&
\operatorname{Der}(\varphi^*K(Y),K(X))
  \arrow[d,dotted,<->]
\\
K(X)\otimes\mathscr T(X)_x
  \arrow[r,"1\otimes d\varphi_x"]
\&
K(X)\otimes\mathscr T(Y)_{\varphi(x)}
\end{tikzcd}
<<<END

原书印页 44，§5.5 定理。原文 “Suppose that \(x,\varphi(x)\) are simple points” 对指定的 \(x\) 作断言。译稿忠实保留了原定理，译注的反例也成立。译注末句宜明确正确判据的量词，并指出原等价命题中仍成立的方向。

<<<OLD
正确的可分性判据应在适当的非空开子集上表述.
<<<NEW
正确的判据是：$\varphi$ 可分，当且仅当存在 $x\in X$，使 $x$ 和 $\varphi(x)$ 都是单点且 $d\varphi_x$ 满射. 若 $\varphi$ 可分，这些条件在 $X$ 的某个稠密开子集上同时成立.
<<<END

逐页复核范围

- 印页 37：从第 5 节标题起核对节首引言和 §5.1 首段、偏导公式及几何切空间定义。上一节习题与注记已正确排除。
- 印页 38：核对余切空间与几何切空间的对偶关系、核与局部化、内蕴定义和点导子的乘积公式。关于将 \(x\) 平移到原点的译注可保留。
- 印页 39：核对点导子与切空间的同构、仿射和射影空间的例子、乘积命题及证明，以及 §5.2 开头的定义与超曲面例子。
- 印页 40：核对特征 \(0\) 和特征 \(p\) 的论证、可分生成与本原元、纤维维数的上半连续性，以及 §5.3 的引理和证明开头。
- 印页 41：核对 Nakayama 引理的应用、Krull 维数、正则局部环、定理 A 和定理 B，以及定理 B 证明中的理想、指数和局部化。关于素理想链起点的译注可保留。
- 印页 42：核对定理 B 证明的结尾、拉回与微分的方向、链式法则、坐标公式、单位元处行列式的微分及三项计算。关于主开子集和行列式微分取于单位元的译注可保留。
- 印页 43：核对 §5.4 第 (3) 项结尾、可分性的定义与事实 (1)–(7)、Frobenius 的拉回、导子空间维数及限制映射的方向。关于辅助域 \(L\) 的译注可保留。
- 印页 44：核对交换图、可分性定理及译注、四道习题、习题 2 的完整提示和节末 Chevalley 引文。译稿完整到第 5 节注记末尾。
- 印页 45：用于核对第 6 节起始边界。译稿未串入相邻节。

仍待人工判定的问题

- 原图中未发现需要标为 `% 待核` 的符号。交叉引用的实际跳转与交换图的排版尚未在主文件中编译验证。
