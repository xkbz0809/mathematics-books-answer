# 原页复核 appendix

FIX

印页 229，附录引言。原文 “For fuller details consult, e.g.,” 中的 “e.g.” 表明所列文献是举例。译稿漏译了这一限定。

<<<OLD
欲知详情，可参阅 Bourbaki [1，第 VI 章]、Humphreys [6，第 III 章]、Serre [2，第 V 章]、Steinberg [10，附录] 以及 SGAD，第 XXI 讲.
<<<NEW
欲知详情，例如可参阅 Bourbaki [1，第 VI 章]、Humphreys [6，第 III 章]、Serre [2，第 V 章]、Steinberg [10，附录] 以及 SGAD，第 XXI 讲.
<<<END

印页 229，A.4。“the \(c_i\) are integers of like sign” 中的同号条件允许零系数。例如，单根 \(\alpha_j\) 自身的展开在 \(i\ne j\) 时有 \(c_i=0\)。译稿的“都​​是同号的整数”容易被读成每个系数都有严格的正号或负号，宜明确写出非严格条件。

<<<OLD
的系数 \(c_i\) 都是同号的整数
<<<NEW
的系数 \(c_i\) 都是整数，且全非负或全非正
<<<END

印页 232，A.12 证明第一段。原书在 “It follows that” 后写的是两个交集作为集合相等。译稿忠实保留了等号，但这里有一处尚未标注的原书疑误。由 \(\tau=\sigma\sigma_0^{-1}\) 可知，右侧交集是左侧交集在 \(\sigma_0\) 下的像。原文前一句只保证 \(\sigma_0\) 保持 \(\Theta'\) 不变，不能保证它保持这个交集不变。下文比较 \(n(\tau)\) 与 \(n(\sigma)\) 时，两交集的基数相等已足够。保留原式并加译注。

<<<OLD
于是
\begin{align*}
  \Theta'\cap-\sigma^{-1}(\Psi^+)
  &=\Theta'\cap-\tau^{-1}(\Psi^+).
\end{align*}
另一方面，
<<<NEW
于是
\begin{align*}
  \Theta'\cap-\sigma^{-1}(\Psi^+)
  &=\Theta'\cap-\tau^{-1}(\Psi^+).
\end{align*}
\footnote{译注：原书在此写成集合相等. 由 \(\tau^{-1}=\sigma_0\sigma^{-1}\) 及 \(\sigma_0(\Theta')=\Theta'\) 可知，右侧交集是左侧交集在 \(\sigma_0\) 下的像. 因而可得两者基数相等，这已足以作下文的计数比较.}
另一方面，
<<<END

印页 232，A.12 同一段末尾。原图在 “while” 后写的是集合差 \(\gamma\in\Psi_{\gamma_0\gamma}^+-\sigma^{-1}(\Psi^+)\)。译稿换成了与负像集取交。这在此处等价，但应照录原式。

<<<OLD
而 \(\gamma\in\Psi_{\gamma_0\gamma}^+\cap-\sigma^{-1}(\Psi^+)\). 这表明 \(n(\tau)<n(\sigma)\).
<<<NEW
而 \(\gamma\in\Psi_{\gamma_0\gamma}^+-\sigma^{-1}(\Psi^+)\). 这表明 \(n(\tau)<n(\sigma)\).
<<<END

逐页复核范围

- 印页 229。核对附录标题、引言及全部作者引文、A.1–A.4、(R1)–(R4) 和 A.5 的页末起句。反射的方向、Cartan 整数公式中的参数次序和最后的 \(r,s\geq 1\) 均与原图相符。
- 印页 230。核对 A.5 续文、A.6–A.7、九类 Dynkin 图在正文中的位置与图后说明，以及四个秩二矩阵。特别核对了 \(\mathsf B_2\) 与 \(\mathsf G_2\) 的非对角项及长短根说明。
- 印页 231。核对 A.8–A.11、基本群表、A.12 的出处、引理 (a)–(c) 及证明首段。A.10 两处 \(>\) 都与原图相符，现有译注准确。A.11 的对偶映射方向及引理中的乘积次序、下标和指标范围均与原图相符。
- 印页 232。核对 A.12 的归纳步、逆映射的次序、正根集的上标、集合运算及证明结尾。译稿已有的“该交集未必是子根系的基”译注所举 \(\mathsf A_3\) 反例成立。
- 四页的 A.1–A.12 顺序完整，所附原页没有习题、提示或原书脚注。未见串入相邻章节或未译段落。

仍待人工核对的是 `\input{dynkin}` 所引用文件的实际渲染。本次材料只给出输入命令。原图中 \(\mathsf B_\ell\)、\(\mathsf F_4\) 的多重边箭头向右，\(\mathsf C_\ell\)、\(\mathsf G_2\) 的多重边箭头向左。正文没有需要标记 `% 待核` 的无法辨认符号。
