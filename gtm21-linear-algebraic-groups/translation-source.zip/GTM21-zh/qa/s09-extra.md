# 原页复核 s09

FIX

1. 印页 65，§9.1。原文 “since \(e\) is a simple point (7.1)” 用的是代数几何术语 *simple point*，这里指非奇异点。译作“单点”容易被理解为对点数的描述，不能明确表达切空间维数等于 \(\dim G\) 所依据的性质。

<<<OLD
（因为 $e$ 是单点，见 \subref{7.1}）
<<<NEW
（因为 $e$ 是非奇异点，见 \subref{7.1}）
<<<END

2. 印页 70，§9.5。图中乘积的一次项确实印作 \(\delta(\varepsilon_x\mathbf y+\varepsilon_y\mathbf x)\)。译稿忠实抄录了原式，但漏注了第二项的因子次序疑误。按印页 69 所定义的乘法，先对第一因子应用 \(\varepsilon_x+\delta\mathbf x\)，对第二因子应用 \(\varepsilon_y+\delta\mathbf y\)。因此第二个一次项来自 \(\delta\mathbf x\) 与 \(\varepsilon_y\)，应为 \(\mathbf x\varepsilon_y\)。保留原式并加译注。

<<<OLD
乘积 $(\varepsilon_x+\delta\mathbf{x})(\varepsilon_y+\delta\mathbf{y})$ 等于 $\varepsilon_{xy}+\delta(\varepsilon_x\mathbf{y}+\varepsilon_y\mathbf{x})$.
<<<NEW
乘积 $(\varepsilon_x+\delta\mathbf{x})(\varepsilon_y+\delta\mathbf{y})$ 等于 $\varepsilon_{xy}+\delta(\varepsilon_x\mathbf{y}+\varepsilon_y\mathbf{x})$.\footnote{译注：原书第二项印作 $\varepsilon_y\mathbf{x}$. 按上文经 $\mu^*$ 定义的乘法，$\mathbf{x}$ 作用于第一张量因子，$\varepsilon_y$ 作用于第二张量因子，故此项应为 $\mathbf{x}\varepsilon_y$.}
<<<END

逐页复核范围

- 印页 65。核对第 9 节与 §9.1 的标题、李代数和左不变导子的定义、左右平移的方向、四个问题、切空间及微分的函子性、定理的全部假设和结论。章题与节标题之间没有引言。
- 印页 66。核对定理的直观说明、内自同构与伴随表示、右平移共轭中的逆元，以及 §9.2 的右卷积定义、导子性质和左不变性。
- 印页 67。核对 \(\eta\) 与 \(\theta\) 的两个复合、微分保持李括号的证明，包括两项的卷积次序和拉回与平移的等式，以及 §9.3 中加法群、乘法群的例子和跨页段落。
- 印页 68。核对 §9.3 的张量积公式、卷积计算与 \(\mathrm{GL}(n,\mathsf K)\) 的矩阵乘法，以及 §9.4 的闭子群、切空间、引理和证明前半。两个导子的复合一般不再是导子，译稿已有译注说明此处如何理解在 \(e\) 处取值。
- 印页 69。核对引理证明后半、三类三角或对角矩阵群及特殊线性群的例子，以及 §9.5 的作者引文、点与代数同态的对应、函子乘法和对偶数定义。
- 印页 70。核对对偶数定义的续文、切丛、分裂正合序列、三道习题、习题 1 的方括号提示、习题 3 的四个分项及特征假设、节末注记。习题 2 的 \(\mathbf h\) 在图中确实印为单位矩阵，现有译注正确指出其在特征不为 \(2\) 时不属于 \(\mathfrak{sl}(2,\mathsf K)\)。译稿收录至节末注记最后一句，并在第 10 节标题前停止。六页范围内未发现遗漏的图表、原书脚注或未译段落。

仍待人工判定的问题

无。
