# 原页复核 bibliog1

FIX

原书第 233 页，书目前说明第 3 段. 原文是 “a reference to Mathematical Reviews (MR) is added”，指附上该文在《数学评论》中的评介出处.“评论索引”误指索引本身.

<<<OLD
另作一点说明：凡俄文论文尚无译本者，均附列 \textit{Mathematical Reviews}（MR）的评论索引.
<<<NEW
另补充一点. 凡无译本可供查阅的俄文论文，均附上该文在 \textit{Mathematical Reviews}（MR）中的评介出处.
<<<END

原书第 233 页，L. Bai、C. Musili、C. S. Seshadri [1]. 纸面题名中的 \(G/B\) 两个字母均用直立体.

<<<OLD
Cohomology of line bundles on \(G/B\).
<<<NEW
Cohomology of line bundles on \(\mathrm{G}/\mathrm{B}\).
<<<END

原书第 233 页，A. Borel、J. Tits [1]、[3]. 两条均印作 “Inst. Hautes Etudes Sci. Publ. Math.”，其中 “Etudes” 的首字母无重音符号. 同页 A. Borel [2] 的 “Études” 有重音符号，应按各条原样保留.

<<<OLD
Groupes réductifs. \textit{Inst. Hautes Études Sci. Publ. Math.} \textbf{27}
<<<NEW
Groupes réductifs. \textit{Inst. Hautes Etudes Sci. Publ. Math.} \textbf{27}
<<<END

<<<OLD
``Groupes réductifs''. \textit{Inst. Hautes Études Sci. Publ. Math.} \textbf{41}
<<<NEW
``Groupes réductifs''. \textit{Inst. Hautes Etudes Sci. Publ. Math.} \textbf{41}
<<<END

原书第 234 页，M. Demazure [2]. 原图在 “du groupe de Cremona” 后印作 “Ann. Sci. Ecole Norm. Sup.”，首字母 E 无重音符号. 紧接的 [3] 则印作 “École”.

<<<OLD
du groupe de Cremona. \textit{Ann. Sci. École Norm. Sup.} (4) \textbf{3}
<<<NEW
du groupe de Cremona. \textit{Ann. Sci. Ecole Norm. Sup.} (4) \textbf{3}
<<<END

原书第 234 页，J. Dieudonné [12]. “réduction mod. p” 中的 p 为直立体. 同页题名中的特征条件 \(p>0\) 用斜体 \(p\)，严格大于号也已照录.

<<<OLD
Remarques sur la réduction mod. \(p\) des groupes linéaires algébriques.
<<<NEW
Remarques sur la réduction mod. \(\mathrm{p}\) des groupes linéaires algébriques.
<<<END

原书第 235 页，G. Harder [1]、[2]. 两条题名的开头分别印作 “Uber einen Satz” 和 “Uber die Galoiskohomologie”，首字母 U 上均无变音符号. 同组 [3] 的小写 “über” 有变音符号. 保留图中拼写，在 [2] 题名后合注.

<<<OLD
[1] Über einen Satz von E. Cartan.
<<<NEW
[1] Uber einen Satz von E. Cartan.
<<<END

<<<OLD
[2] Über die Galoiskohomologie halbeinfacher Matrizengruppen. I.
<<<NEW
[2] Uber die Galoiskohomologie halbeinfacher Matrizengruppen. I.\footnote{译注：原书本条及 [1] 的题名开头均印作 ``Uber''，德语通常拼作 ``Über''.}
<<<END

原书第 236 页，M. Lazard [1]、[2]. [1] 确实印作 “Sur le nilpotence”，应保留 “le”. 现有译注以 `%` 起行，编译后读者不可见. [2] 的期刊名印作 “Inst. Hautes Etudes Sci. Publ. Math.”，“Etudes” 无重音符号.

<<<OLD
Sur le nilpotence de certains groupes algébriques. \textit{C. R. Acad. Sci. Paris} \textbf{241}, 1687--1689 (1955). [2] Groupes analytiques \(p\)-adiques. \textit{Inst. Hautes Études Sci. Publ. Math.} \textbf{26}, 1--219 (1965).
% 译注：原书此处作 ``le nilpotence''；法语名词 nilpotence 为阴性，冠词疑应为 la，正文仍保留原书写法.
<<<NEW
Sur le nilpotence de certains groupes algébriques.\footnote{译注：原书印作 ``le nilpotence''. 法语名词 \textit{nilpotence} 为阴性，冠词疑应为 \textit{la}.} \textit{C. R. Acad. Sci. Paris} \textbf{241}, 1687--1689 (1955). [2] Groupes analytiques \(p\)-adiques. \textit{Inst. Hautes Etudes Sci. Publ. Math.} \textbf{26}, 1--219 (1965).
<<<END

原书第 236 页，R. Marlin [1]. 题名内的六个群名均排为直立体，括号内的 n 也是直立体. 末两项的 2 和 4 均为下标.

<<<OLD
\(\mathrm{SU}(n)\), \(\mathrm{Sp}(n)\), \(\mathrm{SO}(n)\), \(\mathrm{Spin}(n)\), \(G_2\), \(F_4\).
<<<NEW
\(\mathrm{SU(n)}\), \(\mathrm{Sp(n)}\), \(\mathrm{SO(n)}\), \(\mathrm{Spin(n)}\), \(\mathrm{G}_2\), \(\mathrm{F}_4\).
<<<END

逐页复核范围

- 第 233 页（PDF 第 246 页）核完三段说明及 E. Abe、T. Kanno 至 A. Borel、J. Tits 的全部条目，包括 AGDS 对照项.
- 第 234 页（PDF 第 247 页）核完 N. Bourbaki 至 J. Dieudonné、J. B. Carrell 的全部条目，包括 Dieudonné [1] 至 [13]、题名中的严格不等式及 [2] 的勘误附记.
- 第 235 页（PDF 第 248 页）核完 G. B. Elkington 至 B. Iversen 的全部条目，包括 Hijikata [1] 中的下标与 Hochschild [1] 的增补附记.
- 第 236 页（PDF 第 249 页）核完 N. Iwahori 至 M. Miyanishi 的全部条目. Mars [3] 的 \(2\) 为左上标，\(n\) 为下标，译稿正确. 末页已录至末条的卷号、页码和年份.

四页均属书目，未见整条遗漏、跨页串入，也无定理、证明、习题、图表或原书脚注需要补录.

仍待人工判定

- 第 233 页 H. Behr [3] 的整数环字母 \(Z\)，建议在高分辨率原图上确认是粗体还是双线体. 同页 A. Borel、J. Tits [2] 的题名首字母 E 是否带尖音符，也需放大确认.
- 第 235–236 页若干含 “p-adic”“p-adique” 或 “p-adisch” 的题名，需放大核对正体段落中 p 的字形. 这些位置暂保留现有 TeX.
- 第 235 页原书确实印作 “S. J. Haris”，译稿已照录. 如需判定原书作者拼写是否有误，须查该论文的刊载首页.
