# 原页复核 termindex

FIX

印页 241、242、244 的域符号 k 均为直立无衬线体。印页 241 的 “Acts k-morphically” 和 “Defined over k”、印页 242 从 “k-anisotropic” 到 “k-Weyl group” 的十一项，以及印页 244 的 “Zariski k-topology” 都使用同一字形。英文栏和中文栏统一用 \(\mathsf{k}\)。

<<<OLD
Acts \(k\)-morphically & 以 \(k\)-态射方式作用 & 218 \\
<<<NEW
Acts \(\mathsf{k}\)-morphically & 以 \(\mathsf{k}\)-态射方式作用 & 218 \\
<<<END

<<<OLD
Defined over \(k\) & 在 \(k\) 上定义的 & 217, 218 \\
<<<NEW
Defined over \(\mathsf{k}\) & 在 \(\mathsf{k}\) 上定义的 & 217, 218 \\
<<<END

<<<OLD
\(k\)-anisotropic & \(k\)-各向异性的 & 219, 220 \\
\(k\)-closed & \(k\)-闭的 & 217 \\
\(k\)-group & \(k\)-群 & 218 \\
\(k\)-morphism & \(k\)-态射 & 218 \\
\(k\)-quasisplit & \(k\)-拟分裂的 & 223 \\
\(k\)-rank & \(k\)-秩 & 220 \\
\(k\)-rational points & \(k\)-有理点 & 218 \\
\(k\)-roots & \(k\)-根 & 220 \\
\(k\)-split & \(k\)-分裂的 & 219, 220 \\
\(k\)-torus & \(k\)-环面 & 219 \\
\(k\)-Weyl group & \(k\)-Weyl 群 & 220 \\
<<<NEW
\(\mathsf{k}\)-anisotropic & \(\mathsf{k}\)-各向异性的 & 219, 220 \\
\(\mathsf{k}\)-closed & \(\mathsf{k}\)-闭的 & 217 \\
\(\mathsf{k}\)-group & \(\mathsf{k}\)-群 & 218 \\
\(\mathsf{k}\)-morphism & \(\mathsf{k}\)-态射 & 218 \\
\(\mathsf{k}\)-quasisplit & \(\mathsf{k}\)-拟分裂的 & 223 \\
\(\mathsf{k}\)-rank & \(\mathsf{k}\)-秩 & 220 \\
\(\mathsf{k}\)-rational points & \(\mathsf{k}\)-有理点 & 218 \\
\(\mathsf{k}\)-roots & \(\mathsf{k}\)-根 & 220 \\
\(\mathsf{k}\)-split & \(\mathsf{k}\)-分裂的 & 219, 220 \\
\(\mathsf{k}\)-torus & \(\mathsf{k}\)-环面 & 219 \\
\(\mathsf{k}\)-Weyl group & \(\mathsf{k}\)-Weyl 群 & 220 \\
<<<END

<<<OLD
Zariski \(k\)-topology & Zariski \(k\)-拓扑 & 217 \\
<<<NEW
Zariski \(\mathsf{k}\)-topology & Zariski \(\mathsf{k}\)-拓扑 & 217 \\
<<<END

印页 241 的 “Algebraic Lie algebra, 87” 和 “Commutative Lie algebra, 89” 两项中文释义多出词内空格。

<<<OLD
Algebraic Lie algebra & 代数 李代数 & 87 \\
<<<NEW
Algebraic Lie algebra & 代数李代数 & 87 \\
<<<END

<<<OLD
Commutative Lie algebra & 交换 李代数 & 89 \\
<<<NEW
Commutative Lie algebra & 交换李代数 & 89 \\
<<<END

印页 242 的 “Lie p-algebra, 70” 中 \(p\) 为斜体，译稿已保留。中文释义中的 Lie 统一译作“李”，与同栏 “Lie algebra, 65” 的译法一致。

<<<OLD
Lie \(p\)-algebra & Lie \(p\)-代数 & 70 \\
<<<NEW
Lie \(p\)-algebra & 李 \(p\)-代数 & 70 \\
<<<END

印页 243 的 “Restricted Lie algebra, 70”、“Semisimple Lie algebra, 89” 和 “Simple Lie algebra, 91” 三项中文释义多出词内空格。

<<<OLD
Restricted Lie algebra & 限制 李代数 & 70 \\
<<<NEW
Restricted Lie algebra & 限制李代数 & 70 \\
<<<END

<<<OLD
Semisimple Lie algebra & 半单 李代数 & 89 \\
<<<NEW
Semisimple Lie algebra & 半单李代数 & 89 \\
<<<END

<<<OLD
Simple Lie algebra & 单 李代数 & 91 \\
<<<NEW
Simple Lie algebra & 单李代数 & 91 \\
<<<END

印页 244 原文为 “Universal type, 189”。这里的 universal 指代数群的万有型，“泛型”易误指 generic type。

<<<OLD
Universal type & 泛型 & 189 \\
<<<NEW
Universal type & 万有型 & 189 \\
<<<END

逐页复核范围

- 印页 241（PDF 第 253 页）核对左栏 Abelian variety 至 Codimension、右栏 Commutative Lie algebra 至 Flag。“Descending central series” 的页码为 111，译稿正确。
- 印页 242（PDF 第 254 页）核对左栏 Flag variety 至 Isotropy group、右栏 Jacobi identity 至 Nonsingular variety。“Homogeneous coordinates” 的页码为 11，“Nilpotent group” 的页码为 111，译稿均正确。
- 印页 243（PDF 第 255 页）核对左栏 Norm 至 Right translation、右栏 Rigidity 至 Unipotent part。“One parameter multiplicative subgroup” 下方折行的 103 已正确并入该条。
- 印页 244（PDF 第 256 页）核对左栏 Unipotent radical 至 Weight、右栏 Weight space 至 Zariski topology。U 组和 W 组的续接顺序均正确。

四页均为术语索引。条目次序与原印本页码逐项相符，无漏项或串项。所附页无数学断言、证明、习题、图表或脚注。仍待人工判定的问题无。
