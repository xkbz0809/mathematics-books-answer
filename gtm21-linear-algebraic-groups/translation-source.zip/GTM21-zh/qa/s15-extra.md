# 原页复核 s15

FIX

1. 印页 95，§15.1 乘法分解。原文 “we can write \(x_u=1+x_s^{-1}x_n\)” 明确给出 \(x_u\) 的表达式。译稿的“可以写成”承接上句时，容易被读成把 \(x\) 写成右式。

<<<OLD
因此，可以写成 $x_u=1+x_s^{-1}x_n$，从而得到一个（乘法）Jordan 分解 $x=x_sx_u$.
<<<NEW
因此，可令 $x_u=1+x_s^{-1}x_n$，从而得到一个（乘法）Jordan 分解 $x=x_sx_u$.
<<<END

2. 印页 95、96，引理 A、B。原图在两条引理各自的 (d) 末尾都印有空心方框，译稿遗漏了这两个结束标记。

<<<OLD
\item 若 $xy=yx$（$y\in\operatorname{End}V$），则 $(x+y)_s=x_s+y_s$ 且 $(x+y)_n=x_n+y_n$.
<<<NEW
\item 若 $xy=yx$（$y\in\operatorname{End}V$），则 $(x+y)_s=x_s+y_s$ 且 $(x+y)_n=x_n+y_n$.\quad\(\square\)
<<<END

<<<OLD
\item 若 $xy=yx$（$y\in\mathrm{GL}(V)$），则 $(xy)_s=x_sy_s$，$(xy)_u=x_uy_u$.
<<<NEW
\item 若 $xy=yx$（$y\in\mathrm{GL}(V)$），则 $(xy)_s=x_sy_s$，$(xy)_u=x_uy_u$.\quad\(\square\)
<<<END

3. 印页 98，§15.3 交换图。原图是独立的两行两列交换图。两条横箭头均向右，两条竖箭头均从 \(K[G]\) 指向 \(K[H]\)，译稿方向正确。外层 `align*` 会预读内部的 `&`，使 `tikzcd` 无法按通常方式识别列分隔符。将图放在独立的陈列数学环境中。

<<<OLD
\begin{align*}
\begin{tikzcd}
K[G] \arrow[r,"\rho_x"] \arrow[d] & K[G] \arrow[d] \\
K[H] \arrow[r,"\rho_x"'] & K[H]
\end{tikzcd}
\end{align*}
<<<NEW
\[
\begin{tikzcd}
K[G] \arrow[r,"\rho_x"] \arrow[d] & K[G] \arrow[d] \\
K[H] \arrow[r,"\rho_x"'] & K[H]
\end{tikzcd}
\]
<<<END

4. 印页 99，§15.4 标题。原文 “Commuting Sets of Endomorphisms” 中的 “commuting” 指集合内的自同态两两交换。印页 100 的命题用 “a commuting set of matrices” 重申了这一条件。“自同态的交换集合”未清楚表达交换关系的对象。

<<<OLD
\subsection{自同态的交换集合}\label{sub:15.4}
<<<NEW
\subsection{由两两交换的自同态组成的集合}\label{sub:15.4}
<<<END

5. 印页 100，§15.5 证明首段。原文在 \(G\subset\mathrm T(n,K)\) 后接 “and then that”，继而写 “This forces”。这里先借同时三角化选定嵌入，再在该嵌入下得到 \(G_s\subset\mathrm D(n,K)\)。“进而假设”把后一个结论写成了另一项假设。

<<<OLD
由命题~\subref{15.4}，不失一般性，可以假设 $G\subset\mathrm T(n,K)$，进而假设 $G_s\subset\mathrm D(n,K)$.
<<<NEW
由命题~\subref{15.4}，不失一般性，可以假设 $G\subset\mathrm T(n,K)$，于是 $G_s\subset\mathrm D(n,K)$.
<<<END

6. 印页 101，习题 2。原图在 \(\operatorname{Aut}\mathfrak A\) 和 \(\operatorname{Der}\mathfrak A\) 两种情形都用普通数学斜体 \(x\)，相应分量沿用同一字形。译稿将导子的 \(x\) 改成了正文中区分李代数元素所用的无衬线字形。

<<<OLD
\item 设 $\mathfrak A$ 为有限维 $K$ 代数. 若 $x\in\operatorname{Aut}\mathfrak A$（分别为 $\mathsf{x}\in\operatorname{Der}\mathfrak A$），则 $x_s,x_u\in\operatorname{Aut}\mathfrak A$（分别为 $\mathsf{x}_s,\mathsf{x}_n\in\operatorname{Der}\mathfrak A$）.
<<<NEW
\item 设 $\mathfrak A$ 为有限维 $K$ 代数. 若 $x\in\operatorname{Aut}\mathfrak A$（分别为 $x\in\operatorname{Der}\mathfrak A$），则 $x_s,x_u\in\operatorname{Aut}\mathfrak A$（分别为 $x_s,x_n\in\operatorname{Der}\mathfrak A$）.
<<<END

逐页复核范围

- 印页 95。节首导言、有限维假设、引理 A 的四项及乘法分解的起始段。导言在原图中位于第 15 节标题之后，译稿顺序正确。
- 印页 96。乘法分解的续文、引理 B 的四项、无限维情形、正特征下的 \(p^t\) 判据、零特征下的指数与对数级数、引理 C。原印对数级数确实缺少 \(1/i\)，现有译注准确。
- 印页 97。引理 C 的证明、§15.2 的命题及证明前半。核对了 \(T,T'\) 的撇号、行列式中的乘积顺序 \(yx\) 和 \(d*\mathsf{x}=\operatorname{Tr}(\mathsf{x})d\)。证明中的对数级数同样缺少 \(1/i\)，已由印页 96 对应处的译注说明。
- 印页 98。§15.2 证明余下各段及 §15.3 开头。核对了 \(r_x(y)=yx\)、转置、张量因子的顺序、幂指数、交换图的四条箭头，以及右平移和右卷积的限制方向。
- 印页 99。§15.3 定理三项及其证明、闭性论述、§15.4 的定义。原印定理 (a) 确实把 \(\rho_u\) 写成幂零，现有译注与右平移的可逆性及证明中的 \((\rho_x)_u=\rho_u\) 一致。
- 印页 100。§15.4 命题及归纳证明、§15.5 定理及证明。核对了共轭、核与特征空间、稳定旗、逆映射中的 \(x_s^{-1}x\) 及李代数直和。
- 印页 101。习题 1–11、习题 5–11 共用的零特征条件，以及节末注记和全部作者引文。习题 10 的原印确实未声明 \(x\in U\)，现有译注准确。译稿完整到最后一条引文 Borel [1]，并在第 16 节标题之前停止。

仍待人工判定的问题：无。
