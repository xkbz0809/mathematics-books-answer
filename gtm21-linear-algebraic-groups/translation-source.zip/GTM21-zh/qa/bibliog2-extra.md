# 原页复核 bibliog2

FIX

原书印页 237，Ono [9]。图中题名末尾接排为 “groups J. Math. Kyoto Univ.”，在 “groups” 后没有句点，照录原书标点.

<<<OLD
[9] A remark on Gaussian sums and algebraic groups. \textit{J. Math. Kyoto Univ.}
<<<NEW
[9] A remark on Gaussian sums and algebraic groups \textit{J. Math. Kyoto Univ.}
<<<END

原书印页 237，Platonov [2]。图中 “Transl. Ser. 2, Vol. 69” 的丛刊号 2 用正体粗排，卷号 69 也用粗体.

<<<OLD
\textit{Amer. Math. Soc. Transl. Ser. 2}, Vol. \textbf{69}
<<<NEW
\textit{Amer. Math. Soc. Transl. Ser.} \textbf{2}, Vol. \textbf{69}
<<<END

原书印页 237，Platonov [6]。图中 “[Russian] MR 44 #4009.” 的 44 用普通正体.

<<<OLD
[Russian] MR \textbf{44} \#4009.
<<<NEW
[Russian] MR 44 \#4009.
<<<END

原书印页 238，Serre [4]。该条刊名在图中印作 “Inst. Hautes Etudes Sci. Publ. Math.”，其中 “Etudes” 的 E 没有重音符号.

<<<OLD
\textit{Inst. Hautes Études Sci. Publ. Math.} \textbf{34}, 37--52 (1968).
<<<NEW
\textit{Inst. Hautes Etudes Sci. Publ. Math.} \textbf{34}, 37--52 (1968).
<<<END

原书印页 239，Tits [8]。图中确实印作 “Groupes de Coxeter étendues.”；题名中的 “étendues” 与阳性复数名词 “Groupes” 的性不一致. 保留原拼写并加简短译注.

<<<OLD
[8] Normalisateurs de tores. I. Groupes de Coxeter étendues. \textit{J. Algebra} \textbf{4}, 96--116 (1966).
<<<NEW
[8] Normalisateurs de tores. I. Groupes de Coxeter étendues. \textit{J. Algebra} \textbf{4}, 96--116 (1966).\footnote{译注：原书印作 étendues；若该词修饰阳性复数名词 Groupes，则应作 étendus.}
<<<END

原书印页 239，Veĭsfeĭler 与 Kac 合著 [1]。图中此条作者起首印作 “B. Ju Veĭsfeĭler”，上一条独著才印作 “B. Ju. Veĭsfeĭler”.

<<<OLD
B. Ju. Veĭsfeĭler, V. G. Kac, [1]
<<<NEW
B. Ju Veĭsfeĭler, V. G. Kac, [1]
<<<END

原书印页 239，Verma [1]。图中出版项印作 “Budapest: Akad. Kiado 1974.”，“Kiado” 的末字母没有重音符号.

<<<OLD
Budapest: Akad. Kiadó 1974.
<<<NEW
Budapest: Akad. Kiado 1974.
<<<END

原书印页 239，Voskresenskiĭ [3]。图中 “MR 42 #5999.” 的 42 用普通正体.

<<<OLD
MR \textbf{42} \#5999.
<<<NEW
MR 42 \#5999.
<<<END

原书印页 239，Zalesskiĭ [1]。图中刊名缩写 “Fiz.—Mat. Navuk” 使用长破折号，末尾 “MR 38 #5944.” 的 38 用普通正体.

<<<OLD
\textit{Vesci Akad. Navuk BSSR Ser. Fiz.--Mat. Navuk} 1968, no. 2, 129--131. [Russian]. MR \textbf{38} \#5944.
<<<NEW
\textit{Vesci Akad. Navuk BSSR Ser. Fiz.---Mat. Navuk} 1968, no. 2, 129--131. [Russian]. MR 38 \#5944.
<<<END

逐页复核范围

- 印页 237（PDF 250）从 Moore [1] 至 Rosenlicht [2]，核对作者、编号、题名、出版项及译刊附注，并核对 Nakamura [1] 的严格不等式 \(p>0\).
- 印页 238（PDF 251）从跨页续接的 Rosenlicht [3] 至 Sullivan [2]，核对全部条目及 SGAD 的指代，确认 Rosenlicht [3]–[6] 接在同一作者段内，并核对 \(E_6\)、\(E_7\)、\(\mathrm{SL}_2\)、\(\mathrm{GL}(2)\) 和 \(G_2\).
- 印页 239（PDF 252）从 Sweedler [1] 至 Zalesskiĭ [1]，核对全部条目、页末附注及 \(F_4\) 的下标. 三页均为书目，未见条目漏录或串入，也没有证明、习题、图表或脚注.

仍待人工判定的问题

- Tits [8] 的正式出版题名是否确用 “étendus”，须查该论文刊本. 所附书页足以确认 Humphreys 书目印作 “étendues”，替换片段已保留该拼写.
