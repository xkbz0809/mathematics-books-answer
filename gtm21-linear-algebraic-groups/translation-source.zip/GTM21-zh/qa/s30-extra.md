# 原页复核 s30

FIX

印页 184，§30.2。原图从 “For this purpose” 写到 \(B'=B^-\cap P_I\) 和 \(L=B'W_IB'\)，随后直接进入印页 185 的第三种构造。译稿所加脚注复述了原式并另作维数计算，未指出原式有何疑误。删去脚注，保留原句。

<<<OLD
于是 $L=B'W_IB'$.\footnote{译注：原书此处作 $B'=B^-\cap P_I$. 若 $I\ne\Delta$，按 \subref{30.1}(b)，其根为 $\Psi\cap\Phi^-$，而 $\dim B'=\dim T+|\Psi\cap\Phi^-|$，恰为 $L$ 的 Borel 子群应有的维数.}
<<<NEW
于是 $L=B'W_IB'$.
<<<END

印页 184，§30.2。原图写 “Since \([\mathfrak{g}_\alpha,\mathfrak{g}_\beta]\subset\mathfrak{g}_{\alpha+\beta}\)”，未单列 \(\beta=-\alpha\) 的情形。此时右端应理解为零权空间 \(\mathfrak t\)。保留原公式并说明这一读法，同时删去“李代数”前的多余空格。

<<<OLD
$P_I$ 的 李代数分解为直和 $\mathfrak{l}+\mathfrak{v}$，其中 $\mathfrak{l}=\mathfrak{t}\oplus\bigoplus_{\alpha\in\Psi}\mathfrak{g}_\alpha$. 由于 $[\mathfrak{g}_\alpha,\mathfrak{g}_\beta]\subset\mathfrak{g}_{\alpha+\beta}$，$\mathfrak{l}$ 还是一个子代数，而 $\mathfrak{v}$ 是一个理想（因为 $V\triangleleft P_I$）.
<<<NEW
$P_I$ 的李代数分解为直和 $\mathfrak{l}+\mathfrak{v}$，其中 $\mathfrak{l}=\mathfrak{t}\oplus\bigoplus_{\alpha\in\Psi}\mathfrak{g}_\alpha$. 由于 $[\mathfrak{g}_\alpha,\mathfrak{g}_\beta]\subset\mathfrak{g}_{\alpha+\beta}$，\footnote{译注：原书未单列 $\beta=-\alpha$ 的情形. 此时括号的权为零，右端的 $\mathfrak{g}_0$ 指零权空间 $\mathfrak{t}$.} $\mathfrak{l}$ 还是一个子代数，而 $\mathfrak{v}$ 是一个理想（因为 $V\triangleleft P_I$）.
<<<END

印页 185，§30.2。原图括注 “since the Lie algebra of this subgroup is \(\mathscr L(P_I)\)” 的含义已译全。删去“李代数”前的多余空格。后文原图确实先写 “If \(L\) were another Levi factor”，再写 \(L'=C_G(Z')\)，译稿现有译注应保留。

<<<OLD
（因为这个子群的 李代数是 $\mathscr{L}(P_I)$）
<<<NEW
（因为这个子群的李代数是 $\mathscr{L}(P_I)$）
<<<END

印页 186，§30.3 命题证明。原图先说 \(V\) 位于 \(N\cap B\cap nBn^{-1}\) 的 “unipotent part” 中，随即写 “This forces equality to hold throughout”。前一行的包含链要推出等号，还需要 \(V\subset R_u(N\cap B\cap nBn^{-1})\)。命题允许 \(V\) 不连通，原页未交代这一包含。保留原证，明确标出省略的一步。

<<<OLD
因此，上述各处包含关系均为等号，特别地，$V=R_u(N)$ 是连通的.
<<<NEW
因此，上述各处包含关系均为等号，\footnote{译注：要由前面的包含链推出等号，还需说明 $V\subset R_u(N\cap B\cap nBn^{-1})$. 命题允许 $V$ 不连通，原页未说明此处的幺幂部分为何等于该群的连通幺幂根基.} 特别地，$V=R_u(N)$ 是连通的.
<<<END

逐页复核范围

- 印页 183 核对第 30 节引言和 §30.1 首段。页首第 29 节习题与注记均已正确排除。
- 印页 184 核对 §30.1 余文及定理两款，以及 §30.2 开头至 Levi 因子的前两种构造。根的正负、整数与实数线性组合、商群和根对均与原图相符。
- 印页 185 核对 §30.2 余文及定理，以及 §30.3 的递推、引理和证明。共轭方向 \(xZ'x^{-1}=Z\) 与 \(xL'x^{-1}=L\)、各递推下标及作用对象均与原图相符。
- 印页 186 核对 §30.3 命题、证明和推论 A、B。共轭式中的逆元、由 \(U_{-\alpha}\) 转回 \(U_\alpha\) 的论证，以及标准抛物子群所对应子集中的 \(\not\subset\) 均与原图相符。
- 印页 187 核对 §30.4 定理两款、完整证明、特征 \(0\) 与特征 \(p\) 的说明、全部四道习题及第 3 题的括号示例，以及节末注记和三处书目引文。译稿覆盖至 Platonov [2]。
- 印页 188 仅用于确认第 XI 章和第 31 节的边界。译稿未串入该页内容。第 30 节范围内原图无图表或原书脚注。

仍待人工判定

印页 186 关于 “unipotent part” 的一步，宜查本书前文对非连通可解群的术语约定，确认是否已有结果能补足该包含。所附页面未见其他需要标记 `% 待核` 的符号。
