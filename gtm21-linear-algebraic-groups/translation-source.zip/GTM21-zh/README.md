# Humphreys《线性代数群》中文译本

本工程以 James E. Humphreys 的 *Linear Algebraic Groups*（Springer-Verlag，1975，Graduate Texts in Mathematics 21）为底本。所用扫描本的版权页注明，它是 1975 年精装第一版的平装重印本。

## 编译

在本目录执行 `python tools/build.py`，或在有 POSIX shell 的环境执行 `sh tools/build.sh full`。需要 Python 3、含中文支持的 TeX Live、XeLaTeX 和 Biber。输出位于 `build/main.pdf`。运行 `python tools/build.py 另一个目录` 可在独立目录中重新构建。主文件为 `main.tex`，中文字体使用 TeX Live 自带的 Fandol，西文字体使用 Computer Modern Unicode。

## 内容与定位

`chapters/s00.tex` 至 `chapters/s35.tex` 分别对应原书的 36 节。原书第 0 节开头的 15 条预备知识沿用段落编号。全书的章、节、小节和附录 A.1–A.12 均保留原编号。公式、矩阵和交换图可在 TeX 中编辑。各处注明“译注”的文字为译校者所加。

`bibliog1.tex` 和 `bibliog2.tex` 保留原书按作者分别编号的书目。原书的术语索引和符号索引沿用英文版印刷页码。卷末附加的术语索引使用中文译本页码。工作记录位于 `qa` 目录。

符号索引第一个局部环条目中的花体小写 m 使用 TeX Live 提供的 XITS Math 字体。书目直接排在以上两个 `.tex` 文件中，以保留如 Borel [4] 的作者内编号。构建仍会运行模板的 Biber 步骤。

`qa` 中的逐页记录列出查过的定义、证明、习题与原书疑点。以 `<<<OLD`、`<<<NEW` 记录的文件保留校对时的修改建议。遇到与定稿不同的记录时，可查 `applied.json`、`原页判读.md` 和 `书目字形.md` 了解处置，数学内容以定稿正文及标明的译注为准。
