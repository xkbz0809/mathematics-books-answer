# 结合代数表示论基础 · 习题解答源码

主文件 main.tex。使用 TeX Live、XeLaTeX、Biber、Fandol 和 CM Unicode 字体，以及 Python 3。在源码目录执行 python -B -X utf8 tools/build.py main --out-dir build/release。正文跨册链接使用原发布的本地文件名，编译无需原书及配套译本 PDF。
