"""Exact rational representation calculations; paths retain parallel arrow labels."""
from fractions import Fraction as F
from pathlib import Path
from collections import defaultdict
import json
ROOT=Path(__file__).resolve().parents[1]
def z(r,c):return [[F(0)]*c for _ in range(r)]
def tr(A):return list(map(list,zip(*A))) if A else []
def rr(A,n):
 A=[list(map(F,r))for r in A];p=[];i=0
 for j in range(n):
  k=next((k for k in range(i,len(A))if A[k][j]),None)
  if k is None:continue
  A[i],A[k]=A[k],A[i];q=A[i][j];A[i]=[x/q for x in A[i]]
  for k in range(len(A)):
   if k!=i:
    q=A[k][j];A[k]=[x-q*y for x,y in zip(A[k],A[i])]
  p.append(j);i+=1
  if i==len(A):break
 return A,p
def null(A,n):
 R,p=rr(A,n);o=[]
 for j in range(n):
  if j not in p:
   v=[F(0)]*n;v[j]=1
   for i,k in enumerate(p):v[k]=-R[i][j]
   o.append(v)
 return o
def mv(A,v):return [sum(a*b for a,b in zip(row,v))for row in A]
def coord(B,v):
 n=len(B[0])if B else 0;R,p=rr([row+[x]for row,x in zip(B,v)],n)
 assert not any(not any(r[:n])and r[n]for r in R)
 ans=[F(0)]*n
 for i,j in enumerate(p):ans[j]=R[i][n]
 return ans
def hom(M,N,arr):
 dm,am=M;dn,an=N;off=[];q=0
 for a,b in zip(dm,dn):off.append(q);q+=a*b
 eq=[]
 for t,(a,b)in enumerate(arr):
  for i in range(dn[b]):
   for j in range(dm[a]):
    row=[F(0)]*q
    for k in range(dn[a]):row[off[a]+k*dm[a]+j]+=an[t][i][k]
    for k in range(dm[b]):row[off[b]+i*dm[b]+k]-=am[t][k][j]
    eq.append(row)
 return null(eq,q)
class Alg:
 def __init__(self,n,arr,rel):
  self.n=n;self.arr=arr;self.rel=rel;self.paths=[]
  for i in range(n):
   def walk(p,v):
    self.paths.append((i,v,p))
    for t,(a,b)in enumerate(arr):
     if a==v:walk(p+(t,),b)
   walk((),i)
  by=defaultdict(list)
  for a,b,p in self.paths:by[a,b].append(p)
  relations=defaultdict(list)
  for r in rel:
   a=arr[r[0][1][0]][0];b=arr[r[0][1][-1]][1]
   for u,v,p in self.paths:
    if v!=a:continue
    for w,y,q in self.paths:
     if w==b:relations[u,y].append({p+tuple(s)+q:F(c)for c,s in r})
  self.basis={};self.red={}
  for ij,ps in by.items():
   R,p=rr([[r.get(s,0)for s in ps]for r in relations[ij]],len(ps));free=[j for j in range(len(ps))if j not in p]
   self.basis[ij]=[ps[j]for j in free]
   for j,s in enumerate(ps):
    v=[F(0)]*len(free)
    if j in free:v[free.index(j)]=1
    else:
     for k,l in enumerate(free):v[k]=-R[p.index(j)][l]
    self.red[ij[0],s]=v
 def projective(self,i):
  d=[len(self.basis.get((i,v),[]))for v in range(self.n)];ar={}
  for t,(a,b)in enumerate(self.arr):
   cs=[self.red[i,p+(t,)]for p in self.basis.get((i,a),[])];ar[t]=tr(cs)if cs else z(d[b],0)
  return d,ar
 def injective(self,i):
  d=[len(self.basis.get((v,i),[]))for v in range(self.n)];ar={}
  for t,(a,b)in enumerate(self.arr):ar[t]=[self.red[a,(t,)+p]for p in self.basis.get((b,i),[])]
  return d,ar
 def eval(self,rep,p,v):
  for t in p:v=mv(rep[1][t],v)
  return v
 def subrep(self,rep,B):
  ds=[len(m[0])if m else 0 for m in B];ar={}
  for t,(a,b)in enumerate(self.arr):
   cols=[coord(B[b],mv(rep[1][t],v))for v in tr(B[a])];ar[t]=tr(cols)if cols else z(ds[b],0)
  return ds,ar
 def cover(self,rep):
  d,ar=rep;gens=[]
  for v in range(self.n):
   cols=[c for t,(a,b)in enumerate(self.arr)if b==v for c in tr(ar[t])];rank=len(rr(tr(cols),len(cols))[1])if cols else 0
   for j in range(d[v]):
    e=[F(k==j)for k in range(d[v])];new=cols+[e];r=len(rr(tr(new),len(new))[1])
    if r>rank:gens.append((v,e));cols=new;rank=r
  slots=[[(k,p)for k,(i,g)in enumerate(gens)for p in self.basis.get((i,v),[])]for v in range(self.n)];pd=list(map(len,slots));pa={};f=[]
  for v in range(self.n):
   cs=[self.eval(rep,p,gens[k][1])for k,p in slots[v]];f.append(tr(cs)if cs else z(d[v],0))
  for t,(a,b)in enumerate(self.arr):
   A=z(pd[b],pd[a]);ix={s:k for k,s in enumerate(slots[b])}
   for j,(k,p)in enumerate(slots[a]):
    for q,c in zip(self.basis.get((gens[k][0],b),[]),self.red[gens[k][0],p+(t,)]):A[ix[k,q]][j]=c
   pa[t]=A
  return (pd,pa),f,gens,slots
 def tau(self,rep):
  P0,f0,g0,s0=self.cover(rep);B=[]
  for v,M in enumerate(f0):
   cols=null(M,P0[0][v]);B.append(tr(cols)if cols else z(P0[0][v],0))
  ker=self.subrep(P0,B);P1,f1,g1,s1=self.cover(ker);co={}
  for j,(i,g)in enumerate(g1):
   for (k,p),c in zip(s0[i],mv(B[i],g)):
    if c:co[k,j,p]=c
  sI0=[[(k,p)for k,(i,g)in enumerate(g0)for p in self.basis.get((v,i),[])]for v in range(self.n)]
  sI1=[[(k,p)for k,(i,g)in enumerate(g1)for p in self.basis.get((v,i),[])]for v in range(self.n)]
  dd=list(map(len,sI1));aa={};N=[]
  for t,(a,b)in enumerate(self.arr):
   A=z(dd[b],dd[a]);ix={s:k for k,s in enumerate(sI1[a])}
   for row,(k,p)in enumerate(sI1[b]):
    for q,c in zip(self.basis.get((a,g1[k][0]),[]),self.red[a,(t,)+p]):A[row][ix[k,q]]=c
   aa[t]=A
  for v in range(self.n):
   A=z(len(sI0[v]),len(sI1[v]));ix={s:k for k,s in enumerate(sI1[v])}
   for row,(k,q)in enumerate(sI0[v]):
    for (a,b,p),c in co.items():
     if a==k:
      for s,w in zip(self.basis.get((v,g1[b][0]),[]),self.red[v,q+p]):A[row][ix[b,s]]+=c*w
   cols=null(A,dd[v]);N.append(tr(cols)if cols else z(dd[v],0))
  return self.subrep((dd,aa),N),{'P0':[i for i,g in g0],'P1':[i for i,g in g1]}
def thin(n,arr,W):
 d=[int(i in W)for i in range(n)];return d,{t:[[F(1)]]if d[a]and d[b]else z(d[b],d[a])for t,(a,b)in enumerate(arr)}
def run():
 H=Alg(6,[(5,3),(3,2),(2,1),(1,0),(5,4),(4,0)],[])
 T=[H.projective(0),H.projective(5)]+[thin(6,H.arr,W)for W in [{0,2,3,4,5},{0,1,2,3,5},{0,4,5},{2}]]
 hh=[[len(hom(x,y,H.arr))for y in T]for x in T]
 eu=[[sum(a*b for a,b in zip(x[0],y[0]))-sum(x[0][a]*y[0][b]for a,b in H.arr)for y in T]for x in T]
 assert hh==eu,(hh,eu)
 # B vertices 0=original1,1=original2,2=c,3=d,4=e,5=f.
 arr=[(1,0),(1,0),(2,1),(3,1),(4,2),(2,5)]
 B=Alg(6,arr,[[(1,(2,0))],[(1,(3,1))],[(1,(4,5))]])
 C=[[len(B.basis.get((i,j),[]))for i in range(6)]for j in range(6)]
 assert C==hh
 U=[[t[0][j]for t in T]for j in range(6)];tau={};reps={}
 for i in range(6):
  M=B.injective(i)
  for k in range(5):
   tau[f'{i},{k}']={'dimension':M[0]};reps[i,k]=M
   if k<4:M,detail=B.tau(M);tau[f'{i},{k}']['presentation']=detail
 matches={j:[key for key,M in reps.items()if M[0]==u]for j,u in enumerate(U)}
 print('Hom',hh,'U',U,'matches',matches,sep='\n')
 for key,d in tau.items():print(key,d)
 out={'H_arrows':H.arr,'T_dimensions':[t[0]for t in T],'Hom':hh,'Ext_zero':hh==eu,'B_arrows':arr,'B_relations':B.rel,'U_dimensions':U,'U_matches':matches,'tau_injectives':tau}
 (ROOT/'qa/ch15_exact.json').write_text(json.dumps(out,indent=2),'utf8')
if __name__=='__main__':run()
