"""Exhaustive normalized tilting enumeration; Cartan grouping is only a prescreen."""
from ch17_tilting_search import hereditary,candidates
from itertools import permutations,product
from pathlib import Path
import json,time
R=Path(__file__).resolve().parents[1]
def canonical(M):
 n=len(M);col=[0]*n
 while True:
  keys=[(col[i],tuple(sorted((col[j],M[i][j],M[j][i])for j in range(n)if j!=i)))for i in range(n)]
  ks={k:i for i,k in enumerate(sorted(set(keys)))};nc=[ks[k]for k in keys]
  if len(set(nc))==len(set(col)):col=nc;break
  col=nc
 groups=[[i for i in range(n)if col[i]==c]for c in sorted(set(col))];best=None;order=None
 for ps in product(*(permutations(g)for g in groups)):
  p=sum((list(x)for x in ps),[]);v=tuple(M[i][j]for i in p for j in p)
  if best is None or v<best:best=v;order=p
 return ''.join(str(x)+','for x in best),order
def enumerate_one(kind,op=False):
 n,arr,period=hereditary(kind)
 if op:arr=[(b,a)for a,b in arr]
 cs,H,Ex,E,d=candidates(n,arr,period);N=len(cs)
 compat=[sum(1<<j for j in range(N)if i!=j and Ex[i][j]==Ex[j][i]==0)for i in range(N)]
 projs=[i for i,x in enumerate(cs)if x['kind']=='P'and x['m']==0];cliques=[]
 def rec(S,mask,need):
  if need==0:cliques.append(S);return
  while mask.bit_count()>=need:
   bit=mask&-mask;mask^=bit;i=bit.bit_length()-1;rec(S+[i],mask&compat[i],need-1)
 for p in projs:rec([p],compat[p]&~((1<<(p+1))-1),n-1)
 groups={}
 for T in cliques:
  M=[[H[i][j]for j in T]for i in T]
  if op:M=list(map(list,zip(*M))) # End over H^op is dualized back to an H realization.
  key,perm=canonical(M);v=[T[i]for i in perm]
  groups.setdefault(key,[]).append(v)
 out={'kind':kind,'opposite_input':op,'n':n,'arrows':arr,'delta':d,'candidates':cs,'Hom':H,'Ext':Ex,'normalized_tiltings':cliques,'cartan_groups':groups,'status':'Cartan prescreen only; End algebra isomorphism not yet classified'}
 path=R/f'qa/ch17_ex11_13_{kind}_{"op"if op else"orig"}.json'
 path.write_text(json.dumps(out,ensure_ascii=False,separators=(',',':')),'utf8')
 print(kind,'op'if op else'orig','candidates',N,'tiltings',len(cliques),'Cartan_groups',len(groups),flush=True)
if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['D4','D5','E6']);ap.add_argument('--op',action='store_true');a=ap.parse_args();enumerate_one(a.kind,a.op)
