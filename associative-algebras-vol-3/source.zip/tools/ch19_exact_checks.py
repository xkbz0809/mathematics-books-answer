"""Exact Euler-form and parameter checks for XIX.6--7."""
from fractions import Fraction as F
from math import lcm
from pathlib import Path
import json
def rank(a):
 a=[[F(v) for v in row] for row in a];i=0
 for j in range(len(a[0])):
  k=next((k for k in range(i,len(a)) if a[k][j]),None)
  if k is None:continue
  a[i],a[k]=a[k],a[i];v=a[i][j];a[i]=[x/v for x in a[i]]
  for k in range(len(a)):
   if k!=i:
    v=a[k][j];a[k]=[x-v*y for x,y in zip(a[k],a[i])]
  i+=1
 return i
records=[]
for p in [(3,3,3),(2,4,4),(2,3,6),(2,2,2,2)]:
 n=2+sum(x-1 for x in p);B=[[F(0) for _ in range(n)] for _ in range(n)]
 for i in range(n):B[i][i]=2
 B[0][1]=B[1][0]=len(p)-2
 rows=[];z=[0,lcm(*p)];idx=2
 for weight in p:
  arm=[0]+list(range(idx,idx+weight-1))+[1];idx+=weight-1
  z.extend(lcm(*p)*j//weight for j in range(1,weight))
  for u,v in zip(arm,arm[1:]):
   B[u][v]-=1;B[v][u]-=1
   row=[F(0) for _ in range(n)];row[v]+=1;row[u]-=1;row[1]-=F(1,weight);row[0]+=F(1,weight);rows.append(row)
 H=[[sum(row[i]*row[j] for row in rows) for j in range(n)] for i in range(n)]
 assert B==H
 h=[1]*n
 assert all(sum(B[i][j]*h[j] for j in range(n))==0 for i in range(n))
 assert all(sum(B[i][j]*z[j] for j in range(n))==0 for i in range(n))
 assert rank(B)==n-2
 records.append({'weights':p,'rank_K0':n,'rank_hessian':n-2,'h':h,'z':z,'positive_second_generator':[a+b for a,b in zip(h,z)],'sum_of_squares_hessian_identity':True})
a=F(2);orbit={a,1/a,1-a,1/(1-a),a/(a-1),(a-1)/a}
assert F(3) not in orbit
out=Path(__file__).resolve().parents[1]/'qa/ch19_exact_checks.json'
out.write_text(json.dumps({'quadratic_forms':records,'cross_ratio_orbit_of_2':sorted(map(str,orbit)),'parameter_3_excluded':True},ensure_ascii=False,indent=2),encoding='utf-8')
print('Four exact quadratic-form identities and parameter counterexample verified.')
