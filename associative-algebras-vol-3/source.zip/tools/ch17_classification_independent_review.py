"""Independent replay of classification bounds, clique coverage and isomorphisms."""
import json
from fractions import Fraction as F
from itertools import combinations
from ch15_exact import Alg,rr
from ch17_specs import ROOT,inv
def mm(A,B):return [[sum(x*y for x,y in zip(r,c))for c in zip(*B)]for r in A]
def mv(A,x):return [sum(a*b for a,b in zip(r,x))for r in A]
def rank(M,n):return len(rr(M,n)[1])
def verify_iso(S,T,w):
 p=w['vertex_permutation'];assert sorted(p)==list(range(S.n));ims=w['arrow_images'];assert len(ims)==len(S.arr)
 assert sum(map(len,S.basis.values()))==sum(map(len,T.basis.values()))
 for a,(u,v)in enumerate(S.arr):
  for c,q in ims[a]:
   assert q and T.arr[q[0]][0]==p[u]and T.arr[q[-1]][1]==p[v]
 for u,v in set(S.arr):
  aa=[i for i,e in enumerate(S.arr)if e==(u,v)];bb=[i for i,e in enumerate(T.arr)if e==(p[u],p[v])]
  assert len(aa)==len(bb)
  M=[[sum(F(c)for c,q in ims[a]if q==[b])for b in bb]for a in aa];assert rank(M,len(bb))==len(bb)
 for rel in S.rel:
  u=S.arr[rel[0][1][0]][0];v=S.arr[rel[0][1][-1]][1];val=[F(0)]*len(T.basis.get((p[u],p[v]),[]))
  for coeff,path in rel:
   terms=[(F(coeff),())]
   for a in path:terms=[(x*F(y),q+tuple(z))for x,q in terms for y,z in ims[a]]
   for c,q in terms:
    for i,x in enumerate(T.red[p[u],q]):val[i]+=c*x
  assert not any(val)
out={}
for kind,h in [('D4',2),('D5',6),('E6',6)]:
 info={};enddata={}
 for side in ['orig','op']:
  d=json.loads((ROOT/f'qa/ch17_ex11_13_{kind}_{side}.json').read_text());n=d['n'];ar=d['arrows'];E=[[F(int(i==j)-int([i,j]in ar))for j in range(n)]for i in range(n)];Et=list(map(list,zip(*E)));phi=[[-v for v in row]for row in mm(inv(E),Et)];psi=inv(phi);C=list(map(list,zip(*inv(E))))
  for M,vs in [(phi,C),(psi,list(zip(*C)))]:
   power=[[F(i==j)for j in range(n)]for i in range(n)]
   for _ in range(h):power=mm(M,power)
   N=[[power[i][j]-int(i==j)for j in range(n)]for i in range(n)];assert not any(v for row in mm(N,N)for v in row)
   for t in range(h):
    for x in vs:
     inc=mv(N,x);delta=d['delta'];assert inc[0]>0 and all(inc[i]*delta[0]==inc[0]*delta[i]for i in range(n))
    vs=[mv(M,x)for x in vs]
  N=len(d['candidates']);adj=[set(j for j in range(N)if i!=j and d['Ext'][i][j]==d['Ext'][j][i]==0)for i in range(N)];cliques=set();proj={i for i,c in enumerate(d['candidates'])if c['kind']=='P'and c['m']==0}
  def rec(chosen,avail):
   if len(chosen)==n:
    if proj.intersection(chosen):cliques.add(tuple(chosen))
    return
   if len(chosen)+len(avail)<n:return
   while avail:
    v=min(avail);avail.remove(v);rec(chosen+[v],avail&adj[v])
  rec([],set(range(N)))
  assert cliques=={tuple(sorted(t))for t in d['normalized_tiltings']}
  for T in cliques:
   assert proj.intersection(T)
   for i in T:
    for j in T:
     x=d['candidates'][i]['dim'];y=d['candidates'][j]['dim'];e=sum(x[a]*E[a][b]*y[b]for a in range(n)for b in range(n));assert d['Hom'][i][j]==e
  enddata[side]=json.loads((ROOT/f'qa/ch17_ex11_13_{kind}_{side}_endomorphisms.json').read_text())['algebras'];assert len(enddata[side])==len(cliques)
  audit=json.loads((ROOT/f'qa/ch17_ex11_13_{kind}_{side}_characteristic_audit.json').read_text());assert set(audit['exceptional_primes'])<={2}
  ct=ROOT/f'qa/ch17_ex11_13_{kind}_{side}_characteristic_two.json'
  if audit['exceptional_primes']:
   dd=json.loads(ct.read_text());assert not dd['failed'];assert {tuple(sorted(a['T']))for a in dd['verified']}==cliques
  info[side]={'candidate_count':N,'cliques_independently_reenumerated':len(cliques),'strict_period_bounds_verified':True,'exceptional_primes':audit['exceptional_primes'],'characteristic_two_complete_if_needed':True}
 cats=json.loads((ROOT/f'qa/ch17_ex11_13_{kind}_isomorphisms.json').read_text());assert not cats['unresolved'];count=0
 for g in cats['classes']:
  t=g['representative'];T=Alg(len(t['Cartan']),t['arrows'],t['relations']);assert len(g['witnesses'])==g['group_size']
  for wit in g['witnesses']:
   s=enddata[wit['input']][wit['input_index']];S=Alg(len(s['Cartan']),[tuple(e)for e in s['arrows']],s['relations'])
   T.arr=[tuple(e)for e in T.arr]
   verify_iso(S,T,wit['isomorphism']);count+=1
 info['classes']=len(cats['classes']);info['isomorphisms_independently_substituted']=count;out[kind]=info;print(kind,info,flush=True)
(ROOT/'qa/ch17_classification_independent_review.json').write_text(json.dumps(out,indent=2),'utf8')
