"""Actual matrices and End presentations for the wild concealed examples."""
import json,argparse
from fractions import Fraction as F
from ch15_exact import Alg,hom,rr,tr,null,coord
from ch17_specs import ROOT,info
from ch18_specs import H,alg
from ch17_b7_ar import compose
def rank(vs,n):return len(rr(vs,n)[1])if vs else 0
def run(k):
 n,arr=H[k];Aop=Alg(n,[(b,a)for a,b in arr],[]);record=json.loads((ROOT/f'qa/ch18_{k}_construction.json'if k==10 else ROOT/f'qa/ch18_{k}_preprojective_tilting.json').read_text());spec=record['tilting'];assert spec
 cache={};T=[]
 for v in spec:
  if k==10:
   q=record['representations'][len(T)];T.append((q['dimensions'],{int(a):[[F(x)for x in row]for row in mat]for a,mat in q['arrows'].items()}));continue
  i,m=v['i'],v['m']
  if(i,0)not in cache:cache[i,0]=Aop.injective(i)
  for s in range(1,m+1):
   if(i,s)not in cache:cache[i,s]=Aop.tau(cache[i,s-1])[0]
  d,a=cache[i,m];M=(d,{j:tr(x)if x else [[]for _ in range(d[tgt])]for j,x in a.items()for src,tgt in [arr[j]]})
  # Empty transpose has the target/source dimensions in the original orientation.
  M=(d,{j:[[a[j][col][row]for col in range(d[src])]for row in range(d[tgt])]for j,(src,tgt)in enumerate(arr)})
  assert d==v['dim'],(k,i,m,d,v['dim']);T.append(M)
 print(k,'representations built',flush=True)
 B=alg(k);HH=[[hom(x,y,arr)for y in T]for x in T];assert [[len(x)for x in row]for row in HH]==info(B)['C'];f=[]
 for u,v in B.arr:
  comps=[]
  for w in range(n):
   if w in [u,v]:continue
   for a in HH[v][w]:
    for b in HH[w][u]:comps.append(compose(a,b,T[v][0],T[w][0],T[u][0]))
  nc=sum(a*b for a,b in zip(T[v][0],T[u][0]));rank0=rank(comps,nc);chosen=None
  for a in HH[v][u]:
   if rank(comps+[a],nc)>rank0:chosen=a;break
  assert chosen is not None,(k,u,v);f.append(chosen)
 def value(p):
  u=B.arr[p[0]][0];prev=u;g=[F(i==j)for d in T[u][0]for i in range(d)for j in range(d)]
  for a in p:
   s,t=B.arr[a];assert s==prev;g=compose(f[a],g,T[t][0],T[prev][0],T[u][0]);prev=t
  return g
 normal=[]
 for rel in B.rel:
  if len(rel)==1:assert not any(value(rel[0][1]));continue
  vectors=[value(p)for c,p in rel];ker=null(tr(vectors),len(vectors))
  if len(ker)==1 and all(ker[0]):
   coeff=ker[0]
   for(c,p),q in zip(rel,coeff):
    a=p[0];assert all(a not in other for c2,other in rel if other!=p);f[a]=[q/c*x for x in f[a]]
   normal.append({'kind':'scaling','coefficients':[str(x)for x in coeff]})
  else:
   # Choose a full Hom representative for one arrow, allowing addition of a bypass.
   solved=False
   for h,(c,p)in enumerate(rel):
    for a in p:
     if any(a in q for j,(b,q)in enumerate(rel)if j!=h):continue
     u,v=B.arr[a];old=f[a];images=[]
     for candidate in HH[v][u]:f[a]=candidate;images.append(value(p))
     f[a]=old;rhs=[-sum(b*value(q)[i]for j,(b,q)in enumerate(rel)if j!=h)/c for i in range(len(vectors[0]))]
     try:co=coord(tr(images),rhs)
     except AssertionError:continue
     f[a]=[sum(co[j]*HH[v][u][j][i]for j in range(len(co)))for i in range(len(old))]
     if not any(f[a]):f[a]=old;continue
     solved=True;normal.append({'kind':'bypass','arrow_index':a,'coefficients':[str(x)for x in co]});break
    if solved:break
   assert solved,(k,rel)
  assert not any(sum(c*value(p)[i]for c,p in rel)for i in range(len(vectors[0])))
 for rel in B.rel:assert not any(sum(c*value(p)[i]for c,p in rel)for i in range(len(value(rel[0][1]))))
 for(u,v),ps in B.basis.items():
  if u==v:continue
  vs=[value(p)for p in ps]
  assert rank(vs,len(vs[0]))==len(vs)if vs else not HH[v][u],(k,u,v)
 out={'exercise':k,'H_arrows':arr,'tilting':spec,'representations':[{'dimensions':d,'arrows':{str(j):[[str(x)for x in row]for row in a]for j,a in ar.items()}}for d,ar in T],'B_arrow_maps':[[str(x)for x in a]for a in f],'normalization':normal,'End_dimension':int(info(B)['dimension']),'all_relations_verified':True,'path_bases_independent':True,'End_isomorphic_to_B':True}
 (ROOT/f'qa/ch18_{k}_end_verified.json').write_text(json.dumps(out,indent=2),'utf8');print(k,'VERIFIED',out['End_dimension'],normal,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('exercise',type=int);a=p.parse_args();run(a.exercise)
