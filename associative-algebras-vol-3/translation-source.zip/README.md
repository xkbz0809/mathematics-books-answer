# 第三卷中文译本与习题解答源码

原书：Daniel Simson、Andrzej Skowroński，Elements of the Representation Theory of Associative Algebras, Volume 3: Representation-Infinite Tilted Algebras，Cambridge University Press，2007，LMS Student Texts 72。

本工程含第三卷完整中文译文，以及另行编写的全部46题中文解答。XV、XVI、XVII、XVIII、XIX章依次有5、8、15、11、7题；XX章无习题。解答不是原作者编写或认可的官方答案册。包内文件哈希以 SOURCE_MANIFEST.json 为准，核验状态见 qa/final_structural_review.json 及各章QA；本地交付目录另有 qa/delivery.json。

最终译本390页，习题解答113页。正式验收见 qa/release_acceptance.json；全部页面的视觉证据汇总见 qa/final_visual_acceptance.json，原题和跨卷链接核验见 qa/final_navigation.json，既有原书及前两卷文件保全见 qa/final_preservation.json。归档输入与实际编译目录的逐字节比较见 qa/archive_build_inputs.json；后续仅增补QA记录时，编译输入集合摘要保持可复验。

## 两个编译入口

根目录 main.tex 是中文译本，包括卷首、XV–XX章、703条参考文献、原书索引与符号表、术语索引。solutions/main.tex 是全部46题中文解答，含XVII.11–13的437项完整分类表。

使用含XeLaTeX、Biber、CTeX、TikZ-CD、Computer Modern Unicode和Fandol字体的TeX Live，以及Python 3。字体随正常TeX Live安装提供，不要求商业字体。每套工程的 tools/build.py 执行XeLaTeX两遍、Biber、XeLaTeX两遍。

Windows下建议解压到较短路径（例如 D:/books/v3），避免TeX工具对超长文件路径的限制。本次归档重编使用工程内较短的 build/pkg_ 目录；过长目录下曾出现无法写入日志或无法打开实际存在的文件，缩短路径后继续验证，正文不因此改变。

在根目录运行 python -B -X utf8 tools/build.py main --out-dir build/release 编译译本；进入 solutions 目录后运行同一命令编译解答。两个结果分别在各自目录的 build/release/main.pdf。有Bash的环境也可在对应目录运行 bash tools/build.sh full。修改主文件或模板后使用新的输出目录，避免旧辅助文件干扰。

编译只需Python标准库及TeX工具。重新执行PDF检查、生成联系表另需PyMuPDF和Pillow；各数学核验程序的执行次序见相应qa说明。精确代数核验使用整数或有理数，不用浮点近似代替等式验证。

## 文件和核验记录

chapters、frontmatter、backmatter保存译文；solutions/chapters保存解答。mathtranslation.cls、logo.pdf和字体配置沿用本系列。glossary.tsv及文末索引记录术语。箭头节点图用TikZ-CD重绘；两幅整体结构示意保留原书清晰图形。

source保存目录、题目清单及逐页提取文本。原PDF共470页，印刷页码=PDF页码−14；SHA-256为 1f274461bc04319ece0adc551b1249be6914715a6033381ca4c5d2d71806cbf5。公式、图和疑义以原PDF为依据，提取文本只作定位。

qa与solutions/qa保存数学复核、源文问题、精确计算、前后对照、修改前源码快照、结构覆盖、链接及视觉检查。源码中的 \transnote 和 \sourceissue 仍保留修改依据，最终阅读版不显示这些修订过程；确认的数学修正落实正文。各报告分别记录数学审查、实际计算、原PDF对照、编译与视觉检查。

XVII.11–13的完整性、End乘法、2898个归一化倾斜模的同构证书、特征2检查及独立重放，见solutions/qa/ch17_ex11_13_README.md与ch17_classification_independent_review.md。一次性修订工具仅为历史过程，正常重编只运行上述两个入口，不应逐个重跑全部工具。

## PDF链接

把两个输出分别命名为“结合代数表示论基础_第3卷_中文译本.pdf”和“结合代数表示论基础_第3卷_全书习题解答_中文.pdf”，放在同一目录。解答的原题链接取自译本实际命名目标，映射为solutions/book_links.tex；tools/update_solution_book_links.py可从译本最终aux重新生成。

跨卷链接保留本系列相邻文件夹结构。前两卷PDF不参与编译，点击跨卷链接时才需要它们；可在载入宏前定义VolumeOnePDF、VolumeTwoPDF、VolumeThreePDF以改写默认路径。

## 归档范围

上传包保留两套正文、必要图形和模板、参考文献、逐页提取文本、构建与核验工具、精确数据和修改记录。排除整本英文原PDF、交付PDF重复副本、编译缓存、批量渲染图片和解压重编临时目录。SOURCE_MANIFEST.json列出包内文件的大小与SHA-256。原书和前两卷既有文件不因本工程而修改。

2026-11-16已检查数译制作指南，沿用前两卷经验证的模板以保持系列一致；在线模板压缩包当时返回HTTP 403，没有声称检查过未取得的文件。依据见qa/template_decision.json。

