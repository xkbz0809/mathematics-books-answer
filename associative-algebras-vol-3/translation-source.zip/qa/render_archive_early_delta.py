"""Render changed pages and immediate neighbors for actual final visual review."""
from pathlib import Path
import hashlib
import json
import pymupdf as fitz

ROOT = Path(__file__).resolve().parents[1]
diff = json.loads((ROOT / 'qa/archive_early_body_diff.json').read_text(encoding='utf-8'))
pdf = Path(diff['new']['pdf'])
expected = diff['new']['sha256']
assert hashlib.sha256(pdf.read_bytes()).hexdigest() == expected
selected = set(diff['new']['selected_pages'])
changed = diff['new_pages_added_or_visually_changed']
view = set(changed)
view.update([206, 207, 208, 209])
for n in changed:
    view.update({n-1, n+1} & selected)
view.update(w['page'] for w in diff['new']['crop_warnings'])
out = ROOT / 'qa/archive_early_images_final'
out.mkdir(exist_ok=True)
with fitz.open(pdf) as doc:
    for n in sorted(view):
        doc[n-1].get_pixmap(matrix=fitz.Matrix(1.65, 1.65), alpha=False).save(out / f'page_{n:03}.png')
report = {
    'pdf': str(pdf), 'sha256': expected,
    'changed_pages': changed, 'rendered_pages': sorted(view),
    'scale': 1.65, 'actual_viewing_recorded_separately': True,
    'old_crop_warnings': diff['old']['crop_warnings'],
    'new_crop_warnings': diff['new']['crop_warnings'],
}
assert hashlib.sha256(pdf.read_bytes()).hexdigest() == expected
(out / 'render_manifest.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False))
