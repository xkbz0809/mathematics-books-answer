"""Record actual visual inspection performed after an exact page-body comparison."""
from pathlib import Path
from datetime import datetime, timezone
import json
import hashlib
import struct
import pymupdf as fitz

root = Path(__file__).resolve().parents[1]
diff = json.loads((root / 'qa/archive_early_body_diff.json').read_text(encoding='utf-8'))
actual = [11, 12, 89, 90, 91, 206, 207, 208, 209, 210, 211, 212, 213]
matched = {p['new_page']: p for p in diff['exact_body_matches']}
selected = diff['new']['selected_pages']
coverage = set(actual) | set(matched)
assert set(selected) <= coverage
footer_records = []
def strip_hash(page):
    box = page.rect
    clip = fitz.Rect(box.x0, box.y1-65, box.x1, box.y1)
    pix = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), clip=clip, colorspace=fitz.csRGB, alpha=False, annots=True)
    h = hashlib.sha256(struct.pack('>IIII', pix.width, pix.height, pix.n, pix.stride) + pix.samples)
    return h.hexdigest()
for key in ['old', 'new']:
    assert hashlib.sha256(Path(diff[key]['pdf']).read_bytes()).hexdigest() == diff[key]['sha256']
with fitz.open(diff['old']['pdf']) as old, fitz.open(diff['new']['pdf']) as new:
    for n in selected:
        old_hash = strip_hash(old[n-1])
        new_hash = strip_hash(new[n-1])
        footer_records.append({'physical_pdf_page': n, 'old_sha256_rgb': old_hash, 'new_sha256_rgb': new_hash, 'exact': old_hash == new_hash})
for key in ['old', 'new']:
    assert hashlib.sha256(Path(diff[key]['pdf']).read_bytes()).hexdigest() == diff[key]['sha256']
assert all(x['exact'] for x in footer_records)
prior = [
    {'record': 'qa/ch15_ch16_final_visual/review.json', 'physical_pages': [11,89]},
    {'record': 'qa/integrated_final_ch17_ch18/manifest.json', 'physical_pages': [90,250]},
]
report = {
    'reviewer': 'final_visual_early',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'pdf': diff['new']['pdf'],
    'final_sha256': diff['new']['sha256'],
    'final_page_count': diff['new']['page_count'],
    'scope': 'Chapters XV-XVIII; physical PDF pages 11-250 inclusive',
    'chapter_ranges': {'XV': [11,61], 'XVI': [62,89], 'XVII': [90,180], 'XVIII': [181,250]},
    'prior_pdf_sha256': diff['old']['sha256'],
    'prior_actual_visual_review': prior,
    'body_comparison_record': 'qa/archive_early_body_diff.json',
    'body_comparison_method': diff['method'],
    'body_comparison_render': diff['render'],
    'footer_comparison': {'method': 'Exact SHA-256 of rendered RGB pixels and pixel geometry for the complementary bottom 65 pt, at scale 1.5 with annotations, same physical old/new page pairs.', 'exact_count': sum(x['exact'] for x in footer_records), 'total_count': len(footer_records), 'all_exact': all(x['exact'] for x in footer_records), 'page_records': footer_records},
    'exact_body_match_count': diff['new_exact_match_count'],
    'changed_pages': diff['new_pages_added_or_visually_changed'],
    'actually_viewed_final_pages': actual,
    'actually_viewed_final_page_count': len(actual),
    'actual_view_method': 'Each listed final page opened as a full-page PNG at 1.65x (118.8 dpi, approximately 983 x 1390 pixels), including its footer. All eight changed pages and five neighboring pages were actually viewed. The diamond repair and all six reflowed pages 207-212 were inspected explicitly.',
    'covered_page_count': len(set(selected) & coverage),
    'complete_body_visual_coverage': True,
    'coverage_basis': 'Every page in 11-250 is either actually viewed now or has exact retained-body RGB pixels matching a page actually viewed in the two prior records. Complementary bottom-65pt footer strips match exactly on all 240 physical page pairs. Pixel equality is not newly claimed visual inspection.',
    'crop_warnings': {'old': diff['old']['crop_warnings'], 'new': diff['new']['crop_warnings']},
    'resolved_issues': [
        {'id': 'VIS-XV-11', 'pages': [11,12], 'description': 'Chapter XV title now breaks at the phrase boundary: 代数的管状扩张 / 与管状余扩张. No single isolated final character. Neighbor page unchanged and readable.'},
        {'id': 'VIS-XVII-90', 'pages': [89,90,91], 'description': 'Definition 1.2 stone term and final punctuation remain together on the final line. No punctuation-only line. Neighbor pages unchanged and readable.'},
        {'id': 'VIS-XVIII-208', 'pages': [206,207,208,209,210,211,212,213], 'description': 'Example 3.4 end diamond is now beside the final sentence on physical page 207. Page 208 begins with Example 3.5 and no orphan marker. All six changed/reflowed pages 207-212 and both unchanged boundary neighbors 206/213 were actually viewed, with no clipping or overlap observed.', 'evidence': ['qa/archive_early_images_final/page_207.png', 'qa/archive_early_images_final/page_208.png']},
    ],
    'remaining_issues': [],
    'other_observed_issues': [],
    'footer_scope': 'Full footers actually viewed for the thirteen explicitly listed pages. In addition, all 240 complementary footer strips exactly match the corresponding previously visually reviewed old page at scale 1.5.',
    'limitations': ['This is a visual layout acceptance record, not a new source-fidelity or mathematical proof audit.', 'Link destinations are outside this review.', 'Any rebuilt PDF requires a new hash comparison and visual checking of changed pages.'],
    'status': 'accepted_complete_visual_coverage_no_remaining_observed_layout_issue',
    'supersedes': 'qa/archive_visual_early_firstpass.json',
    'page_records': [
        {'physical_pdf_page': n,
         'actually_viewed_now': n in actual,
         'image': f'qa/archive_early_images_final/page_{n:03}.png' if n in actual else None,
         'exact_old_body_match': matched.get(n),
         'prior_review_record': ('qa/ch15_ch16_final_visual/review.json' if matched[n]['old_page'] < 90 else 'qa/integrated_final_ch17_ch18/manifest.json') if n in matched else None}
        for n in selected
    ],
}
(root / 'qa/archive_visual_early.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: report[k] for k in ['final_sha256','exact_body_match_count','changed_pages','actually_viewed_final_pages','covered_page_count','status']}, ensure_ascii=False))
