# 第三卷跨卷链接复核

状态：本次检查范围通过。译本与习题册源码中的 484 处 `volone` / `voltwo` 调用（译本 481 处，习题册 3 处；共 180 个不同卷号／标签组合）均有映射，目标均存在于对应最终 PDF 的命名目的地树中。扫描范围包括根部及 solutions 的 chapters、frontmatter、backmatter、front、back，以及 main.tex、metadata.tex，忽略 TeX 注释；保留在源代码的译注参数也计入扫描。

## 证据与边界

- 第一卷目标为相邻目录中的 `结合代数表示论基础 中文译本.pdf`，422 页、2997 个命名目的地。`build/main.aux` 所属的 `main.pdf` 与该最终 PDF 的 SHA-256 相同。
- 第二卷目标为相邻目录中的 `结合代数表示论基础_第2卷_中文译本.pdf`，256 页、1640 个命名目的地。`build/release_source/build/main.aux` 所属的 `main.pdf` 与该最终 PDF 的 SHA-256 相同。
- 根部及 solutions 两份第一卷映射各 792 项，第二卷映射各 307 项；全部目的地存在，无重复键，与相应已确认 aux 的目的地完全相符。解析 `csname` 必须一直读到 `endcsname`。
- 两本第三卷成品应同放在第三卷项目根目录中；四份映射的相对路径均以此交付位置解析，均精确指向现有第一、二卷译本。构建子目录内的中间 PDF 不是这些相对路径的交付基准。
- 本次没有改动第一、二卷任何文件，也未改动正在由其他作者编写的 `ch18_sec5*.tex` 或 `ch18_exercises.tex`。
- 本次没有重编第三卷整书或习题册；下述独立编译探针证明当前映射宏的实际 PDF 输出，最终集成 PDF 的完整复核由主构建流程执行。

## 已修复

1. 两份第一卷映射均补入 `I:2.11 -> AMS.45`，对应第一卷附加同构公式，原调用位于 `chapters/ch15_sec1.tex`。
2. 两份第一卷映射均把 `IX:sec6 -> An` 修正为 `section.9.6`。此项虽然尚未被本次实际正文调用，但原映射不在最终 PDF 名字树中。
3. `chapters/ch19_sec3b.tex` 的 `IX:3.1`、`VIII:2.13`、`VIII:4.5` 改用 `volone`。
4. `chapters/ch19_sec3c.tex` 的 `VIII:1.8`、`VIII:5.6` 改用 `volone`。

共 7 个不同问题、9 处源码项修改（两个映射问题分别在译本和习题册各修一次）。所有目的地均来自与最终 PDF 匹配的 aux，并再次检查最终 PDF 名字树，未按编号猜造锚点。修前 6 处正文调用无效，修后为 0。

## 编译后的链接验证

`unit_cross_volume_links.tex` 分组加载根部和 solutions 的实际映射文件，覆盖各自用到的不同引用，并额外包含两个修复的映射标签。XeLaTeX 成功生成 6 页、186 个链接，逐一检查了底层 `/GoToR` 动作、中文 UTF-8 文件路径及命名目的地，与源码映射完全一致；186/186 通过。无溢出、缺字或未定义控制序列。6 页接触表已视觉检查，链接行完整。

此验证确认文件和目标名可解析；不同 PDF 阅读器对跨文件打开的交互策略不属于本次自动化验证范围。

## 哈希保持

第一卷最终 PDF：`3f08626baad9c76974f56f23a6a44a446b34acf03ce68181ca62b4fea0d65dfb`

第二卷最终 PDF：`0620a6405a10c3f928c4eed69d8157571c5b47c75b7b64940c4241bf4ecd7203`

检查开始、修复完成、编译验证完成时的上述哈希一致。

## 文件索引

- `audit_before.json`、`before_corrections.zip`：修前记录及原始源码副本。
- `changes.json`、`changes.diff`：全部修改及精确依据。
- `audit.json`：修后全部引用、映射、目标与 aux 哈希。
- `compiled_probe.json`：每个编译链接的原始 PDF 动作。
- `compiled_verification.json`：逐链接校验结果及目标页坐标。
- `probe_contact.png`：已视觉检查的 6 页接触表。
- `../../tools/audit_cross_volume_links.py`：可重跑的只读审查器。
- `../../tools/fix_cross_volume_links.py`：一次性修复脚本，拒绝覆盖最初快照。
- `../../tools/probe_cross_volume_links.py`、`verify_cross_volume_probe.py`：编译与实际动作验证。

复核日期：2026-11-16。
