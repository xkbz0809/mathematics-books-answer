from pathlib import Path
import json, hashlib

root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads((root/p).read_text(encoding='utf-8'))
base=read('qa/archive_visual_late_pass1.json')
c=read('qa/archive_xix_xx_final_delta.json')
render=read('qa/archive_visual_late_final_pages/manifest.json')
assert c['old']['sha256']==base['sha256']
assert c['new']['sha256']==render['sha256']=='2f434ffacfe74a3436dfaff686dc26b5837736a7ce6dd3127a39cda330a45776'
assert hashlib.sha256(Path(c['new']['pdf']).read_bytes()).hexdigest()==c['new']['sha256']
viewed=[323,324,325,326,327]
assert set(c['new_pages_added_or_visually_changed']) <= set(viewed)
assert not render['footer_mismatches']
matches={x['new_page']:x for x in c['exact_body_matches']}
hashes={x['page']:x['sha256_rgb'] for x in c['new']['pages']}
prior={x['page']:x for x in base['page_evidence']}
footers={x['page']:x for x in render['footers']}
evidence=[]
for n in range(251,328):
    e={'page':n,'body_pixel_sha256':hashes[n],'footer_check':footers[n]}
    if n in viewed:
        path=f'qa/archive_visual_late_final_pages/p{n:03}.png'
        e.update(method='actually_viewed_final_individual_page_image',image=path,
                 image_sha256=hashlib.sha256((root/path).read_bytes()).hexdigest(),render_scale=1.8)
    else:
        m=matches[n]
        assert m['old_page']==n
        e.update(method='exact_rendered_body_pixel_transfer',old_page=m['old_page'],
                 prior_review='qa/archive_visual_late_pass1.json',prior_pdf_sha256=base['sha256'],
                 prior_evidence=prior[m['old_page']])
    evidence.append(e)
fixes=base['fixes']+[{
    'object':'XX.5.13 theorem','old_page':324,'new_page':325,'status':'resolved',
    'observation':'In the final PDF the theorem heading, setup, and both conditions (a),(b) are together at the top of page 325. Pages 324-327 were actually viewed to check the repagination.'
}]
r={
    'pdf':c['new']['pdf'],'sha256':c['new']['sha256'],'total_pdf_pages':390,
    'scope':'XIX and XX, physical PDF pages 251-327 inclusive',
    'covered_physical_pages':[251,327],'covered_page_count':77,
    'final_actual_pages_viewed':viewed,'final_actual_viewed_count':5,
    'pass1_actual_pages_viewed':base['actual_pages_viewed'],'pass1_actual_viewed_count':44,
    'unique_physical_pages_actually_viewed_across_both_passes':sorted(set(viewed)|set(base['actual_pages_viewed'])),
    'unique_physical_pages_actually_viewed_count':len(set(viewed)|set(base['actual_pages_viewed'])),
    'actual_page_image_view_events':49,
    'final_pages_covered_by_exact_pixel_transfer':72,
    'final_delta_changed_pages':c['new_pages_added_or_visually_changed'],
    'all_final_changed_pages_actually_viewed':True,
    'comparison':'qa/archive_xix_xx_final_delta.json',
    'first_pass_review':'qa/archive_visual_late_pass1.json',
    'page_evidence':evidence,'fixes':fixes,
    'unresolved_target_repairs':[],
    'new_clipping_or_obstruction_found':[],
    'accepted_layout_observations':base['accepted_layout_observations'],
    'footers':{'checked_pages':77,'method':'Extracted text in the bottom 65pt band equals physical PDF page minus 10 on all assigned pages. Final actually viewed pages also have visually correct footer placement.',
               'printed_page_range':[241,317],'mismatches':[]},
    'inputs_modified':False,
    'status':'passed_with_accepted_preexisting_minor_typography',
    'conclusion':'All 77 assigned pages are covered by actual individual-page visual inspection or exact body-pixel evidence transferred from reviewed pages. All eight target pagination repairs are resolved; no new clipping or obstruction was found.',
    'limitations':[
       'This is layout acceptance, not a fresh mathematical proof or original-PDF fidelity audit.',
       'Exact pixel equality applies to the retained body region above the bottom 65pt at the stated render scale. Footer content was checked separately; hyperlink destinations are outside this pass.',
       'The pre-existing isolated period in XX.1.8(a) and normal chapter-end whitespace are explicitly accepted, rather than silently described as absent.'
    ]
}
(root/'qa/archive_visual_late.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'output':'qa/archive_visual_late.json','sha256':r['sha256'],'covered':77,'final_actual_views':5,'pass1_actual_views':44,'unique_pages_viewed':46,'resolved_repairs':8,'status':r['status']},ensure_ascii=False))
