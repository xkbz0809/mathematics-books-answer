# XV / XVI 显示公式样式统一

完成日期：2026-11-16。

检查两个章节的 37 个 TeX 文件，将 20 个文件内 190 个纯公式 `\[...\]` 外层改为 `align*`；99 个含 TikZ 或外部输入图的显示块保留原图排版。所有公式内容、标记及标签不变；未对数学作任何修改。

修改前 37 个源文件与原单位构建 aux 已保存到 `before.zip`。`conversion.json` 逐块记录原内容、行号、内容哈希、显式 tag/label 和处理决策；`changes.diff` 保留全部变更。

验证脚本把修前和修后文件的显示环境外壳规范化后逐字比较，37/37 完全一致；所有显式 tag/label 的有序序列相同。第 XV / XVI 章单位 aux 的 80 / 39 个标签键及显示编号也分别完全相同。

各进行一次 XeLaTeX 单位编译，沿用已有单位 aux/bbl 作为种子：

- XV：`build/unit_ch15_display/unit_ch15.pdf`，51 页。
- XVI：`build/unit_ch16_display/unit_ch16.pdf`，28 页。

两次编译均成功，无 overfull、缺字、未定义命令或 LaTeX 错误。少量无法在单章内解析的跨章引用均属于正常单位构建边界（完整列表见 `verification.json`），最终应以全书重编为准。公式外层间距改变使各单位比旧清洁版多 1 页，编号不变。

已视觉检查 XV 第 2、25 页及 XVI 第 2、14 页，公式居中、矩阵、保留的图和显式公式号正常。此次抽查不代替最终全书逐页视觉检查。

工具：`tools/normalize_ch15_ch16_displays.py` 为一次性改写，拒绝覆盖初始快照；`tools/verify_ch15_ch16_displays.py` 为内容不变、标签编号和构建检查。
