from pathlib import Path
import json, hashlib
import pymupdf as fitz

root = Path(__file__).resolve().parents[1]
comparison = json.loads((root / 'qa/archive_xix_xx_body_comparison.json').read_text(encoding='utf-8'))
pdf = Path(comparison['new']['pdf'])
assert hashlib.sha256(pdf.read_bytes()).hexdigest() == comparison['new']['sha256']
out = root / 'qa/archive_visual_late_pages'
out.mkdir(exist_ok=True)
pages = sorted(set(comparison['new_pages_added_or_visually_changed']) | set(range(268,291)) | set(range(313,323)))
doc = fitz.open(pdf)
text = []
for n in pages:
    doc[n-1].get_pixmap(matrix=fitz.Matrix(1.8,1.8), alpha=False).save(out / f'p{n:03}.png')
    text.append({'page': n, 'text': doc[n-1].get_text()})
(out / 'page_text.json').write_text(json.dumps(text, ensure_ascii=False, indent=2), encoding='utf-8')
manifest = {'pdf': str(pdf), 'sha256': comparison['new']['sha256'], 'rendered_pages': pages, 'scale': 1.8,
            'status': 'Rendered only, not evidence of actual viewing.'}
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(manifest, ensure_ascii=False))
