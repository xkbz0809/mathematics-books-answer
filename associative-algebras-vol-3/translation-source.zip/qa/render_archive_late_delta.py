from pathlib import Path
import json, hashlib
import pymupdf as fitz

root=Path(__file__).resolve().parents[1]
c=json.loads((root/'qa/archive_xix_xx_final_delta.json').read_text(encoding='utf-8'))
pdf=Path(c['new']['pdf'])
assert hashlib.sha256(pdf.read_bytes()).hexdigest()==c['new']['sha256']
d=fitz.open(pdf)
out=root/'qa/archive_visual_late_final_pages'
out.mkdir(exist_ok=True)
selected=set(c['new']['selected_pages'])
changed=set(c['new_pages_added_or_visually_changed'])
pages=sorted(selected & (changed | {p-1 for p in changed} | {p+1 for p in changed}))
for n in pages:
    d[n-1].get_pixmap(matrix=fitz.Matrix(1.8,1.8),alpha=False).save(out/f'p{n:03}.png')
footers=[]
for n in sorted(selected):
    p=d[n-1]
    t=p.get_text('text',clip=fitz.Rect(0,p.rect.height-65,p.rect.width,p.rect.height)).strip()
    footers.append({'page':n,'footer_text':t,'expected':str(n-10),'matches_expected':t==str(n-10)})
result={'pdf':str(pdf),'sha256':c['new']['sha256'],'total_pages':len(d),'rendered_pages':pages,
        'changed_pages':sorted(changed),'footers':footers,'footer_mismatches':[x for x in footers if not x['matches_expected']],
        'status':'Rendered only; actual page-image viewing must be recorded separately.'}
(out/'manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
assert hashlib.sha256(pdf.read_bytes()).hexdigest()==c['new']['sha256']
print(json.dumps({'pdf_sha256':result['sha256'],'rendered_pages':pages,'footer_mismatches':result['footer_mismatches']},ensure_ascii=False))
