# 源码 ZIP 与实际解压编译目录独立核验

复核日期：2026-11-16。复核者：volume3_inventory。

本次检查的归档为 `结合代数表示论基础_第3卷_译本与习题解答_数译上传源码包.zip`，3,226,523 字节；ZIP SHA-256 为 `f56ea90bb176214493a6dec1c29aa436f47afee1696b378eda0bf79e7a8cf4da`。实际解压并编译的目录为 `build/pkg_163817`。

**359 个编译相关文件全部与 ZIP 逐字节相同，也与当前项目源码相同。** 范围包括所有打包的 `.tex`、`.cls`、`.sty`、`.bib` 及其他样式/字体/图片格式、两个 `logo.pdf`，并额外核对了两套 `tools/build.py` 和 `tools/build.sh`。同样核对了单位测试及 QA 中的 TeX 文件，未只检查实际正文。运行中产生的 build 子目录不计入源码输入。

输入集合的稳定摘要为：

`8435d0c2bd687e241f9641dfd30e98ca8b7c6a53533098e21565804ece2410b3`

该摘要只依赖每个编译输入的路径及字节，不依赖 ZIP 时间戳或新增的 JSON/Markdown 复核材料。因此最后仅增补 QA 后重新打包，可以重跑审查，证明成品所用编译输入仍然相同。

递归跟踪两个正式入口的本地依赖，`main.tex` 闭包为 210 个文件，`solutions/main.tex` 闭包为 28 个文件；均无缺失依赖或需要人工补判的动态路径。模板所需 TeX Live 标准包单独记录为外部安装依赖，没有当作包内遗漏。

重点文件 `backmatter/bibliography_order.tex` 在 ZIP 和 stage 中均存在且字节相同，其预先引用顺序严格为 `b1` 到 `b703`，未缺项或乱序。两个模板、两个标志 PDF、两份参考文献、两幅整体结构图、解答的书内链接映射均核验通过。ZIP CRC、清单中的哈希、重复项、Windows 文件名大小写冲突及不安全相对路径检查也全部通过。

审查工具仅写 QA 报告，没有修改 ZIP、stage 或编译输入。实际五步编译是否完成由主构建报告另行记录，本报告不以文件齐全代替编译成功。

## Windows 路径问题的独立证据

已读取旧解压目录 `qa/source_bundle_rebuild_20261116_163710` 的两份 `main-pass1.txt`：

- 译本日志报告 `backmatter/bibliography_order.tex` 不存在，但该文件实际存在；其绝对路径为 **263 个字符**。
- 解答日志报告不能写入 `main.log`；相应完整路径为 **262 个字符**。
- 改用 `build/pkg_163817` 后，上述两条路径分别缩至 **239、238 个字符**，输入文件及正在写入的日志均存在。

因此旧失败与当前环境下 TeX 的长路径处理限制相符，并非归档遗漏 `bibliography_order.tex`。没有为绕过路径问题修改正文或模板。建议使用较短解压路径，例如 `D:\books\v3`。具体路径和观察见 `archive_windows_path_evidence.json`。

## 最后重打包后的复验

在第三卷项目根目录执行：

```powershell
python -B -X utf8 tools/verify_archive_build_inputs.py --stage build/pkg_163817 --report qa/archive_build_inputs.json
```

以最后一次输出的 `verification_passed: true`、输入集合摘要和归档 SHA 为准。若只新增非编译 QA 材料，ZIP 哈希会改变，但上面的输入集合摘要保持不变。完整逐文件证据、两个依赖闭包和关键文件哈希都在 `archive_build_inputs.json`。
