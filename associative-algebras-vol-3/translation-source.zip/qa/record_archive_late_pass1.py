from pathlib import Path
import json, hashlib

root = Path(__file__).resolve().parents[1]
read = lambda p: json.loads((root / p).read_text(encoding='utf-8'))
c = read('qa/archive_xix_xx_body_comparison.json')
prior = read('qa/release_xix_xx_review.json')
assert c['old']['sha256'] == prior['sha256']
fixed_pdf = root/'build/before_marker/main.pdf'
assert hashlib.sha256(fixed_pdf.read_bytes()).hexdigest() == c['new']['sha256']
viewed = [268,269,270,271,276,277,278,279,281,282,283,284,285,286,287,288,289,290,291,292,293,294,295,296,297,298,299,300,301,302,303,313,314,315,316,317,318,319,320,321,322,323,324,325]
assert set(c['new_pages_added_or_visually_changed']) <= set(viewed)
matches = {x['new_page']: x for x in c['exact_body_matches']}
hashes = {x['page']: x['sha256_rgb'] for x in c['new']['pages']}
prior_evidence = {x['new_page']: x for x in prior['page_evidence']}
evidence = []
for n in range(251,328):
    e = {'page': n, 'body_pixel_sha256': hashes[n]}
    if n in viewed:
        path = f'qa/archive_visual_late_pages/p{n:03}.png'
        e.update(method='actually_viewed_individual_page_image', image=path,
                 image_sha256=hashlib.sha256((root/path).read_bytes()).hexdigest(), render_scale=1.8)
    else:
        m = matches[n]
        assert m['old_page'] in prior_evidence
        e.update(method='exact_rendered_body_pixel_transfer', old_page=m['old_page'],
                 prior_review='qa/release_xix_xx_review.json', prior_evidence=prior_evidence[m['old_page']])
    evidence.append(e)
fixes = [
    {'object':'XIX.2.2 proof heading', 'old_page':269, 'new_page':270, 'status':'resolved', 'observation':'Proof heading and text begin together; previous page ends with the statement.'},
    {'object':'XIX.3.13 case 1 introduction and diagram', 'old_page':277, 'new_page':278, 'status':'resolved', 'observation':'Case 1 introduction and its quiver are together.'},
    {'object':'XIX.3.18 r=4 introduction and diagram', 'old_page':282, 'new_page':283, 'status':'resolved', 'observation':'The r=4 introduction is immediately followed by its complete diagram.'},
    {'object':'XIX exercise 4 introduction and diagram', 'old_page':286, 'new_page':287, 'status':'resolved', 'observation':'Exercise 4 starts together with its first defining quiver.'},
    {'object':'XX.1.2 theorem', 'old_page':288, 'new_page':290, 'status':'resolved', 'observation':'Heading, setup and both conditions are together.'},
    {'object':'XX.4.16 definition', 'old_page':314, 'new_page':316, 'status':'resolved', 'observation':'Heading, setup and all five defining conditions are together.'},
    {'object':'XX.5.1 definition', 'old_page':319, 'new_page':321, 'status':'resolved', 'observation':'Heading, setup and complete part (a) are together.'}
]
r = {
    'pdf':str(fixed_pdf), 'original_build_path':c['new']['pdf'], 'sha256':c['new']['sha256'], 'total_pdf_pages':390,
    'scope':'XIX and XX, physical PDF pages 251-327 inclusive',
    'covered_physical_pages':[251,327], 'covered_page_count':77,
    'actual_pages_viewed':viewed, 'actual_viewed_count':len(viewed),
    'all_changed_pages_actually_viewed':True, 'changed_pages_count':37,
    'exact_match_total':40, 'pages_covered_only_by_exact_match_transfer':33,
    'comparison':'qa/archive_xix_xx_body_comparison.json',
    'page_evidence':evidence, 'fixes':fixes,
    'issues':[
       {'object':'XX.5.13 theorem', 'page':324, 'continued_on':325, 'status':'reported_to_root_for_next_build', 'observation':'Only the theorem setup remains at page bottom; both conditions start on the next page.'}
    ],
    'accepted_layout_observations':[
       {'page':288, 'observation':'Chapter XIX ends with exercise 7(b), three short lines at the top. Large chapter-end whitespace is retained as normal final-page pagination.'},
       {'page':278, 'observation':'Five quiver cases fit intact; the E8 case is necessarily smaller. No clipping or new collision was found.'},
       {'page':291, 'observation':'The period after cyclic component appears alone on the following line. This is pre-existing: old physical page 290 text extraction shows the same isolated period. It is a minor typographic issue outside the seven target repairs.'}
    ],
    'new_clipping_or_obstruction_found':[],
    'inputs_modified':False,
    'status':'All 77 pages covered; seven target repairs resolved. Awaiting final delta build for one additionally reported theorem-header split.',
    'limitations':[
       'This is a layout acceptance pass, not a fresh mathematical proof or original-PDF fidelity audit.',
       'Exact-pixel transfer covers the body above the bottom 65pt only; footer and link target checks are separate.',
       'Only pages listed in actual_pages_viewed were actually viewed during this pass; rendered-only pages are not counted.'
    ]
}
(root/'qa/archive_visual_late_pass1.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'output':'qa/archive_visual_late_pass1.json','covered':77,'actual':len(viewed),'transfer_only':33,'sha256':r['sha256']},ensure_ascii=False))
