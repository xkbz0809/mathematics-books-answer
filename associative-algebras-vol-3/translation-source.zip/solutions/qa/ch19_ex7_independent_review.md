# XIX.7(b) independent review

Reviewer: volume2_final_visual. Scope: source-parameter correction, derived heart argument, and location of the tilting module. No edits to root-owned solution files.

The parameter correction is supported by the primary author PDF of Barot–Lenzing, "Derived Canonical Algebras as One-Point Extensions", section 1:
https://www.matem.unam.mx/~barot/articles/dercanon.pdf
It explicitly identifies derived-equivalence classes with isomorphism classes of associated weighted projective lines. Thus parameters 2 and 3 over C, with distinct cross-ratio orbits, give a valid counterexample to arbitrary choice at weight (2,2,2,2).

Gregory 2021, Proposition 9.2:
https://londmathsoc.onlinelibrary.wiley.com/doi/full/10.1112/plms.12403
The primary text explicitly places mod-Gamma in coh_ge(X) vee coh_minus(X)[1], and twists the bundle above lcm(weights). The solution's inverse-heart sign Y direct-sum Z[1] is correct. Hereditariness then gives Hom(V,Y[j] direct-sum Z[j+1])=0 for j>=2, so the claimed projective-dimension bound follows.

Suggested precision for geometric placement: a nonzero object on the right of the torsion-sheaf tube family has inverse image Z[1] for a vector bundle Z. Choose a simple finite-length sheaf S with Hom(Z,tau S) nonzero (a nonzero fibre); Serre duality gives Hom(S,Z[1]) nonzero. Since Hom(S,V')=0 for all finite-length S and a vector bundle V', the constructed module cannot lie on that right side. This closes the final positional inference rather than relying only on the words "separation order".

Verdict: the reviewed argument is mathematically supported, subject to adding or citing this explicit placement criterion. Root was informed. This is not an independent audit of all seven XIX answers.
