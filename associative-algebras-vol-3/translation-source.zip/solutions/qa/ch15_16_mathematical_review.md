# XV/XVI exercise review

Scope: all 5 exercises of XV and all 8 exercises of XVI. Original PDF exercise pages 76–78 and 114–116 were rendered and visually read, including arrow directions and zero relations. Original PDF is unchanged. This is the author's verification of the independently written solutions, not a claim of a second independent mathematical review.

## Exact checks

- `tools/ch16_branches.py` constructs the explicit interval tiltings for XVI.2 and XVI.3, verifies all 121 and 289 Ext entries respectively, all End arrows and displayed zero relations. End dimensions are 30 and 44.
- The same script enumerates all string modules for XVI.6, XVI.7 and XVI.8 (15, 24, 26 modules), computes Hom spaces, irreducible arrows, translations, and connected section mutations. Section counts are exactly 1, 1, 2. The final XVI.8 source diagram has **nine** vertices, obtained by removing both bottom-tail vertices 0 and 1 from the eleven-vertex diagram of XVI.2. An initial private trial accidentally retained one extra vertex; it was corrected by re-opening the original figure before writing the final solution. No false section count reached the TeX answer.
- `tools/ch15_exact.py` retains labels on parallel arrows, verifies XV.2's six summands over the two-arm hereditary quiver of arm lengths 4 and 2. Hom equals Euler, all Ext vanish, and the dimension matrix equals the proposed bound algebra's Cartan matrix. The actual generators/relations are justified in the TeX proof. Exact DTr computes the six injective orbits through the displayed connecting section.
- `qa/ch15_preinjective_mesh.json` verifies 17 complete meshes including all finite-boundary meshes of XV.2's explicit repeated-quiver cut. This is supplementary arithmetic evidence, not the reason for infinite exhaustion; the latter follows from the connecting-section theorem as explained in the answer.
- XV.3 core-mouth tau cycles, XV.4 core-mouth tau cycle and XV.5 core-mouth tau cycle were computed by exact DTr and compared with the listed thin supports. Their resulting component ranks are (5,6), 15 and 8.
- XV.1's explicit four-subspace tilting representation and five-orbit boundary agree with the already checked construction used in Volume 2 XII.13. The current answer includes the representations, Hom/Euler matrix, relation generators and projective-presentation table rather than merely referring to that answer.

## Source corrections and false assertions

### XVI.8, printed p.102, PDF p.116

The first line defines B. The last line says Γ(mod A′) of A′ has precisely two sections. A′ is the eight-vertex algebra of XVI.7, whose unique section is explicitly proved in the preceding answer. The nine-vertex graph actually displayed in XVI.8 gives B, with exactly two explicitly listed sections. Correct the two final A′ tokens to B. The proof exhibits the almost split sequence

0 → [5] → [2,3,4,5] → [2,3,4] → 0,

and proves exhaustion by section mutation. This is a symbol correction, not a change to the quiver or relations.

### XVI.2.2(b,c), XVI.2.3(ii), XVI.2.4(i,ii)

Printed pp.79–80 and 89–90 (PDF pp.93–94 and 103–104) contain stronger uniqueness claims that fail already for H2=K(2→1). Write I=M[1,1], P=M[1,2], J=M[2,2]. The AR quiver is I→P→J and τJ=I. Both {I,P} and {P,J} are convex sections meeting each tau orbit once, and both are equioriented A2. Both H2=I⊕P and DH2=P⊕J are distinct basic tilting modules with endomorphism algebra isomorphic to H2. No qualification “up to translation” appears in these claims. This was communicated to the translation owner, who should preserve the source claims with a reliable explanatory note. The exercise solutions use only the valid existence statements and give their own proof of the additional criterion for uniqueness of **all** sections in XVI.5.

## Unit builds and visual checks

Both chapters passed the five-step XeLaTeX/Biber build. Subsequent local display-escape and pagination corrections were rebuilt. XV has 8 unit pages; XVI has 7. All pages were inspected using contact sheets and detail renders. The common AR notation at the start of XV is locally set in small type so the definitions occupy one complete page instead of leaving a three-line second page. Two lost command backslashes in the XVI draft were visible in the rendered PDF and were repaired; final displays were re-opened. No overfull boxes or undefined references remain in either unit log.

The unit `bookref` macro is intentionally a placeholder supplied by root; final external translation links, integrated pagination, bookmark destinations and a final independent mathematical review remain integration duties. `qa/ch15_16_review.json` records the final unit PDF hashes.
