from ch17_specs import algebra,ROOT,inv
from ch17_strings import homthin,asrep,calculate
from ch15_exact import Alg,hom,z,F
from itertools import product
import json
def brute6(d):
 N=len(d['modules']);E=d['AR_arrows'];reach=[[False]*N for _ in range(N)]
 for a,b in E:reach[a][b]=True
 for k in range(N):
  for i in range(N):
   if reach[i][k]:
    for j in range(N):reach[i][j]|=reach[k][j]
 found=[]
 for sec in product(*d['orbits']):
  S=set(sec);seen={sec[0]}
  while True:
   new=seen|{b for a,b in E if a in seen and b in S}|{a for a,b in E if b in seen and a in S}
   if new==seen:break
   seen=new
  if seen!=S:continue
  if any(any(reach[a][x]for a in S)and any(reach[x][b]for b in S)for x in range(N)if x not in S):continue
  found.append(list(sec))
 return found
def recover(k,d,U):
 B=algebra(k);SS=set(U);Harr=[];fmap=[]
 for a,b in d['AR_arrows']:
  if a in SS and b in SS:Harr.append((U.index(b),U.index(a)));fmap.append(d['AR_maps'][f'{a},{b}'])
 T=[]
 for v in range(B.n):
  dims=[int(v in d['modules'][i]['vertices'])for i in U];ar={}
  for t,(a,b)in enumerate(Harr):ar[t]=[[F(fmap[t][v])]]if dims[a]and dims[b]else z(dims[b],dims[a])
  T.append((dims,ar))
 HH=[[len(hom(M,N,Harr))for N in T]for M in T]
 EE=[[sum(x*y for x,y in zip(M[0],N[0]))-sum(M[0][a]*N[0][b]for a,b in Harr)for N in T]for M in T]
 C=[[len(B.basis.get((i,j),[]))for i in range(B.n)]for j in range(B.n)]
 assert HH==EE==C,(k,HH,EE,C)
 return {'section_U':U,'H_arrows':Harr,'T_dimensions':[M[0]for M in T],'T_arrow_scalars':[[int(M[1][t][0][0])if M[1][t]and M[1][t][0]else 0 for t in range(len(Harr))]for M in T],'Hom':HH,'all_Ext_zero':True,'End_Cartan_verified':True}
def run():
 D=json.loads((ROOT/'qa/ch17_string_ar.json').read_text('utf8'));found=brute6(D['6']);print('independent direct section search6',found)
 out={'6_all_sections_independent':found,'6':recover(6,D['6'],[3,15,10,16,11,18,12,19]),'8':recover(8,D['8'],D['8']['selected_section']['vertices'])}
 H=Alg(2,[(0,1)],[]);ar=calculate(H,'A2_calibration');T=[H.projective(i)for i in range(2)];HH=[[len(hom(M,N,H.arr))for N in T]for M in T]
 out['A2_calibration']={'H_arrows':H.arr,'P_Hom':HH,'regular_End_arrows':[(0,1)],'injective_modules':[H.injective(i)[0]for i in range(2)],'complete_AR':ar}
 print('H6',out['6']['H_arrows']);print('T6',out['6']['T_dimensions']);print('H8',out['8']['H_arrows']);
 (ROOT/'qa/ch17_slices_tiltings.json').write_text(json.dumps(out,indent=2),'utf8')
if __name__=='__main__':run()
