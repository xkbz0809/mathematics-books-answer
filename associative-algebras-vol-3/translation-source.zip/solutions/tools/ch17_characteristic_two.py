"""Independently regenerate all normalized tiltings in characteristic two."""
from pathlib import Path
from fractions import Fraction
import json,random,argparse
import ch15_exact as ex
import ch17_end_algebras as en
import ch17_end_isomorphisms as iso
R=Path(__file__).resolve().parents[1]
class F2(int):
 def __new__(cls,x=0):
  if isinstance(x,str):x=Fraction(x)
  if isinstance(x,Fraction):
   if x.denominator%2==0:raise ZeroDivisionError('even denominator')
   x=x.numerator
  return int.__new__(cls,int(x)%2)
 def __add__(a,b):return F2(int(a)+int(b))
 __radd__=__add__
 def __sub__(a,b):return F2(int(a)-int(b))
 def __rsub__(a,b):return F2(int(b)-int(a))
 def __mul__(a,b):return F2(int(a)*int(b))
 __rmul__=__mul__
 def __truediv__(a,b):
  if not F2(b):raise ZeroDivisionError
  return F2(a)
 def __rtruediv__(a,b):
  if not a:raise ZeroDivisionError
  return F2(b)
 def __neg__(a):return a
 def __pow__(a,b):
  if b<0 and not a:raise ZeroDivisionError
  return F2(1)if b==0 else a
def mod_torus(A,c,n):return [F2(1)]*n if all(F2(x)==1 for x in c)else None
def run(kind,op):
 ex.F=F2;en.F=F2;iso.F=F2;iso.torus=mod_torus
 tag=f'{kind}_{"op"if op else"orig"}';data=json.loads((R/f'qa/ch17_ex11_13_{tag}.json').read_text('utf8'));catalog=json.loads((R/f'qa/ch17_ex11_13_{kind}_isomorphisms.json').read_text('utf8'));refs={g['representative']['cartan_key']:g['representative']for g in catalog['classes']}
 rng=random.Random(211317);ms=[];trials=[]
 for ci,c in enumerate(data['candidates']):
  d=c['dim']
  for attempt in range(10000):
   M=(d,{t:[[F2(rng.randrange(2))for _ in range(d[a])]for _ in range(d[b])]for t,(a,b)in enumerate(data['arrows'])})
   if len(ex.hom(M,M,data['arrows']))==1:break
  else:raise RuntimeError(('no absolutely indecomposable realization',tag,ci,d))
  ms.append(M);trials.append(attempt+1)
 print(tag,'char2 representations',len(ms),'max trials',max(trials),flush=True)
 HB={};used={(i,j)for T in data['normalized_tiltings']for i in T for j in T}
 for i,j in sorted(used):
  HB[i,j]=ex.hom(ms[i],ms[j],data['arrows']);assert len(HB[i,j])==data['Hom'][i][j],(tag,i,j,len(HB[i,j]),data['Hom'][i][j])
 print(tag,'char2 Hom pairs',len(HB),flush=True)
 out=[];failed=[]
 for gi,(key,Ts)in enumerate(data['cartan_groups'].items()):
  for T in Ts:
   B=en.build_end(T,ms,HB)
   if op:
    B['arrows']=[(b,a)for a,b in B['arrows']];B['relations']=[[(c,tuple(reversed(p)))for c,p in rel]for rel in B['relations']];B['Cartan']=ex.tr(B['Cartan'])
   w=iso.iso(B,refs[key])
   if w is None:failed.append({'T':T,'algebra':B,'target':refs[key]})
   else:out.append({'T':T,'cartan_key':key,'algebra':B,'isomorphism':w})
  if gi%20==0:print(tag,'char2 groups',gi+1,'failed',len(failed),flush=True)
 result={'kind':kind,'opposite_input':op,'field':'F2, with extension to every algebraically closed field of characteristic 2','representations':ms,'trials':trials,'Hom_pairs_verified':len(HB),'verified':out,'failed':failed,'status':'complete'if not failed else'failed'}
 (R/f'qa/ch17_ex11_13_{tag}_characteristic_two.json').write_text(json.dumps(result,separators=(',',':')),'utf8');print(tag,'char2 finished',len(out),'failed',len(failed),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['D4','D5','E6']);ap.add_argument('--op',action='store_true');a=ap.parse_args();run(a.kind,a.op)
