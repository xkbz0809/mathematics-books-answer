"""Render explicit verified answers XVIII.5--9 and retain wildness witnesses."""
import json
from ch17_specs import ROOT
from ch18_specs import H,B
intro={
5:r"""把所求遗传箭图的中心记作 $0$，三臂取为
\[
 2\to1\to0,\qquad4\to3\to0,\qquad7\to6\to5\to0.
\]
将题给 $B$ 的顶点按下列箭编号：
\[
 1\to0,\quad2\xrightarrow{\gamma}1,\quad3\xrightarrow{\sigma}2,\quad
 3\xrightarrow{\beta}4\xrightarrow{\alpha}1,\quad5\to2,\quad6\to3,\quad4\to7.
\]
关系为 $\sigma\gamma=\beta\alpha$；这里乘积按先左后右的路书写顺序理解.""",
6:r"""将所求遗传箭图编号为
\[
 1\to0,\qquad4\to3\to2\to0,\qquad8\to7\to6\to5\to0.
\]
将题给 $B$ 的箭编号为
\[
 0\xrightarrow{\alpha}1\xrightarrow{\beta}2\xrightarrow{\gamma}3,\qquad
 1\to4\to5,\qquad8\to7\to6\to2.
\]
唯一关系为三箭路 $\alpha\beta\gamma=0$.""",
7:r"""将所求遗传箭图编号为
\[
 1\to0,\qquad3\to2\to0,\qquad9\to8\to7\to6\to5\to4\to0.
\]
题给 $B$ 的编号则取为
\[
\begin{gathered}
 0\xrightarrow{\alpha}1\xrightarrow{\beta}2,\qquad
 0\xrightarrow{\gamma}3\xrightarrow{\sigma}2,\qquad
 4\xrightarrow{\xi}0,\quad5\to0,\\
 3\to6\to7\leftarrow8\leftarrow9 .
\end{gathered}
\]
关系为 $\alpha\beta=\gamma\sigma$ 及 $\xi\alpha=0$.""",
8:r"""把所求遗传箭图编号为
\[
 1\to0,\qquad1\to2\to3\to4\to0,\qquad5\to1.
\]
在题给菱形中，把上、左、下、右四点依次编号 $0,1,2,3$，竖直内部两点自上而下编号 $4,5$，于是箭为
\[
 0\xrightarrow{\alpha}1,\quad2\xrightarrow{\gamma}1,\quad
 3\xrightarrow{\beta}0,\quad3\xrightarrow{\sigma}2,\quad0\to4\to5\to2,
\]
关系为 $\beta\alpha=\sigma\gamma$.""",
9:r"""将所求野遗传箭图编号为
\[
 4\to3\to2\to1\to0,\qquad0\to5,\quad0\to6,\quad7\to4,\quad9\to8\to4.
\]
在题给 $B$ 中，源、汇分别标为 $0,1$，六箭长路的内部顶点依次为 $2,3,4,5,6$，其余两条源汇路为 $0\to7\to1$ 和 $0\to8\to1$，另有 $8\to9$. 三条源汇路之和为零."""
}
out=[]
wild={}
for k in range(5,10):
 d=json.loads((ROOT/f'qa/ch18_{k}_end_verified.json').read_text());n,arr=H[k];ts=d['tilting']
 out.append('\\Sol{XVIII}{'+str(k)+'}\n'+intro[k])
 out.append(r"""
记 $P_i$ 为这一遗传代数 $H$ 的顶点 $i$ 处投射模，按 $B$ 的顶点次序令
\[
 T=\bigoplus_{v=0}^{"""+str(n-1)+r"""}T_v,\qquad T_v=\tau_H^{-m_v}P_{i_v}.
\]
以下表格给出实际所需的全部直和项：
\[
\begin{array}{c|"""+'c'*n+"}\nv&"+'&'.join(map(str,range(n)))+r"\\\hline"+"\nm_v&"+'&'.join(str(v['m'])for v in ts)+r"\\"+"\ni_v&"+'&'.join(str(v['i'])for v in ts)+r"""
\end{array}
\]
""")
 out.append(r"""用前题的后投射 Hom 公式 \eqref{sol:XVIII:ppHom} 逐对计算，再减去遗传 Euler 配对，全部一次扩张维数均为零. 各直和项互不同构且恰有 """+str(n)+r""" 项，因此 $T$ 为后投射倾斜模.""")
 if k==5: out.append(r"""非恒等 Hom 模去经过其他直和项的复合，恰留下所列八支箭. 从顶点 $3$ 到 $1$ 的两条路给出同一个一维空间；选择箭的基后，两复合相等. 其余路独立，故没有其他关系.""")
 if k==6: out.append(r"""非恒等 Hom 模去二次根基恰留下所列八支箭. 三箭复合 $\alpha\beta\gamma$ 为零，而不含该禁路的路像线性无关，因此恰有这一条生成关系.""")
 if k==7: out.append(r"""非恒等 Hom 模去二次根基恰留下所列十支箭. 菱形两路的复合相等，另有 $\xi\alpha=0$；全部不被这两条关系消去的基路径的像线性无关.""")
 if k==8: out.append(r"""非恒等 Hom 模去二次根基恰留下所列七支箭. 菱形两路的复合在选择基后相等；竖直三箭路及其可复合延伸不产生额外关系. 逐端点的基路径像均线性无关.""")
 if k==9: out.append(r"""三条源汇路张成二维 Hom 空间，唯一线性关系的三个系数全非零；选取箭的基使关系成为三路之和为零. 其余基路径的像线性无关，另一个端点 $9$ 不引入新关系.""")
 out.append(r"""所得自同态代数的维数为 $"""+str(d['End_dimension'])+r"""$，等于题给束缚箭图代数的维数，故上面的箭映射诱导
\[
 \operatorname{End}_H(T)\cong B.
\]
这些核验可在后投射网格范畴中完成；所有关系系数均可选为 $0,\pm1$，因而同一构造适用于任意特征.""")
 v=[1.0]*n
 for _ in range(100):
  w=list(v)
  for a,b in arr:w[a]+=v[b];w[b]+=v[a]
  z=max(w);v=[x/z for x in w]
 for scale in range(2,101):
  y=[round(scale*x)for x in v];q=sum(x*x for x in y)-sum(y[a]*y[b]for a,b in arr)
  if q<0:break
 assert q<0;wild[k]={'vector':y,'q':q}
 out.append(r"""此外，向量 $y=("""+','.join(map(str,y))+r""")$ 满足 $q_H(y)="""+str(q)+r"""<0$，所以 $H$ 确为野遗传代数. 这证明 $B$ 是题目指定定向的野隐蔽代数，而不仅是与该底图导出等价的代数.""")
p=ROOT/'chapters/ch18.tex';s=p.read_text('utf8');assert r'\Sol{XVIII}{5}'not in s
p.write_text(s+'\n\n'+'\n\n'.join(out)+'\n','utf8')
(ROOT/'qa/ch18_wild_witnesses.json').write_text(json.dumps(wild,indent=2),'utf8')
