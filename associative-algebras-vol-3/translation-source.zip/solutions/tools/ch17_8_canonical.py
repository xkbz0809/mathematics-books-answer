import json
from ch15_exact import hom,thin
from ch17_specs import ROOT as r,algebra,info
S=json.loads((r/'qa/ch17_slices_tiltings.json').read_text());A=json.loads((r/'qa/ch17_ar_coordinates.json').read_text());B=json.loads((r/'qa/ch17_string_ar.json').read_text())['8'];d=A['8'];H=set(map(tuple,d['H_arrows']));cycle=[0,8,9,7,1,2,3,4,5,6,10,11,12,14,16,15,13];base=[int((cycle[i],cycle[(i+1)%17])in H)for i in range(17)];ht=[0]
for j,b in enumerate(base):ht.append(ht[-1]+int(j<7)-b)
assert ht[-1]==0;h={i:v for i,v in zip(cycle,ht)};coords={(m,i):u for m,i,u in d['coordinates']};order=[4,8,9,7,1,2,3,13,15,16,14,12,11,10,6,5,0];usi=[coords[h[i],i]for i in order];U=[[int(v in B['modules'][u]['vertices'])for v in range(17)]for u in usi];T=list(map(list,zip(*U)));arr=[(16,1)]+[(i,i+1)for i in range(1,6)]+[(6,0),(16,7)]+[(i,i+1)for i in range(7,15)]+[(15,0)];M=[thin(17,arr,[i for i,v in enumerate(x)if v])for x in T];HH=[[len(hom(x,y,arr))for y in M]for x in M];E=[[sum(a*b for a,b in zip(x,y))-sum(x[i]*y[j]for i,j in arr)for y in T]for x in T];assert HH==E==info(algebra(8))['C'];tau={int(i):j for i,j in B['tau'].items()};it={j:i for i,j in tau.items()};where={};bounds=[]
for i,u in enumerate(usi):
 j=u;m=0;where[0,i]=u
 while j in tau:j=tau[j];m+=1;where[m,i]=j
 hi=m;j=u;m=0
 while j in it:j=it[j];m-=1;where[m,i]=j
 bounds.append([m,hi])
S['8_canonical_7_10']={'section_U':usi,'H_arrows':arr,'T_dimensions':T,'Hom':HH,'all_Ext_zero':True};A['8_canonical_7_10']={'H_arrows':arr,'T_supports':[[i for i,v in enumerate(x)if v]for x in T],'U_supports':[[i for i,v in enumerate(x)if v]for x in U],'bounds':bounds,'count':171,'arrows':308,'coordinates':[[m,i,u]for(m,i),u in where.items()]};(r/'qa/ch17_slices_tiltings.json').write_text(json.dumps(S,indent=2),'utf8');(r/'qa/ch17_ar_coordinates.json').write_text(json.dumps(A,indent=2),'utf8');print('T',A['8_canonical_7_10']['T_supports']);print('bounds',bounds)
