"""Publish the exhaustively certified XVII.11--13 catalogue and finite-bound audit."""
from pathlib import Path
import json,csv,math
from ch17_tilting_search import hereditary,mm,inv,tran,mv
R=Path(__file__).resolve().parents[1]
summary={};catalogue=[]
for kind,num in [('D4',11),('D5',12),('E6',13)]:
    d=json.loads((R/f'qa/ch17_ex11_13_{kind}_isomorphisms.json').read_text('utf8'))
    assert not d['unresolved']
    n,arrows,period=hereditary(kind)
    finite_bounds=[]
    raw={}
    for side in ['orig','op']:
        raw[side]=a=json.loads((R/f'qa/ch17_ex11_13_{kind}_{side}.json').read_text('utf8'))
        arr=a['arrows'];E=[[int(i==j)-int([i,j]in arr)for j in range(n)]for i in range(n)]
        C=tran(inv(E));phi=[[-int(x)for x in row]for row in mm(inv(E),tran(E))];psi=inv(phi)
        delta=a['delta'];powers={}
        for name,M in [('Phi',phi),('Psi',psi)]:
            p=[[int(i==j)for j in range(n)]for i in range(n)]
            for t in range(period):p=mm(M,p)
            N=[[int(p[i][j])-int(i==j)for j in range(n)]for i in range(n)]
            assert not any(x for row in mm(N,N)for x in row)
            powers[name]=N
        families={}
        for fam,M,initial in [('P',psi,list(zip(*C))),('I',phi,C)]:
            shifts=[];v=[tuple(map(int,x))for x in initial]
            for m in range(period):
                for i,x in enumerate(v):
                    w=mv(powers['Psi'if fam=='P'else'Phi'],x)
                    assert all(w[j]*delta[0]==w[0]*delta[j]for j in range(n))and w[0]>0
                    shifts.append([m,i,w[0],delta[0]])
                v=[mv(M,x)for x in v]
            assert all(min(x)>0 for x in v)
            families[fam]={'positive_shifts_in_delta_units':shifts,'all_vectors_at_period_strictly_positive':True}
        ca=json.loads((R/f'qa/ch17_ex11_13_{kind}_{side}_characteristic_audit.json').read_text('utf8'))
        # The characteristic audit records every denominator, rank pivot and isomorphism determinant.
        finite_bounds.append({'side':side,'period':period,'delta':delta,'power_minus_identity':powers,'families':families,'characteristic_audit_file':f'ch17_ex11_13_{kind}_{side}_characteristic_audit.json'})
        char2=R/f'qa/ch17_ex11_13_{kind}_{side}_characteristic_two.json'
        if char2.exists():assert not json.loads(char2.read_text('utf8'))['failed']
    tex=[r'\begingroup\footnotesize',r'\setlength{\tabcolsep}{3pt}',r'\renewcommand{\arraystretch}{1.25}',r'\begin{longtable}{@{}p{.075\textwidth}p{.49\textwidth}p{.39\textwidth}@{}}',r'编号 & 箭与生成关系 & 倾斜模各直和项的维数向量\\\hline',r'\endfirsthead',r'编号 & 箭与生成关系 & 倾斜模各直和项的维数向量\\\hline',r'\endhead']
    for c in d['classes']:
        a=c['representative'];names='abcdefghijklmno';arrowtexts=[f'{names[i]}:{x+1}\\to {y+1}'for i,(x,y)in enumerate(a['arrows'])]
        reltexts=[]
        for rel in a['relations']:
            st=''
            for co,path in rel:
                assert str(co)in ['1','-1'];term=''.join(names[i]for i in path)
                st+=('+'if st and str(co)=='1'else'-'if str(co)=='-1'else'')+term
            reltexts.append(st+'=0')
        vectors=[raw[a['input']]['candidates'][i]['dim']for i in a['T']]
        assert max(max(v)for v in vectors)<10
        vtexts=[''.join(map(str,v))for v in vectors]
        # Two arrows per visual line; all vertex numbers are 1-based in the printed catalogue.
        alines=[r',\quad '.join(arrowtexts[i:i+2])for i in range(0,len(arrowtexts),2)]
        rlines=[r',\quad '.join(reltexts[i:i+2])for i in range(0,len(reltexts),2)]if reltexts else [r'I=0']
        maths=lambda ls:'$\\begin{gathered}[t]'+r'\\'.join(ls)+r'\end{gathered}$'
        vv=[r'\mathtt{'+','.join(vtexts[i:i+2])+'}'for i in range(0,len(vtexts),2)]
        tex.append(f"{kind}-{c['id']:03d} & "+maths(alines+rlines)+' & '+maths(vv)+r'\\\hline')
        catalogue.append({'type':kind,'id':c['id'],'vertex_count':n,'arrows':[[x+1,y+1]for x,y in a['arrows']],'relations':a['relations'],'arrow_names':list(names[:len(a['arrows'])]),'tilting_dimensions':vectors,'dimension':a['dimension'],'Cartan':a['Cartan'],'normalized_representatives':c['group_size']})
    tex += [r'\end{longtable}',r'\endgroup']
    (R/f'chapters/ch17_catalogue_{kind}.tex').write_text('\n'.join(tex)+'\n','utf8')
    summary[kind]={'classes':len(d['classes']),'tiltings':d['normalized_tilting_count'],'bounds':finite_bounds,'all_isomorphisms_verified':True,'cartan_groups_distinct':True,'candidate_counts':{s:len(a['candidates'])for s,a in raw.items()},'tiltings_per_side':{s:len(a['normalized_tiltings'])for s,a in raw.items()}}
(R/'qa/ch17_ex11_13_catalogue.json').write_text(json.dumps(catalogue,ensure_ascii=False,indent=2),'utf8')
(R/'qa/ch17_ex11_13_completeness.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),'utf8')
with (R/'qa/ch17_ex11_13_catalogue.csv').open('w',encoding='utf-8-sig',newline='')as f:
    w=csv.DictWriter(f,fieldnames=catalogue[0].keys());w.writeheader();w.writerows(catalogue)
print({k:{a:v for a,v in d.items()if a!='bounds'}for k,d in summary.items()})
