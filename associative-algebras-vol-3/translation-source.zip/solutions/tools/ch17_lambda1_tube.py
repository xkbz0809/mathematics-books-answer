"""Exact local Hom/radical computation for the doubly framed nilpotent Jordan tube."""
from ch15_exact import F,z,rr,null,hom
from ch17_specs import ROOT
import json
def mm(A,B):return [[sum(x*y for x,y in zip(r,c))for c in zip(*B)]for r in A]
def decode(v,M,N):
 at=0;out=[]
 for a,b in zip(M[0],N[0]):out.append([list(v[at+i*a:at+(i+1)*a])for i in range(b)]);at+=a*b
 return out
def flat(f):return tuple(x for A in f for row in A for x in row)
def compose(f,g,M,L,N):
 # f:M->L, g:L->N
 out=[]
 for v in range(3):
  if L[0][v]:out.append(mm(g[v],f[v]))
  else:out.append(z(N[0][v],M[0][v]))
 return out
def rep(n,s,t):
 eta=z(n,t)
 if t:eta[0][0]=1
 xi=z(s,n)
 if s:xi[0][-1]=1
 N=z(n,n)
 for i in range(n-1):N[i][i+1]=1
 return [s,n,t],{0:eta,1:xi,2:N}
def run(limit=5):
 names=[];mods=[]
 for n in range(1,limit+1):
  for f,s,t in [('R',0,0),('P',0,1),('I',1,0),('D',1,1)]:names.append(f+str(n));mods.append(rep(n,s,t))
 arr=[(2,1),(1,0),(1,1)];N=len(mods);HH=[[[]for _ in mods]for _ in mods]
 for i,M in enumerate(mods):
  for j,L in enumerate(mods):HH[i][j]=[decode(v,M,L)for v in hom(M,L,arr)]
 edges=[];radend={}
 # Non-scalar self maps are the powers of the nilpotent Jordan map.
 for i,M in enumerate(mods):
  n=M[0][1];rad=[]
  for k in range(1,n):
   a=z(n,n)
   for v in range(n-k):a[v][v+k]=1
   rad.append([z(M[0][0],M[0][0]),a,z(M[0][2],M[0][2])])
  radend[i]=rad
 for i,M in enumerate(mods):
  for j,L in enumerate(mods):
   if i==j or not HH[i][j]:continue
   vectors=set()
   for k,X in enumerate(mods):
    left=radend[i]if k==i else HH[i][k];right=radend[j]if k==j else HH[k][j]
    for f in left:
     for g in right:
      v=flat(compose(f,g,M,X,L))
      if any(v):vectors.add(v)
   nc=sum(a*b for a,b in zip(M[0],L[0]));rank=len(rr(list(vectors),nc)[1])if vectors else 0
   if len(HH[i][j])>rank:edges.append((names[i],names[j],len(HH[i][j])-rank))
 print('arrows away from truncation')
 for a,b,r in edges:
  if int(a[1:])<limit and int(b[1:])<limit:print(a,b,r)
 (ROOT/'qa/ch17_lambda1_tube.json').write_text(json.dumps({'limit':limit,'names':names,'dimensions':[x[0]for x in mods],'Hom_dimensions':[[len(v)for v in r]for r in HH],'arrows':edges},indent=2),'utf8')
if __name__=='__main__':run()
