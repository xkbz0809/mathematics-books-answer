"""Exact representations and End presentations for the classification exercises."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import json,random,argparse,time
from ch15_exact import Alg,hom,rr,null,z,tr
R=Path(__file__).resolve().parents[1]
def decode(x):
 if isinstance(x,list):return [decode(t)for t in x]
 if isinstance(x,dict):return {int(k)if k.isdigit()else k:decode(v)for k,v in x.items()}
 return F(x)if isinstance(x,str)else x
def encode(x):
 if isinstance(x,F):return int(x)if x.denominator==1 else str(x)
 if isinstance(x,(list,tuple)):return [encode(t)for t in x]
 if isinstance(x,dict):return {str(k):encode(v)for k,v in x.items()}
 return x
def ranks(B,n):return len(rr(B,n)[1])if B else 0
def reps(data):
 A=Alg(data['n'],data['arrows'],[]);O=Alg(A.n,[(b,a)for a,b in A.arr],[]);cache={};out=[];rng=random.Random(170011)
 for k,c in enumerate(data['candidates']):
  if c['kind'] in ('P','I'):
   alg=O if c['kind']=='P'else A;key=(c['kind'],c['i']);m=c['m']
   if key not in cache:cache[key]=[alg.injective(c['i'])]
   while len(cache[key])<=m:cache[key].append(alg.tau(cache[key][-1])[0])
   d,a=cache[key][m]
   if c['kind']=='P':a={t:tr(v)if d[s]and d[e]else z(d[e],d[s])for t,((s,e),v)in enumerate(zip(A.arr,a.values()))}
   M=(d,a)
  else:
   d=c['dim']
   for attempt in range(1000):
    a={t:[[F(rng.randrange(2))for _ in range(d[s])]for _ in range(d[e])]for t,(s,e)in enumerate(A.arr)};M=(d,a)
    if len(hom(M,M,A.arr))==1:break
   else:raise RuntimeError(('regular realization failed',k,c))
  assert list(M[0])==c['dim'],(k,M[0],c)
  assert len(hom(M,M,A.arr))==1,(k,c)
  out.append(M)
 return out
def split(v,dm,dn):
 out=[];j=0
 for m,n in zip(dm,dn):out.append([list(v[j+i*m:j+(i+1)*m])for i in range(n)]);j+=m*n
 return out
def compose(f,g,di,dj,dk):
 # f: i -> j, g: j -> k; return g f.
 ff=split(f,di,dj);gg=split(g,dj,dk);v=[]
 for a,b,ni,nj,nk in zip(ff,gg,di,dj,dk):
  for i in range(nk):
   for j in range(ni):v.append(sum(b[i][h]*a[h][j]for h in range(nj)))
 return v
def identity(d):return [F(i==j)for n in d for i in range(n)for j in range(n)]
def build_end(T,reps,HB):
 n=len(T);dm=[reps[i][0]for i in T];H=lambda i,j:HB[T[i],T[j]]
 arr=[];amaps=[]
 for i in range(n):
  for j in range(n):
   if i==j or not H(i,j):continue
   dim=len(H(i,j)[0]);base=[];rank=0
   for k in range(n):
    if k in (i,j):continue
    for f in H(i,k):
     for g in H(k,j):
      v=compose(f,g,dm[i],dm[k],dm[j]);r=ranks(base+[v],dim)
      if r>rank:base.append(v);rank=r
   for f in H(i,j):
    r=ranks(base+[f],dim)
    if r>rank:arr.append((j,i));amaps.append(f);base.append(f);rank=r
 paths={};ev={}
 for start in range(n):
  def walk(end,p,f):
   assert len(p)<n+2,('oriented cycle',arr)
   paths.setdefault((start,end),[]).append(p);ev[start,p]=f
   for t,(a,b)in enumerate(arr):
    if a==end:walk(b,p+(t,),compose(amaps[t],f,dm[b],dm[end],dm[start]))
  walk(start,(),identity(dm[start]))
 fullrels={}
 for (a,b),ps in paths.items():
  vectors=[ev[a,p]for p in ps];rel=null(tr(vectors),len(ps));fullrels[a,b]=rel
  assert len(ps)-len(rel)==len(H(b,a)),(T,a,b,ps,rel,len(H(b,a)))
 # Remove relations obtained by multiplying already chosen smaller relations.
 minimal=[]
 for a,b in sorted(paths,key=lambda k:max(map(len,paths[k]))):
  ps=paths[a,b];index={p:i for i,p in enumerate(ps)};base=[];rank=0
  for s,e,rel in minimal:
   for lp in paths.get((a,s),[]):
    for rp in paths.get((e,b),[]):
     v=[F(0)]*len(ps)
     for coef,p in rel:v[index[lp+p+rp]]+=coef
     zrank=ranks(base+[v],len(ps))
     if zrank>rank:base.append(v);rank=zrank
  for v in fullrels[a,b]:
   zrank=ranks(base+[v],len(ps))
   if zrank>rank:
    terms=[(x,p)for x,p in zip(v,ps)if x];minimal.append((a,b,terms));base.append(v);rank=zrank
 rels=[r for a,b,r in minimal];B=Alg(n,arr,rels)
 C=[[len(B.basis.get((i,j),[]))for i in range(n)]for j in range(n)]
 assert C==[[len(H(i,j))for j in range(n)]for i in range(n)]
 return {'T':T,'arrows':arr,'relations':rels,'dimension':sum(map(sum,C)),'Cartan':C,'max_parallel_arrows':max(arr.count(e)for e in arr)if arr else 0}
def run(kind,op):
 tag=f'{kind}_{"op"if op else"orig"}';src=R/f'qa/ch17_ex11_13_{tag}.json';data=json.loads(src.read_text('utf8'));repfile=R/f'qa/ch17_ex11_13_{tag}_representations.json'
 if repfile.exists():ms=decode(json.loads(repfile.read_text('utf8')))
 else:ms=reps(data);repfile.write_text(json.dumps(encode(ms),separators=(',',':')),'utf8')
 print(tag,'representations',len(ms),flush=True);HB={}
 # Compute only Hom spaces that occur in a compatible pair.
 used={(i,j)for T in data['normalized_tiltings']for i in T for j in T}
 for c,(i,j)in enumerate(sorted(used)):
  HB[i,j]=hom(ms[i],ms[j],data['arrows']);assert len(HB[i,j])==data['Hom'][i][j],(tag,i,j,len(HB[i,j]),data['Hom'][i][j])
 print(tag,'Hom pairs verified',len(HB),flush=True)
 results=[]
 # Keep every normalized tilting, so every Cartan-group identification is audited.
 for k,(key,Ts)in enumerate(data['cartan_groups'].items()):
  for T in Ts:
   B=build_end(T,ms,HB)
   if op:
    B['arrows']=[(b,a)for a,b in B['arrows']];B['relations']=[[(c,tuple(reversed(p)))for c,p in rel]for rel in B['relations']];B['Cartan']=tr(B['Cartan'])
   B['cartan_key']=key;results.append(B)
  if k%10==0:print(tag,'groups',k+1,'of',len(data['cartan_groups']),'algebras',len(results),flush=True)
 out={'kind':kind,'opposite_input':op,'algebras':results,'Hom_pairs_verified':len(HB),'method':'Actual rational representations; full Hom matrix checked against independent hereditary formula; rad/rad^2 arrows; path-kernel relations; quotient Cartan and dimension reverified.'}
 (R/f'qa/ch17_ex11_13_{tag}_endomorphisms.json').write_text(json.dumps(encode(out),separators=(',',':')),'utf8')
 print(tag,'done',len(results),'max parallel',max(x['max_parallel_arrows']for x in results),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['D4','D5','E6']);ap.add_argument('--op',action='store_true');a=ap.parse_args();run(a.kind,a.op)
