"""Finite normalized search of hereditary Euclidean tiltings with a given End Cartan matrix.

Every tilting with a postprojective summand can be tau-normalized to contain a
projective; the dual covers the remaining tiltings. A compatible nonprojective
X must have a zero coordinate in tau X. This bounds postprojective/preinjective
candidates within one unipotent Coxeter period. Regular candidates are all
stones, enumerated by 0 <= dim X <= delta and defect=0. Hom formulas use exact
transjective and uniserial-tube formulas, not Euler alone.
"""
from ch17_specs import algebra,info,inv,ROOT
from ch15_exact import F,null
from itertools import product
import math,json,argparse,time
def mm(A,B):return [[sum(x*y for x,y in zip(r,c))for c in zip(*B)]for r in A]
def mv(A,v):return tuple(int(sum(x*y for x,y in zip(r,v)))for r in A)
def tran(A):return list(map(list,zip(*A)))
def pair(x,E,y):return sum(x[i]*sum(E[i][j]*y[j]for j in range(len(y)))for i in range(len(x)))
def hereditary(kind):
 if kind=='E7':return 8,[(3,2),(2,1),(1,0),(4,0),(7,6),(6,5),(5,0)],12
 if kind=='E6':return 7,[(2,1),(1,0),(4,3),(3,0),(6,5),(5,0)],6
 if kind=='D4':return 5,[(2,0),(2,1),(3,2),(4,2)],2
 if kind=='D5':return 6,[(2,0),(2,1),(3,2),(4,3),(5,3)],6
 if kind=='D11':return 12,[(2,0),(2,1)]+[(i,i-1)for i in range(3,10)]+[(10,9),(11,9)],18
 if kind=='A6_11':return 17,[(i,i-1)for i in range(1,6)]+[(16,5),(6,0)]+[(i,i-1)for i in range(7,16)]+[(16,15)],66
 raise ValueError(kind)
def candidates(n,arr,period,width=0,full=False):
 E=[[int(i==j)-int((i,j)in arr)for j in range(n)]for i in range(n)];C=tran(inv(E));Phi=[[-int(v)for v in r]for r in mm(inv(E),tran(E))];Psi=inv(Phi)
 h=null([[E[i][j]+E[j][i]for j in range(n)]for i in range(n)],n)[0];den=math.lcm(*(x.denominator if isinstance(x,F)else 1 for x in h));h=tuple(int(x*den)for x in h);g=math.gcd(*h);h=tuple(x//g for x in h)
 if h[0]<0:h=tuple(-x for x in h)
 assert all(x>0 for x in h)
 powers=[[[int(i==j)for j in range(n)]for i in range(n)]]
 for t in range(period+1):powers.append(mm(Phi,powers[-1]))
 pp=[];pi=[];ppvec=[tuple(map(int,col))for col in zip(*C)];pivec=[tuple(map(int,row))for row in C]
 allpp={};allpi={}
 for m in range(period+width+1):
  for i,x in enumerate(ppvec):
   allpp[m,i]=x
   if full or m==0 or 0 in mv(Phi,x):pp.append({'kind':'P','m':m,'i':i,'dim':x})
  for i,x in enumerate(pivec):
   allpi[m,i]=x
   if full or 0 in mv(Phi,x):pi.append({'kind':'I','m':m,'i':i,'dim':x})
  ppvec=[mv(Psi,x)for x in ppvec];pivec=[mv(Phi,x)for x in pivec]
 defect=[sum(h[i]*E[i][j]for i in range(n))for j in range(n)]
 roots=set()
 for x in product(*(range(v+1)for v in h)):
  if sum(a*b for a,b in zip(defect,x)):continue
  if sum(a*a for a in x)-sum(x[a]*x[b]for a,b in arr)==1:roots.add(x)
 mouths=[];seen=set()
 for x in sorted(roots):
  if x in seen:continue
  orb=[];v=x
  while v not in orb:orb.append(v);seen.add(v);v=mv(Psi,v)
  assert v==x and all(v in roots for v in orb)
  sums=[sum(v[i]for v in orb)for i in range(n)];length=sums[0]//h[0];assert all(sums[i]==length*h[i]for i in range(n))
  if length==1:mouths.append(orb)
 rg=[]
 for t,orb in enumerate(mouths):
  r=len(orb)
  for i in range(r):
   x=[0]*n
   for l in range(1,r):
    x=[a+b for a,b in zip(x,orb[(i+l-1)%r])];rg.append({'kind':'R','tube':t,'r':r,'i':i,'l':l,'dim':tuple(x)})
 assert {x['dim']for x in rg}==roots
 cand=pp+rg+pi;N=len(cand)
 def HH(a,b):
  ka,kb=a['kind'],b['kind'];x,y=a['dim'],b['dim']
  if ka=='P'and kb=='P':return allpp[b['m']-a['m'],b['i']][a['i']]if a['m']<=b['m']else 0
  if ka=='I'and kb=='I':return allpi[a['m']-b['m'],a['i']][b['i']]if a['m']>=b['m']else 0
  if ka=='P'and kb=='I':return pair(x,E,y)
  if ka=='P'and kb=='R':
   v=y
   for _ in range(a['m']):v=mv(Phi,v)
   return v[a['i']]
  if ka=='R'and kb=='I':
   v=x
   for _ in range(b['m']):v=mv(Psi,v)
   return v[b['i']]
  if ka=='R'and kb=='R':
   if a['tube']!=b['tube']:return 0
   return int(any((a['i']+a['l']-t-b['i'])%a['r']==0 for t in range(1,min(a['l'],b['l'])+1)))
  return 0
 H=[[HH(a,b)for b in cand]for a in cand];Ex=[[H[i][j]-pair(a['dim'],E,b['dim'])for j,b in enumerate(cand)]for i,a in enumerate(cand)]
 assert all(v>=0 for row in Ex for v in row),[(i,j,v)for i,row in enumerate(Ex)for j,v in enumerate(row)if v<0][:4]
 assert all(H[i][i]==1 and Ex[i][i]==0 for i in range(N))
 print('candidate counts',len(pp),len(rg),len(pi),'total',N,flush=True)
 return cand,H,Ex,E,h
def search(cand,H,Ex,C):
 n=len(C);N=len(cand);keys={(C[i][j],C[j][i])for i in range(n)for j in range(n)if i!=j};compat={key:[0]*N for key in keys}
 for i in range(N):
  for j in range(N):
   if i!=j and not Ex[i][j]and not Ex[j][i]:
    key=H[i][j],H[j][i]
    if key in compat:compat[key][i]|=1<<j
 allmask=(1<<N)-1;nodes=0
 def rec(assign,dom):
  nonlocal nodes
  nodes+=1
  if len(assign)==n:return assign
  v=min((v for v in range(n)if v not in assign),key=lambda v:dom[v].bit_count());mask=dom[v]
  while mask:
   bit=mask&-mask;mask-=bit;c=bit.bit_length()-1;new=list(dom);good=True
   for w in range(n):
    if w not in assign and w!=v:
     new[w]&=compat[C[v][w],C[w][v]][c]
     if not new[w]:good=False;break
   if good:
    ans=rec({**assign,v:c},new)
    if ans is not None:return ans
  return None
 for c,a in enumerate(cand):
  if a['kind']!='P'or a['m']!=0:continue
  for v in range(n):
   dom=[allmask]*n;dom[v]=1<<c
   for w in range(n):
    if w!=v:dom[w]=compat[C[v][w],C[w][v]][c]
   if all(dom):
    ans=rec({v:c},dom)
    if ans is not None:return [cand[ans[v]]for v in range(n)],nodes
 return None,nodes
def run(kind,exercise):
 n,arr,period=hereditary(kind);B=algebra(exercise);assert B.n==n;C=info(B)['C'];out={}
 for dual in [False,True]:
  a=[(b,a)for a,b in arr]if dual else arr;target=tran(C)if dual else C;t=time.time();cand,H,Ex,E,h=candidates(n,a,period);ans,nodes=search(cand,H,Ex,target)
  out[str(dual)]={'candidate_count':len(cand),'nodes':nodes,'seconds':time.time()-t,'tilting':ans,'H_arrows':a,'h':h}
  print('RESULT',kind,exercise,'dual',dual,'nodes',nodes,'seconds',round(time.time()-t,2),'T',ans,flush=True)
  if ans is not None:break
 (ROOT/f'qa/ch17_{exercise}_{kind}_tilting_search.json').write_text(json.dumps(out,indent=2),'utf8')
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('kind');p.add_argument('exercise',type=int);args=p.parse_args();run(args.kind,args.exercise)
