"""Exact representations and the complete AR quiver for XVII.7."""
from pathlib import Path
import json
from fractions import Fraction as F
from ch15_exact import z, tr, rr, hom, thin
from ch17_specs import ROOT, algebra, info

def mm(A,B):
 return [[sum(x*y for x,y in zip(row,col))for col in zip(*B)]for row in A] if A and B else [[] for _ in A]
def unpack(v,ds,dt):
 out=[];k=0
 for a,b in zip(ds,dt):out.append([v[k+j*a:k+(j+1)*a]for j in range(b)]);k+=a*b
 return out
def flat(M):return [x for a in M for row in a for x in row]
def compose(f,g,di,dk,dj):
 ff=unpack(f,di,dk);gg=unpack(g,dk,dj)
 return [sum(gg[v][a][b]*ff[v][b][c]for b in range(dk[v]))for v in range(len(di))for a in range(dj[v])for c in range(di[v])]
def rank(vs,n):return len(rr(vs,n)[1]) if vs else 0

def run():
 B=algebra(7);spec=info(B);records=json.loads((ROOT/'qa/ch17_7_image_modules.json').read_text());mods=[]
 for rec in records:
  d=rec['Bdim'];a={k:[[F(1)for _ in range(d[s])]for _ in range(d[t])]for k,(s,t)in enumerate(B.arr)}
  if max(d)==2:
   a[0]=[[F(1)],[F(0)]];a[1]=[[F(1),F(1)]]
   a[4]=[[F(1),F(0)],[F(0),F(1)]] if d[4]==2 else [[F(0)],[F(1)]]
   if d[4]==2:a[5]=[[F(0)],[F(1)]]
  M=(d,a);mods.append(M)
  assert len(hom(M,M,B.arr))==1
  for rel in B.rel:
   start=B.arr[rel[0][1][0]][0];end=B.arr[rel[0][1][-1]][1];S=z(d[end],d[start])
   for c,path in rel:
    P=[[F(int(i==j))for j in range(d[start])]for i in range(d[start])]
    current=start
    for k in path:
     s,t=B.arr[k];assert current==s
     P=[[sum(a[k][i][j]*P[j][h]for j in range(d[s]))for h in range(d[start])]for i in range(d[t])];current=t
    for i in range(d[end]):
     for j in range(d[start]):S[i][j]+=c*P[i][j]
   assert all(not v for row in S for v in row),(d,rel,S)
 N=len(mods);HH=[[hom(M,NM,B.arr)for NM in mods]for M in mods];arrows=[]
 for i in range(N):
  for j in range(N):
   if i==j or not HH[i][j]:continue
   comps=[]
   for k in range(N):
    if k in (i,j):continue
    for f in HH[i][k]:
     for g in HH[k][j]:comps.append(compose(f,g,mods[i][0],mods[k][0],mods[j][0]))
   irr=len(HH[i][j])-rank(comps,sum(a*b for a,b in zip(mods[i][0],mods[j][0])))
   assert irr>=0
   if irr:arrows.append([i,j,irr])
 dims=[M[0]for M in mods];proj=[];tau={}
 for i,M in enumerate(mods):
  if M[0] in [B.projective(v)[0]for v in range(B.n)]:proj.append(i);continue
  tm,detail=B.tau(M);assert tm[0]in dims,(i,tm[0]);tau[str(i)]=dims.index(tm[0])
 # Every nonprojective mesh satisfies the dimension-vector identity.
 for j,t in tau.items():
  j=int(j);pred=[(i,m)for i,k,m in arrows if k==j]
  assert [sum(dims[i][v]*m for i,m in pred)for v in range(B.n)]==[a+b for a,b in zip(dims[j],dims[t])],(j,t,pred)
 out={'count':N,'dimensions':dims,'representations':[{'dimensions':d,'arrows':{str(k):[[int(v)for v in row]for row in A]for k,A in a.items()}}for d,a in mods],'Hom':[[len(x)for x in row]for row in HH],'arrows':arrows,'tau':tau,'projectives':proj,'Euler':spec['Euler'],'radical':spec['radical']}
 (ROOT/'qa/ch17_7_complete_ar.json').write_text(json.dumps(out,indent=2),'utf8');print('MODULES',N,'ARROWS',len(arrows),'PROJECTIVES',proj,flush=True)
if __name__=='__main__':run()
