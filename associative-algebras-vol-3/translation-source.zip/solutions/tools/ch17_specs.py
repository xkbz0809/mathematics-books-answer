"""Source-audited arrow labels for XVII exercises. Vertex labels are local, zero based."""
from ch15_exact import Alg,rr,null
from fractions import Fraction as F
from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parents[1]
SPECS={
2:(14,{'gamma':(1,0),'alpha':(2,0),'sigma':(3,1),'beta':(3,2),'rho':(4,3),'mu':(5,1),'xi':(6,5),'eta':(5,7),'epsilon':(6,8),'nu':(9,3),'delta':(9,10),'omega':(11,9),'phi':(12,10),'psi':(10,13)},[('rho sigma gamma','rho beta alpha'),'mu gamma','xi eta','nu sigma','omega delta','phi psi']),
3:(9,{'alpha':(0,1),'beta':(2,0),'gamma':(0,3),'rho':(3,4),'sigma':(5,0),'xi':(0,6),'mu':(7,6),'eta':(6,8)},['sigma gamma rho','beta xi','sigma xi','mu eta']),
4:(8,{'alpha':(1,0),'beta':(2,0),'gamma':(3,0),'sigma':(4,0),'rho':(5,1),'omega':(5,2),'xi':(6,2),'eta':(6,3),'mu':(7,3),'epsilon':(7,4)},[('rho alpha','omega beta'),('xi beta','eta gamma'),('mu gamma','epsilon sigma')]),
5:(9,{'alpha':(3,2),'beta':(2,1),'gamma':(1,0),'sigma':(3,4),'delta':(4,0),'epsilon':(5,4),'rho':(8,1),'mu':(8,7),'eta':(7,6),'xi':(6,0)},[('sigma delta','alpha beta gamma'),('rho gamma','mu eta xi')]),
6:(8,{'alpha':(2,0),'beta':(0,1),'gamma':(0,3),'sigma':(3,4),'delta':(5,3),'xi':(5,6),'eta':(7,5)},['alpha beta','gamma sigma','delta sigma','eta xi']),
7:(12,{'alpha':(0,1),'beta':(1,2),'gamma':(0,3),'sigma':(3,2),'epsilon':(4,1),'mu':(5,4),'xi':(6,5),'eta':(7,5),'rho':(8,4),'phi':(9,3),'psi':(10,9),'nu':(9,11)},[('gamma sigma','alpha beta'),'xi mu','eta mu','rho epsilon','phi sigma','psi nu']),
8:(17,{'alpha':(0,1),'beta':(1,2),'gamma':(3,2),'sigma':(4,3),'delta':(4,5),'xi':(6,5),'eta':(0,6),'psi':(7,1),'phi':(8,7),'epsilon':(7,9),'mu':(10,6),'nu':(10,11),'omega':(12,10),'rho':(13,12),'theta':(12,14),'iota':(15,14),'lambda':(14,16)},['alpha beta','eta xi','phi epsilon','rho theta','iota lambda','omega nu']),
}
def algebra(k):
 n,d,rel=SPECS[k];names=list(d);arr=list(d.values())
 def path(s):
  p=tuple(names.index(x)for x in s.split());assert all(arr[a][1]==arr[b][0]for a,b in zip(p,p[1:]));return p
 rs=[[(1,path(r))]if isinstance(r,str)else[(1,path(r[0])),(-1,path(r[1]))]for r in rel]
 return Alg(n,arr,rs)
def la(a):
 arr=[(4,3),(3,1),(4,2),(2,1),(1,0),(5,4)]
 return Alg(6,arr,[[(1,(0,1,4)),(-1,(2,3,4))],[(1,(5,0,1)),(-a,(5,2,3))]])
def inv(A):
 n=len(A);R,p=rr([[F(x)for x in row]+[F(i==j)for j in range(n)]for i,row in enumerate(A)],n);assert len(p)==n;return [r[n:]for r in R]
def integer(A):return [[int(x)if x.denominator==1 else str(x)for x in row]for row in A]
def info(A):
 n=A.n;C=[[F(len(A.basis.get((i,j),[])))for i in range(n)]for j in range(n)];E=list(map(list,zip(*inv(C))));G=[[E[i][j]+E[j][i]for j in range(n)]for i in range(n)];h=[]
 for v in null(G,n):
  m=math.lcm(*(x.denominator if isinstance(x,F)else 1 for x in v));w=[int(x*m)for x in v];g=math.gcd(*w);h.append([x//g for x in w])
 return {'n':n,'arrows':A.arr,'relations':A.rel,'C':integer(C),'Euler':integer(E),'symmetric':integer(G),'radical':h,'dimension':sum(map(sum,C))}
def run():
 out={}
 for k in range(2,9):
  d=info(algebra(k));out[str(k)]=d;print(k,'radical',d['radical'],'dim',d['dimension'])
 for k,a in [('14',F(2)),('15',F(1))]:
  d=info(la(a));out[k]=d;print(k,'Euler',d['Euler'],'radical',d['radical'],'dim',d['dimension'])
 (ROOT/'qa/ch17_quivers.json').write_text(json.dumps(out,indent=2,default=str),'utf8')
if __name__=='__main__':run()
