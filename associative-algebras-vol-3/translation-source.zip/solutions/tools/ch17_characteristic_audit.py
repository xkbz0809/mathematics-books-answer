"""Record all exceptional primes in the exact rational rank certificates."""
from fractions import Fraction
from pathlib import Path
import json,argparse
import ch15_exact as ex
import ch17_end_algebras as en
R=Path(__file__).resolve().parents[1];primes=set();pivots=0
def record(x):
 x=Fraction(x)
 for n in [abs(x.numerator),x.denominator]:
  p=2
  while p*p<=n:
   while n%p==0:primes.add(p);n//=p
   p+=1
  if n>1:primes.add(n)
def audited_rr(A,n):
 global pivots
 A=[list(map(Fraction,r))for r in A];p=[];i=0
 for j in range(n):
  k=next((k for k in range(i,len(A))if A[k][j]),None)
  if k is None:continue
  A[i],A[k]=A[k],A[i];q=A[i][j];record(q);pivots+=1;A[i]=[x/q for x in A[i]]
  for k in range(len(A)):
   if k!=i:
    q=A[k][j];A[k]=[x-q*y for x,y in zip(A[k],A[i])]
  p.append(j);i+=1
  if i==len(A):break
 return A,p
def run(kind,op):
 ex.rr=audited_rr;en.rr=audited_rr;tag=f'{kind}_{"op"if op else"orig"}'
 reps=en.decode(json.loads((R/f'qa/ch17_ex11_13_{tag}_representations.json').read_text('utf8')))
 for d,a in reps:
  for m in a.values():
   for row in m:
    for x in row:record(x)
 en.run(kind,op)
 iso=json.loads((R/f'qa/ch17_ex11_13_{kind}_isomorphisms.json').read_text('utf8'))
 for g in iso['classes']:
  for w in g['witnesses']:
   if w['input']!=('op'if op else'orig'):continue
   for img in w['isomorphism']['arrow_images']:
    for c,path in img:record(c)
   # Every two-arrow block determinant is also a denominator exclusion.
   a=g['representative']['arrows'];source=json.loads((R/f'qa/ch17_ex11_13_{tag}_endomorphisms.json').read_text('utf8'))['algebras'][w['input_index']]
   ar=source['arrows'];pairs={}
   for i,e in enumerate(ar):pairs.setdefault(tuple(e),[]).append(i)
   for e,ids in pairs.items():
    if len(ids)!=2:continue
    imgs=w['isomorphism']['arrow_images'];targets=sorted({p[0]for i in ids for c,p in imgs[i]if len(p)==1});assert len(targets)==2
    mat=[[sum(Fraction(c)for c,p in imgs[i]if p==[j])for j in targets]for i in ids];record(mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0])
 out={'kind':kind,'opposite_input':op,'Gaussian_pivots_checked':pivots,'exceptional_primes':sorted(primes),'scope':'Actual Hom systems, radical products, path-kernel relations, quotient dimension ranks, representation entries and explicit isomorphism coefficients/determinants.'}
 (R/f'qa/ch17_ex11_13_{tag}_characteristic_audit.json').write_text(json.dumps(out,indent=2),'utf8');print(out,flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['D4','D5','E6']);ap.add_argument('--op',action='store_true');a=ap.parse_args();run(a.kind,a.op)
