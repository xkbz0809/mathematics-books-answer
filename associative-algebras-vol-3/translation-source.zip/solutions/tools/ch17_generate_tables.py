import json
from ch17_specs import ROOT
D=json.loads((ROOT/'qa/ch17_ar_coordinates.json').read_text())
def supp(v):
 chunks=[];i=0
 while i<len(v):
  j=i
  while j+1<len(v)and v[j+1]==v[j]+1:j+=1
  chunks.append(str(v[i])if i==j else (str(v[i])+','+str(v[j]) if j==i+1 else str(v[i])+r',\ldots,'+str(v[j])))
  i=j+1
 return r'\{'+','.join(chunks)+r'\}'
for k,key in [(6,'6'),(7,'7'),(8,'8_canonical_7_10')]:
 d=D[key];rows=[r'\begin{longtable}{c|l|rr}',r'$i$&$\operatorname{supp}_H T_i$&$L_i$&$U_i$\\\hline\endhead']
 for i,(s,(l,u))in enumerate(zip(d['T_supports'],d['bounds'])):rows.append(f'{i}&$'+supp(s)+f'$&{l}&{u}'+r'\\')
 rows+=[r'\end{longtable}'];(ROOT/f'chapters/ch17_table{k}.tex').write_text('\n'.join(rows)+'\n','utf8')
A=json.loads((ROOT/'qa/ch17_7_complete_ar.json').read_text());rows=[r'\begin{longtable}{r|l@{\qquad}r|l}',r'序号&非零坐标&序号&非零坐标\\\hline']
def dim(d):return r'\{'+','.join(str(i)+(r'^{(2)}'if v==2 else '')for i,v in enumerate(d)if v)+r'\}'
for i in range(0,len(A['dimensions']),2):
 row=f'{i+1}&$'+dim(A["dimensions"][i])+'$'
 if i+1<len(A['dimensions']):row+=f'&{i+2}&$'+dim(A["dimensions"][i+1])+'$'
 else:row+='&&'
 rows.append(row+r'\\')
rows.append(r'\end{longtable}');(ROOT/'chapters/ch17_roots7.tex').write_text('\n'.join(rows)+'\n','utf8')
for name in ['ch15.tex','ch16.tex','ch17_ex1_5.tex']:
 p=ROOT/'chapters'/name;p.write_text(p.read_text('utf8').replace('分枝','分支'),'utf8')
