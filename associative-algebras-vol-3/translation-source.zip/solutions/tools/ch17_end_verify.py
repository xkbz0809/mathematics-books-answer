"""Exact End presentations and Coxeter polynomials for XVII.6--8."""
import json
from ch15_exact import thin,hom,rr
from ch17_specs import ROOT,algebra,info,inv
from ch17_b7_ar import compose
def mm(A,B):return [[sum(x*y for x,y in zip(row,col))for col in zip(*B)]for row in A]
def cp(M):
 n=len(M);P=[[int(i==j)for j in range(n)]for i in range(n)];a=[1];traces=[]
 for k in range(1,n+1):
  P=mm(P,M);traces.append(sum(P[i][i]for i in range(n)))
  a.append(-sum(a[k-j]*traces[j-1]for j in range(1,k+1))/k)
 return [int(x)for x in a]
out={}
S=json.loads((ROOT/'qa/ch17_slices_tiltings.json').read_text())
for k in [6,7,8]:
 B=algebra(k)
 if k==7:
  d=json.loads((ROOT/'qa/ch17_7_D11_tilting_search.json').read_text())['False'];arr=d['H_arrows'];dims=[t['dim']for t in d['tilting']]
 else:d=S['8_canonical_7_10' if k==8 else str(k)];arr=d['H_arrows'];dims=d['T_dimensions']
 n=len(dims);T=[thin(n,arr,[j for j,d in enumerate(v)if d])for v in dims];HH=[[hom(a,b,arr)for b in T]for a in T]
 E=[[int(i==j)-int((i,j)in map(tuple,arr))for j in range(n)]for i in range(n)]
 eu=[[sum(a[i]*E[i][j]*b[j]for i in range(n)for j in range(n))for b in dims]for a in dims]
 assert eu==[[len(h)for h in row]for row in HH]==info(B)['C']
 arrows=[]
 for u,v in B.arr:assert len(HH[v][u])==1;arrows.append(HH[v][u][0])
 values={}
 for u,v,p in B.paths:
  f=[int(a==b)for d in dims[u]for a in range(d)for b in range(d)];prev=u
  for t in p:
   s,tgt=B.arr[t];assert s==prev
   f=compose(arrows[t],f,dims[tgt],dims[prev],dims[u]);prev=tgt
  values[u,p]=f
 for rel in B.rel:
  u=B.arr[rel[0][1][0]][0]
  assert not any(sum(c*values[u,p][i]for c,p in rel)for i in range(len(values[u,rel[0][1]])))
 for (u,v),paths in B.basis.items():
  vs=[values[u,p]for p in paths];assert len(rr(vs,len(vs[0]))[1])==len(paths) if vs else not HH[v][u]
 EB=info(B)['Euler'];Phi=[[-x for x in row]for row in mm(inv(EB),list(map(list,zip(*EB))))];poly=cp(Phi)
 out[str(k)]={'all_Ext_zero':True,'all_relations_zero':True,'all_path_bases_independent':True,'End_isomorphic_to_B':True,'Coxeter_polynomial_descending':poly,'dimension':int(info(B)['dimension'])}
 print(k,poly,flush=True)
(ROOT/'qa/ch17_end_and_coxeter.json').write_text(json.dumps(out,indent=2),'utf8')
