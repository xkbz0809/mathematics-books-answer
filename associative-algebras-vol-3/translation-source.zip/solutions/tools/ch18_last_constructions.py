"""Independent concrete tilting constructions for XVIII.10 and .11."""
import json
from fractions import Fraction as F
from ch15_exact import Alg,hom,thin
from ch17_specs import ROOT,info
from ch18_specs import H,alg
from ch17_tilting_search import search

def euler(x,y,arr):return sum(a*b for a,b in zip(x,y))-sum(x[a]*y[b]for a,b in arr)
def serial(M):return {'dimensions':M[0],'arrows':{str(a):[[str(v)for v in row]for row in mat]for a,mat in M[1].items()}}
def ten():
 n,arr=H[10];A=Alg(n,arr,[]);B=alg(10)
 specs=[('P',i,i)for i in [8,9,4,7,10,11,12]]+[('I',i,j)for i,j in [(1,1),(1,3),(3,3),(1,4),(7,7),(6,7)]]
 T=[A.projective(i)if kind=='P'else thin(n,arr,set(range(i,j+1)))for kind,i,j in specs]
 HH=[[len(hom(x,y,arr))for y in T]for x in T];XX=[[HH[i][j]-euler(x[0],y[0],arr)for j,y in enumerate(T)]for i,x in enumerate(T)]
 assert not any(v for row in XX for v in row)
 cand=[{'kind':a,'m':0 if a=='P'else b,'i':c,'dim':M[0],'index':k}for k,((a,b,c),M)in enumerate(zip(specs,T))]
 ans,nodes=search(cand,HH,XX,info(B)['C']);assert ans
 out={'H_arrows':arr,'tilting':ans,'End_dimension':sum(map(sum,HH)),'Ext_all_zero':True,'representations':[serial(T[v['index']])for v in ans]}
 (ROOT/'qa/ch18_10_construction.json').write_text(json.dumps(out,indent=2),'utf8');print('10',[(v['kind'],v['m'],v['i'])for v in ans],flush=True)
def eleven():
 n,arr=H[4];A=Alg(n,arr,[]);base=[{3,4,5},{3,4},{3,5},{4,5}]
 T=[thin(n,arr,{0}|s)for s in base]
 e=[[F(i==j)for j in range(3)]for i in range(3)]
 for j in [1,2]:
  d=[3]+[int(i==j)if i in [1,2]else 2 for i in range(1,6)]
  cols={1:[[F(1)]for _ in range(3)]if j==1 else [[]for _ in range(3)],2:[[F(1)]for _ in range(3)]if j==2 else [[]for _ in range(3)],3:[[row[0],row[1]]for row in e],4:[[row[0],row[2]]for row in e],5:[[row[1],row[2]]for row in e]}
  T.append((d,{a:cols[u]for a,(u,v)in enumerate(arr)}))
 HH=[[len(hom(x,y,arr))for y in T]for x in T];XX=[[HH[i][j]-euler(x[0],y[0],arr)for j,y in enumerate(T)]for i,x in enumerate(T)]
 assert not any(v for row in XX for v in row);assert all(HH[i][i]==1 for i in range(6))
 Aop=Alg(n,[(b,a)for a,b in arr],[]);translated=[]
 for d,ar in T:
  D=(d,{i:[[ar[i][c][r]for c in range(d[v])]for r in range(d[u])]for i,(u,v)in enumerate(arr)})
  N,detail=Aop.tau(D);dims,mat=N
  translated.append((dims,{i:[[mat[i][c][r]for c in range(dims[u])]for r in range(dims[v])]for i,(u,v)in enumerate(arr)}))
 h2=[[len(hom(x,y,arr))for y in translated]for x in translated]
 assert h2==HH
 for i,x in enumerate(translated):
  for j,y in enumerate(translated):assert h2[i][j]==euler(x[0],y[0],arr)
 out={'Tprime':[serial(x)for x in T],'T':[serial(x)for x in translated],'Hom':HH,'Ext_all_zero':True,'all_End_K':True,'dimensions':[x[0]for x in translated]}
 (ROOT/'qa/ch18_11_regular_tilting.json').write_text(json.dumps(out,indent=2),'utf8');print('11',out['dimensions'],HH,flush=True)
if __name__=='__main__':ten();eleven()
