"""Supplement full_review4 page-by-page visual review with exact text coverage."""
from pathlib import Path
import hashlib,json,re
import pymupdf as fitz
R=Path(__file__).resolve().parents[1];p=R/'build/full_review4/main.pdf';d=fitz.open(p);out=R/'qa/full_review4_visual_zoom25_113';out.mkdir(exist_ok=True)
zoom=[33,90,102,104,110]
for k in zoom:d[k-1].get_pixmap(matrix=fitz.Matrix(1.7,1.7),alpha=False).save(out/f'p{k:03d}.png')
text='\n'.join(pg.get_text()for pg in d)
coverage={}
for kind,n in [('D4',20),('D5',103),('E6',314)]:
 ids=re.findall(r'\b'+kind+r'-\d{3}\b',text);expected=[f'{kind}-{i:03d}'for i in range(1,n+1)]
 assert sorted(ids)==expected,(kind,len(ids),set(expected)-set(ids))
 coverage[kind]={'expected':n,'actual':len(ids),'each_exactly_once':True}
bad=[]
for k in range(24,len(d)):
 pg=d[k];w,h=pg.rect.width,pg.rect.height
 for box in pg.get_text('words'):
  if box[0]<-0.5 or box[1]<-0.5 or box[2]>w+.5 or box[3]>h+.5:bad.append({'page':k+1,'word':box[4],'bbox':box[:4]})
report={'pdf':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'pages':len(d),'actual_visual_contact_pages':list(range(25,114)),'zoom_pages':zoom,'catalogue_coverage':coverage,'text_outside_page':bad,'scope':'Actual contact-sheet review of every page25–113, with enlarged selected dense pages. Pages1–24 separately reviewed by root. This is full_review4, before final external-link mapping and final wording refinements.'}
(R/'qa/full_review4_visual_review25_113.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8');print(json.dumps(report,ensure_ascii=False))
