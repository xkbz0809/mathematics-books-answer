from pathlib import Path
import pymupdf as f,json,re
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];out=R/'qa/ch17_catalogue_visual';out.mkdir(exist_ok=True)
d=f.open(R/'build/u17/u17.pdf');seen=[];outside=[]
for i,p in enumerate(d):
 seen+=re.findall(r'(D4|D5|E6)-(\d{3})',p.get_text())
 for w in p.get_text('words'):
  if w[0]<10 or w[2]>p.rect.width-10:outside.append([i+1,w])
 for page in [0,4,16,30,58]:
  if i==page:p.get_pixmap(matrix=f.Matrix(1.6,1.6)).save(out/f'page_{i+1:03d}.png')
for start in range(0,len(d),9):
 canvas=Image.new('RGB',(1200,1800),'#dddddd');draw=ImageDraw.Draw(canvas)
 for k in range(start,min(start+9,len(d))):
  p=d[k];pix=p.get_pixmap(matrix=f.Matrix(.65,.65));im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.thumbnail((390,560));x=(k-start)%3*400;y=(k-start)//3*600;canvas.paste(im,(x+(400-im.width)//2,y+22));draw.text((x+8,y+4),str(k+1),fill='black')
 canvas.save(out/f'contact_{start+1:03d}.png')
expected={(t,f'{i:03d}')for t,n in [('D4',20),('D5',103),('E6',314)]for i in range(1,n+1)}
assert set(seen)==expected and len(seen)==437,(len(seen),len(expected-set(seen)))
report={'pages':len(d),'table_rows_expected':437,'table_rows_found':len(seen),'each_exactly_once':len(set(seen))==437,'text_outside_safe_page_bounds':outside,'compiled_five_passes':True,'overfull':0,'missing_glyphs':0,'unresolved_references':0}
(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8');print(report)
