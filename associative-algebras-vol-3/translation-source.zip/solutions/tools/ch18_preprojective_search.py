"""Exact preprojective tilting searches for XVIII.4--9."""
import json,argparse
from ch18_specs import H,alg
from ch17_specs import ROOT,info,inv
from ch17_tilting_search import search
def transpose(A):return list(map(list,zip(*A)))
def mv(A,v):return tuple(sum(a*b for a,b in zip(row,v))for row in A)
def mm(A,B):return [[sum(a*b for a,b in zip(row,col))for col in zip(*B)]for row in A]
def pool(k,limit=30):
 n,arr=H[k];E=[[int(i==j)-int((i,j)in arr)for j in range(n)]for i in range(n)];C=transpose(inv(E));Psi=[[-x for x in row]for row in mm(inv(transpose(E)),E)];layers=[];V=transpose(C);cand=[]
 for m in range(limit+1):
  assert min(min(v)for v in V)>=0
  layers.append(V)
  for i,v in enumerate(V):
   if m==0 or 0 in layers[m-1][i]:cand.append({'kind':'P','m':m,'i':i,'dim':tuple(map(int,v))})
  V=[mv(Psi,v)for v in V]
 N=len(cand);HH=[[int(layers[b['m']-a['m']][b['i']][a['i']])if a['m']<=b['m']else 0 for b in cand]for a in cand]
 XX=[[HH[i][j]-sum(a['dim'][u]*E[u][v]*b['dim'][v]for u in range(n)for v in range(n))for j,b in enumerate(cand)]for i,a in enumerate(cand)]
 assert all(x>=0 for row in XX for x in row)
 return cand,HH,XX,E,layers
def run(k):
 cand,HH,XX,E,layers=pool(k);C=info(alg(k))['C'];ans,nodes=search(cand,HH,XX,C);out={'H_arrows':H[k][1],'candidate_count':len(cand),'max_candidate_m':max(c['m']for c in cand),'search_nodes':nodes,'tilting':ans}
 (ROOT/f'qa/ch18_{k}_preprojective_tilting.json').write_text(json.dumps(out,indent=2),'utf8');print(k,out,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('exercise',type=int);a=p.parse_args();run(a.exercise)
