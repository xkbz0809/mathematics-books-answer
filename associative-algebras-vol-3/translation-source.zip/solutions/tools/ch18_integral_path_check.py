"""Check integral path-image bases admit unit determinant minors."""
import json
from fractions import Fraction as F
from ch17_specs import ROOT
from ch18_specs import alg
from ch15_exact import rr
from ch17_b7_ar import compose
def det(M):
 M=[list(v)for v in M];d=F(1)
 for j in range(len(M)):
  k=next(i for i in range(j,len(M))if M[i][j])
  if k!=j:M[k],M[j]=M[j],M[k];d=-d
  z=M[j][j];d*=z
  for i in range(j+1,len(M)):
   c=M[i][j]/z
   for t in range(j,len(M)):M[i][t]-=c*M[j][t]
 return d
out={}
for k in range(4,11):
 r=json.loads((ROOT/f'qa/ch18_{k}_end_verified.json').read_text());dims=[x['dimensions']for x in r['representations']];f=[[F(x)for x in row]for row in r['B_arrow_maps']];B=alg(k);records=[]
 assert all(x.denominator==1 for row in f for x in row)
 def value(p):
  u=B.arr[p[0]][0];prev=u;g=[F(i==j)for d in dims[u]for i in range(d)for j in range(d)]
  for a in p:
   s,t=B.arr[a];g=compose(f[a],g,dims[t],dims[prev],dims[u]);prev=t
  return g
 for(u,v),ps in B.basis.items():
  if u==v or not ps:continue
  vs=[value(p)for p in ps];piv=rr(vs,len(vs[0]))[1];dd=det([[x[c]for c in piv]for x in vs]);assert abs(dd)==1,(k,u,v,dd)
  records.append({'endpoints':[u,v],'rank':len(vs),'unit_minor_columns':piv,'determinant':str(dd)})
 out[k]={'all_integral':True,'all_unit_minors':True,'records':records}
 print(k,'integral unit minors',len(records),flush=True)
(ROOT/'qa/ch18_path_basis_integrality.json').write_text(json.dumps(out,indent=2),'utf8')
