"""Render a unit PDF and compact contact sheets without changing it."""
from pathlib import Path
import argparse,json,hashlib
import pymupdf as fitz
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('pdf');p.add_argument('out');a=p.parse_args();f=Path(a.pdf);out=Path(a.out);out.mkdir(parents=True,exist_ok=True);doc=fitz.open(f)
for i,page in enumerate(doc):page.get_pixmap(matrix=fitz.Matrix(1.3,1.3)).save(out/f'p{i+1:03}.png')
for start in range(0,len(doc),6):
 sheet=Image.new('RGB',(1560,1460),'white')
 for j,i in enumerate(range(start,min(start+6,len(doc)))):
  im=Image.open(out/f'p{i+1:03}.png').convert('RGB');im.thumbnail((500,700));card=Image.new('RGB',(520,730),'#dddddd');card.paste(im,((520-im.width)//2,22));ImageDraw.Draw(card).text((8,5),str(i+1),fill='black');sheet.paste(card,((j%3)*520,(j//3)*730))
 sheet.save(out/f'sheet{start+1:03}.png')
print(json.dumps({'pages':len(doc),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'pdf':str(f.resolve()),'contact_sheets':list(range(1,len(doc)+1,6))}))
