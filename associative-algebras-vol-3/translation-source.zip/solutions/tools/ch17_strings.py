"""Complete finite-string enumeration and AR computation for XVII.6,8,9."""
from ch17_specs import algebra,SPECS,ROOT
from ch15_exact import Alg,F,rr,null,z,tr
from collections import deque
import json,csv
def strings(A):
 adj={v:[]for v in range(A.n)}
 for t,(a,b)in enumerate(A.arr):adj[a].append((b,t+1));adj[b].append((a,-t-1))
 bad=[]
 for r in A.rel:
  assert len(r)==1
  w=tuple(t+1 for t in r[0][1]);bad.extend([w,tuple(-t for t in w[::-1])])
 mods={}
 for v in range(A.n):
  def walk(vertices,word):
   key=(tuple(sorted(vertices)),tuple(sorted(abs(t)-1 for t in word)))
   mods[key]=(frozenset(vertices),frozenset(abs(t)-1 for t in word))
   for w,t in adj[vertices[-1]]:
    if word and t==-word[-1]:continue
    nw=word+(t,)
    if any(len(nw)>=len(b)and nw[-len(b):]==b for b in bad):continue
    assert w not in vertices,('repeated vertex needs general string matrices',vertices,nw)
    walk(vertices+[w],nw)
  walk([v],())
 return sorted(mods.values(),key=lambda M:(len(M[0]),sorted(M[0]),sorted(M[1])))
def homthin(M,N,A):
 V,W=M[0]&N[0],[];vs=sorted(V);off={v:i for i,v in enumerate(vs)}
 for t,(a,b)in enumerate(A.arr):
  if a in M[0]and b in N[0]:
   row=[F(0)]*len(vs)
   if t in N[1]and a in V:row[off[a]]+=1
   if t in M[1]and b in V:row[off[b]]-=1
   W.append(row)
 out=[]
 for x in null(W,len(vs)):
  d=[F(0)]*A.n
  for v,c in zip(vs,x):d[v]=c
  out.append(d)
 return out
def asrep(M,A):
 d=[int(i in M[0])for i in range(A.n)]
 return d,{t:[[F(t in M[1])]]if d[a]and d[b]else z(d[b],d[a])for t,(a,b)in enumerate(A.arr)}
def pd(rep,A):
 cur=rep
 for k in range(5):
  P,f,g,s=A.cover(cur)
  if P[0]==cur[0]:return k
  B=[]
  for v,M in enumerate(f):
   cols=null(M,P[0][v]);B.append(tr(cols)if cols else z(P[0][v],0))
  cur=A.subrep(P,B)
 raise ValueError('resolution exceeded')
def opposite(A):return Alg(A.n,[(b,a)for a,b in A.arr],[[(c,p[::-1])for c,p in r]for r in A.rel])
def runone(k,ar=True):
 A=algebra(k)
 if k==9:raise ValueError
 return calculate(A,k,ar)
def calculate(A,k,ar=True):
 mods=strings(A);N=len(mods);print(k,'strings',N,flush=True);out={'n':A.n,'modules':[{'vertices':sorted(x),'arrows':sorted(y)}for x,y in mods]}
 if not ar:
  O=opposite(A);both=[]
  for i,M in enumerate(mods):
   p=pd(asrep(M,A),A)
   if p>=2:
    q=pd(asrep(M,O),O)
    if q>=2:both.append({'module':i,'pd':p,'id':q,'support':sorted(M[0]),'arrows':sorted(M[1])})
  out['pd_id_ge2']=both;print('both',both,flush=True);return out
 HH=[[homthin(M,N,A)for N in mods]for M in mods];edges=[];maps={}
 for i in range(N):
  for j in range(N):
   if i==j or not HH[i][j]:continue
   prod=set()
   for l in range(N):
    if l==i or l==j or not HH[i][l]or not HH[l][j]:continue
    for f in HH[i][l]:
     for g in HH[l][j]:
      v=tuple(a*b for a,b in zip(f,g))
      if any(v):prod.add(v)
   rank=len(rr(list(prod),A.n)[1])if prod else 0
   if rank==len(HH[i][j]):continue
   assert rank<len(HH[i][j]);base=list(prod)
   for f in HH[i][j]:
    r=len(rr(base+[f],A.n)[1])
    if r>rank:edges.append((i,j));maps[f'{i},{j}']=list(map(int,f));base.append(f);rank=r
 pids=[]
 for v in range(A.n):
  d,a=A.projective(v);s=frozenset(i for i,x in enumerate(d)if x);e=frozenset(t for t,m in a.items()if any(x for row in m for x in row));pids.append(mods.index((s,e)))
 tau={}
 for j in range(N):
  if j in pids:continue
  v=tuple(sum(t in mods[i][0]for i,b in edges if b==j)-int(t in mods[j][0])for t in range(A.n));assert all(x in (0,1)for x in v),(k,j,v)
  cand=[i for i,M in enumerate(mods)if tuple(int(t in M[0])for t in range(A.n))==v];assert len(cand)==1,(j,cand,v);tau[j]=cand[0]
 itau={v:k for k,v in tau.items()};assert len(itau)==len(tau);orbits=[];where={}
 for i,p in enumerate(pids):
  orb=[];x=p
  while True:
   where[x]=(i,len(orb));orb.append(x)
   if x not in itau:break
   x=itau[x]
  orbits.append(orb)
 assert len(where)==N,(len(where),N)
 allowed={}
 for a,b in edges:
  i,h=where[a];j,l=where[b];assert i!=j
  vals={l-h,l-h-1}
  if i>j:i,j=j,i;vals={-x for x in vals}
  if (i,j)in allowed:allowed[i,j]&=vals
  else:allowed[i,j]=vals
 assert all(allowed.values());slices=[];chosen={}
 order=sorted(range(A.n),key=lambda i:(-sum(i in e for e in allowed),len(orbits[i])))
 def pathacts(M,p):return all(t in M[1]for t in p)
 def faithful(sec):return all(any(v in mods[i][0] and pathacts(mods[i],p)for i in sec)for (v,w),paths in A.basis.items()for p in paths)
 def rec(at):
  if at==A.n:
   sec=[orbits[i][chosen[i]]for i in range(A.n)];secedges=[(a,b)for a,b in edges if a in sec and b in sec]
   if faithful(sec):slices.append({'vertices':sec,'heights':[chosen[i]for i in range(A.n)],'arrows':secedges})
   return
  i=order[at]
  for h in range(len(orbits[i])):
   if any((min(i,j),max(i,j))in allowed and ((hj-h if i<j else h-hj)not in allowed[min(i,j),max(i,j)])for j,hj in chosen.items()):continue
   chosen[i]=h;rec(at+1);del chosen[i]
 rec(0)
 print(k,'AR edges',len(edges),'orbits',[len(x)for x in orbits],'faithful sections',len(slices),flush=True)
 out.update(AR_arrows=edges,AR_maps=maps,tau=tau,projectives=pids,orbits=orbits,orbit_edges=[{'i':i,'j':j,'allowed':sorted(v)}for (i,j),v in allowed.items()])
 if len(slices)>100:
  out.update(faithful_section_count=len(slices),selected_section=slices[0])
  with (ROOT/f'qa/ch17_{k}_section_heights.csv').open('w',encoding='utf8',newline='')as f:
   w=csv.writer(f);w.writerow(range(A.n));w.writerows(s['heights']for s in slices)
 else:out['faithful_sections']=slices
 return out
def run():
 out={str(k):runone(k)for k in [6,8]}
 A=algebra(8);names=list(SPECS[8][1]);C=Alg(A.n,A.arr,A.rel+[[(1,(names.index('sigma'),names.index('gamma')))]])
 out['9']=calculate(C,9,False)
 (ROOT/'qa/ch17_string_ar.json').write_text(json.dumps(out,indent=2),'utf8')
if __name__=='__main__':run()
