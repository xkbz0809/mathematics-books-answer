"""Independent exact nonnegative-root enumeration for XVII.7."""
import json,math,itertools
from fractions import Fraction as F
from ch17_specs import ROOT,algebra,info,inv
D=info(algebra(7));G=D['symmetric'];n=len(G);mins={}
for size in range(n,0,-1):
 for S in itertools.combinations(range(n),size):
  if all(i in mins for i in S):continue
  try:J=inv([[G[i][j]for j in S]for i in S])
  except AssertionError:continue
  for k,i in enumerate(S):
   if i in mins or J[k][k]<=0:continue
   v=[F(0)]*n
   for t,j in enumerate(S):v[j]=J[t][k]/J[k][k]
   if min(v)<0:continue
   if any(sum(G[j][t]*v[t]for t in range(n))<0 for j in range(n)if j not in S):continue
   mins[i]=F(1)/(2*J[k][k])
 if len(mins)==n:break
assert len(mins)==n
bounds=[math.isqrt((1/mins[i]).numerator//(1/mins[i]).denominator)for i in range(n)]
print('bounds',bounds,'box',math.prod(b+1 for b in bounds),flush=True)
roots=[]
for v in itertools.product(*(range(b+1)for b in bounds)):
 q=sum(v[i]*v[i]for i in range(n))+sum(G[i][j]*v[i]*v[j]for i in range(n)for j in range(i+1,n))
 if q==1:roots.append(v)
expected={tuple(d)for d in json.loads((ROOT/'qa/ch17_7_complete_ar.json').read_text())['dimensions']}
assert set(roots)==expected,(len(roots),len(expected),set(roots)^expected)
(ROOT/'qa/ch17_7_positive_roots.json').write_text(json.dumps({'coordinate_minima':[str(mins[i])for i in range(n)],'coordinate_bounds':bounds,'nonnegative_roots':roots,'count':len(roots),'equals_constructed_representations':True},indent=2),'utf8');print('ROOTS',len(roots))
