"""Explicit arrow-image isomorphisms inside each Cartan prescreen group."""
from ch15_exact import Alg,rr,coord,tr
from ch17_end_algebras import encode,decode
from fractions import Fraction as F
from itertools import permutations,product
from pathlib import Path
import json,argparse,math
R=Path(__file__).resolve().parents[1]
def factors(x):
 x=abs(x);d={};p=2
 while p*p<=x:
  while x%p==0:d[p]=d.get(p,0)+1;x//=p
  p+=1
 if x>1:d[x]=d.get(x,0)+1
 return d
def gf2(A,b,n):
 a=[list(map(lambda x:x%2,r))+[s]for r,s in zip(A,b)];p=[];i=0
 for j in range(n):
  k=next((k for k in range(i,len(a))if a[k][j]),None)
  if k is None:continue
  a[i],a[k]=a[k],a[i]
  for k in range(len(a)):
   if k!=i and a[k][j]:a[k]=[x^y for x,y in zip(a[k],a[i])]
  p.append(j);i+=1
 if any(not any(r[:n])and r[n]for r in a):return None
 x=[0]*n
 for i,j in enumerate(p):x[j]=a[i][n]
 return x
def torus(A,c,n):
 if not A:return [F(1)]*n
 fs=[];pr=set()
 for x in c:
  a=factors(x.numerator);b=factors(x.denominator);d={p:a.get(p,0)-b.get(p,0)for p in set(a)|set(b)};fs.append(d);pr|=set(d)
 ans=[F(1)]*n
 for prime in sorted(pr):
  aug=[list(r)+[d.get(prime,0)]for r,d in zip(A,fs)];z,p=rr(aug,n)
  if any(not any(r[:n])and r[n]for r in z):return None
  v=[F(0)]*n
  for i,j in enumerate(p):v[j]=z[i][n]
  if any(x.denominator!=1 for x in v):return None
  ans=[x*F(prime)**int(e)for x,e in zip(ans,v)]
 sg=gf2(A,[int(x<0)for x in c],n)
 if sg is None:return None
 return [-a if s else a for a,s in zip(ans,sg)]
def autos(C):
 n=len(C);profile=[tuple(sorted((C[i][j],C[j][i])for j in range(n)))for i in range(n)];groups=[[i for i in range(n)if profile[i]==p]for p in sorted(set(profile))]
 yield list(range(n))
 for ps in product(*(permutations(g)for g in groups)):
  p=[0]*n
  for g,h in zip(groups,ps):
   for a,b in zip(g,h):p[a]=b
  if p==list(range(n)):continue
  if all(C[i][j]==C[p[i]][p[j]]for i in range(n)for j in range(n)):yield p
def gl2s(wide=False):
 first=[(1,0,0,1),(0,1,1,0),(1,1,0,1),(1,0,1,1),(1,-1,0,1),(1,0,-1,1)];seen=set()
 vals=[F(0),F(1),F(-1)] if not wide else [F(0),F(1),F(-1),F(2),F(-2),F(1,2),F(-1,2)]
 for m in first+list(product(vals,repeat=4)):
  m=tuple(map(F,m))
  if m in seen or m[0]*m[3]==m[1]*m[2]:continue
  seen.add(m);yield m
def algebra(d):return Alg(len(d['Cartan']),[tuple(x)for x in d['arrows']],[( [(F(c),tuple(p))for c,p in rel] )for rel in d['relations']])
def try_iso(S,T,p,wide=False,allow_bypass=False):
 A=algebra(S);B=algebra(T);n=A.n;es=len(A.arr);pairs={}
 for i,e in enumerate(A.arr):pairs.setdefault(e,[]).append(i)
 target={}
 for i,e in enumerate(B.arr):target.setdefault(e,[]).append(i)
 if any(len(ii)!=len(target.get((p[a],p[b]),[]))for (a,b),ii in pairs.items()):return None
 doubles=[(e,ii)for e,ii in pairs.items()if len(ii)>1]
 assert all(len(ii)==2 for e,ii in doubles)
 pathcounts={q:tuple(q.count(i)for i in range(es))for a,b,q in A.paths}
 bypasses=[]
 if allow_bypass:
  for (a,b),ii in pairs.items():
   if len(ii)==1:
    ps=[q for q in B.basis.get((p[a],p[b]),[])if len(q)>=2]
    if ps:bypasses.append((ii[0],ps))
 choices=[list(gl2s(wide))for _ in doubles]+[list(product([F(0),F(1),F(-1)],repeat=len(ps)))for i,ps in bypasses]
 for params in product(*choices):
  mats=params[:len(doubles)]
  ims={}
  for e,ii in pairs.items():
   jj=target[p[e[0]],p[e[1]]]
   if len(ii)==1:ims[ii[0]]=[(F(1),(jj[0],))]
  for (e,ii),m in zip(doubles,mats):
   jj=target[p[e[0]],p[e[1]]]
   for k in range(2):ims[ii[k]]=[(m[2*k+l],(jj[l],))for l in range(2)if m[2*k+l]]
  for (i,ps),cs in zip(bypasses,params[len(doubles):]):ims[i]+=[(c,q)for c,q in zip(cs,ps)if c]
  images={}
  for a,b,q in A.paths:
   terms=[(F(1),())]
   for e in q:terms=[(c*d,t+f)for c,t in terms for d,f in ims[e]]
   v=[F(0)]*len(B.basis.get((p[a],p[b]),[]))
   for c,t in terms:
    for i,x in enumerate(B.red[p[a],t]):v[i]+=c*x
   images[a,q]=v
  equations=[];values=[];good=True
  for (a,b),basis in A.basis.items():
   M=tr([images[a,q]for q in basis]);size=len(basis)
   if len(rr(M,size)[1])!=size:good=False;break
   for u,v,q in A.paths:
    if (u,v)!=(a,b)or q in basis:continue
    beta=coord(M,images[a,q]);alpha=A.red[a,q]
    for path,x,y in zip(basis,alpha,beta):
     if bool(x)!=bool(y):good=False;break
     if not x:continue
     row=[u-v for u,v in zip(pathcounts[q],pathcounts[path])];value=x/y
     if not any(row):
      if value!=1:good=False;break
     else:equations.append(row);values.append(value)
    if not good:break
   if not good:break
  if not good:continue
  scalars=torus(equations,values,es)
  if scalars is None:continue
  # Independent final substitution into every defining relation.
  for rel in A.rel:
   start=A.arr[rel[0][1][0]][0];end=A.arr[rel[0][1][-1]][1];v=[F(0)]*len(B.basis[p[start],p[end]])
   for c,q in rel:
    c*=math.prod(scalars[e]for e in q)
    for i,x in enumerate(images[start,q]):v[i]+=c*x
   assert not any(v)
  return {'vertex_permutation':p,'arrow_images':[[[c*scalars[i],e]for c,e in ims[i]]for i in range(es)],'verification':'Every source relation maps to zero; vertex idempotents permuted; arrow radical-quotient blocks invertible; equal dimension.'}
 return None
def iso(S,T):
 for p in autos(S['Cartan']):
  w=try_iso(S,T,p)
  if w:return w
 for p in autos(S['Cartan']):
  w=try_iso(S,T,p,allow_bypass=True)
  if w:return w
 return None
def run(kind):
 all=[]
 for op in ['orig','op']:
  d=json.loads((R/f'qa/ch17_ex11_13_{kind}_{op}_endomorphisms.json').read_text('utf8'))
  for i,a in enumerate(d['algebras']):a['input']=op;a['input_index']=i;all.append(a)
 groups={}
 for a in all:groups.setdefault(a['cartan_key'],[]).append(a)
 classes=[];unresolved=[]
 for gi,(key,vals)in enumerate(sorted(groups.items())):
  # Prefer a representative with simple integral coefficients.
  vals.sort(key=lambda a:(sum('/'in str(c)for rel in a['relations']for c,p in rel),len(a['relations']),str(a['relations'])))
  ref=vals[0];wits=[]
  for a in vals:
   w=iso(a,ref)
   if w is None:unresolved.append({'cartan_group':gi,'source':a,'target':ref});continue
   wits.append({'input':a['input'],'input_index':a['input_index'],'T':a['T'],'isomorphism':w})
  classes.append({'id':gi+1,'representative':ref,'witnesses':wits,'group_size':len(vals)})
  if gi%10==0:print(kind,'groups',gi+1,'/',len(groups),'unresolved',len(unresolved),flush=True)
 out={'kind':kind,'cartan_group_count':len(groups),'normalized_tilting_count':len(all),'classes':classes,'unresolved':unresolved,'status':'complete'if not unresolved else'unresolved isomorphisms; do not call Cartan groups algebra classes'}
 (R/f'qa/ch17_ex11_13_{kind}_isomorphisms.json').write_text(json.dumps(encode(out),separators=(',',':')),'utf8')
 print(kind,'finished groups',len(groups),'unresolved',len(unresolved),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('kind',choices=['D4','D5','E6']);a=ap.parse_args();run(a.kind)
