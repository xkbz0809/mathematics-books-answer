from pathlib import Path
from collections import deque
from math import comb
import json
ROOT=Path(__file__).resolve().parents[1]
Q11=[(1,0),(2,1),(3,2),(4,3),(4,5),(3,6),(2,7),(7,8),(8,9),(10,8)]
R11=[(3,2,7),(4,3,6),(10,8,9)]
Q17=[(1,0),(0,2),(3,1),(4,3),(3,8),(4,5),(6,5),(5,7),(16,2),(2,9),(10,9),(11,10),(10,12),(9,13),(13,14),(15,14)]
R17=[(1,0,2),(4,3,8),(6,5,7),(16,2,9),(11,10,12),(10,9,13)]
Q6=[(2,1),(1,0),(5,2),(2,3),(3,4)] # a0,b1,c2,d3,e4,f5
R6=[(2,1,0),(5,2,3)]
Q8=Q6+[(6,3),(6,7)]
R8=R6+[(6,3,4)]
Q9=[e for e in Q11 if e not in [(1,0),(2,1)]]

def hom(S,T,arr):
 I=S&T
 if not I:return frozenset()
 for a,b in arr:
  if a in I and b in T-S:return frozenset()
  if b in I and a in S-T:return frozenset()
 return I

def intervals(arr,root):
 vs=sorted({v for e in arr for v in e});adj={v:[]for v in vs}
 for a,b in arr:adj[a].append(b);adj[b].append(a)
 children={};sizes={}
 def walk(v,p):
  children[v]=[w for w in adj[v]if w!=p]
  sizes[v]=1+sum(walk(w,v)for w in children[v]);return sizes[v]
 walk(root,None);ans={}
 def label(v,a,b):
  ans[v]=(a,b);lo=[w for w in children[v]if (v,w)in arr];hi=[w for w in children[v]if (w,v)in arr]
  assert len(lo)<=1 and len(hi)<=1
  u=sizes[lo[0]]if lo else 0
  if lo:label(lo[0],a,a+u-1)
  if hi:label(hi[0],a+u+1,b)
 label(root,1,len(vs));return ans

def all_strings(arr,rels):
 vs=sorted({v for e in arr for v in e});adj={v:[]for v in vs}
 for a,b in arr:adj[a].append(b);adj[b].append(a)
 paths=[]
 for a in vs:
  def walk(p):
   if p[-1]>=a:
    if not any(set(r)<=set(p)for r in rels):paths.append(frozenset(p))
   for b in adj[p[-1]]:
    if b not in p:walk(p+[b])
  walk([a])
 return vs,sorted(set(paths),key=lambda x:(len(x),sorted(x)))

def data(arr,rels,root):
 ints=intervals(arr,root);vs=sorted(ints);n=len(vs);Harr=[(i,i-1)for i in range(2,n+1)]
 T=[frozenset(range(ints[v][0],ints[v][1]+1))for v in vs]
 HH=[[hom(x,y,Harr)for y in T]for x in T];D=[[int(bool(h))for h in row]for row in HH]
 Ext=[[D[i][j]-(len(x&y)-sum(a in x and b in y for a,b in Harr))for j,y in enumerate(T)]for i,x in enumerate(T)]
 assert not any(z for row in Ext for z in row)
 edges=[]
 for i in range(n):
  for j in range(n):
   if i!=j and HH[i][j] and not any(k not in (i,j)and HH[i][k]and HH[k][j]and T[i]&T[k]&T[j]for k in range(n)):edges.append((vs[j],vs[i]))
 assert set(edges)==set(arr),(edges,arr)
 for a,b,c in rels:
  assert not(T[vs.index(a)]&T[vs.index(b)]&T[vs.index(c)])
 assert len(T)==n
 return {'vertices':vs,'arrows':arr,'zero_relations':rels,'germ':root,'intervals':{str(v):ints[v]for v in vs},'Hom':D,'Ext1':Ext,'End_arrows_verified':edges}

def ar_data(arr,rels,root):
 vs,mods=all_strings(arr,rels);N=len(mods);HH=[[hom(x,y,arr)for y in mods]for x in mods]
 edges=[]
 for i in range(N):
  for j in range(N):
   if i!=j and HH[i][j]and not any(k not in(i,j)and HH[i][k]and HH[k][j]and mods[i]&mods[k]&mods[j]for k in range(N)):edges.append((i,j))
 def proj(v):
  reach={v}
  for _ in vs:
   for a,b in arr:
    if a in reach and not any(r[0]in reach and (a,b)==r[-2:]for r in rels):reach.add(b)
  return frozenset(reach)
 # Projectives can be obtained without traversal ambiguity by path-to-v test.
 pids=[]
 for v in vs:
  reach={v}
  def rec(path):
   for a,b in arr:
    if a==path[-1] and not any(tuple((path+[b])[i:i+len(r)])==tuple(r)for r in rels for i in range(len(path)+2-len(r))):reach.add(b);rec(path+[b])
  rec([v]);pids.append(mods.index(frozenset(reach)))
 tau={}
 for j in range(N):
  if j in pids:continue
  x=[sum(v in mods[i]for i,k in edges if k==j)-int(v in mods[j])for v in vs]
  assert all(z in(0,1)for z in x),(j,x)
  tau[j]=mods.index(frozenset(v for v,z in zip(vs,x)if z))
 inv={v:k for k,v in tau.items()};assert len(inv)==len(tau)
 # Canonical section Hom_H(T,I(j)) obtained from the interval tilting module.
 ints=intervals(arr,root);Harr=[(i,i-1)for i in range(2,len(vs)+1)]
 section=[]
 for j in range(1,len(vs)+1):
  I=frozenset(range(j,len(vs)+1))
  supp=frozenset(v for v in vs if hom(frozenset(range(ints[v][0],ints[v][1]+1)),I,Harr))
  section.append(mods.index(supp))
 seen={tuple(sorted(section))};todo=deque(seen)
 while todo:
  s=todo.popleft();ss=set(s)
  for x in s:
   if not any(a in ss and b==x for a,b in edges)and x in inv:
    nxt=tuple(sorted(ss-{x}|{inv[x]}))
    if nxt not in seen:seen.add(nxt);todo.append(nxt)
   if not any(a==x and b in ss for a,b in edges)and x in tau:
    nxt=tuple(sorted(ss-{x}|{tau[x]}))
    if nxt not in seen:seen.add(nxt);todo.append(nxt)
 return {'vertices':vs,'module_supports':[sorted(x)for x in mods],'AR_arrows':edges,'tau':tau,'projectives':dict(zip(vs,pids)),'canonical_section':section,'all_sections':[list(s)for s in sorted(seen)]}

def run():
 out={'capacity15':comb(30,15)//16,'tiltings':{'XVI2':data(Q11,R11,0),'XVI3':data(Q17,R17,0)},'AR':{}}
 for name,arr,rels,root in [('XVI6',Q6,R6,1),('XVI7',Q8,R8,1),('XVI8',Q9,R11,2)]:
  d=ar_data(arr,rels,root);out['AR'][name]=d
  print(name,'modules',len(d['module_supports']),'sections',len(d['all_sections']),[[d['module_supports'][i]for i in s]for s in d['all_sections']])
 for k,d in out['tiltings'].items():print(k,d['intervals'])
 (ROOT/'qa/ch16_exact.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
if __name__=='__main__':run()

