"""Characteristic-independent Schur realizations for XVIII.4--10."""
import json
from fractions import Fraction as F
import ch15_exact as ex
from ch17_specs import ROOT
primes=set();pivots=0
def record(x):
 x=F(x)
 for n in [abs(x.numerator),x.denominator]:
  p=2
  while p*p<=n:
   while n%p==0:primes.add(p);n//=p
   p+=1
  if n>1:primes.add(n)
def rr(A,n):
 global pivots
 A=[list(map(F,r))for r in A];ps=[];i=0
 for j in range(n):
  k=next((k for k in range(i,len(A))if A[k][j]),None)
  if k is None:continue
  A[i],A[k]=A[k],A[i];q=A[i][j];record(q);pivots+=1;A[i]=[v/q for v in A[i]]
  for k in range(len(A)):
   if k!=i:
    q=A[k][j]
    if q:A[k]=[a-q*b for a,b in zip(A[k],A[i])]
  ps.append(j);i+=1
  if i==len(A):break
 return A,ps
ex.rr=rr;out={}
for k in range(4,11):
 primes=set();pivots=0;r=json.loads((ROOT/f'qa/ch18_{k}_end_verified.json').read_text())
 for rep in r['representations']:
  M=(rep['dimensions'],{int(a):[[F(v)for v in row]for row in mat]for a,mat in rep['arrows'].items()})
  for mat in M[1].values():
   for row in mat:
    for v in row:
     assert v.denominator==1
  assert len(ex.hom(M,M,r['H_arrows']))==1
 out[k]={'representations':len(r['representations']),'Schur_rank_pivots':pivots,'exceptional_primes':sorted(primes)}
 print(k,out[k],flush=True)
(ROOT/'qa/ch18_schur_characteristic_audit.json').write_text(json.dumps(out,indent=2),'utf8')
