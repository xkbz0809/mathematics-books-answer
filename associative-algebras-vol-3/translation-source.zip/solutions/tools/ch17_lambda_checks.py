"""Independent homological and form checks for XVII.14--15."""
import json
from fractions import Fraction as F
from ch15_exact import z,tr,null,hom
from ch17_specs import ROOT,la,info
def mm(A,B):return [[sum(a*b for a,b in zip(row,col))for col in zip(*B)]for row in A]
def transpose(A):return list(map(list,zip(*A)))
def det(A):
 A=[list(map(F,r))for r in A];out=F(1);n=len(A)
 for i in range(n):
  j=next(j for j in range(i,n)if A[j][i])
  if i!=j:A[i],A[j]=A[j],A[i];out=-out
  v=A[i][i];out*=v
  for j in range(i+1,n):
   c=A[j][i]/v;A[j]=[a-c*b for a,b in zip(A[j],A[i])]
 return out
def resolution(B,M):
 ans=[]
 while any(M[0]):
  P,f,g,s=B.cover(M);ans.append([i+1 for i,v in g]);K=[]
  for v,A in enumerate(f):
   cs=null(A,P[0][v]);K.append(tr(cs)if cs else z(P[0][v],0))
  M=B.subrep(P,K);assert len(ans)<=5
 return ans
B=la(F(1));res={}
for i in range(6):
 d=[int(j==i)for j in range(6)];M=d,{k:z(d[t],d[s])for k,(s,t)in enumerate(B.arr)};res[str(i+1)]=resolution(B,M)
assert res['6']==[[6],[5],[2],[1]]
assert [len(res[str(i+1)])-1 for i in range(6)]==[0,1,1,1,2,3]
def family(n,s,t):
 d=[s,n,n,n,n,t];I=[[F(i==j)for j in range(n)]for i in range(n)]
 return d,{0:I,1:I,2:I,3:[[F(i==j)+F(j==i+1)for j in range(n)]for i in range(n)],4:[[F(j==n-1)for j in range(n)]]if s else [],5:[[F(i==0)]for i in range(n)]if t else [[]for _ in range(n)]}
checks=[]
for n in range(1,5):
 for name,s,t in [('R',0,0),('P',0,1),('I',1,0),('D',1,1)]:
  M=family(n,s,t);TM,detail=B.tau(M);expected={'R':family(n+1,1,1)[0],'P':family(n,1,0)[0],'I':family(n,0,1)[0],'D':family(n-1,0,0)[0]if n>1 else [0]*6}[name]
  assert TM[0]==expected,(name,n,TM[0],expected)
  checks.append({'name':name+str(n),'dimension':M[0],'tau_dimension':TM[0],'End':len(hom(M,M,B.arr))})
G=info(B)['symmetric']
U=[[0,0,0,0,1,0],[0,0,0,0,1,1],[1,0,0,0,2,1],[0,1,0,0,1,2],[0,0,1,0,0,1],[0,0,0,1,0,1]]
D=[[2*int(i==j)for j in range(6)]for i in range(6)]
for i,j in [(0,2),(1,2),(2,3),(3,4),(3,5)]:D[i][j]=D[j][i]=-1
assert mm(mm(transpose(U),D),U)==G
assert abs(det(U))==1
out={'simple_minimal_projective_resolutions':res,'global_dimension':3,'tube_tau_checks':checks,'congruence_matrix':U,'congruence_determinant':int(det(U)),'congruence_verified':True,'q14':info(la(F(2)))['Euler'],'q15':info(B)['Euler']}
(ROOT/'qa/ch17_14_15_checks.json').write_text(json.dumps(out,indent=2),'utf8');print('all exact checks pass',len(checks),'tau values','det',det(U))
