# Chapter 10 English source comparison

Kenneth Hoffman and Ray Kunze, *Linear Algebra*, second edition. Compared the editable English source against every supplied original page image for Chapter 10, including the pages shared between sections. The counts below count numbered exercises once and include their lettered parts in the comparison.

| Section | Original printed pages | Numbered exercises |
| --- | --- | ---: |
| 10.1 Bilinear Forms | 359–367 | 14 |
| 10.2 Symmetric Bilinear Forms | 367–375 | 18 |
| 10.3 Skew-Symmetric Bilinear Forms | 375–379 | 13 |
| 10.4 Groups Preserving Bilinear Forms | 379–385 | 18 |

The 63 numbered exercises and the text of all four sections were checked, including Theorems 1–9, Examples 1–8, and displayed formulas (10-1)–(10-8). This comparison covered the English wording and mathematics. Checking the new compiled pages for layout and links remains part of the whole-book build.

Two readings in the editable English text were restored to the supplied scan.

- Printed p. 374, §10.2, Exercise 15. In the equation for the primed basis vector, the original first sum has the inverse-matrix entry with subscript \(ij\), and the second has subscript \(ji\). Magnification confirms this order. The entries have equal values by symmetry, but the earlier transcription reversed them.
- Printed p. 378, §10.3, Exercise 5(d). The supplied page reads “a linear operato on” at the first occurrence. The final *r* is absent. The second occurrence on the next line reads “a linear operator”. Both readings are retained as visible.

Other checked readings include the baseline \(t\) in Example 2 on p. 360, the argument grouping in §10.1 Exercise 2 on p. 366, the incomplete phrase at the foot of p. 367, the reference to \(T\) at the end of §10.2 Exercise 11 on p. 374, the references to \(V\) and (9-7) on pp. 375–376, and the unrestricted scalar-multiple claim in Example 8 on p. 383. The English source preserves these readings. The SHA-256 digests of the editable 10-01.tex and the offline copy were identical at this check.
