# Hoffman–Kunze, Linear Algebra, second edition (1971): English collation

## Coverage, 26 November 2026

| Section | Printed pages | Source PDF pages (1-based) | Checking performed |
| --- | --- | --- | --- |
| 5.1, Commutative Rings | 140–141 | 149–150 | Complete section, including the three ring axioms and matrix product formula. |
| 5.2, Determinant Functions | 141–150 | 150–159 | Complete section. Checked definitions, examples, lemmas, Theorem 1, corollary, displays (5-1)–(5-8) and the fourteen exercises. |
| 6.1, Introduction | 181–182 | 190–191 | Complete section through the questions preceding 6.2, including (6-1) and (6-2). |
| 7.1, Cyclic Subspaces and Annihilators | 227–231 | 236–240 | Complete section. Checked Theorems 1 and 2, corollary, companion matrix, all eight exercises, and the continuation of Exercise 3 onto p. 231. |

The dated source files are the section files in english/retypeset/chapters. The visual witness was the corresponding page images from the UCR-hosted scan of the second edition, with the same printed/PDF page correspondence as the working copy. The local chapter sources and the saved complete-source file were compared. Page 150 was checked through the end of 5.2, p. 182 through the end of 6.1, and p. 231 through the end of 7.1.

## Changes to the English text

- 5.2, pp. 145–146. Restored the definition's bold upright “adjacent” and the emphasis on “any” and “adjacent” in its proof.
- 5.2, p. 149. Restored the emphasis on “columns” in Exercises 7 and 8.
- 6.1, p. 181. Restored the italics on “linear operators” in the second paragraph.
- 7.1, p. 228. Restored the emphasis on “a” in the parenthetical after “Here the cyclic vector.”

This pass identified no new confirmed mathematical error in these four sections. The earlier independent record for 7.5 is in work/review-07-05-20261126.md. No new claim of page-by-page coverage for sections 5.3–5.7, 6.2–6.8, or 7.2–7.4 is made by this pass. The English PDF needs a build from the updated chapter files before checking its rendered typography.

Visual comparison reference: https://math.ucr.edu/~mpierce/teaching/linear-algebra/docs/Hoffman%2CKunze-LinearAlgebra.pdf