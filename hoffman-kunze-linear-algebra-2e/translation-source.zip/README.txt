Hoffman & Kunze《线性代数》，Prentice-Hall 1971 年第二版，原扫描 416 页。
中文源稿包含原书前置材料、分节正文、附录、书目、索引，以及逐题解答和两种语言共享的勘误记录。
本版收入 59/59 节；解答 540/540 道正式习题；勘误 135 条。
使用已安装 ctex、Fandol、AMS、TikZ、enumitem、hyperref 的 TeX Live 及 Python 3。
在本目录运行 python build.py，即可于 build/ 生成四份 PDF。也可对 translation.tex、solutions.tex、errata-zh.tex、errata-en.tex 分别运行两次 XeLaTeX。
题号及原页范围见 exercises.csv，独立复核和原书页码对应见 review/。
