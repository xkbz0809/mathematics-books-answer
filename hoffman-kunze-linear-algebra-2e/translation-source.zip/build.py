"""Build the Chinese reading copy, solutions, and both errata from the editable files.
Run: python build.py. XeLaTeX (TeX Live, with ctex and Fandol) is required.
"""
from pathlib import Path
import argparse
import csv
import json
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
build = root / "build"
build.mkdir(exist_ok=True)
parser = argparse.ArgumentParser()
parser.add_argument("targets", nargs="*", default=["translation", "solutions", "errata-zh", "errata-en"])
args = parser.parse_args()
def literature(which):
    return sorted((root / which).glob("[0-9][0-9]-[0-9][0-9].tex"))

def indexed_solutions(path, body):
    catalogue = root / "exercises.csv"
    if not catalogue.is_file():
        catalogue = root.parent / "english" / "retypeset" / "exercises.csv"
    section = ".".join(str(int(n)) for n in path.stem.split("-"))
    body = re.sub(r"\\orig(?:chapter|section)\{[^{}]*\}\{[^{}]*\}", "", body)
    body = re.sub(r"\\(?:chapter|section)\*\{[^{}]*\}", "", body)
    body = re.sub(r"\\addcontentsline\{toc\}\{(?:chapter|section)\}\{[^{}]*\}", "", body)
    with catalogue.open(encoding="utf8", newline="") as handle:
        rows = [r for r in csv.DictReader(handle) if r["section"] == section]
    depth = 0
    count = 0
    def interval(first, last):
        return first if first == last else first+"--"+last
    def insert(m):
        nonlocal depth, count
        token = m[0]
        if token.startswith(r"\begin"):
            depth += 1
        elif token.startswith(r"\end"):
            depth -= 1
        elif depth == 1:
            row = rows[count]
            count += 1
            printed = interval(row["original_printed_start"],row["original_printed_end"])
            scan = interval(row["original_pdf_start"],row["original_pdf_end"])
            return r"\item \exerciseplace{"+section+"."+row["exercise"]+"}{"+printed+"}{"+scan+"} "
        return token
    body = re.sub(r"\\(?:begin\{enumerate\}|end\{enumerate\}|item\b)",insert,body)
    assert count == len(rows), (section,count,len(rows))
    body = re.sub(r"(\\exerciseplace\{[^}]+\}\{[^}]+\}\{[^}]+\})\s*(?:（(?:原书)?第\s*[\d、，,–—－至和及\s-]+\s*页）|原书第\s*[\d、，,–—－至和及\s-]+\s*页。)",r"\1 ",body)
    indexed = root / "indexed-solutions" / path.name
    indexed.parent.mkdir(exist_ok=True)
    indexed.write_text(body,encoding="utf8")
    return indexed

def lines_for(kind):
    files = literature(kind)
    refs = []
    previous_chapter = None
    for p in files:
        body = p.read_text(encoding="utf-8")
        if not re.sub(r"(?m)(?<!\\)%.*", "", body).strip():
            continue
        if kind == "solutions":
            # Chapter and section names are shared with the translated text.
            chapter = p.stem.split("-")[0]
            if chapter != previous_chapter:
                first = (root/"chapters"/(chapter+"-01.tex")).read_text(encoding="utf8")
                heading = re.search(r"\\origchapter\{[^{}]+\}\{[^{}]+\}",first)
                assert heading, chapter
                refs.append(heading[0])
                previous_chapter = chapter
            original = (root/"chapters"/p.name).read_text(encoding="utf8")
            heading = re.search(r"\\origsection\{[^{}]+\}\{[^{}]+\}",original)
            assert heading, p
            refs.append(heading[0])
            p = indexed_solutions(p,body)
        refs.append(r"\input{" + p.relative_to(root).with_suffix("").as_posix() + "}")
    assert refs
    return refs

def errata(lang):
    rows = json.loads((root / "errata" / "entries.json").read_text(encoding="utf-8-sig"))
    if isinstance(rows, dict):
        rows = rows["entries"]
    assert rows and len(set(row["id"] for row in rows)) == len(rows)
    en = lang == "en"
    title = "Errata" if en else "原书勘误"
    head = (r"\documentclass[11pt]{article}\usepackage[utf8]{inputenc}\usepackage[a5paper,margin=18mm]{geometry}\usepackage{fontspec,amsmath,amssymb,mathtools,enumitem}\usepackage[hidelinks,unicode]{hyperref}" if en else r"\documentclass[UTF8,fontset=fandol,11pt]{ctexart}\usepackage[a5paper,margin=18mm]{geometry}\usepackage{amsmath,amssymb,mathtools,enumitem}\usepackage[hidelinks,unicode]{hyperref}")
    source = [head,r"\hypersetup{pdftitle={Hoffman–Kunze — "+title+r"}}",r"\setlength{\emergencystretch}{2em}\raggedbottom\begin{document}",r"\begin{center}{\LARGE\bfseries Hoffman--Kunze}\\[4pt]{\Large "+title+r"}\end{center}"]
    intro_en = (r"\noindent Kenneth Hoffman and Ray Kunze, \emph{Linear Algebra}, second edition, Prentice-Hall, 1971. "
                "References give the original printed page and its one-based page in the supplied 416-page scan. "
                f"The {len(rows)} entries below give the printed reading, a correction and its justification.")
    intro_zh = (r"\noindent 肯尼思·霍夫曼、雷·昆泽，《线性代数》，Prentice-Hall，1971 年第二版。"
                f"下列 {len(rows)} 条均已核对指定版本。每条列出原书印刷页和所给扫描件（共 416 页，从 1 数起）的 PDF 页，以及原文、订正和依据。")
    source.append(intro_en if en else intro_zh)
    for row in rows:
        number = row["page"]
        last = row.get("page_end", number)
        printed_range = str(number) if number == last else f"{number}--{last}"
        scan_first = row["pdf_page"]
        scan_last = row.get("pdf_page_end", scan_first)
        scan_range = str(scan_first) if scan_first == scan_last else f"{scan_first}--{scan_last}"
        section = str(row["section"])
        loc = row["location_"+lang]
        key = row["id"]
        proof = row["reason_"+lang]
        change = row["correction_"+lang]
        original = row["original_tex"]
        source.append(r"\section*{"+key+r"\enspace "+(f"p.~{printed_range}" if en else f"原书第 {printed_range} 页")+"}")
        where = (r"\S{}"+section) if section!="Index" else ("Index" if en else "索引")
        source.append(r"\noindent "+(f"Scan p.~{scan_range}. " if en else f"扫描件第 {scan_range} 页。")+where+r"\quad "+loc+r"\par\smallskip")
        for label,content in [(("Printed text" if en else "原文"),original),(("Correction" if en else "订正"),change),(("Reason" if en else "理由"),proof)]:
            source.append(r"\noindent\textbf{"+label+r".}\quad "+content+r"\par\smallskip")
        if key in {"E128","E129","E132"}:
            label = "Reader report, checked against the supplied scan" if en else "读者报告，已与本书扫描件比对"
            source.append(r"\noindent\href{https://math.stackexchange.com/q/437253}{"+label+r"}\par")
    if en:
        source.extend([r"\section*{Items to verify}",r"Three marks in the supplied scan have an uncertain reading. Their printed shapes are retained in the English typesetting. They are counted separately from the verified corrections above.",
                       r"\begin{itemize}\item Printed p.~212 (scan p.~221), \S{}6.6, Theorem 9(i). The subscript on the squared projection is narrow. Its dot cannot be read with certainty. The identity is $E_i^2=E_i$.",
                       r"\item Printed p.~215 (scan p.~224), \S{}6.7, Theorem 11(iv). The same ambiguity occurs in the projection identity. The mathematical subscript is $i$.",
                       r"\item Printed p.~265 (scan p.~274), \S{}7.5, proof of Theorem 11. A raised mark follows $W$ after the words \emph{We shall prove}. Its shape differs from the clear primes farther down the page.\end{itemize}"])
    else:
        source.extend([r"\section*{待核事项}",r"所给扫描件中有三处印迹的字形仍待核实。英文重排保留这些印迹，以下三项单独计数。",
                       r"\begin{itemize}\item 印刷第 212 页（扫描第 221 页），第 6.6 节定理 9(i)。投影平方项的下标很窄，点迹无法确辨。等式的数学含义为 $E_i^2=E_i$。",
                       r"\item 印刷第 215 页（扫描第 224 页），第 6.7 节定理 11(iv)。同一投影恒等式中的下标字形也难以确辨；由公式可判定下标应取 $i$。",
                       r"\item 印刷第 265 页（扫描第 274 页），第 7.5 节定理 11 的证明。以 \emph{We shall prove} 开头的句子中，$W$ 的右上方有一处印迹，形状与本页后文清晰的撇号有别。\end{itemize}"])
    source.append(r"\end{document}")
    return source

def manuscript(target):
    if target.startswith("errata-"):
        return errata(target.split("-")[-1])
    title = "线性代数（第二版）" if target == "translation" else "线性代数（第二版）课后习题中文解答"
    source = [r"\input{preamble}",r"\hypersetup{pdftitle={"+title+r"}}",r"\begin{document}\frontmatter"]
    if target == "translation":
        source.extend([r"\input{frontmatter}",r"\input{original-contents}",r"\renewcommand{\contentsname}{本译稿目录}\tableofcontents",r"\mainmatter",*lines_for("chapters")])
        for path in [*sorted((root/"back").glob("A[1-6].tex")),root/"back"/"bibliography.tex",root/"back"/"index.tex"]:
            if path.is_file():
                source.append(r"\input{"+path.relative_to(root).with_suffix("").as_posix()+"}")
    elif target == "solutions":
        source.extend([r"\begin{titlepage}\centering\vspace*{2cm}{\Huge\bfseries 线性代数\par}\bigskip{\Large 课后习题中文解答\par}\bigskip Hoffman--Kunze，1971 年第二版\par\vfill 依原书章、节和题号编排\end{titlepage}",r"\tableofcontents\mainmatter",*lines_for("solutions")])
    else:
        raise ValueError(target)
    return source + [r"\end{document}"]

def compile_one(target):
    tex = root / (target + ".tex")
    tex.write_text("\n".join(manuscript(target)) + "\n",encoding="utf-8")
    for _ in range(2):
        resp = subprocess.run(["xelatex", "-no-shell-escape", "-interaction=batchmode", "-halt-on-error", "-output-directory="+str(build), tex.name],cwd=root)
        if resp.returncode:
            raise SystemExit((build/(target+".log")).read_text(encoding="utf-8",errors="replace")[-2500:])
    log=(build/(target+".log")).read_text(encoding="utf-8",errors="replace")
    errors=[line for line in log.splitlines() if "Missing character:" in line or "undefined references" in line or "multiply defined" in line or "Overfull" in line]
    print(target, "issues", len(errors), errors[:6], flush=True)
if __name__ == "__main__":
    for name in args.targets:
        compile_one(name)
