# Basic Algebra II 独立中文翻译工程

本工程只对应 Nathan Jacobson《Basic Algebra II》第二版（W. H. Freeman and Company，1989）。原 PDF 为用户提供的 702 页文件。以原页可见内容为依据识读与翻译，现有文本层只作检索线索。

译文包含出版信息与献辞、两篇前言、原书目录和所附第一卷目录、导论、第 1—11 章、习题、章末参考文献、原索引及新增中英术语索引。正文共有 138 节（含导论 4 节）、544 道编号习题、707 个原式标号；原索引有 826 个条目。未增编习题解答。编号沿用原书；原书中的疑点、误印或损坏不作无说明的改写。

本卷源码与第一卷完全独立：

- src/main.tex 是唯一主入口，src/jacobson.sty 为本卷样式。
- src/chapters 保存按章、节拆分的可编辑中文 LaTeX。
- src/index-data 和 generate-index.py 保存原索引数据及其生成程序；现成的 src/original-index.tex 已可直接编译。
- qa 保存分节覆盖、原文疑点、编译日志、引用与版面核验记录。
- 核验说明.md 给出最终验收的实际范围和限制。早期分节记录中的“尚未编译”等状态是当时的过程状态，最终状态以该说明及最终核验记录为准。

## 编译

需要 Python 3、XeLaTeX，以及 TeX Live 中的 ctex、fontspec、amsmath、tikz-cd、Fandol 和 Computer Modern Unicode 字体。将 xelatex 加入 PATH；本机也可自动使用已安装的 TeX Live 2026。

在本工程目录执行：

    python -X utf8 build.py --clean

程序清除本工程的旧辅助文件，至少编译三遍；若引用或长表格尚需稳定，则自动追加编译，最多六遍。输出为 src/main.pdf。脚本只报告编译情况；编译成功不代替翻译、原文或数学内容核验。

无需第一卷工程、原 PDF、OCR 文件、网络服务或预先生成的辅助文件即可构建 PDF。重新核对来源时，应另行使用用户提供的原书 PDF；原书不包含在源码压缩包中。

样式采用 ctexbook，参考 MathTranslations 指南及本次取得的官方模板约定，并为原书手工编号及独立分卷作了适配。原书页码链接和中英术语索引由本工程独立维护。
