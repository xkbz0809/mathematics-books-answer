from pathlib import Path
import subprocess, json, re, sys, hashlib, shutil, argparse
root=Path(__file__).resolve().parent
src=root/'src'
parser=argparse.ArgumentParser(description='Build this independent Chinese translation with XeLaTeX.')
parser.add_argument('--clean',action='store_true',help='Remove generated auxiliary files before the three-pass build.')
args=parser.parse_args()
tex=shutil.which('xelatex') or r'D:\texlive\2026\bin\windows\xelatex.exe'
if not Path(tex).is_file():
    sys.exit('XeLaTeX was not found. Install TeX Live with ctex and add xelatex to PATH.')
if args.clean:
    for extension in ['aux','toc','out','log','fls','fdb_latexmk']:
        candidate=src/('main.'+extension)
        if candidate.is_file(): candidate.unlink()
qa=root/'qa'; qa.mkdir(exist_ok=True)
log=[]
for n in range(1,7):
    p=subprocess.run([str(tex),'-interaction=nonstopmode','-halt-on-error','-file-line-error','main.tex'],cwd=src,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (qa/f'build-pass-{n}.log').write_bytes(p.stdout)
    log.append({'pass':n,'exit_code':p.returncode})
    if p.returncode: break
    current=(src/'main.log').read_text(encoding='utf-8',errors='replace')
    if n>=3 and not re.search(r'Rerun to get|Label\(s\) may have changed|Table widths have changed',current):
        break
s=(src/'main.log').read_text(encoding='utf-8',errors='replace') if (src/'main.log').exists() else ''
report={'runs':log,'scope':'Compilation only; translation coverage and visual review are recorded separately.','clean_auxiliary_start':args.clean,'errors':len(re.findall(r'^!|(?:LaTeX|Package\s+\w+)\s+Error|Undefined control sequence|Emergency stop',s,re.M)),'undefined':len(re.findall(r'(?:Reference|Citation).*undefined',s)), 'missing_glyphs':len(re.findall('Missing character:',s)), 'overfull_boxes':len(re.findall('Overfull',s)), 'rerun':len(re.findall(r'Rerun to get|Label\(s\) may have changed',s))}
report['errors']=max(report['errors'],sum(x['exit_code']!=0 for x in log))
if (src/'main.pdf').exists(): report['pdf_sha256']=hashlib.sha256((src/'main.pdf').read_bytes()).hexdigest()
(qa/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(1 if any(x['exit_code'] for x in log) or any(report[k] for k in ['errors','missing_glyphs','undefined','overfull_boxes','rerun']) else 0)
