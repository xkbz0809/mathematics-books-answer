from pathlib import Path
import re,json
base=Path(__file__).resolve().parent
out=[r'\chapter*{原书索引}\markboth{原书索引}{原书索引}',r'\phantomsection\addcontentsline{toc}{chapter}{原书索引}',r'\label{original-index}',
     r'\noindent\textbf{译者说明：}以下按原索引顺序排列，页码保留原书印刷页码；点击页码可跳至相应原页内容的译文起点. 原索引中的重复页码与疑似误指也按原书保留.',
     r'\begingroup',r'\small',r'\newcommand{\originalindexline}[3]{\par\noindent\hangindent=1.5em\hspace*{#1em}#2\if\relax\detokenize{#3}\relax\else，#3\fi\par}']
counts={}
for f in sorted((base/'src'/'index-data').glob('*.txt')):
    out.append(r'\sourcepage{'+f.stem+'}')
    count=0
    for line in f.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        indent,term,refs=line.split('|')
        refs=refs.replace('–','--')
        refs=re.sub(r'\d+',lambda m:r'\sourcepageref{'+m.group()+'}',refs)
        out.append(r'\originalindexline{'+indent+'}{'+term+'}{'+refs+'}')
        count+=1
    counts[f.stem]=count
out.append(r'\endgroup')
(base/'src'/'original-index.tex').write_text('\n'.join(out)+'\n',encoding='utf-8')
(base/'qa'/'index-generation.json').write_text(json.dumps({'source_page_entries':counts,'entries':sum(counts.values()),'generated_from':'Manually translated index entries read from source page images','complete':set(counts)==set(map(str,range(695,703)))},ensure_ascii=False,indent=2),encoding='utf-8')
print(counts,sum(counts.values()))
