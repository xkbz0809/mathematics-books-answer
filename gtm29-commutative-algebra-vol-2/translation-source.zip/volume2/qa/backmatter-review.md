# 第二卷索引初译记录

- 已逐页实际查看原PDF418–423（原409–414）的6页索引，逐条录入中文、英文与原章/节/页定位.
- 目前是供后续正文使用与统一的初译，尚未独立逐条复核、未编译索引、未核对所有目标标签. 不能视为成品.
- 语境区分：拓扑 complete 译“完备”；附录4/5涉及整闭包的 complete module/ideal 暂译“完全模/理想”，待完整定义核对. complete linear system 译“完备线性系”.
- 待术语核对：system of integrity（整性系）、distinguished pseudo-polynomial（特异伪多项式）、cycle（闭链）、superficial element（表面元）、unmixed ideal（无混合理想）等，必须结合正文语义审定.
- 原书索引个别页号可能存在误指，例如 valuation ring 末项 VI,9,34；这里保留源索引，以后须对照正文明确记录.
