《交换巴拿赫代数教程》中文译稿：可编译 LaTeX 源码
Eberhard Kaniuth, A Course in Commutative Banach Algebras, GTM 246, Springer, 2009。

入口：main.tex。正文含原书五章、附录及书后材料，共51节；保留原题面/原提示，不含另编习题解答。数学核验的边界在PDF内《译本说明》，特别是定理5.2.7(iii)、习题5.8.9、24、40(i)及附录命题 A.6.4 外部证明和相应依赖。每个保留意见以相应正文为准。
构建：先安装配套的 XeLaTeX、Biber 和所需字体（见 BUILD-DEPENDENCIES.txt），在解压的 GTM246-LaTeX 目录执行 bash tools/build.sh full。输出为 build/main.pdf。Linux 云环境已从此源码清洁复编；Windows 有 tools/build.ps1 备选，未在 Windows 上实测。无需联网下载项目图件和工作区历史；系统 TeX/字体另行安装。
清单：62份活动 TeX 文件及文类、参考文献、项目标志和构建脚本。sources-manifest.json 给出项目内源文件大小与 SHA-256；没有捆绑原书扫描件、系统 TeX 发行版、编译缓存或历史备份。
