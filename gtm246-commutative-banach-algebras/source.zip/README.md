# 《交换巴拿赫代数教程》习题解答 · 可复编 LaTeX 源码

这是 Eberhard Kaniuth 原著（Springer GTM 246，2009）的独立中文习题解答，不是官方解答或原书译本。原题的 235 个题号全部收录：234 题有完整解答或已核反例，2.12.61 仅部分已核，其乘积特征在一般情形下是否穷尽切片积的全部特征仍待证明。

- PDF 题头的原书页号是原书印刷页；译稿 PDF 页号从已交付译稿的封面起算。
- 《题号页码对应.tsv》为 UTF-8 制表符分隔表，另列原书 PDF 物理页、解答册 PDF 物理页，以及解答册中的显示页码。物理页均从 1 起。
- 各题的 LaTeX 片段在 answers/，由 main.tex 统一编排。已在正文标出确证的原书问题，并提供证明、反例或修正。

## 编译

建议使用 TeX Live 2025 的完整安装（包括 CTeX、xeCJK、fontspec、biblatex、biber、AMS 数学宏包、TikZ、enumitem、needspace 与 hyperref），并安装 Computer Modern Unicode OpenType 字体和 Fandol 字体（标准 TeX Live 可用 cm-unicode、fandol）。无需原书 PDF、中文译稿、外部网络服务或 shell-escape。

从本目录运行：

    bash tools/build.sh

生成 build/main.pdf。Windows 上可用带 Bash 的环境，或者在 TeX 编辑器中顺序运行 XeLaTeX、Biber、XeLaTeX、XeLaTeX（均针对 main.tex 的同一输出目录；脚本另外执行头两次 XeLaTeX）。初次编译产生的交叉引用提示会在后续遍数消失。
