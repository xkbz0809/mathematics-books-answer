from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import re
import shutil
import subprocess
import sys
from contextlib import nullcontext
from uuid import uuid4

import pymupdf


ROOT = Path(__file__).resolve().parent
NAME = 'GTM26-代数理论-中文译本'


def build(root):
    subprocess.run([sys.executable, '-X', 'utf8', '-c', 'from assemble import write_includes;write_includes()'], cwd=root, check=True)
    subprocess.run([sys.executable, '-X', 'utf8', 'nav/build.py', '--standalone'], cwd=root, check=True)
    subprocess.run([sys.executable, '-X', 'utf8', 'nav/verify.py'], cwd=root, check=True)
    coverage = json.loads((root/'nav/coverage.json').read_text(encoding='utf8'))
    assert not coverage['missing'] and len(coverage['sections']) == 18, coverage['missing']
    log = (root/'nav/edition.log').read_text(encoding='utf8', errors='replace')
    for error in ('Missing character:', 'There were undefined references', 'multiply defined', 'Undefined control sequence'):
        assert error not in log, error
    return coverage


def page_digests(filename):
    with pymupdf.open(filename) as document:
        return [hashlib.sha256(page.read_contents() + repr(page.rect).encode() + page.get_text().encode()).hexdigest() for page in document]


def review_note_pages(filename):
    source = (ROOT/'nav/edition.tex').read_text(encoding='utf8')
    expected = set(re.findall(r'\b[ES]\d{3}\b', source))
    table = ROOT.parent/'errata/Supplement-errata.tsv'
    if table.is_file():
        for row in table.read_text(encoding='utf-8-sig').splitlines():
            assert row.split('\t')[0] in expected, row
    pages = {key: [] for key in sorted(expected)}
    with pymupdf.open(filename) as pdf:
        for page in pdf:
            for key in set(re.findall(r'[ES]\d{3}(?!\d)', page.get_text())) & expected:
                pages[key].append(page.number + 1)
    assert all(pages.values()), [key for key in pages if not pages[key]]
    return pages


def release():
    coverage = build(ROOT)
    files = [p for p in ROOT.glob('*.tex') if p.name != 'body-includes.tex']
    files += [ROOT/'assemble.py', ROOT/'release_check.py', ROOT/'nav/build.py', ROOT/'nav/verify.py', ROOT/'nav/README.md']
    for dirname in ('ch1b', 'ch2a', 'ch2b', 'ch3b', 'ch4'):
        files.extend((ROOT/dirname).glob('*.tex'))
        files.extend((ROOT/dirname).glob('*.md'))
    files.extend((ROOT/'assets').glob('*.*'))
    files.extend((ROOT/'ch2a/section2-figures').glob('*.png'))
    files.extend((ROOT/'independent-review').glob('*.md'))
    files.extend((ROOT/'ch1b/qa').glob('*.md'))
    files.extend(ROOT.glob('*.md'))
    target = ROOT.parent
    with nullcontext(ROOT/'work'/('release-'+uuid4().hex[:10])) as temporary:
        scratch = Path(temporary)
        scratch.mkdir(parents=True)
        archive = scratch/'sources.zip'
        with ZipFile(archive, 'w', ZIP_DEFLATED) as output:
            for path in sorted(set(files)):
                output.write(path, path.relative_to(ROOT).as_posix())
        fresh = scratch/'rebuild'
        with ZipFile(archive) as compressed:
            compressed.extractall(fresh)
        build(fresh)
        original = ROOT/'nav/edition.pdf'
        pages = page_digests(original)
        assert pages == page_digests(fresh/'nav/edition.pdf'), '独立重排的逐页排版指令、页面尺寸或文本不同'
        notes = review_note_pages(original)
        shutil.copy2(original, target/(NAME+'.pdf'))
        shutil.copy2(archive, target/(NAME+'-可编辑源稿.zip'))
        book = target/'GTM26-Algebraic Theories1976.pdf'
        result = dict(translated_pdf_pages=len(pages), chapters=4, sections=coverage['sections'], identical_page_text_geometry_and_contents=len(pages), review_note_pdf_pages=notes, source_pdf_sha256=hashlib.sha256(book.read_bytes()).hexdigest() if book.is_file() else None, output_pdf_sha256=hashlib.sha256(original.read_bytes()).hexdigest(), editable_zip_sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
        (target/(NAME+'-编排核验.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf8')


if __name__ == '__main__':
    release()
