from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def fragments(directory):
    return sorted((ROOT / directory).glob("*.tex"))


def add_files(lines, paths):
    for path in paths:
        if path.stem.lower() in {"main", "test", "check", "preview"}:
            continue
        lines.append(r"\input{" + path.relative_to(ROOT).with_suffix("").as_posix() + "}")


def write_includes():
    lines = []
    add_files(lines, fragments("ch1b"))
    lines.append(r"\chapter{范畴论要诀}")
    add_files(lines, fragments("ch2a"))
    lines.append(r"\setcounter{section}{2}")
    add_files(lines, [path for path in fragments("ch2b") if path.name.startswith("II-")])
    lines.append(r"\chapter{范畴中的代数理论}")
    add_files(lines, [path for path in fragments("ch2b") if path.name.startswith("III-")])
    add_files(lines, fragments("ch3b"))
    lines.append(r"\chapter{若干应用与相互联系}")
    add_files(lines, fragments("ch4"))
    (ROOT / "body-includes.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def build():
    write_includes()
    for iteration in range(3):
        result = subprocess.run(
            ["xelatex", "-jobname=book", "-interaction=batchmode", "-halt-on-error", "main.tex"],
            cwd=ROOT,
        )
        log = (ROOT / "book.log").read_text(encoding="utf-8", errors="replace")
        if result.returncode:
            print(log[-4000:])
            return result.returncode
        if iteration and not re.search(r"Rerun to get|has changed\. Rerun", log):
            break
    for line in log.splitlines():
        if re.search(r"Missing character|Overfull|undefined|multiply defined|Output written", line):
            print(line)
    return 0


if __name__ == "__main__":
    sys.exit(build())
