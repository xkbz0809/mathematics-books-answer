from pathlib import Path
from collections import Counter
import json
import re
import subprocess
import argparse

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
STARTS = [[7, 15, 24, 32, 50], [82, 115, 139], [161, 204, 224, 234, 246, 257, 272], [280, 292, 309]]
PLAIN = {'有限元泛代数': 1, '识别定理': 1, '带结构的对象': 3, '自由对象': 2, '无穷元理论': 5}
SOURCE = 'GTM26-Algebraic Theories1976.pdf'
PAGE = re.compile(r'(?<![a-zA-Z0-9])(?:vii|vi|[1-9][0-9]{0,2})(?=,|，|、|：|（|\\par|\s*$)')
ITEM = re.compile(r'^(?:\\paragraph\*?\{|\\par\\noindent\\textbf\{|\\itm\{\(?)(\d+\.\d+)(?![.\d])')
REF = re.compile(r'((?:定理|命题|引理|推论|定义)[ ~]*)([1-4]\.\d+(?:\.\d+)?)(?![.\d])')


def expand(name):
    path = ROOT / (name + '.tex')
    return re.sub(r'(?m)^\\input\{([^}]+)\}\s*$', lambda match: expand(match[1]) + '\n', path.read_text(encoding='utf-8'))


def build(standalone=False):
    entries = {}
    pages = Counter()
    chapter = 0
    body = False
    result = []
    original = not standalone and (ROOT.parent/SOURCE).is_file()
    items = {}
    duplicates = set()
    contexts = {}
    def link(match):
        text = match[0]
        target = {'vi': 6, 'vii': 7}.get(text) or int(text) + 8
        if not 1 <= target <= 364:
            raise ValueError(text)
        pages[target] += 1
        return rf'\href[page={target}]{{file:../../{SOURCE}}}{{{text}}}' if original else text

    for line in expand('main').splitlines():
        if line == r'\mainmatter':
            body = True
        if line == r'\backmatter':
            body = False
        if line == r'\begin{document}':
            result.append(r'\hypersetup{bookmarksdepth=3,linktoc=all}\renewcommand{\thesection}{\arabic{section}}')
        if body and line.startswith(r'\chapter{'):
            chapter += 1
        if body and re.fullmatch(r'(?:\\phantomsection)?\\addcontentsline\{toc\}\{section\}\{[^{}]+\}', line.strip()):
            continue
        heading = re.match(r'^\\section(\*?)\{([^{}]+)\}(.*)$', line)
        if heading and body:
            prefix = re.match(r'^(\d+)[.．]\s*(?:\\ )?\s*(.*)$', heading[2])
            number, title = (int(prefix[1]), prefix[2]) if prefix else (PLAIN[heading[2]], heading[2])
            key = f'{chapter}.{number}'
            if key in entries:
                raise ValueError('duplicate section ' + key)
            entries[key] = {'title': title, 'original': STARTS[chapter-1][number-1]}
            line = rf'\setcounter{{section}}{{{number-1}}}\section{{{title}}}{heading[3]}'
        elif re.fullmatch(r'\\(?:subsection|section)\*\{[^{}$]+\}', line):
            level, title = re.fullmatch(r'\\(subsection|section)\*\{(.+)\}', line).groups()
            line += rf'\addcontentsline{{toc}}{{{level}}}{{{title}}}'
        if line == r'\section*{符号索引}\addcontentsline{toc}{section}{符号索引}':
            if original:
                line += '\n' + r'数码链接至配套英文原书的相应印页；不是译本页码。\par'
        if not body and line.startswith(r'\noindent') and line.endswith(r'\par') and chapter == 4:
            parts = line.split('$')
            parts[::2] = [PAGE.sub(link, part) for part in parts[::2]]
            line = '$'.join(parts)
        if body and chapter:
            contexts[len(result)] = chapter
            item = ITEM.match(line)
            if item:
                key = f'{chapter}.{item[1]}'
                if key in items:
                    duplicates.add(key)
                items[key] = (len(result), item.span(1))
        result.append(line)
    for key in items.keys() - duplicates:
        line_id, (start, end) = items[key]
        line = result[line_id]
        result[line_id] = line[:start] + rf'\protect\hypertarget{{gtm.{key}}}{{{line[start:end]}}}' + line[end:]
    linked = Counter()
    for line_id, chapter_id in contexts.items():
        def reference(match):
            number = match[2]
            key = number if number.count('.') == 2 else f'{chapter_id}.{number}'
            if key not in items or key in duplicates:
                return match[0]
            linked[key] += 1
            return match[1] + rf'\hyperlink{{gtm.{key}}}{{{number}}}'
        if not result[line_id].lstrip().startswith('%'):
            result[line_id] = REF.sub(reference, result[line_id])
    if chapter != 4:
        raise ValueError('expected four chapters')
    missing = [f'{chap}.{sec}' for chap, starts in enumerate(STARTS, 1) for sec in range(1, len(starts)+1) if f'{chap}.{sec}' not in entries]
    (OUT/'coverage.json').write_text(json.dumps(dict(sections=entries, missing=missing, item_anchors=len(items)-len(duplicates), ambiguous_items=sorted(duplicates), explicit_references=linked, original_linked=original, index_destinations=pages), indent=2, ensure_ascii=False), encoding='utf-8')
    (OUT/'edition.tex').write_text('\n'.join(result)+'\n', encoding='utf-8')
    for iteration in range(4):
        subprocess.run(['xelatex','-interaction=batchmode','-halt-on-error','-output-directory=nav','nav/edition.tex'], cwd=ROOT, check=True)
        log = (OUT/'edition.log').read_text(encoding='utf-8',errors='replace')
        if iteration and 'Rerun to get' not in log and 'has changed. Rerun' not in log:
            break
    print('Absent section headings:', missing)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--standalone', action='store_true')
    build(parser.parse_args().standalone)
