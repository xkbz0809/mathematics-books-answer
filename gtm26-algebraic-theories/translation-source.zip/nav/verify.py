from collections import Counter
import json
import re
from pathlib import Path
from urllib.parse import unquote

import pymupdf

from build import OUT, ROOT, SOURCE


def verify():
    coverage = json.loads((OUT/'coverage.json').read_text(encoding='utf-8'))
    with pymupdf.open(OUT/'edition.pdf') as document:
        names = document.resolve_names()
        outline = document.get_toc(simple=False)
        external = Counter()
        internal = Counter()
        for page in document:
            for link in page.get_links():
                if link['kind'] == pymupdf.LINK_GOTOR:
                    assert (OUT/unquote(link['file'])).resolve() == ROOT.parent/SOURCE, link
                    external[str(link['page']+1)] += 1
                elif link['kind'] == pymupdf.LINK_NAMED:
                    target = link['nameddest']
                    assert target in names and 0 <= names[target]['page'] < len(document), target
                    internal[target] += 1
        assert external == (coverage['index_destinations'] if coverage['original_linked'] else {}), external
        assert set(target for target in names if target.startswith('gtm.')) == set(target for target in names if target.startswith('gtm.') and names[target]['page'] >= 0)
        assert sum(name.startswith('gtm.') for name in names) == coverage['item_anchors']
        for key, count in coverage['explicit_references'].items():
            assert internal['gtm.'+key] >= count, key
        for key, entry in coverage['sections'].items():
            hits = [row for row in outline if row[0] == 2 and row[1].endswith(entry['title'])]
            toc = (OUT/'edition.toc').read_text(encoding='utf-8')
            locations = re.findall(r'\\contentsline \{section\}\{\\numberline \{\d+\}' + re.escape(entry['title']) + r'\}\{[^}]+\}\{([^}]+)\}', toc)
            assert len(locations) == 1, key
            destination = locations[0]
            assert internal[destination] and destination in names, destination
            assert len(hits) == 1 and hits[0][2] == names[destination]['page']+1, (key,hits)
        for level, title, physical, detail in outline:
            assert 1 <= physical <= len(document), title
        print(f'{len(document)} pages; {len(outline)} bookmarks; {len(coverage["sections"])}/18 sections; {sum(external.values())} original-page links; {coverage["item_anchors"]} numbered targets; {sum(coverage["explicit_references"].values())} explicit references')


if __name__ == '__main__':
    verify()
