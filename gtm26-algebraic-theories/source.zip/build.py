from pathlib import Path
from collections import Counter
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import json
import re
import shutil
import subprocess
import pymupdf

ROOT = Path(__file__).resolve().parent
BOOK = "GTM26-Algebraic Theories1976.pdf"
SECTIONS = [
 ("1-1",9,13,15,"有限元泛代数"),("1-2",15,23,24,"等式呈示的克隆"),("1-3",12,31,32,"代数理论"),("1-4",14,48,50,"一个理论的代数"),("1-5",24,75,80,"无限元理论"),("1-5p",6,80,81,"集合论入门"),
 ("2-1",27,106,115,"基范畴"),("2-2",23,136,139,"自由对象"),("2-3",15,154,160,"带结构的对象"),
 ("3-1",24,189,204,"识别定理"),("3-2",20,214,224,"作为幺半群的理论"),("3-3",8,231,233,"抽象 Birkhoff 子范畴"),("3-4",8,244,246,"正则范畴"),("3-5",11,252,257,"纤维完备范畴中的代数"),("3-6",14,268,272,"双代数"),("3-7",11,277,279,"余极限"),
 ("4-1",10,289,292,"极小代数与拓扑动力学"),("4-2",11,305,309,"自由代数理论与系统的极小实现"),("4-3",12,332,340,"非确定性")]
CHAPTERS=["集合上的代数理论","范畴论要诀","范畴中的代数理论","若干应用与相互联系"]
PRE = r"""\documentclass[UTF8,11pt,oneside,openany]{ctexbook}
\usepackage[a4paper,top=24mm,bottom=24mm,left=26mm,right=26mm]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools,mathrsfs,bm,enumitem,tikz-cd,hyperref,xcolor}
\usetikzlibrary{arrows.meta,positioning,automata}
\definecolor{accent}{HTML}{126461}
\hypersetup{colorlinks=true,linkcolor=accent,urlcolor=accent,filecolor=accent,bookmarksdepth=2,pdftitle={代数理论：课后习题解答},pdfauthor={GTM 26 中文习题参考解答}}
\setcounter{tocdepth}{1}
\setlength{\emergencystretch}{3em}
\allowdisplaybreaks
\newcommand{\answer}[2]{\par\addvspace{1.1em}\noindent\phantomsection\hypertarget{answer.\unit.#1}{}\addcontentsline{toc}{subsection}{\unit.#1\quad #2}{\bfseries\color{accent}\unit.#1\quad #2}\par\nobreak\smallskip}
\newcommand{\unresolved}[1]{\textbf{本项未完成：}#1}
\providecommand{\id}{\mathrm{id}}\providecommand{\Set}{\mathbf{Set}}\providecommand{\Hom}{\operatorname{Hom}}
\providecommand{\T}{\mathbf T}\providecommand{\bbT}{\mathbf T}\providecommand{\K}{\mathcal K}\providecommand{\LL}{\mathcal L}
\providecommand{\cA}{\mathcal A}\providecommand{\cB}{\mathcal B}\providecommand{\cC}{\mathcal C}\providecommand{\cD}{\mathcal D}\providecommand{\cK}{\mathcal K}\providecommand{\cL}{\mathcal L}
\begin{document}
"""
def build(draft=False):
    out=[PRE]; fragments=[]; report={}; previous=None
    for tag,count,first,last,title in SECTIONS:
        path=ROOT/'parts'/(tag+'.tex')
        content=path.read_text(encoding='utf8') if path.exists() else ''
        if tag=='3-1' and (ROOT/'parts/3-1b.tex').exists():
            content+='\n'+(ROOT/'parts/3-1b.tex').read_text(encoding='utf8')
        if tag=='4-3' and (ROOT/'parts/4-3b.tex').exists():
            content+='\n'+(ROOT/'parts/4-3b.tex').read_text(encoding='utf8')
        numbers=re.findall(r'(?m)^\\answer\{([^}]+)\}',content)
        expected=list('ABCDEF') if tag.endswith('p') else list(map(str,range(1,count+1)))
        flagged=[]
        for question,body in zip(numbers,re.split(r'(?m)^\\answer\{[^}]+\}',content)[1:]):
            for note in re.findall(r'\\unresolved\{([^}]*)',body):
                flagged.append(dict(question=question, detail=note))
        report[tag]=dict(expected=count, present=numbers, missing=[s for s in expected if s not in numbers], flagged=flagged)
        if not draft and numbers!=expected: raise ValueError((tag,numbers,expected))
        if not numbers:continue
        chapter=int(tag[0])
        if previous!=chapter: fragments.append(r'\chapter{'+CHAPTERS[chapter-1]+'}');previous=chapter
        unit=tag.replace('-','.').replace('p','P')
        fragments+= [r'\section*{'+unit+r'\quad '+title+r'}\addcontentsline{toc}{section}{'+unit+r'\quad '+title+r'}\def\unit{'+unit+'}',
            r'\noindent 原书习题：印页 '+str(first)+'--'+str(last)+r'；\href[page='+str(first+8)+r']{file:'+BOOK+r'}{打开英文原页}。\par',
            r'\begingroup',content,r'\endgroup']
    name='trial' if draft else 'answers'
    total=sum(len(s['present']) for s in report.values()); flagged=sum(len(s['flagged']) for s in report.values())
    locations=[]
    for tag,entry in report.items():
        for item in entry['flagged']:
            code=tag.replace('-','.').replace('p','P')+'.'+item['question']
            locations.append(r'\hyperlink{answer.'+code+'}{'+code+'}')
    remaining=(r'\par 尚未完全解决的条目：'+ '、'.join(locations)+'。各题内标明具体分问及已证范围。') if flagged else ''
    proof=ROOT/'build'; proof.mkdir(exist_ok=True)
    out += [r'\begin{titlepage}\centering\vspace*{27mm}{\large GRADUATE TEXTS IN MATHEMATICS · 26\par}\vspace{12mm}{\Huge 代数理论\par}\bigskip{\LARGE 课后习题参考解答\par}\vfill Ernest G. Manes 著《Algebraic Theories》配套中文解答\par\bigskip '+('分批试排稿' if draft else '独立编写，非作者或出版社官方答案')+r'\end{titlepage}',
            r'\frontmatter\chapter*{阅读说明}本册只处理各节末的编号习题及集合论入门 A--F，不收正文留给读者的练习。以原书习题号码为准，如 2.3.8(d) 表示第二章第三节第八题的 (d) 问。章节首页标出原书印页范围，页序链接指向同目录的英文原版。沿用原书从左到右的复合记法；个别解答显式写 $g\circ f$ 时表示先 $f$ 后 $g$。若题设照印本不成立，以反例或有条件的修正版代替假证明。'+(f'本次含 {total} 个主条目；正文明确标记的未完成处 {flagged} 项。'),
            remaining,r'\tableofcontents\mainmatter',*fragments,r'\end{document}']
    (ROOT/(name+'.tex')).write_text('\n'.join(out),encoding='utf8')
    for iteration in range(3):
        cmd=['xelatex','-halt-on-error','-interaction=batchmode','-output-directory=build',name+'.tex']
        rc=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.DEVNULL).returncode
        log=(proof/(name+'.log')).read_text(encoding='utf8',errors='replace')
        if rc:raise RuntimeError(log[-2000:])
        if iteration and 'Rerun to get' not in log and 'has changed' not in log:break
    bad=[line for line in log.splitlines() if 'Missing character:' in line or 'undefined references' in line]
    if bad: raise ValueError(bad[:10])
    pdf=proof/(name+'.pdf')
    with pymupdf.open(pdf) as doc:
        marks=doc.get_toc()
        assert sum(level==3 for level,title,page in marks)==total,(len(marks),total)
        assert all(1<=page<=len(doc) for level,title,page in marks)
        words={}
        for level,title,pageno,dest in doc.get_toc(simple=False):
            if level!=3:continue
            code=title.split()[0]
            page=doc[pageno-1]
            if pageno not in words:words[pageno]=page.get_text('words')
            anchor_y=page.rect.height-dest['to'].y if dest['kind']==pymupdf.LINK_NAMED else dest['to'].y
            distance=min((abs(w[1]-anchor_y) for w in words[pageno] if w[4]==code),default=10000)
            if distance>36:raise ValueError(f'Bookmark {code} misses the printed heading on PDF page {pageno}')
        links=Counter(link['page']+1 for page in doc for link in page.get_links() if link['kind']==pymupdf.LINK_GOTOR)
        for tag,count,first,last,title in SECTIONS:
            if report[tag]['present']:assert links[first+8]>=1,(tag,first)
        print(name,len(doc),total,flagged,flush=True)
    (proof/(name+'-coverage.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    if not draft:
        title='GTM26-代数理论-课后习题中文解答'
        shutil.copy2(pdf,ROOT.parent/(title+'.pdf'))
        with ZipFile(ROOT.parent/(title+'-源稿.zip'),'w',ZIP_DEFLATED) as archive:
            for path in [ROOT/'build.py',ROOT/'inventory.py',ROOT/'answers.tex',*sorted((ROOT/'parts').glob('*.tex')),proof/'source-exercises.json',proof/'answers-coverage.json',*ROOT.glob('*.md')]:
                archive.write(path,path.relative_to(ROOT).as_posix())

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--draft',action='store_true')
    build(parser.parse_args().draft)
