from pathlib import Path
import re
import json
import sys

from build import ROOT, SECTIONS

source=(ROOT.parent/'zh/nav/edition.tex').read_text(encoding='utf8')
heads=list(re.finditer(r'(?m)^\\subsection\*\{[^}\n]*习题\}',source))
assert len(heads)==len(SECTIONS)
token=r'\\begin\{(?:enumerate|itemize|description)\}|\\end\{(?:enumerate|itemize|description)\}|\\item(?![A-Za-z])'
index={}
for pos,(head,(tag,count,*rest)) in enumerate(zip(heads,SECTIONS)):
    chunk=source[head.end():heads[pos+1].start() if pos+1<len(heads) else len(source)]
    stop=re.search(r'\\(?:section\{|chapter\{|backmatter|setcounter\{section)',chunk)
    if stop:chunk=chunk[:stop.start()]
    depth=0;rows=[]; current=None
    for match in re.finditer(token,chunk):
        val=match[0]
        if val.startswith(r'\begin'):depth+=1
        elif val.startswith(r'\end'):depth-=1
        elif depth==1:
            current=dict(prompt=chunk[match.end():match.end()+88].splitlines()[0].strip(),nested=0)
            rows.append(current)
        elif depth==2 and current is not None:current['nested']+=1
    index[tag]=rows
    print(f'{tag}: {len(rows)}/{count}',flush=True)
    if len(rows)!=count:
        print([r['prompt'][:32] for r in rows])
(ROOT/'build'/'source-exercises.json').write_text(json.dumps(index,indent=1,ensure_ascii=False),encoding='utf8')
