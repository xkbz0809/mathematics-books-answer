"""Windows-safe full MathTranslations build: XeLaTeX twice, biber, XeLaTeX twice."""
from pathlib import Path
import argparse, datetime, json, os, re, shutil, subprocess, sys, time

parser = argparse.ArgumentParser()
parser.add_argument('mode', nargs='?', choices=['full'], default='full')
parser.add_argument('--project', type=Path, default=Path(__file__).resolve().parents[1])
parser.add_argument('--tex', default='main.tex')
parser.add_argument('--clean', action='store_true')
args = parser.parse_args()
project = args.project.resolve()
tex = project / args.tex
stem = tex.stem
logdir = project / 'build' / (stem + '-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
logdir.mkdir(parents=True, exist_ok=True)
if args.clean:
    for ext in ['aux','toc','out','bcf','bbl','blg','run.xml','lof','lot','log']:
        candidate = project / (stem + '.' + ext)
        if candidate.is_file():
            candidate.unlink()
texbin = Path(r'D:\texlive\2026\bin\windows')
xelatex = shutil.which('xelatex') or str(texbin/'xelatex.exe')
biber = shutil.which('biber') or str(texbin/'biber.exe')
xe = [xelatex, '-interaction=nonstopmode', '-file-line-error', args.tex]
commands = [xe, xe, [biber, stem], xe, xe]
result = {'tex': str(tex), 'started_at': datetime.datetime.now().isoformat(), 'steps': [], 'complete': False}
for i, cmd in enumerate(commands, 1):
    started = time.monotonic()
    env = os.environ.copy()
    env.update({'LC_ALL': 'C', 'LC_CTYPE': 'C', 'LANG': 'C'})
    cache = project / 'build' / 'biber-cache'
    cache.mkdir(parents=True, exist_ok=True)
    env['PAR_GLOBAL_TEMP'] = str(cache)
    proc = subprocess.run(cmd, cwd=project, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out = proc.stdout.decode('utf-8', errors='replace')
    (logdir / f'{i:02d}-{Path(cmd[0]).stem}.log').write_bytes(proc.stdout)
    step = {'step':i,'command':cmd,'returncode':proc.returncode,'seconds':round(time.monotonic()-started,2)}
    result['steps'].append(step)
    print(json.dumps(step, ensure_ascii=False), flush=True)
    if proc.returncode:
        result['failure_tail'] = out[-9000:]
        break
else:
    result['complete'] = True
final_log = project / (stem+'.log')
if final_log.exists():
    text = final_log.read_text(encoding='utf-8', errors='replace')
    result['final_checks'] = {
        'tex_errors': re.findall(r'(?m)^!.*|^.*\.(?:tex|cls|sty):\d+:.*', text),
        'missing_glyphs': re.findall(r'(?m)^Missing character:.*', text),
        'undefined_references': re.findall(r'(?m)^.*(?:undefined|multiply defined).*$' , text),
        'overfull_boxes': re.findall(r'(?m)^Overfull.*$', text),
        'underfull_boxes': re.findall(r'(?m)^Underfull.*$', text),
    }
pdf = project / (stem+'.pdf')
result['pdf_exists'] = pdf.exists()
if pdf.exists():
    import pymupdf
    doc = pymupdf.open(pdf)
    result['pages'] = len(doc)
    result['bookmarks'] = doc.get_toc()
    (logdir/'rendered_text.txt').write_text('\n\f\n'.join(p.get_text() for p in doc),encoding='utf-8')
(logdir/'build_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2),encoding='utf-8')
print('Build record:', logdir/'build_result.json')
if not result['complete']:
    print(result.get('failure_tail',''))
sys.exit(0 if result['complete'] else 1)
