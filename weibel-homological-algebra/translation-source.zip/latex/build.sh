#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -X utf8 tools/build.py full --project . --tex main.tex --clean
