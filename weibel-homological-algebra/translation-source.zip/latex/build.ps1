$ErrorActionPreference = 'Stop'
$projectPath = $PSScriptRoot
python -X utf8 (Join-Path $projectPath 'tools\build.py') full --project $projectPath --tex main.tex --clean
exit $LASTEXITCODE
