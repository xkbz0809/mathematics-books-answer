同调代数导论 — Charles A. Weibel
中文 LaTeX 译稿，可编辑源文件

入口：main.tex
编译：XeLaTeX → XeLaTeX → Biber → XeLaTeX → XeLaTeX。
Windows：在本目录运行 powershell -File build.ps1。
也可运行 python -X utf8 tools/build.py full --project . --tex main.tex --clean。
build.sh 为类 Unix 环境提供同一 Python 构建流程入口；本次实际验证环境为 Windows。
需要 Python 3、PyMuPDF，以及含 XeLaTeX、Biber、ctex、tikz-cd、biblatex、Fandol 字体的 TeX Live。
若 xelatex / biber 不在 PATH，脚本的 Windows 回退位置为 D:\texlive\2026\bin\windows；可按本机安装位置修改。

原书依据：用户提供的 An Introduction to Homological Algebra.pdf，465 个 PDF 页面。
Charles A. Weibel，Cambridge Studies in Advanced Mathematics 38，1994 年初版；
版权页同时记载 1995 年平装版、1997 年重印、2003 年转为数字印刷。
原书 SHA-256：
2422dd67ac8fc00c41adb4249074ae63ddce79f1e9eec5c6ead419644ec80668

保留原书的章节、条目和习题编号。习题仅译题目。
主题索引保留原书的词目和层次，页码换算为译稿页码并链接至对应位置；末尾术语索引也使用译稿页码。
经核实的英文原书问题在正文以带 E 编号的“原书勘误”脚注说明。中英文勘误表使用相同编号，列有原书印刷页和可点击的原书 PDF 页码。

模板来源：https://mathtranslations.org/guide/
官方模板下载：https://mathtranslations.org/static/catalog/mathtranslations-translation-template.3ea772c9d558.zip
下载包 SHA-256：a90e3b05895f36a577883feb14573a0a3d9136a560ca04c3827c9a5822f568b4
mathtranslation.cls 由下载模板按本书长篇结构本地调整为 ctexbook，并添加独立习题计数器等。

本目录只保留实际主文件及其依赖，不含章节预览驱动、编译缓存或上游示例内容。
完整的分批来源图像、工作过程和原始 PDF 保存在上级项目工作目录。
