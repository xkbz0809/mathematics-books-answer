# Greub《线性代数》第四版中译本

本项目据 Werner H. Greub, *Linear Algebra*, fourth edition, Springer-Verlag, 1975（Graduate Texts in Mathematics 23）所附英文 PDF 扫描页翻译并重排。

## 编译

将整个压缩包解压到同一目录，在含有 book.tex 的目录中连续运行三次以下命令。推荐使用完整 TeX Live，工程在 Windows、TeX Live 2026、XeLaTeX 下验证过。

    xelatex -interaction=nonstopmode -halt-on-error book.tex

首次运行会生成目录、书签和交叉引用所需的辅助文件。最后一遍生成的 book.pdf 是全书。若改动章节而使分页变化，继续编译到交叉引用稳定。工程使用 ctexbook、amsmath、amssymb、amsthm、enumitem、tikz-cd、geometry 及 hyperref。所有图表及正文公式均随源码提供。

交付的 PDF 使用 ctex 默认的 Windows 中文字体配置，正文宋体、章标题黑体。其他系统的 ctex 会选择当地的字体配置，段落折行和页码可能随字体变化。

## 内容

- book.tex 是全书入口，front.tex 和 dependency.tex 分别是书前各版序言等材料及章节依赖图。
- chapter-zero.tex 为第 0 章，sections 目录含第一至十三章的分节译稿。每章的公式号与小节号沿用原书，章节及小节可由 PDF 目录或书签进入。
- bibliography.tex 和 index-zh.tex 分别为书目与中英对照主题索引。索引保留原书的印刷页码，数字链接到译文中对应的节。重排后的中文页码见页眉、页脚及目录。
- 原书中影响理解的排印错误或条件不足，在相应位置用“译注”标明。原书的星号、个别跳号及重复编号予以保留。
