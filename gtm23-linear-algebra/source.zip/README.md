# Greub《线性代数》第四版中文习题解答

本册对应 Werner H. Greub, *Linear Algebra*, fourth edition, Graduate Texts in Mathematics 23, Springer-Verlag, 1975。正文依照原书节末习题顺序，含第 I 至 XIII 章的 482 道题。

用含中文支持的 TeX Live 在本目录运行两遍 `xelatex book.tex`。主文件为 `book.tex`，`chapters.tex` 确定编排次序，`sections` 中每个文件收录一节的中文题干、解答及原书页码。文件名的两个数字依次表示章和节。

需要使用指向英文原页的链接时，将生成的 PDF 与原扫描本 `GTM23-Linear Algebra1975.pdf` 放在同一目录。PDF 阅读器需要支持跳转到本地文件。手动定位的规则为印刷页码加 14。
