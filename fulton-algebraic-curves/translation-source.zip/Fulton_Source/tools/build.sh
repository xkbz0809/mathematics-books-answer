#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
if [ "$#" -eq 0 ]; then set -- full; fi
exec python3 tools/build.py "$@"
