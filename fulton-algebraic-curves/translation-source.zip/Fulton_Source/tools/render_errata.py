"""Render the translation notes and both errata from their common entries."""
from pathlib import Path
import json
import re

b=Path(__file__).resolve().parents[1]
dest=b/"errata"
records=json.loads((dest/"entries.json").read_text(encoding="utf-8"))
chapters=[('F','序言','Preface'),('1','仿射代数集','Affine Algebraic Sets'),('2','仿射簇','Affine Varieties'),('3','平面曲线的局部性质','Local Properties of Plane Curves'),('4','射影簇','Projective Varieties'),('5','射影平面曲线','Projective Plane Curves'),('6','簇、态射与有理映射','Varieties, Morphisms, and Rational Maps'),('7','奇点解消','Resolution of Singularities'),('8','黎曼–罗赫定理','Riemann--Roch Theorem'),('A','附录 A · 非零特征','Appendix A · Nonzero Characteristic'),('B','附录 B · 延伸阅读建议','Appendix B · Suggestions for Further Reading')]
def zhstyle(s):
    return s.replace('。','.').replace('“',chr(96)*2).replace('”',"''")
def standalone(s):
    s=s.replace('“',chr(96)*2).replace('”',chr(39)*2)
    s=re.sub(r'\\(?:ref|autoref)\{(?:ex|sec|prop):([^}]+)\}',r'\1',s)
    s=s.replace('§',r'\S\,')
    return s
def display(s):return standalone(zhstyle(s))
ids={e['id'] for e in records}
assert len(ids)==len(records)
notes=[]
for e in records:
    id=e['id']
    notes.append(r'\expandafter\def\csname displayerr'+id+r'\endcsname{'+e['number']+'}')
    notes.append(r'\expandafter\def\csname note'+id+r'\endcsname{'+display(e.get('short',e['zh']))+'}')
(b/'notes.tex').write_text('\n'.join(notes)+'\n',encoding='utf-8')
for lang in ('zh','en'):
    iszh=lang=='zh'
    t=[]
    cats={'math':('数学更正','Mathematical correction'),'condition':('适用条件与证明说明','Hypothesis or proof detail'),'editorial':('公式、文字或引文排误','Notation, text or reference')}
    groups=[]
    for g,z,h in chapters:
        rows=[e for e in records if e['group']==g]
        if not rows: continue
        name=(('第 '+g+' 章 · '+z) if iszh else ('Chapter '+g+' · '+h)) if g.isdigit() else (z if iszh else h)
        groups.append((g,name,rows))
    t.append(r'\newcommand{\entrycount}{'+str(len(records))+'}')
    t.append(r'\newcommand{\erratasummary}{'+ ('、'.join(cats[k][0]+str(sum(e['kind']==k for e in records))+'项' for k in ('math','condition','editorial')) if iszh else ', '.join(str(sum(e['kind']==k for e in records))+' '+v for k,v in [('math','mathematical corrections'),('condition','hypothesis or proof details'),('editorial','notation, text or reference corrections')])) +'}')
    t+= [r'\newcommand{\errnavigation}{\begin{tabular*}{\linewidth}{@{}l@{\extracolsep{\fill}}r@{}}\toprule']
    for g,name,rows in groups:
        t.append(r'\hyperlink{g:'+g+'}{'+name+r'} & \hyperlink{g:'+g+'}{'+rows[0]['number']+'--'+rows[-1]['number']+r'}\\')
    t += [r'\bottomrule\end{tabular*}}',r'\newcommand{\printentries}{']
    for g,name,rows in groups:
        t.append(r'\grouphead{'+g+'}{'+name+'}')
        for e in rows:
            s=display(e['zh']) if iszh else standalone(e['en'])
            location=display(e['loc_zh']) if iszh else standalone(e['loc_en'])
            if e.get('url'): s+=r' \externalref{'+e['url'].replace('#',r'\#')+'}{'+e['source']+'}'
            t.append(r'\correction{'+e['number']+'}{'+cats[e['kind']][0 if iszh else 1]+'}{'+str(e['page'])+'}{'+str(e['pdfpage'])+'}{'+location+'}{'+s+'}')
    t.append('}')
    (dest/('text-'+lang+'.tex')).write_text('\n'.join(t)+'\n',encoding='utf-8')
print('Entries',len(records),'by type',{k:sum(e['kind']==k for e in records) for k in ('math','condition','editorial')})
