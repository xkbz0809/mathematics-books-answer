"""Build the translation and the two parallel errata with TeX Live."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
OUTPUTS = {
    "main": "Fulton_Algebraic_Curves_ZH.pdf",
    "errata-zh": "Fulton_Errata_ZH.pdf",
    "errata-en": "Fulton_Errata_EN.pdf",
}

def stage(work):
    work.mkdir(parents=True, exist_ok=True)
    files = list(ROOT.glob("*.tex")) + list(ROOT.glob("*.bib")) + list(ROOT.glob("*.cls"))
    files.append(ROOT / "logo.pdf")
    for sub in ("chapters", "figures", "errata"):
        files.extend(p for p in (ROOT / sub).rglob("*") if p.is_file() and p.suffix.lower() in {".tex", ".png", ".pdf", ".jpg"})
    for src in files:
        target = work / src.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, target)

def build(job, output):
    work = output / "work" / job
    stage(work)
    for extension in ("aux", "toc", "out", "bbl", "bcf", "blg", "run.xml"):
        (work / f"{job}.{extension}").unlink(missing_ok=True)
    xelatex = ["xelatex", "-interaction=nonstopmode", "-halt-on-error", job + ".tex"]
    commands = [xelatex, xelatex, ["biber", job], xelatex, xelatex] if job == "main" else [xelatex, xelatex]
    for i, args in enumerate(commands, 1):
        logfile = work / f"pass-{i}.txt"
        print(f"{job}  {i}/{len(commands)}  {args[0]}", flush=True)
        with logfile.open("wb") as fp:
            rc = subprocess.run(args, cwd=work, stdout=fp, stderr=subprocess.STDOUT).returncode
        if rc:
            lines = logfile.read_text(encoding="utf-8", errors="replace").splitlines()
            print("\n".join(lines[-24:]), file=sys.stderr)
            raise SystemExit(rc)
    shutil.copyfile(work / f"{job}.pdf", output / OUTPUTS[job])
    print(OUTPUTS[job], flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("job", choices=("full", *OUTPUTS), nargs="?", default="full")
    parser.add_argument("--out", type=Path, default=ROOT / "build")
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    for job in (OUTPUTS if args.job == "full" else (args.job,)):
        build(job, output)

if __name__ == "__main__":
    main()
