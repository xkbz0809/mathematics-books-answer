# 《代数曲线：代数几何引论》中文译本

William Fulton 著，原书电子版署期为 2008 年 1 月 28 日。中文译本及中英文勘误于 2026 年 11 月 21 日整理。底本 PDF 的 SHA-256 为 `937a5c2a962b5de196a64578242b5395afdbea03a132124e4feebcfe62adf628`。

## 编译

使用含中文宏包和 Fandol 字体的 TeX Live、XeLaTeX、Biber 及 Python 3.9 或更高版本。本项目已用 TeX Live 2026 编译。请在解压得到的工程目录运行以下命令。

```sh
python tools/build.py full
```

在 Unix 系统也可以运行 `sh tools/build.sh full`。构建脚本在独立目录内运行 XeLaTeX，清除旧辅助文件，并在译本的第二遍和第三遍之间运行 Biber。`build` 目录中生成以下文件。

| 文件 | 内容 |
|---|---|
| `Fulton_Algebraic_Curves_ZH.pdf` | 中文全译本，含译校脚注、附录、原书主题索引与中英术语索引 |
| `Fulton_Errata_ZH.pdf` | 中文勘误表 |
| `Fulton_Errata_EN.pdf` | 英文勘误表 |

只构建其中一册时，可将命令末尾的 `full` 替换为 `main`、`errata-zh` 或 `errata-en`。

## 文件与定位

`main.tex` 为译本入口，`chapters` 收录各章，`figures` 保存几何插图。`front.tex`、`appendixA.tex` 至 `appendixC.tex` 和 `source-index.tex` 分别收录序言、附录和原书索引。书目记录在 `references.bib` 中。所有文本均使用 UTF-8。

页边的“原”标记跟踪原书印刷页码。正文原第 1 页对应底本 PDF 第 9 页。勘误表的页码链接指向作者公开的电子版。三个 PDF 中同一个 E 编号对应同一条译校意见。

`errata/entries.json` 保存全部勘误的编号、类别、原书与 PDF 页码、双语位置和双语说明。修改记录后，运行 `python tools/render_errata.py` 再编译。生成的 `notes.tex` 供译本脚注使用，`errata/text-zh.tex` 和 `errata/text-en.tex` 供两份勘误表使用。若新增记录，请在相应译文段落放置匹配内部键的 `\errnote{键}`。

原书网址：https://dept.math.lsa.umich.edu/~wfulton/CurveBook.pdf
