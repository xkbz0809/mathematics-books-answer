# Fulton《代数曲线》习题解答源码

源码对应 2008 年 1 月 28 日电子版的 312 道编号习题。Fulton_Exercises_ZH.tex 是可独立编译的 LaTeX 稿。在 TeX Live（含 CTeX、Fandol、TikZ、needspace）环境连续执行三遍 xelatex Fulton_Exercises_ZH.tex。仓库 PDF 和重编的 LaTeX PDF 使用不同的版式。Fulton_Exercises_Reader_ZH.html 是随交付提供的浏览器阅读稿。
