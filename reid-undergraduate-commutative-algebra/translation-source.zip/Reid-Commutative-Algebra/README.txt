本科交换代数 • 中文译本与中英文勘误
Miles Reid, Undergraduate Commutative Algebra, LMS Student Texts 29
原版 1995 年，2002 年转为数字印刷。译校日期 2026 年 11 月 21 日。

在本目录运行（Windows / TeX Live 2026，XeLaTeX）：
  latexmk -xelatex main.tex
  latexmk -xelatex errata-zh.tex
  latexmk -xelatex errata-en.tex

main.tex 为中文译本入口。ch*.tex 为各章，fig/ 为从读者提供的原书裁出的插图。
fontset=windows 使用 Windows 中文字体。在其他平台编译中文稿时，可将中文入口文件的 fontset 改为当前系统的 ctex 字库配置，例如 TeX Live 自带的 fandol。
errata-data.txt 中每条记录由定位信息、中文校注和英文校注三行组成。修改后运行：
  python make_errata.py
然后重新编译。notes.tex 与两个勘误入口文件由该脚本生成。supplement-zh.tex 和 supplement-en.tex 含任意底域情形的正规化有限性补证。

原书印刷页码和从 1 起算的 PDF 页序相差 14。例如原书第 122 页对应 PDF 第 136 页。译本重分页。书后术语索引保留原书页码。
