"""Regenerate the three LaTeX note files from the bilingual editorial register."""
from pathlib import Path
r=Path(__file__).resolve().parent
data=(r/'errata-data.txt').read_text(encoding='utf-8').splitlines()
assert len(data)%3==0
records=[]
for n in range(0,len(data),3):
 ident,pages,zloc,eloc,kind=data[n].split('|')
 records.append((ident,pages,zloc,eloc,kind,data[n+1],data[n+2]))
kinds={'typo':('排印订正','Typographical correction'),'hyp':('条件补充','Missing hypothesis'),'scope':('表意澄清','Clarification'),'ref':('交叉引用','Cross-reference'),'proof':('论证补充','Proof correction'),'notation':('记号订正','Notation')}
group={0:'第 0 章　你好！',1:'第 1 章　基础',2:'第 2 章　模',3:'第 3 章　诺特环',4:'第 4 章　有限扩张与诺特正规化',5:'第 5 章　零点定理与环谱',6:'第 6 章　分式环与局部化',7:'第 7 章　准素分解',8:'第 8 章　离散赋值环与正规整环',9:'第 9 章　再见！'}
gen=['% Generated from errata-data.txt by make_errata.py.']
for ident,_,_,_,_,z,_ in records:
 if ident=='E28':
  z=z.replace('完整补证见本表末',r'完整补证见\hyperref[proof:normalisation]{书末译校补证}')
 gen.append(r'\expandafter\def\csname note'+ident+r'\endcsname{'+z+'}')
(r/'notes.tex').write_text('\n'.join(gen)+'\n',encoding='utf-8')
for i,lang in enumerate(('zh','en')):
 zh=lang=='zh'
 cls=r'\documentclass[UTF8,scheme=plain,fontset=windows,11pt]{ctexart}' if zh else r'\documentclass[11pt]{article}'
 title='原书勘误表' if zh else 'Errata and corrections'
 banner='本科交换代数' if zh else 'Undergraduate Commutative Algebra'
 loc='原书第 %s 页　·　PDF 第 %s 页' if zh else 'Print pp. %s  /  PDF pp. %s'
 pre=r'''\usepackage[a4paper,margin=24mm,top=23mm,bottom=24mm,headheight=15pt]{geometry}
\usepackage{amsmath,amssymb,xcolor,fancyhdr,hyperref}
\definecolor{ink}{HTML}{18394B}\definecolor{tone}{HTML}{245C68}
\hypersetup{unicode,colorlinks=true,linkcolor=tone,urlcolor=tone}
\newcommand{\Z}{\mathbb Z}\newcommand{\F}{\mathbb F}\newcommand{\C}{\mathbb C}
\DeclareMathOperator{\Spec}{Spec}\DeclareMathOperator{\Frac}{Frac}\DeclareMathOperator{\Supp}{Supp}\DeclareMathOperator{\Tr}{Tr}\DeclareMathOperator{\Ann}{Ann}
\providecommand{\llbracket}{[\![}\providecommand{\rrbracket}{]\!]}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\small\thepage}\renewcommand{\headrulewidth}{.25pt}
\setlength{\emergencystretch}{2em}\setlength{\parindent}{0pt}\setlength{\parskip}{5pt}
\raggedbottom
'''
 pdfmeta=r'\hypersetup{pdfauthor={OpenAI Codex},pdftitle={'+banner+' — '+title+r'}}'
 s=[cls,pre,pdfmeta,r'\fancyhead[L]{\small\itshape '+banner+r'}\fancyhead[R]{\small '+title+r'}',r'\begin{document}',r'\thispagestyle{plain}',r'{\large\itshape Miles Reid \enspace / \enspace '+banner+r'}\par',r'{\Huge\bfseries\color{ink} '+title+r'}\par\medskip']
 if zh:
  s+=['原书为剑桥大学出版社 1995 年初版、2002 年转数字印刷的伦敦数学会学生丛书第 29 卷。本表收录本次译校核出的 42 项，英文表和中文译本旁注使用同一编号。每项给出印刷页、从 1 起计的 PDF 页序及节或习题位置。表意澄清说明原文简写的适用范围。','OpenAI Codex（GPT-6）译校，2026 年 11 月 21 日。']
 else:
  s+=['London Mathematical Society Student Texts 29, Cambridge University Press, first published 1995, transferred to digital printing in 2002. This independent editorial list records 42 items identified in preparing the Chinese translation. The Chinese list and the notes in the translated book use the same identifiers. PDF pages are counted from the first page of the supplied 167-page file. Clarifications indicate the scope of abbreviated statements.','Prepared by OpenAI Codex (GPT-6), 21 November 2026.']
 last=-1
 for ident,pp,zloc,eloc,kind,z,e in records:
  pdf='--'.join(str(int(a)+14) for a in pp.split('--'))
  chap=next(j for j,(a,b) in enumerate([(1,18),(19,36),(37,48),(49,57),(58,69),(70,83),(84,94),(95,111),(112,128),(129,148)]) if a<=int(pp.split('--')[0])<=b)
  if chap!=last:
   label=group[chap] if zh else 'Chapter '+str(chap)
   s.append(r'\addvspace{7pt}\pdfbookmark[1]{'+label+'}{chap'+str(chap)+r'}\par\nobreak{\large\bfseries\color{ink}'+label+r'}\par\nobreak\smallskip')
   last=chap
  line=loc%(pp,pdf)
  if not zh:
   if '--' not in pp: line=line.replace('pp.', 'p.')
  s+= [r'\noindent\begin{minipage}{\linewidth}',r'{\bfseries\color{tone}'+ident+r'}\quad {\bfseries '+(zloc if zh else eloc)+r'}\par',r'{\footnotesize\sffamily\color{tone}'+line+r'\quad '+kinds[kind][i]+r'}\par',z if zh else e,r'\end{minipage}\par\addvspace{7pt}']
 s+=[r'\clearpage\pdfbookmark[1]{'+('E28 证明补充' if zh else 'E28 supplementary proof')+r'}{proof}',r'\input{supplement-'+lang+r'}',r'\end{document}']
 (r/('errata-'+lang+'.tex')).write_text('\n'.join(s)+'\n',encoding='utf-8')
