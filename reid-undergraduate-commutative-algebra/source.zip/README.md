# Reid《本科交换代数》课后习题解答源码

入口为 solutions.tex，正文和题面已汇编到 solutions-body.tex。使用带 CTeX 的 XeLaTeX 和 Windows 中文字体，在本目录连续运行三遍 xelatex solutions.tex。源码不依赖原书或配套译本。
