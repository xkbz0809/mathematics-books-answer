from pathlib import Path
import argparse, os, shutil, subprocess, json, re, sys, hashlib
parser=argparse.ArgumentParser(description='Build this independent Jacobson Chinese translation.')
parser.add_argument('--clean',action='store_true',help='Remove generated TeX intermediates before compiling.')
args=parser.parse_args()
root=Path(__file__).resolve().parent
src=root/'src'
configured=os.environ.get('JACOBSON_XELATEX')
tex=configured or shutil.which('xelatex') or r'D:\texlive\2026\bin\windows\xelatex.exe'
if not Path(tex).is_file():
    parser.error('XeLaTeX not found. Put xelatex on PATH or set JACOBSON_XELATEX to its executable.')
if args.clean:
    for suffix in ['.aux','.toc','.out','.log','.fls','.fdb_latexmk','.xdv','.synctex.gz']:
        path=src/('main'+suffix)
        if path.exists(): path.unlink()
qa=root/'qa'; qa.mkdir(exist_ok=True)
log=[]
for n in range(1,4):
    p=subprocess.run([str(tex),'-interaction=nonstopmode','-halt-on-error','-file-line-error','main.tex'],cwd=src,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (qa/f'build-pass-{n}.log').write_bytes(p.stdout)
    log.append({'pass':n,'exit_code':p.returncode})
    if p.returncode: break
s=(src/'main.log').read_text(encoding='utf-8',errors='replace') if (src/'main.log').exists() else ''
report={'runs':log,'scope':'Compilation only; see qa/release-qa-report.md for visual and source checks.','errors':len(re.findall(r'^!|^.*\.(?:tex|sty):\d+:|(?:LaTeX|Package\s+\w+)\s+Error|Undefined control sequence|Emergency stop',s,re.M)),'undefined':len(re.findall(r'(?:Reference|Citation).*undefined',s)), 'missing_glyphs':len(re.findall('Missing character:',s)), 'overfull_boxes':len(re.findall('Overfull',s)), 'rerun':len(re.findall(r'Rerun to get|Label\(s\) may have changed',s))}
report['build_passed']=not any(x['exit_code'] for x in log) and not any(report[k] for k in ['errors','missing_glyphs','undefined','overfull_boxes','rerun'])
report['pdf_sha256']=hashlib.sha256((src/'main.pdf').read_bytes()).hexdigest() if (src/'main.pdf').exists() else None
(qa/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
sys.exit(1 if any(x['exit_code'] for x in log) or any(report[k] for k in ['errors','missing_glyphs','undefined','overfull_boxes','rerun']) else 0)
