# Basic Algebra I 独立中文翻译工程

状态：本卷全文中文翻译与重排已完成，最终版为 426 页。来源覆盖、构建、成品布局和导航检查结果见 `qa/release-qa-report.md`；这些检查不等于逐命题独立验证，也不保证数学内容绝无错误。

本工程仅对应原书第 I 卷。所有 TeX 文件与样式均在 src 内，不依赖另一卷源代码。原始 PDF 保留在上级目录且只读。

构建：在本工程目录运行 `python -X utf8 build.py --clean`（需要 Python 3、XeLaTeX、ctex、Fandol、CMU 字体）。程序优先从 PATH 寻找 XeLaTeX，也可用环境变量 `JACOBSON_XELATEX` 指定其完整路径；本机后备路径为 `D:\texlive\2026\bin\windows\xelatex.exe`。程序连续构建三遍，输出为 `src/main.pdf`；三遍记录位于 `qa/build-pass-1.log` 至 `qa/build-pass-3.log`，汇总为 `qa/build-report.json`。构建成功只说明编译检查通过。

当前无外部 biblatex 数据库，原书参考文献随正文重排。样式采用 ctexbook 真实章节层次，参考 MathTranslations 现行指南及官方模板的字体、标点和链接约定。源码不需要另一卷，也不需要原扫描 PDF 即可编译。若要执行额外的 PDF 检查脚本，需要安装 PyMuPDF 和 Pillow；这些包不参与 LaTeX 构建。

全文包含前置材料、原目录、原序言、第 0–8 章共 94 节、原书习题、附录、原书索引，并另附中英文术语索引。原书索引保留原条目次序及原印刷页码；其页码可点击跳到译本来源位置。术语索引的页码是译本页码。

所供原扫描 PDF 第 22–23、387、514 页有可见缺文或错行，译文保留明确标示，不猜补。`qa/source-issues-register.json` 汇集译制中发现的 174 条原文疑点记录，其中有候选、约定问题和排印问题，不能统称为 174 个已经证明的数学错误。

`qa/ch00-coverage.json` 至 `qa/ch08-coverage.json` 等保留译制阶段记录；其中“待编译”“全书未完成”等字样是当时的阶段状态。最终状态以 `qa/release-qa-report.md`、`qa/release-structure.json`、`qa/release-visual-manifest.json` 和本说明为准。
