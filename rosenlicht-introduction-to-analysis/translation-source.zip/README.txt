Rosenlicht, Dover 1986. Chinese translation, solutions and bilingual errata.
Run xelatex -no-shell-escape twice on each of translation.tex, solutions.tex, errata-zh.tex and errata-en.tex in this folder. Edit chNN.tex, solNN.tex or the language-paired errata.json, then run python refresh-edition.py to refresh entry points, generated answer files, both errata and the exercise index. After refreshing, run the four XeLaTeX jobs twice. PDF page numbers in source-pages.csv count from the scanned cover.
Translation chapters: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Solutions chapters: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
