from pathlib import Path
import pymupdf as fitz
from PIL import Image, ImageOps
base=Path(__file__).resolve().parent.parent
d=fitz.open(next(base.glob('*.pdf')))
out=base/'Rosenlicht-source'/'images';out.mkdir(parents=True,exist_ok=True)
for fig,n,rect in [(31,184,(5,75,643,265)),(32,186,(39,535,632,741)),(33,200,(120,72,537,348))]:
    page=d[n-1];scale=page.rect.width/650
    pix=page.get_pixmap(matrix=fitz.Matrix(1.0,1.0),clip=fitz.Rect(*[v*scale for v in rect]),colorspace=fitz.csGRAY,alpha=False)
    im=Image.frombytes('L',(pix.width,pix.height),pix.samples)
    im.point(lambda p: min(255,max(0,round((p-30)*255/158)))).save(out/f'fig{fig}.png')
