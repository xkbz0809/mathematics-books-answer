from pathlib import Path
from PIL import Image,ImageOps
import sys
root=Path(__file__).resolve().parent
for n in [183,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,199,200,201,202,203,204,207,208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,225]:
    im=Image.open(root/'pages'/f'{n:03}.png')
    im.thumbnail((680,1170))
    im.save(root/'sheets'/f'v{n}.jpg',quality=82)
