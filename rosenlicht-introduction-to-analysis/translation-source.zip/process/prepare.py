from pathlib import Path
import pymupdf as fitz
from PIL import Image, ImageDraw
base=Path(__file__).resolve().parent.parent
work=base/'Rosenlicht-work'
for name in ('text','pages','sheets','build'): (work/name).mkdir(parents=True, exist_ok=True)
doc=fitz.open(next(base.glob('*.pdf')))
for n,p in enumerate(doc,1):
    text=p.get_text('text',sort=True)
    (work/'text'/f'{n:03}.txt').write_text(text,encoding='utf-8')
    if n<15 or 182<=n<=229 or n>=263:
        if (work/'pages'/f'{n:03}.png').exists(): continue
        pix=p.get_pixmap(matrix=fitz.Matrix(.66,.66),colorspace=fitz.csGRAY,alpha=False)
        im=Image.frombytes('L',(pix.width,pix.height),pix.samples)
        im.save(work/'pages'/f'{n:03}.png')
for i,ns in enumerate(((1,2,3,4,5,6,7,8,9,10,11,12,13,14),(263,264,265,266,267,268,269,270,271,272,273,274,275,276),(15,26,29,43,47,75,81,104,111,122,125,146,151,174,183,204,207,226,229,258))):
    sheet=Image.new('L',(230*7,390*((len(ns)+6)//7)),255)
    for j,n in enumerate(ns):
        p=doc[n-1]
        pix=p.get_pixmap(matrix=fitz.Matrix(.17,.17),colorspace=fitz.csGRAY,alpha=False)
        im=Image.frombytes('L',(pix.width,pix.height),pix.samples)
        im.thumbnail((220,365)); pos=((j%7)*230,(j//7)*390)
        sheet.paste(im,(pos[0],pos[1]+14))
        ImageDraw.Draw(sheet).text(pos,str(n),fill=0)
    sheet.save(work/'sheets'/f'sheet{i}.png')
print('processed',len(doc))