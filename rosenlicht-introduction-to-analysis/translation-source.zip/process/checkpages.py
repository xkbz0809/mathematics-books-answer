from PIL import Image,ImageDraw,ImageOps
from pathlib import Path
base=Path('Rosenlicht-work')
for idx,ns in enumerate(([184,186,200],[198,204],[226,227,228],[187,188,193],[195,199,202],[215,217,221])):
    out=Image.new('L',(650*len(ns),1122),255)
    for i,n in enumerate(ns):
        im=Image.open(base/'pages'/f'{n:03}.png')
        im.thumbnail((650,1122));out.paste(im,(650*i,0))
    out.save(base/'sheets'/f'checks{idx}.jpg',quality=86)
