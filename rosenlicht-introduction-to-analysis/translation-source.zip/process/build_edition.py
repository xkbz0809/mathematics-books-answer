"""Build a numbered, scope-labelled Rosenlicht edition from a source snapshot."""
import argparse, csv, datetime, hashlib, json, os, re, shutil, subprocess, tempfile, zipfile
from pathlib import Path
import pymupdf
parser=argparse.ArgumentParser()
parser.add_argument('--text',required=True)
parser.add_argument('--solutions',required=True)
parser.add_argument('--full',action='store_true')
args=parser.parse_args()
project=Path(__file__).resolve().parent.parent
src=project/'Rosenlicht-source'
dest=project/'交付'/'Rosenlicht-Dover-1986'
dest.mkdir(parents=True,exist_ok=True)
work=Path(tempfile.mkdtemp(prefix='Rosenlicht-build-'))
tex=work/'source'
shutil.copytree(src,tex,ignore=shutil.ignore_patterns('*.aux','*.log','*.out','*.toc','*.pdf','__pycache__'))
chs=[int(x) for x in args.text.split(',')]
sol=[int(x) for x in args.solutions.split(',')]
assert sorted(set(chs))==chs and sorted(set(sol))==sol
if args.full: assert chs==sol==list(range(1,11))
label=lambda ns:'、'.join(str(n) for n in ns)
def master(name,body):
    (tex/(name+'.tex')).write_text('\\input{preamble}\n\\begin{document}\n'+body+'\n\\end{document}\n',encoding='utf8')
cover=lambda title,desc:r'\bookcover{'+title+'}{'+desc+'}\n'
def bodycmd(ch):
    return '\\setcounter{chapter}{'+str(ch-1)+'}\\input{ch'+f'{ch:02}'+'}\n'
tag='' if args.full else '（阶段稿）'
master('translation',cover('中文译本'+tag,('全书十章，附原书页码、进一步阅读书目与索引。' if args.full else '本册收录原书第 '+label(chs)+' 章'))+r'\frontmatter\tableofcontents\input{front}\input{original-contents}\mainmatter'+'\n'+''.join(bodycmd(ch) for ch in chs)+(r'\backmatter\input{back}\input{publisher}' if (tex/'back.tex').exists() else ''))
def flattened(filename, trail=()):
    if filename in trail:
        raise ValueError('cyclic input: '+filename)
    t=(tex/(filename+'.tex')).read_text(encoding='utf-8-sig')
    return re.sub(r'\\input\{([^{}]+)\}',lambda m: flattened(m[1].removesuffix('.tex'),trail+(filename,)),t)
expected=[10,16,38,46,15,28,41,15,20,32]
def pdf_span(x):
    return re.sub(r'\d+',lambda m:str(14+int(m[0])),x)
subtasks={"1.3":"a–c 各含证明与作图","1.8":"单射、满射两种判据","1.9":"子集、自映射、满自映射的个数","2.7":"最大值和最小值两式","2.9":"上界、下界、上确界和下确界","2.10":"a–c 各求上确界和下确界","2.14":"有理数及无理数的稠密性","2.15":"循环小数的界定与有理性的充要条件","3.2":"验证度量；画开球","3.3":"开球、闭球、同一球的不同球心和半径、开集","3.13":"证明收敛；计算极限","3.18":"上下极限不等式；等号条件","3.19":"上极限与和的不等式；一列收敛时的等号","3.23":"和、差、标量积三条极限律","3.34":"积集的有界性、开性、闭性、紧致性","3.38":"开集和闭集两种版本","4.2":"闭集原像；非正、非负、零水平集","4.4":"映射及逆映射的连续性","4.5":"振幅零判据；振幅不小于给定正数的点集闭","4.17":"两个函数的一致连续性及理由","4.21":"延拓的唯一性和一致连续性","4.23":"范数等价与有限维完备性","4.28":"开盒和闭盒的连通性","4.32":"根式列的收敛性及其极限函数","4.34":"分别判断三个有理函数序列","4.37":"和列与积列","4.40":"单调性与连续极限情形的一致收敛","4.45":"连续函数空间的完备性与范数；由复合给出的连续线性映射","4.46":"有界连续函数、全体有界函数及两空间的关系","9.1":"连续性及可微点","9.4":"存在性、唯一性、可微性","9.9":"验证热核和其积分所满足的方程","9.12":"连续可微、二阶偏导数的存在及混合偏导数不相等","9.16":"极值一阶必要条件；二阶型负定、正定和不定三种情形","9.19":"精确表述与证明","5.4":"递增和递减两种等价式","5.5":"两个函数的单调性","5.11":"极大值与极小值两个分支","5.12":"弦、切线、二阶导数判据的解析表述及证明","6.9":"绝对值的可积性及积分不等式","6.10":"平方及乘积","6.22":"正性、递减性、极限位于零与一之间","6.25":"各小问前另证对数商递减并趋零","6.27":"比较判别及幂次推论","6.28":"比较判别及幂次推论","7.2":"两种函数分别计算三种极限","7.10":"三个级数分别判断参数范围","7.14":"给定实数、任意大及任意小的三种重排要求","7.24":"收敛半径、微分方程及和函数","7.25":"绝对收敛性与和","7.26":"级数乘积公式及指数函数的另一种构造","7.28":"四种三角函数分别求定义与导数","7.29":"单调性及两个反函数的定义、可微性和导数","7.30":"反正切展开和端点值","7.32":"复数级数的收敛、绝对收敛及重排分组、函数级数的一致收敛及连续性、收敛圆定理","7.35":"求两个导数证明两种积分次序给出同一结果","8.2":"牛顿递推及任意正初值","8.3":"唯一根、压缩映射及三位小数","8.4":"最大的定义区间及隐函数","8.12":"证明推论3、4、6","10.6":"绝对值的可积性及积分不等式","10.13":"聚点集和零体积","10.18":"有界结论与无界情形","10.21":"二重积分及两个累次积分","10.26":"两个递推","10.32":"（c）尾集条件和两种有界性；（e）、（f）均须证明正向及非负情形的逆向"}
lettered={"1.1":"abc","1.2":"abcd","1.3":"abc","1.4":"abcd","1.5":"ab","1.7":"abcdef","1.10":"abc","2.2":"ab","2.4":"ab","2.5":"abcd","2.8":"abc","2.10":"abc","3.1":"abc","3.16":"abc","3.17":"abc","3.20":"abc","3.30":"abc","4.1":"abcd","4.9":"abc","4.10":"abc","4.14":"ab","4.22":"abcd","4.29":"ab","4.31":"abcd","4.33":"ab","5.1":"abc","5.2":"ab","5.3":"ab","5.9":"abcd","6.6":"abcde","6.21":"ab","6.24":"abcde","6.25":"abc","7.8":"ab","7.17":"abc","7.20":"abcde","7.33":"abcde","7.34":"abcd","7.39":"abcde","7.40":"abcd","7.41":"abcde","8.1":"ab","9.7":"abcd","9.14":"ab","9.18":"ab","10.7":"abcde","10.15":"abc","10.28":"abc","10.31":"abc","10.32":"abcdefg"}
with (tex/'exercise-index.csv').open('w',encoding='utf-8-sig',newline='') as csvf:
    table=csv.writer(csvf)
    table.writerow(['章','原题号','印刷页','PDF顺序页','小问或原题列项','未另编号的要求或说明','题干源码','解答源码'])
    for n in chs:
        unit=flattened(f'ch{n:02}')
        marks=list(re.finditer(r'\\Prob\{(\d+)\}\{([^{}]*)\}\{([^{}]*)\}',unit))
        if [int(m[1]) for m in marks]!=list(range(1,expected[n-1]+1)):
            raise ValueError(f'Chapter {n} problem numbers do not match the scan inventory: {len(marks)}')
        for j,m in enumerate(marks):
            rest=unit[m.end():marks[j+1].start() if j+1<len(marks) else len(unit)]
            subs=lettered.get(f'{n}.{m[1]}','')
            extras={
                (1,7):('12',subs),
                (3,22):('63--64','公理 (i),(ii),(iii),(iiii)；五项未单独编号的要求'),
                (3,37):(m[2],'待证等价条件 (i),(ii),(iii)'),
                (4,24):(m[2],''),(4,26):(m[2],''),
                (5,7):(m[2],''),(5,8):(m[2],''),(5,15):(m[2],''),
                (6,17):(m[2],''),(6,19):(m[2],''),
                (10,4):(m[2],'引用 VI.6(a)–(e) 的五项推广'),
                (10,23):(m[2],'五个其余的积分次序，未单独编号'),
            }
            paper,subs=extras.get((n,int(m[1])),(m[2],subs))
            table.writerow([n,m[1],paper,pdf_span(paper),subs,subtasks.get(f'{n}.{m[1]}',''),f'ch{n:02}.tex',f'sol{n:02}.tex' if n in sol else ''])

titles=['集合论的基本概念','实数系','度量空间','连续函数','微分','黎曼积分','极限运算的交换','逐次逼近法','偏微分','重积分']
def solcmd(n):
    content=flattened(f'sol{n:02}')
    content=re.sub(r'(?m)^\s*\\(?:chapter|section)\*?\{[^{}]+\}\s*(?:\\addcontentsline\{toc\}\{(?:section|chapter)\}\{[^{}]+\})?', '',content,count=1)
    content=re.sub(r'\\Prob\{(\d+)\}\{([^{}]*)\}\{[^{}]*\}',lambda m:r'\item \textcolor{gray}{\scriptsize 原书 '+m[2]+r' 页}\enspace ',content)
    bib='answers-'+str(n)
    level=0; count=0; parts=[]; pos=0
    for token in re.finditer(r'\\begin\{enumerate\}|\\end\{enumerate\}|\\item\b',content):
        k=token[0]
        if k==r'\begin{enumerate}': level+=1
        elif k==r'\end{enumerate}': level-=1
        elif level==1:
            count+=1
            if content[token.end():].lstrip().startswith('['): continue
            parts.extend((content[pos:token.end()],r'\phantomsection\pdfbookmark[1]{'+str(n)+'.'+str(count)+'}{ans.'+str(n)+'.'+str(count)+'}'))
            pos=token.end()
    parts.append(content[pos:])
    if args.full and count!=[10,16,38,46,15,28,41,15,20,32][n-1]:
        raise ValueError(f'Chapter {n} has {count} top-level solutions')
    (tex/(bib+'.tex')).write_text(''.join(parts),encoding='utf8')
    return '\\setcounter{chapter}{'+str(n-1)+'}\\chapter{'+titles[n-1]+'}\\input{'+bib+'}\n'
master('solutions',cover('习题解答'+tag,('全书十章，共 261 道编号习题，按原书题序编排。' if args.full else '本册收录原书第 '+label(sol)+' 章'))+r'\frontmatter\tableofcontents\mainmatter'+'\n'+''.join(solcmd(n) for n in sol))
data=json.loads((tex/'errata.json').read_text(encoding='utf-8-sig'))
for lang in ['zh','en']:
    eng=lang=='en'
    title='Errata' if eng else '中文勘误'
    scope='Maxwell Rosenlicht, Introduction to Analysis. Dover, 1986, unabridged reprint of the 1968 edition.' if eng else '马克斯韦尔·罗森利希特《分析引论》。底本为 Dover 1986 年重印的 1968 年版。'
    intro='Entries verified against the source scan. PDF page numbers count from the first sheet.' if eng else '以下条目已经对照指定版本的扫描页。PDF 页码从第一张起计。'
    headings=[r'\pagestyle{plain}',r'\begin{center}\vspace*{8mm}{\Huge\bfseries '+title+r'}\\[4mm]{\Large\itshape Introduction to Analysis}\end{center}',scope+r'\par '+intro+r'\par']
    for entry in sorted(data,key=lambda e:(e['p'],e['id'])):
        langdata=entry[lang];headings.extend([r'\phantomsection\pdfbookmark[0]{'+entry['id']+'}{err.'+entry['id']+r'}\section*{'+entry['id']+r'\quad '+langdata[0]+'}',(('Back cover' if eng else '封底') if entry['id']=='E011' else ('Printed p. ' if eng else '原书第 ')+entry['pp'])+('；PDF ' if not eng else ', PDF ')+entry['pdf']+r'\par',langdata[1]])
    master('errata-'+lang,'\n'.join(headings))
refresh_header = 'from pathlib import Path\nfrom types import SimpleNamespace\nimport csv,json,re\ntex=Path(__file__).resolve().parent\nchs='+repr(chs)+'\nsol='+repr(sol)+'\nargs=SimpleNamespace(full='+repr(args.full)+')\n'
builder_source=Path(__file__).read_text(encoding='utf-8-sig')
refresh_body=builder_source[builder_source.index('label=lambda ns:'):builder_source.index('refresh_header = ')]
(tex/'refresh-edition.py').write_text(refresh_header+refresh_body,encoding='utf8')
outnames={'translation':'Rosenlicht-Translation-ZH','solutions':'Rosenlicht-Solutions-ZH','errata-zh':'Rosenlicht-Errata-ZH','errata-en':'Rosenlicht-Errata-EN'}
report={}
for job,stem in outnames.items():
    for step in (1,2):
        with (work/(job+str(step)+'.log')).open('wb') as log:
            x=subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',job+'.tex'],cwd=tex,stdout=log,stderr=subprocess.STDOUT)
        if x.returncode:
            print((work/(job+str(step)+'.log')).read_text(encoding='utf8',errors='replace')[-2000:],flush=True); raise SystemExit(1)
    logtext=(tex/(job+'.log')).read_text(encoding='utf-8',errors='replace')
    if re.search(r'(There were undefined references|Missing character:)',logtext):
        print(job, [z for z in logtext.splitlines() if 'Missing character' in z or 'undefined references' in z][:20],flush=True)
    with pymupdf.open(tex/(job+'.pdf')) as d:
        txt=''.join(p.get_text() for p in d)
        assert len(d)>0 and len(txt)>100
        if job.startswith('errata'): assert all(e['id'] in txt for e in data)
        report[job]={'pages':len(d),'outline':len(d.get_toc()),'bytes':(tex/(job+'.pdf')).stat().st_size}
        for i in {0,len(d)//2,len(d)-1}:
            d[i].get_pixmap(matrix=pymupdf.Matrix(.65,.65)).save(work/(job+str(i)+'.png'))
    shutil.copy2(tex/(job+'.pdf'),work/(stem+'.pdf'))
zip_path=work/'Rosenlicht-Editable-Sources.zip'
(tex/'README.txt').write_text('Rosenlicht, Dover 1986. Chinese translation, solutions and bilingual errata.\nRun xelatex -no-shell-escape twice on each of translation.tex, solutions.tex, errata-zh.tex and errata-en.tex in this folder. Edit chNN.tex, solNN.tex or the language-paired errata.json, then run python refresh-edition.py to refresh entry points, generated answer files, both errata and the exercise index. After refreshing, run the four XeLaTeX jobs twice. PDF page numbers in source-pages.csv count from the scanned cover.\nTranslation chapters: '+str(chs)+'\nSolutions chapters: '+str(sol)+'\n',encoding='utf8')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(tex.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.tex','.png','.jpg','.json','.md','.csv','.txt','.py'}:
            z.write(p,p.relative_to(tex))
    for p in sorted((project/'Rosenlicht-work'/'text').glob('*.txt')):
        z.write(p,'process/OCR/'+p.name)
    for name in ('prepare.py','checkpages.py','thumbs.py','build_edition.py','verify_release.py'):
        p=project/'Rosenlicht-work'/name
        if p.is_file(): z.write(p,'process/'+name)
with zipfile.ZipFile(zip_path) as z: assert z.testzip() is None
for f in ['translation.tex','solutions.tex','errata-zh.tex','errata-en.tex','exercise-index.csv','refresh-edition.py']+[f'answers-{n}.tex' for n in sol]:
    shutil.copy2(tex/f,src/f)
for file in [work/(x+'.pdf') for x in outnames.values()]+[zip_path]:
    tmp=dest/(file.name+'.new')
    shutil.copyfile(file,tmp); os.replace(tmp,dest/file.name)
print(json.dumps(dict(temp=str(work),chapters=chs,solutions=sol,files=report),ensure_ascii=False),flush=True)
