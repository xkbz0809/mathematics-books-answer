"""Verify the assembled books and independently refresh the editable archive."""
from pathlib import Path
import csv,hashlib,io,json,re,subprocess,sys,tempfile,zipfile
import pymupdf as pdf
base=Path(__file__).resolve().parent.parent
out=base/'交付'/'Rosenlicht-Dover-1986'
src=base/'Rosenlicht-source'
ids={i['id'] for i in json.loads((src/'errata.json').read_text(encoding='utf-8-sig'))}
counts=[10,16,38,46,15,28,41,15,20,32]
wanted=[f'{c}.{k}' for c,num in enumerate(counts,1) for k in range(1,num+1)]
result={}
for filename in sorted(out.glob('*.pdf')):
    with pdf.open(filename) as doc:
        toc=doc.get_toc()
        pages=[p.get_text() for p in doc]
        text=''.join(pages)
        found=set(re.findall(r'E\d{3}',text))
        assert len(doc)>0 and all(p.strip() for p in pages)
        assert not any(k in text for k in ['阶段稿','??','待补译','解答待补'])
        assert 'E001' not in found
        if 'Solutions' in filename.name:
            marks=[x[1] for x in toc if re.fullmatch(r'\d+\.\d+',x[1])]
            assert marks==wanted,(len(marks),len(wanted))
        if 'Translation' in filename.name:
            assert ids==found,(ids-found,found-ids)
        if 'Errata' in filename.name:
            assert ids==found and set(t[1] for t in toc)==ids
        for i in {0,len(doc)//4,len(doc)//2,len(doc)-1}:
            doc[i].get_pixmap(matrix=pdf.Matrix(.5,.5))
        result[filename.name]={'pages':len(doc),'bookmarks':len(toc),'sha256':hashlib.sha256(filename.read_bytes()).hexdigest()}
with zipfile.ZipFile(out/'Rosenlicht-Editable-Sources.zip') as z:
    assert z.testzip() is None
    assert len([p for p in z.namelist() if re.match(r'process/OCR/\d{3}\.txt$',p)])==276
    work=Path(tempfile.mkdtemp(prefix='Rosenlicht-source-check-'))
    z.extractall(work)
    for k in ('translation.tex','solutions.tex','errata-zh.tex','errata-en.tex','exercise-index.csv'):
        assert k in z.namelist()
    p=subprocess.run([sys.executable,str(work/'refresh-edition.py')],cwd=work,check=True,capture_output=True)
    for k in ('translation.tex','solutions.tex','errata-zh.tex','errata-en.tex','answers-7.tex','exercise-index.csv'):
        assert (work/k).read_bytes()==z.read(k),k
    rows=list(csv.reader((work/'exercise-index.csv').open(encoding='utf-8-sig')))[1:]
    assert [f'{row[0]}.{row[1]}' for row in rows]==wanted
    assert len(list(csv.reader((work/'source-pages.csv').open(encoding='utf-8-sig'))))==277
print(json.dumps(dict(files=result,problems=len(wanted),errata=len(ids),edit_source_refresh='identical'),ensure_ascii=False,indent=2))
