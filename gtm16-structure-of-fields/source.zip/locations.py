"""Locate the printed exercise headings in the Chinese PDF and the English scan."""
from pathlib import Path
import argparse
import json
import re

import pymupdf as pdf

HERE = Path(__file__).resolve().parent
BOOK = HERE.parents[1]
COUNTS = (89, 46, 37, 43, 13, 11, 39)

# Printed page where the chapter exercises start, then the first exercise on
# each successive scan page. All 278 labels checked against the English scan.
SCAN_STARTS = (
    (14, (1,8,17,25,32,36,42,45,52,60,72,83)),
    (41, (1,5,12,21,23,26,30,41)),
    (61, (1,6,19,32)),
    (91, (1,5,14,20,21,36)),
    (107, (1,2,5,7)),
    (123, (1,3,9)),
    (140, (1,12,15,18,20,22,25,30,35)),
)


def chinese_headings(doc):
    toc = doc.get_toc(False)
    result = {}
    for i, (_, title, first, target) in enumerate(toc):
        section = re.match(r"^E\.([0-6])\s", title)
        if not section:
            continue
        ch = int(section[1])
        start = first - 1
        origin = target["to"]
        section_top = doc[start].rect.height - origin.y
        stop = next((row[2] for row in toc[i + 1:] if row[0] <= 2), len(doc))
        found = {}
        label = re.compile(rf"E\.{ch}\.(\d{{1,2}})\.?")
        for pno in range(start, stop):
            page = doc[pno]
            for block in page.get_text("dict")["blocks"]:
                for line in block.get("lines", []):
                    for span in line["spans"]:
                        match = label.fullmatch(span["text"].strip())
                        if not match:
                            continue
                        n = int(match[1])
                        x, top = span["bbox"][:2]
                        # enumitem right-aligns the exercise numbers. Each extra
                        # digit in CMU Serif/Roman occupies one half-em.
                        label_left = origin.x - (len(match[1]) - 1) * span["size"] / 2
                        if abs(x - label_left) > 1.5:
                            continue
                        if pno == start and top < section_top - 4:
                            continue
                        found.setdefault(n, []).append((pno, top))
        assert set(found) == set(range(1, COUNTS[ch] + 1)), (ch, sorted(found))
        positions = []
        for n in range(1, COUNTS[ch] + 1):
            assert len(found[n]) == 1, ("ambiguous printed exercise heading", ch, n, found[n])
            pno, top = found[n][0]
            positions.append((pno, top))
            # GoToR/XYZ uses bottom-up PDF coordinates. Leave 7pt above the heading.
            y = round(doc[pno].rect.height - max(0, top - 7), 2)
            result[f"{ch}.{n}"] = (pno, y)
        assert positions == sorted(positions), ("printed exercise order", ch)
    expected = [f"{ch}.{n}" for ch, count in enumerate(COUNTS) for n in range(1, count + 1)]
    assert list(result) == expected
    return result


def main():
    parser = argparse.ArgumentParser(description="Locate the exercise labels in a freshly typeset Chinese translation.")
    parser.add_argument("translation", nargs="?", type=Path, default=BOOK / "zh" / "main.pdf")
    with pdf.open(parser.parse_args().translation) as doc:
        chinese = chinese_headings(doc)
    locations, lines = {}, []
    for key, (zh, y) in chinese.items():
        ch, number = map(int, key.split("."))
        first, starts = SCAN_STARTS[ch]
        printed = first + max(i for i, n in enumerate(starts) if n <= number)
        locations[key] = [printed + 11, zh, y]
        lines.append(
            r"\expandafter\def\csname loc@" + key + r"\endcsname{\href{https://gtm16.invalid/orig/"
            + key + "}{原书 " + str(printed) + r" 页}\enspace ·\enspace\href{https://gtm16.invalid/zh/"
            + key + "}{中文题面}}"
        )
    (HERE / "locations.json").write_text(json.dumps(locations), encoding="ascii")
    (HERE / "locations.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(locations)} printed Chinese exercise headings located")
    for key in ("3.2", "5.6"):
        print(f"E.{key}: Chinese PDF page {locations[key][1] + 1}, /XYZ y={locations[key][2]}")


if __name__ == "__main__":
    main()

