"""Build the Chinese exercise solutions. Requires XeLaTeX and PyMuPDF."""
from pathlib import Path
from urllib.parse import unquote
import json
import re
import shutil
import subprocess

import pymupdf as pdf

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "域的结构（章末习题解答）.pdf"
TARGETS = {"orig": "GTM16-The Structure of Fields1974.pdf", "zh": "域的结构（中文译本）.pdf"}
COUNTS = (89, 46, 37, 43, 13, 11, 39)
KEYS = [f"{ch}.{i}" for ch, count in enumerate(COUNTS) for i in range(1, count + 1)]
BODIES = [f"s{ch}.tex" for ch in range(7)] + ["s6b.tex"]


def prepare(chapter):
    # A normal source line ending in a Chinese full stop is a logical paragraph.
    # Keep displays and their continuation untouched. Set short subparts apart.
    chapter = re.sub(r"(?<=。)[ \t]*(?=\((?:[b-z]|[2-9])\)[ \t])", "\n\n", chapter)
    chapter = re.sub(r"(?<=。)\n(?=[^\s\\%])", "\n\n", chapter)
    chapter = re.sub(r"\n(?=\((?:[b-z]|[2-9])\)[ \t])", "\n\n", chapter)
    return chapter


def compile_book(stage):
    chapters = {}
    for file in BODIES:
        chapters[file] = (HERE / file).read_text(encoding="utf-8-sig")
        (stage / file).write_text(prepare(chapters[file]), encoding="utf-8")
    for ch, total in enumerate(COUNTS):
        source = chapters[f"s{ch}.tex"] + (chapters["s6b.tex"] if ch == 6 else "")
        expected = [f"{ch}.{i}" for i in range(1, total + 1)]
        assert re.findall(r"\\begin\{solution\}\{([\d.]+)\}", source) == expected
        assert source.count(r"\end{solution}") == total
    for file in ("main.tex", "locations.tex"):
        shutil.copyfile(HERE / file, stage / file)
    with (HERE / "build-output.txt").open("wb") as stream:
        for _ in range(2):
            subprocess.run(
                ["xelatex", "-halt-on-error", "-interaction=nonstopmode",
                 "-file-line-error", "-no-shell-escape", "main.tex"],
                cwd=stage, stdout=stream, stderr=subprocess.STDOUT, check=True,
            )
    log = (stage / "main.log").read_text(encoding="utf-8", errors="replace")
    assert not re.search(r"Missing character:|There were undefined references|multiply defined|Overfull \\[hv]box", log), "See build-output.txt for the XeLaTeX diagnostics."


def install_links(d, locations):
    found = []
    for page in d:
        for link in page.get_links():
            match = re.fullmatch(r"https://gtm16\.invalid/(orig|zh)/([\d.]+)", link.get("uri", ""))
            if not match:
                continue
            kind, key = match.groups()
            orig, trans, y = locations[key]
            dest = f"[{orig} /Fit]" if kind == "orig" else f"[{trans} /XYZ null {y} null]"
            name = pdf.get_pdf_str(TARGETS[kind])
            filespec = f"<< /Type /Filespec /F {name} /UF {name} >>"
            d.xref_set_key(link["xref"], "A", f"<< /S /GoToR /F {filespec} /D {dest} /NewWindow true >>")
            found.append((key, kind))
    assert found == [(key, kind) for key in KEYS for kind in TARGETS]


def verify_book(d, locations):
    headings = [(r[1], r[2] - 1, r[3]) for r in d.get_toc(False) if r[0] == 2]
    assert [title for title, _, _ in headings] == ["E." + key for key in KEYS]
    chapter_bookmarks = [r for r in d.get_toc(False) if r[0] == 1]
    assert len(chapter_bookmarks) == 8 and chapter_bookmarks[0][1] == "习题索引"
    index_links = d[0].get_links()
    assert len(index_links) == 14
    for ch, bookmark in enumerate(chapter_bookmarks[1:]):
        assert bookmark[1].startswith(f"第 {ch} 章")
        for link in index_links[ch * 2 : ch * 2 + 2]:
            assert link["page"] == bookmark[2] - 1
            assert abs(link["to"].y - bookmark[3]["to"].y) < 1
    expected_by_page = {}
    for title, pno, dest in headings:
        expected_by_page.setdefault(pno, []).append((title, dest))
    nlinks = 0
    for page in d:
        lines = [s for block in page.get_text("dict")["blocks"] for line in block.get("lines", []) for s in line["spans"]]
        assert "??" not in page.get_text()
        links = page.get_links()
        assert all(link["kind"] != pdf.LINK_URI for link in links)
        links = [link for link in links if link["kind"] == pdf.LINK_GOTOR]
        expected = expected_by_page.get(page.number, [])
        assert len(links) == len(expected) * 2
        for idx, (title, anchor) in enumerate(expected):
            key = title[2:]
            orig, trans, y = locations[key]
            spans = [s for s in lines if s["text"].strip() == title and s["font"].endswith("-Bold") and s["bbox"][0] < 80]
            assert len(spans) == 1, (title, page.number + 1)
            heading = spans[0]["bbox"]
            # XeTeX emits named destinations. Their "to" is in PDF bottom-up space.
            offset = heading[1] - (page.rect.height - anchor["to"].y)
            assert -2 < offset < 20, (title, offset)
            for j, (kind, pno) in enumerate((("orig", orig), ("zh", trans))):
                link = links[2 * idx + j]
                assert unquote(link["file"]) == TARGETS[kind] and link["page"] == pno
                assert abs(link["from"].y0 - heading[1]) < 8
                _, raw = d.xref_get_key(link["xref"], "A/D")
                if kind == "zh":
                    match = re.fullmatch(r"\[(\d+)/XYZ null ([\d.]+) null\]", raw)
                    assert match and abs(float(match[2]) - y) < 0.02
                else:
                    assert raw == f"[{orig}/Fit]"
                nlinks += 1
    return len(d), len(headings), nlinks


def main():
    locations = json.loads((HERE / "locations.json").read_text(encoding="utf-8-sig"))
    assert list(locations) == KEYS
    stage = HERE / "typeset"
    stage.mkdir(exist_ok=True)
    compile_book(stage)
    with pdf.open(stage / "main.pdf") as doc:
        install_links(doc, locations)
        doc.save(stage / "final.pdf", garbage=4, deflate=True)
    with pdf.open(stage / "final.pdf") as doc:
        pages, exercises, links = verify_book(doc, locations)
    (stage / "final.pdf").replace(OUTPUT)
    print(f"{pages} pages, {exercises} exercises, {links} links to the two source PDFs")


if __name__ == "__main__":
    main()

