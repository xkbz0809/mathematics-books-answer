# 《域的结构》章末习题解答

David J. Winter, *The Structure of Fields* (1974), Graduate Texts in Mathematics 16。解答依原书编号覆盖第 0 至第 6 章，共 278 题。

## 编译

需要 XeLaTeX（TeX Live 中的 ctex、Fandol、TeX Gyre、amsmath、tikz-cd、hyperref 等）、Python 3 和 PyMuPDF。此版本在 Python 3.13、PyMuPDF 1.28.2 上验证。将压缩包解压到可写目录，在包含 build.py 的目录运行：

    python -X utf8 build.py

成品为 **域的结构（章末习题解答）.pdf**。中间排版文件在 typeset 目录；诊断信息在 build-output.txt。脚本会核对 278 项单题书签和 556 项跨文件链接。

## 文件

- main.tex 设置版式、书签和章节导航。
- s0.tex 至 s6.tex、s6b.tex 保存中文解答；第 6 章从第 25 题起见 s6b.tex。
- locations.tex、locations.json 保存英文扫描本和本次中文译本的题面定位。
- locations.py 可用本书同版式的中文 PDF 重新提取排在页面上的全部 278 个题号。译本重新排版后，可先运行 `python -X utf8 locations.py "域的结构（中文译本）.pdf"`，再编译答案册。
- build.py 排版并写入跨 PDF 跳转，检查题号、书签及链接。

## 跳转题面

将成品与下列两份 PDF 放在同一目录，用支持跨文件跳转的桌面 PDF 阅读器打开：

- GTM16-The Structure of Fields1974.pdf
- 域的结构（中文译本）.pdf

每道题标题右侧的“原书”指向该题开始的扫描页，“中文题面”指向本次译本中的对应题号。其他排版版本的页码可能不同。

