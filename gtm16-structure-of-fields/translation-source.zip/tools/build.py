from pathlib import Path
import os,subprocess,sys
src=Path(__file__).resolve().parents[1]
os.chdir(src)
flags=['-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','main.tex']
for cmd in [['xelatex',*flags],['xelatex',*flags],['biber','main'],['xelatex',*flags],['xelatex',*flags]]:
 subprocess.run(cmd,check=True)
