#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/.."
python tools/build.py
