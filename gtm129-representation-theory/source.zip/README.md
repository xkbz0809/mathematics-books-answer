# GTM129 · 表示论：第一教程习题解答源码

署名：小可本州。solutions.tex 为整册主文件，answers/ 为逐题参考副本。请使用带 Fandol 与 CM Unicode 字体的 TeX Live，多次运行 xelatex solutions.tex 使目录、书签与题号索引稳定。assets/ 保存解答册编译所用的五幅题图。
