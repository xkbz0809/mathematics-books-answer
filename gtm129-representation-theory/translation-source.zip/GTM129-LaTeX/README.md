# GTM129《表示论：第一教程》中文译本

原著：William Fulton、Joe Harris，*Representation Theory: A First Course*，Graduate Texts in Mathematics 129。

本项目包含全书中文翻译与重新排版，范围为前言、四个部分的导言、第1—26讲、附录A—F、提示与答案、参考文献、符号索引和主题索引。文末增加中英术语对照表。参考文献中的原始题名与出版信息保留原文，以便检索。

## 阅读

- 阅读整书请打开交付的中文PDF。目录和书签可以跳至各讲、各节及附录。
- 定理、公式、习题等编号沿用原书。带星号且有书后答案的习题可通过星号跳至提示；提示编号可在原书存在对应条目时跳回正文。
- 符号索引、主题索引和文末术语表均使用**本译本页脚的页码**，打印后可直接据此翻阅。符号与主题索引共583条，链接指向相关定义、公式或具体讨论位置；连续内容以译本页码范围表示。
- 源书疑点记录是翻译时留下的核查线索，不是逐条证明完成的正式勘误表。印刷内容得到确认，不等于其数学内容已经被判错；未决项不宜直接用于改动原书。

## 来源

主来源为用户提供的559页PDF `GTM129-Representation Theory-A First Course.pdf`。其前言含第5次修订印刷的附注，版权页标注Springer 2004。Markdown仅作为提取初稿使用，数学内容、图表和编号以PDF为准。

新增的563页扫描本也已全书对齐。原PDF省略的七页是空白页；新增扫描本重复印刷266—267页，并缺失印刷362—363页正文。因此采用原PDF为主、新PDF辅助核验。来源散列值与逐页对照见 `qa/source_manifest.json` 和 `qa/source_comparison/`。

## 编辑与编译

`GTM129-zh.tex` 是合并后的主文件，所有中文正文和公式均在其中。`assets/` 保存普通插图，`logo.pdf` 是项目模板标志。交换图、映射图等以 `tikz-cd` 代码重排。主文件中的 `% SRC 单元:编号` 注释可追溯到覆盖检查记录，编辑时建议保留。

使用包含XeLaTeX、ctex、Fandol、Computer Modern Unicode、amsmath、TikZ/tikz-cd、titlesec、enumitem和hyperref的TeX发行版编译。在本目录运行：

```text
xelatex -interaction=nonstopmode -halt-on-error GTM129-zh.tex
xelatex -interaction=nonstopmode -halt-on-error GTM129-zh.tex
```

首次编译或修改目录、术语、交叉引用后，若日志要求重编，继续编译至引用稳定。本项目已使用本机TeX Live 2026的XeLaTeX生成并检查交付PDF；其他排版引擎可能产生不同分页。字体采用TeX发行版提供的Fandol和Computer Modern Unicode，不依赖Windows专有字体。

索引页码使用正文中的标签和自动页码引用；正文增删或分页变化后重新编译，索引页码会随之更新。请保留正文的 `ix:` 定位标签以及已有定理、公式和小节标签。原书页码只保留在 `qa/index_rebuild/` 核查材料中，不作为读者索引的页码。

## 校验资料

`qa/` 提供源段落覆盖、引用与文献、图表和页面检查、原书疑点、版本比较等记录。单章JSON保留当时的阶段性检查信息；是否通过最终合编和PDF核验，以 `qa/final_validation.json` 及交付的《译校说明》为准。

这是依据用户提供材料制作的中文学习译稿，并非出版社发布的中文版本。原PDF、Markdown和新增扫描本均保持原样。
