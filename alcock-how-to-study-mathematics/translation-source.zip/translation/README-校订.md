# 《How to Study as a Mathematics Major》中文校订工程

原著：Lara Alcock，Oxford University Press，2013年第一版。

初译署名与模型信息沿用原项目；2026年10月6日由Codex多智能体对照用户提供的出版PDF校订。保留MathTranslations模板及原有章节文件布局。`main.tex`为入口，`diagrams/`为本轮新增的原生中文节点图，`figures/`保留原有图像资产。

## 编译

需要带XeLaTeX、ctex、Fandol、CMU Serif、TikZ、tikz-cd及enumitem的TeX Live。切换到本文件所在目录后执行：

```powershell
xelatex -interaction=nonstopmode -halt-on-error main.tex
xelatex -interaction=nonstopmode -halt-on-error main.tex
```

如日志仍要求重跑，则再运行一次。交付前已检查最终日志、引用、目录与术语索引。

## 阅读约定

- 正文和符号表的章、节引用指向本译本；术语索引页码也属于本译本。
- 书末英文原书索引继续使用原版印刷页码，缩进保留主项与子项关系。
- 数字脚注为恢复的原著脚注，按章编号；匕首脚注标为“译校注”，属于本次校订。
- 原书用于教学的错误推导、错误等号或箭头按原意保留。已确定的原书笔误通过校注明示；扫描图标签不清晰等问题详见随附校对报告。

## 变更记录

全部最终修改可在随附的“全部更改对照.html”和“全部更改.patch”中逐项核对；结构化文件清单含校订前后SHA-256。初译工程另有完整备份。
