# Isaacs《代数：研究生教程》（GSM 100）习题解答

使用 TeX Live，在本目录连续运行三遍 xelatex solutions.tex。
