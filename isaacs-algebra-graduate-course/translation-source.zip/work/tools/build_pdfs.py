"""Build the four PDFs from the edition configured in tex/scope.tex."""
from __future__ import annotations
import argparse
import re
import shutil
import subprocess
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
TEX=WORK/"tex"
NAMES=("translation","solutions","errata-zh","errata-en")

def compile_document(name):
    build=TEX/"build"
    build.mkdir(exist_ok=True)
    command=["xelatex","-file-line-error","-halt-on-error","-interaction=batchmode",
             "-output-directory=build",f"{name}.tex"]
    if not shutil.which(command[0]):
        raise SystemExit("Install XeLaTeX with ctex and Fandol fonts.")
    log=build/f"{name}.log"
    for pass_number in range(1,5):
        result=subprocess.run(command,cwd=TEX,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        text=log.read_text(encoding="utf8",errors="replace") if log.exists() else ""
        if result.returncode:
            errors=[s for s in text.splitlines() if s.startswith("!") or re.search(r"\.tex:\d+:",s)]
            raise SystemExit("\n".join(errors+text.splitlines()[-18:]))
        rerun=("Rerun to get cross-references right" in text
               or "Rerun to get outlines right" in text or "has changed. Rerun" in text)
        if pass_number>=2 and not rerun:
            break
    for token in ("Missing character:","There were undefined references","multiply defined","Font shape"):
        warnings=[s.strip() for s in text.splitlines() if token in s]
        if warnings:
            print(f"{name}: {token} ({len(warnings)})", *warnings[:3], sep="\n")
    for match in re.finditer(r"Overfull \\hbox \(([0-9.]+)pt too wide\)([^\n]*)",text):
        if float(match[1])>=5:
            print(f"{name}: {match[0]}")
    print(f"{name}.pdf { (build/f'{name}.pdf').stat().st_size:,} bytes, {pass_number} passes")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("documents",nargs="*",metavar="DOCUMENT")
    args=parser.parse_args()
    for name in args.documents or NAMES:
        if name not in NAMES:
            raise SystemExit(f"Unknown document: {name}")
        compile_document(name)
