"""Index original chapter-end exercises and the parts visible in each source."""
from pathlib import Path
import csv
import re
import json
import unicodedata

WORK=Path(__file__).resolve().parents[1]
CHAPTER_START=[16,27,43,55,68,83,96,112,128,142,155,172,190,207,226,246,267,287,306,320,339,355,372,392,414,431,446,466,487,506]
START=[25,39,52,66,80,94,109,126,140,153,169,185,204,223,242,264,284,303,317,336,353,370,389,411,428,442,462,484,503,517]
COUNT=[9,22,14,9,20,13,17,17,13,9,13,30,17,16,13,13,15,25,15,20,11,8,17,17,13,22,14,15,15,11]
# First exercise to start on each problem page, as numbered on the scan.
# A zero denotes a page containing only the continuation of the preceding item.
FIRST=[[1,8],[1,4,14,22],[1,5,9],[1,7],[1,11,0],[1,10],[1,4,13],[1,13],
       [1,11],[1,5],[1,2,12],[1,5,12,22,28],[1,6,13],[1,3,13],[1,9],
       [1,4,12],[1,3,12],[1,12,23],[1,4,12],[1,12,19],[1,7],[1,3],
       [1,5,12],[1,6,17],[1,8,13],[1,6,16,22],[1,2,8,13],[1,5,10],
       [1,4,13],[1,9]]
CONTINUED={40,41,42,54,67,82,127,141,171,186,189,205,206,266,285,318,371,413,429,444,463,464}
ID=r"(?P<n>\d+)\.(?P<k>\d+)"
PROBLEM=re.compile(r"\\begin\{problem\}\{"+ID+r"\}(.*?)\\end\{problem\}",re.S)
TAG=re.compile(r"\\SrcPage\{([^{}]+)\}\{(\d+)\}|\\BookSection\{([^{}]+)\}|\\begin\{statement\}\{([^{}]+)\}\{([^{}]+)\}|\\ProblemsHeading")
LABEL=re.compile(r"(?:\A|\n)\s*(?:\\(?:textbf|emph)\{)?[\(（]\s*([a-h])\s*[)）]",re.M)
EXENUM=re.compile(r"\\begin\{enumerate\}(?:\s*\[([^]]*)\])?(.*?)\\end\{enumerate\}",re.S)

def item_parts(body):
    for options,inside in EXENUM.findall(body):
        if "roman" in options or "arabic" in options:
            continue
        items=re.findall(r"\\item(?:\s*\[([^]]+)\])?",inside)
        if items:
            return ''.join(chr(97+i) for i in range(len(items)))
    found=set(LABEL.findall(body))
    found.update(re.findall(r"\\(?:textbf|emph)\{\s*[\(（]([a-h])[)）]\}",body))
    if not found:
        found.update(re.findall(r"(?:(?:^|\n)\s*|\\(?:par|quad)\s*)[\(（]([a-h])[)）]",body,re.M))
    return ''.join(sorted(found))

def read_tex(n,prefix):
    path=WORK/"tex"/f"{prefix}{n:02}.tex"
    if not path.exists():
        return "",{}
    text=path.read_text(encoding="utf-8-sig")
    return text,{int(m["k"]):m.group(3) for m in PROBLEM.finditer(text) if int(m["n"])==n}

def dump(name,header,data):
    with (WORK/"index"/name).open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.writer(f)
        writer.writerow(header)
        writer.writerows(data)

def record(n,chapter_first,page_first,count):
    source,problems=read_tex(n,"ch")
    _,solutions=read_tex(n,"sol")
    starts={}
    for offset,current in enumerate(page_first):
        if not current:
            continue
        following=next((j for j in page_first[offset+1:] if j),count+1)
        for item in range(current,following):
            starts[item]=chapter_first+offset
    intervals={}
    for k,p in starts.items():
        next_start=starts.get(k+1,chapter_first+len(page_first)-1)
        if k==count:
            end=chapter_first+len(page_first)-1
        elif next_start>p and next_start not in CONTINUED:
            end=next_start-1
        else:
            end=next_start
        intervals[k]=p,end
    entries=[]
    for k,(p,q) in intervals.items():
        titleparts=item_parts(problems[k]) if k in problems else ""
        solvedparts=item_parts(solutions[k]) if k in solutions else ""
        entries.append([n,f"{n}.{k}",p-13,q-13,p,q,titleparts,solvedparts,
                        "已收录" if k in problems else "待收入合编",
                        "已有解答稿" if k in solutions else "待收入合编"])
    sections=[]
    page=CHAPTER_START[n-1]
    section=""
    for match in TAG.finditer(source):
        printed,pdf,sect,kind,number=match.groups()
        if pdf:
            page=int(pdf)
        elif sect:
            section=sect
            sections.append([n,section,"节",section,page-13,page])
        elif kind:
            sections.append([n,section,kind,number,page-13,page])
        else:
            section="Problems"
    return entries,sections

if __name__=="__main__":
    entries,sections=[],[]
    for n,(chapter_first,page_first,count) in enumerate(zip(START,FIRST,COUNT),1):
        items,sections_in_chapter=record(n,chapter_first,page_first,count)
        entries.extend(items)
        sections.extend(sections_in_chapter)
    assert len(entries)==463 and len({row[1] for row in entries})==463
    dump("exercises.csv",["章","原题","印刷起页","印刷末页_含注与提示","PDF起页","PDF末页_含注与提示","译稿中识别的字母小问","解答稿中识别的字母小问","译稿收录","解答收录"],entries)
    dump("numbered_entries.csv",["章","节","类别","编号","印刷定位页","PDF定位页"],sections)
    print(f"{len(entries)} original exercises; {len(sections)} recorded sections and statements")