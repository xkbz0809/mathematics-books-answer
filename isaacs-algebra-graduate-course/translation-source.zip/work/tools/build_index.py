from pathlib import Path
import re

work=Path(__file__).resolve().parents[1]
files=sorted((work/'index').glob('idx*.txt'))
heading=r"""\chapter*{原书索引}\addcontentsline{toc}{chapter}{原书索引}\label{book:subjectindex}
本索引保留原书英文词序与纸本页码。缩进行是上一主条目的子项。译本正文中方括形标记的第一项为纸本页，第二项为 PDF 顺序页。
\begingroup\small\setlength{\parskip}{.09em}\setlength{\parindent}{0pt}\raggedright
\begin{multicols}{2}"""
t=[heading]; pages=[]; count=0
for file in files:
    for line in file.read_text(encoding='utf-8-sig').splitlines():
        if not line.strip():
            continue
        if line.startswith('@'):
            p=int(line[1:]);pages.append(p)
            t.append(r"\par\medskip\noindent{\bfseries\color{accent}"+(r"\OriginalAnchor{"+str(p)+"}"+f"原索引第 {p} 页")+r"}\par\smallskip")
            continue
        key,loc=line.split('|',1)
        sub=key.startswith('>')
        key=key.lstrip('>').strip()
        if loc and re.fullmatch('[0-9, –]+',loc):
            loc=re.sub(r'\d+',lambda m:r'\OriginalPageRef{'+m[0]+'}',loc).replace('–','--')
        else:
            loc=loc.strip()
        t.append((r"\hangindent=2em\hspace*{1em}" if sub else r"\hangindent=1em\noindent ")+key+(r"\enspace "+loc if loc else '')+r"\par")
        count+=1
if pages!=list(range(507,517)): raise SystemExit("Missing index pages: "+str(pages))
t.extend([r'\end{multicols}',r'\endgroup'])
(work/'tex'/'subjectindex.tex').write_text('\n'.join(t)+'\n',encoding='utf8')
print(f"{count} entries and subentries; original pp. 507-516")
