"""Package the current editable edition, original-page OCR and review records."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import argparse
import hashlib

WORK=Path(__file__).resolve().parents[1]

def package(destination):
    destination=Path(destination).resolve()
    destination.parent.mkdir(parents=True,exist_ok=True)
    paths=[]
    for d,patterns in (("tex",("*.tex",)),("index",("*.csv","*.txt","*.sha256","*.json")),
                       ("qa",("*.md","*.json","*.csv","*.tsv")),
                       ("tools",("*.py",)),("ocr",("*.txt","*.json"))):
        for pat in patterns:
            paths.extend(sorted((WORK/d).glob(pat)))
    readme=WORK/"README.md"
    if readme.is_file():
        paths.append(readme)
    temp=destination.with_suffix(destination.suffix+".tmp")
    with ZipFile(temp,"w",compression=ZIP_DEFLATED,compresslevel=5) as zipf:
        for path in paths:
            zipf.write(path,(Path("work")/path.relative_to(WORK)).as_posix())
    with ZipFile(temp) as zipf:
        if zipf.testzip() is not None:
            raise SystemExit("CRC error in the source archive")
    temp.replace(destination)
    print(f"{destination.name} {len(paths)} files {destination.stat().st_size} bytes")
    print(hashlib.sha256(destination.read_bytes()).hexdigest())

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination")
    package(parser.parse_args().destination)
