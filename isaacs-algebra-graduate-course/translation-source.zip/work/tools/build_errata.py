"""Build both errata PDFs from the same chapter records, retaining original identifiers."""
import argparse
import json
import re
from pathlib import Path

w=Path(__file__).resolve().parents[1]
qa=w/"qa"
tex=w/"tex"
parser=argparse.ArgumentParser()
parser.add_argument("--chapters",nargs="+",type=int,required=True)
args=parser.parse_args()
nums=sorted(set(args.chapters))
fields={"id","printed","pdf","where_zh","where_en","original","fix_zh","fix_en","why_zh","why_en"}
items=[]
for n in nums:
    p=qa/f"err{n:02}.json"
    for a in json.loads(p.read_text(encoding="utf-8-sig")):
        missing=fields-set(a)
        if missing: raise SystemExit(f"{p.name}: missing {missing}")
        if not re.fullmatch(fr"E{n:02}\d\d",a["id"]): raise SystemExit(a["id"])
        for k in fields: a[k]=str(a[k])
        a["chapter"]=n
        items.append(a)
if len({a["id"] for a in items})!=len(items): raise SystemExit("Duplicate identifiers")
items.sort(key=lambda a:(int(re.search(r'\d+',a["pdf"])[0]),a["id"]))
master={"edition":"American Mathematical Society, Graduate Studies in Mathematics 100 (2009 reprint of the 1994 edition), ISBN 978-0-8218-4799-2","reviewed_chapters":nums,"entries":items}
(qa/"errata-master.json").write_text(json.dumps(master,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
ranges=[]
for n in nums:
    if ranges and ranges[-1][-1]+1==n: ranges[-1].append(n)
    else: ranges.append([n])
coverage=", ".join(str(x[0]) if len(x)==1 else f"{x[0]}--{x[-1]}" for x in ranges)
for lang in ["zh","en"]:
    zh=lang=="zh"
    title="中文勘误" if zh else "Errata"
    t=[r"\documentclass[UTF8,fontset=fandol,zihao=-4,oneside]{ctexart}",r"\input{errata-layout}",r"\hypersetup{pdftitle={Isaacs: Algebra — "+title+"}}",r"\begin{document}"]
    if not zh: t.append(r"\raggedright")
    t.extend([r"\noindent{\small\color{quiet}"+("数学研究生丛书" if zh else "Graduate Studies in Mathematics")+r"\quad 100}\par\medskip",
        r"\noindent{\LARGE\bfseries\color{ink}"+("代数：研究生教程" if zh else r"Algebra: A Graduate Course")+r"}\par",
        r"\noindent{\Large\color{accent}"+title+r"}\par\smallskip",
        r"\noindent I. Martin Isaacs\par\medskip"])
    if zh:
        t.append(r"\noindent 依据美国数学会 2009 年重印本（原版 1994 年），ISBN 978-0-8218-4799-2。纸本页码与 PDF 顺序页各自列出，PDF 封面计第 1 页。")
        t.append(r"\par\noindent 本册收录第 "+coverage+r" 章中核实的 "+str(len(items))+r" 项。按原书页序排列，编号与英文版、译注一致。")
    else:
        t.append(r"\noindent Based on the American Mathematical Society's 2009 reprint of the 1994 edition, ISBN 978-0-8218-4799-2. The PDF page count starts at the front cover. Printed and PDF page numbers are given separately.")
        t.append(r"\par\noindent This list covers Chapters "+coverage+" and contains "+str(len(items))+r" confirmed entries, ordered by their locations in the book. Identifiers match the Chinese errata and the notes in the translation.")
    t.append(r"\par\medskip\hrule\medskip")
    for i,a in enumerate(items):
        n=a["chapter"]
        if i==0 or items[i-1]["chapter"]!=n:
            head=f"第 {n} 章" if zh else f"Chapter {n}"
            t.append(r"\section*{"+head+r"}\pdfbookmark[1]{"+head+r"}{chapter"+str(n)+"}")
        where=a["where_"+lang].replace("\n"," ")
        locate=(("纸本 "+a["printed"]+" 页，PDF 第 "+a["pdf"]+" 页") if zh else ("Printed p. "+a["printed"]+" / PDF p. "+a["pdf"]))
        t.append(r"\needspace{5\baselineskip}\par\noindent\hypertarget{"+a["id"]+r"}{}{\large\bfseries\color{accent}"+a["id"]+r"}\quad{\small "+locate+r"}\par\nobreak\noindent\textbf{"+where+"}")
        for label,field in [(("原文" if zh else "As printed"),"original"),(("修正" if zh else "Correction"),"fix_"+lang),(("理由" if zh else "Reason"),"why_"+lang)]:
            t.append(r"\par\noindent{\color{quiet}\bfseries "+label+r"}\quad "+a[field])
        t.append(r"\par\medskip")
    if not items: t.append(r"\par "+("本次未发现可确认的原书错误。" if zh else "No errors in the source were confirmed within the stated scope."))
    t.append(r"\end{document}")
    (tex/f"errata-{lang}.tex").write_text("\n".join(t)+"\n",encoding="utf8")
print("Chapters",coverage,"entries",len(items))
