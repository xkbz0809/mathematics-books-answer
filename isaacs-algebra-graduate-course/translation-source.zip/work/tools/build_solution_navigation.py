"""Build the exercise page locators and chapter navigation from the edition's scan ledger."""
import csv
from collections import defaultdict
from pathlib import Path

WORK = Path(__file__).resolve().parents[1]
TEX = WORK / "tex"

def span(a, b):
    return a if a == b else a + "--" + b

def build():
    locations, chapters = [], defaultdict(list)
    with (WORK / "index" / "exercises.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.reader(handle):
            if not row[0].isdigit():
                continue
            chapter, item, first, last, first_pdf, last_pdf = row[:6]
            locations.append(r"\expandafter\def\csname sourcefor@" + item +
                             r"\endcsname{原书 " + span(first, last) +
                             r" 页\quad PDF " + span(first_pdf, last_pdf) + " 页}")
            chapters[chapter].append(item)
    if len(locations) != 463 or len(chapters) != 30:
        raise ValueError("The source must contain 30 chapters and 463 exercise locators.")
    for chapter, items in chapters.items():
        numbers = r"\hspace{.66em}\allowbreak ".join(r"\ProbRef{" + item + "}" for item in items)
        locations.append(r"\expandafter\def\csname navfor@" + chapter + r"\endcsname{" + numbers + "}")
    (TEX / "solution-locations.tex").write_text("\n".join(locations) + "\n", encoding="utf-8")

if __name__ == "__main__":
    build()
