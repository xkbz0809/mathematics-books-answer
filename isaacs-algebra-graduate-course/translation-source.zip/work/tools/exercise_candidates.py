"""Review OCR candidates for original exercise boundaries; coordinates are scan points."""
from pathlib import Path
import unicodedata as ud
import re, json
W=Path(__file__).resolve().parents[1]
START=[25,39,52,66,80,94,109,126,140,153,169,185,204,223,242,264,284,303,317,336,353,370,389,411,428,442,462,484,503,517]
END=[26,42,54,67,82,95,111,127,141,154,171,189,206,225,243,266,286,305,319,338,354,371,391,413,430,445,465,486,505,518]
COUNT=[9,22,14,9,20,13,17,17,13,9,13,30,17,16,13,13,15,25,15,20,11,8,17,17,13,22,14,15,15,11]

def candidates(p,n):
    data=json.loads((W/"ocr"/f"p{p:04}.json").read_text(encoding="utf8"))
    for row in data:
        line=ud.normalize("NFKC",row["text"]).strip()
        if not line or not row["words"]: continue
        left=row["words"][0][1]; top=row["words"][0][2]
        if not re.match(r"^[\dLlI]{1,3}(?:\s|[.,。・•·、:，]|\d)",line): continue
        if len(line)<8: continue
        yield f"{line[:23]}"

if __name__=="__main__":
    for n,(a,b) in enumerate(zip(START,END),1):
        print(f"CH {n}")
        for p in range(a,b+1):
            print(f"{p} "+" | ".join(candidates(p,n)))
