"""Select completed chapters when making an edition."""
from argparse import ArgumentParser
from pathlib import Path
import re

tex=Path(__file__).resolve().parents[1]/"tex"
parser=ArgumentParser()
parser.add_argument("--translation",nargs="+",type=int,required=True)
parser.add_argument("--solutions",nargs="+",type=int,required=True)
parser.add_argument("--index",action="store_true")
args=parser.parse_args()

def describe(nums):
    groups=[]
    for n in sorted(set(nums)):
        if groups and groups[-1][-1]+1==n:
            groups[-1].append(n)
        else:
            groups.append([n])
    return "、".join(str(g[0]) if len(g)==1 else f"{g[0]}–{g[-1]}" for g in groups)

def include(nums,prefix,out):
    fragments=[]
    all_nums=sorted(set(nums))
    for n in all_nums:
        file=tex/f"{prefix}{n:02}.tex"
        if not file.is_file():
            raise SystemExit(f"Missing: {file}")
        if prefix=="ch":
            if n==min(all_nums) and n<=15:
                fragments.append(r"\BookSourcePart{非交换代数}{1}{14}")
            if n>=16 and not any(16<=a<n for a in all_nums):
                if not any(a<16 for a in all_nums):
                    fragments.append(r"\setcounter{part}{1}")
                fragments.append(r"\BookSourcePart{交换代数}{231}{244}")
        fragments.append(r"\input{"+file.stem+"}")
    (tex/out).write_text("\n".join(fragments)+"\n",encoding="utf8")

include(args.translation,"ch","chapterlist-zh.tex")
include(args.solutions,"sol","chapterlist-sol.tex")
nums=sorted(set(args.solutions))
exs=sum(len(re.findall(r"\\begin\{problem\}\{[^}]+\}",(tex/f"sol{n:02}.tex").read_text(encoding="utf8"))) for n in nums)
tcomplete=set(args.translation)==set(range(1,31)) and args.index
scomplete=set(nums)==set(range(1,31))
tscope=("全书中文译本" if tcomplete else "分章稿") + "，收录第 "+describe(args.translation)+" 章。"
sscope=("全书习题" if scomplete else "分章稿")+"，收录第 "+describe(nums)+" 章，共 "+str(exs)+" 道。"
(tex/"scope.tex").write_text(r"\newcommand{\TranslationScope}{"+tscope+"}\n"+r"\newcommand{\SolutionScope}{"+sscope+"}\n",encoding="utf8")
back=(r"\input{subjectindex}"+"\n" if args.index else "")+r"\input{backcover}"+"\n"
(tex/"endlist.tex").write_text(back,encoding="utf8")
print(tscope,sscope)
