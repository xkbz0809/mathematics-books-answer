"""Write a problem and part index using scan page boundaries, corrections and chapter manuscripts."""
import csv
import string
from build_ledger import WORK,START,FIRST,COUNT,dump,record
from index_problem_parts import inspect
# Missing labels were checked against the edition. Range codes encode the label order.
ORIGINAL_PARTS={"2.12":("abc",40),"3.11":("ab",54),"8.2":("abcd",126),"19.6":("abc",318),
                "22.3":("ab",371),"23.2":("ab",389),"23.14":("ab",391),
                "29.12":("abc",504)}
# Roman lists give individual conditions, not separately assigned problems.
ROMAN={"10.5":"i, ii"}
def run():
    source={}
    for ch,(a,first,count) in enumerate(zip(START,FIRST,COUNT),1):
        observed,_,_=inspect(ch,a,first,count)
        for _,qid,c,_paper,pdf in observed:
            source.setdefault(qid,{})[c]=pdf
    for qid,(parts,pdf) in ORIGINAL_PARTS.items():
        source[qid]={c:pdf for c in parts}
    full,parts_index=[],[]
    for ch,(a,first,count) in enumerate(zip(START,FIRST,COUNT),1):
        rows,_=record(ch,a,first,count)
        for n,qid,paper,last,pdf,end_pdf,translated,solved,ch_state,sol_state in rows:
            orig=source.get(qid,{})
            if qid=="1.2":
                translated=""
            # When a scannable in-line label is absent from OCR, the chapter transcription
            # identifies it; for a cross-page exercise the two-page interval is retained.
            for c in translated:
                if c not in orig:
                    orig[c]=None
            cs=sorted(orig)
            # Fill only internal alphabet gaps (often punctuation-only printed rows).
            if cs and cs==sorted(set(cs)) and cs[-1]<="h":
                for c in string.ascii_lowercase[:ord(cs[-1])-96]:
                    orig.setdefault(c,None)
            for c in sorted(orig):
                p=orig[c]
                parts_index.append([qid,c,p-13 if p else paper,p-13 if p else last,
                                    p or pdf,p or end_pdf])
            full.append([n,qid,paper,last,pdf,end_pdf,",".join(sorted(orig)),ROMAN.get(qid,""),ch_state,sol_state])
    dump("exercises.csv",["章","原题","印刷起页","印刷末页_含注与提示","PDF起页","PDF末页_含注与提示","原题字母小问","并列条件","题干收录","解答收录"],full)
    dump("exercise_parts.csv",["原题","小问","印刷起页","印刷末页","PDF起页","PDF末页"],parts_index)
    print(len(full),"exercises;",len(parts_index),"lettered parts")
if __name__=="__main__":
    run()
