"""Validate the links, coverage, identifiers and final page text in the four compiled books."""
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
import pymupdf
from build_ledger import COUNT, WORK, item_parts, read_tex

TEX = WORK / "tex"
OUT = TEX / "build"
QA = WORK / "qa"
INDEX = WORK / "index"
DOCS = ("translation", "solutions", "errata-zh", "errata-en")

def check(value, message):
    if not value:
        raise ValueError(message)

def rows(name):
    with (INDEX / name).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))

def normalized(text):
    return "".join(text.split())

def source_structure():
    problems = rows("exercises.csv")
    expected = [f"{n}.{k}" for n, count in enumerate(COUNT, 1) for k in range(1,count+1)]
    check([r["原题"] for r in problems] == expected, "Problem order")
    parts = {r["原题"]: r["原题字母小问"].replace(",","") for r in problems}
    expected_parts = [(qid, letter) for qid in expected for letter in parts[qid]]
    check([(r["原题"],r["小问"]) for r in rows("exercise_parts.csv")] == expected_parts, "Lettered part order")
    for row in problems:
        a,b,c,d = (int(row[key]) for key in ("印刷起页","印刷末页_含注与提示","PDF起页","PDF末页_含注与提示"))
        check(c-a==13 and d-b==13 and a<=b,f"Problem source interval {row['原题']}")
    statements, sections, printed, notes = set(), set(), set(), set()
    for n in range(1,31):
        s, ch = read_tex(n,"ch")
        _, sol = read_tex(n,"sol")
        check(list(ch)==list(sol)==list(range(1,COUNT[n-1]+1)), f"Chapter {n} exercise sequence")
        for k in ch:
            qid=f"{n}.{k}"
            check(item_parts(sol[k])==parts[qid] or not parts[qid], f"Solution parts {qid}")
            check(len(sol[k].strip())>=12,f"Empty solution {qid}")
        sect = re.findall(r"\\BookSection\{([^}]+)\}",s)
        check(len(sect)==len(set(sect)),f"Section duplication {n}")
        sections.update(sect)
        nums = re.findall(r"\\begin\{statement\}\{[^{}]*\}\{(\d+\.\d+)\}",s)
        check(nums==[f"{n}.{k}" for k in range(1,len(nums)+1)], f"Statement numbering in chapter {n}")
        statements.update(nums)
        for paper,pdf in re.findall(r"\\SrcPage\{(\d+)\}\{(\d+)\}",s):
            check(int(pdf)-int(paper)==13,f"Chapter {n} source anchor {paper}/{pdf}")
            printed.add(int(paper))
        entries = json.loads((QA/f"err{n:02}.json").read_text(encoding="utf-8-sig"))
        ids={e["id"] for e in entries}
        check({i for i in re.findall(r"(?<![0-9A-Z])E\d{4}(?!\d)",s) if i.startswith(f"E{n:02}")}==ids, f"Correction notes in chapter {n}")
        notes.update(ids)
    check(printed==set(range(3,231))|set(range(233,506)), "Original narrative and problem page coverage")
    bm={row["原书签"] for row in rows("bookmarks.csv") if re.fullmatch(r"\d+[A-Z]",row["原书签"])}
    check(bm|{"2E","3C"}==sections, "Sections versus printed headings and scan bookmarks")
    check(len(rows("pages.csv"))==530, "Original page inventory")
    check(len(list((WORK/"ocr").glob("p[0-9][0-9][0-9][0-9].txt")))==530,"OCR text")
    entries = json.loads((QA/"errata-master.json").read_text(encoding="utf8"))["entries"]
    check({e["id"] for e in entries}==notes and len(entries)==len(notes), "Bilingual master")
    check(entries==sorted(entries,key=lambda e:(int(re.search(r"\d+",str(e["pdf"]))[0]),e["id"])),"Errata order")
    for e in entries:
        for lang in ("zh","en"):
            check(all(e[k+"_"+lang].strip() for k in ("where","fix","why")), f'Missing {lang} fields in {e["id"]}')
    return expected, statements, sections, printed, notes

def pdf_coverage():
    exercises,statements,sections,printed,notes=source_structure()
    print(f"30 chapters; {len(statements)} statements; {len(sections)} sections; {len(printed)} original body pages; {len(exercises)} exercises; {len(rows('exercise_parts.csv'))} lettered parts; {len(notes)} corrections.")
    docs={n:pymupdf.open(OUT/(n+".pdf")) for n in DOCS}
    original_names=docs["translation"].resolve_names()
    rows_out=[]
    for name,doc in docs.items():
        names=doc.resolve_names()
        toc=doc.get_toc()
        txt=[]
        fonts=set()
        totals=Counter()
        remote=set()
        for page in doc:
            lines=page.get_text()
            check(lines.strip(),f"{name}, empty page {page.number+1}")
            txt.append(normalized(lines))
            fonts.update(f[0] for f in page.get_fonts())
            for link in page.get_links():
                k=link["kind"]
                if k in (pymupdf.LINK_GOTOR, pymupdf.LINK_LAUNCH):
                    # MuPDF also classifies a named GoToR destination as a file launch.
                    obj=doc.xref_object(link["xref"])
                    target=re.search(r"/D\s*\((isa\.[^)]+)\)",obj)
                    check("/GoToR" in obj and target is not None, f"{name} malformed remote action {obj}")
                    check(link["file"].split("#",1)[0].replace("\\","/").split("/")[-1]=="Isaacs_Algebra_ZH.pdf", f"{name} companion filename {link}")
                    check(target[1] in original_names, f"{name} companion target {target[1]}")
                    remote.add(target[1])
                    k=pymupdf.LINK_GOTOR
                elif k in (pymupdf.LINK_GOTO,pymupdf.LINK_NAMED):
                    dest=link.get("page")
                    if dest is None and link.get("nameddest") in names:
                        dest=names[link["nameddest"]].get("page")
                    check(isinstance(dest,int) and 0<=dest<len(doc),f"{name} internal link {link}")
                elif k!=pymupdf.LINK_URI:
                    raise ValueError(f"{name} cannot resolve link {link}")
                totals[k]+=1
        for xref in fonts:
            check(doc.extract_font(xref)[3],f"{name}, non-embedded font {xref}")
        for path in [OUT/(name+".log")]:
            log=path.read_text(encoding="utf8",errors="replace")
            for pattern in ("Missing character:","There were undefined references","multiply defined","Font shape","Overfull \\vbox"):
                check(pattern not in log,f"{name} compile warning {pattern}")
            for overflow in re.findall(r"Overfull \\hbox \(([\d.]+)pt too wide\)",log):
                check(float(overflow)<5,f"{name} margin overflow {overflow} pt")
        for level,title,page in toc:
            check(1<=page<=len(doc),f"{name} invalid bookmark {title}")
        if name in ("translation","solutions"):
            for prefix, numbers in ([("ex",exercises),("st",statements),("sec",sections),("ch",range(1,31)),("origpg",printed|{1,231}|set(range(507,517)))] if name=="translation" else [("ex",exercises),("ch",range(1,31))]):
                for num in numbers:
                    key=f"isa.{prefix}.{num}"
                    check(key in names,f"{name} missing anchor {key}")
                    if prefix in ("ex","st","sec"):
                        pos=names[key]["page"]
                        check(str(num) in txt[pos] or str(num) in txt[min(pos+1,len(doc)-1)],f"{name} number invisible at {key} p{pos+1}")
            if name=="solutions":
                check([t.split()[-1] for level,t,p in toc if level==2]==exercises,"Solution bookmarks")
                check({f"isa.ex.{q}" for q in exercises}<=remote,"Each solution should link to the translated question")
            else:
                check({e for e in notes if e not in ''.join(txt)}==set(),"Corrections missing in rendered translation")
        else:
            check({k for k in names if re.fullmatch(r"E\d{4}",k)}==notes,f"{name} named correction anchors")
            for key in notes:
                pos=names[key]["page"]
                check(key in txt[pos] or key in txt[min(pos+1,len(doc)-1)],f"{name} printed ID {key}")
            rendered=set(re.findall(r"E\d{4}"," ".join(txt)))
            check(rendered==notes,f"{name} correction IDs {sorted(rendered^notes)}")
        rows_out.append([name,len(doc),len(toc),sum(totals.values()),totals[pymupdf.LINK_GOTOR],len(fonts),hashlib.sha256((OUT/(name+".pdf")).read_bytes()).hexdigest()])
        print(*rows_out[-1][:-1],flush=True)
    with (QA/"pdf-verification.csv").open("w",encoding="utf-8-sig",newline="") as f:
        writer=csv.writer(f);writer.writerow(["文件","页数","书签","链接","跨册链接","内嵌字体数","SHA256"]);writer.writerows(rows_out)
    for doc in docs.values():
        doc.close()

if __name__=="__main__":
    pdf_coverage()
