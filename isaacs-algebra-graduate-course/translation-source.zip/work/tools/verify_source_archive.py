"""Build the source archive in a clean directory and compare it with the released PDFs."""
import argparse
from pathlib import Path, PurePosixPath
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile

import pymupdf


DOCUMENTS = {
    "translation": "Isaacs_Algebra_ZH.pdf",
    "solutions": "Isaacs_Exercises_ZH.pdf",
    "errata-zh": "Isaacs_Errata_ZH.pdf",
    "errata-en": "Isaacs_Errata_EN.pdf",
}


def compare(reference_path, rebuilt_path):
    with pymupdf.open(reference_path) as reference, pymupdf.open(rebuilt_path) as rebuilt:
        if len(reference) != len(rebuilt) or reference.get_toc() != rebuilt.get_toc():
            raise ValueError(f"{reference_path.name}: page count or bookmarks differ")
        if reference.resolve_names() != rebuilt.resolve_names():
            raise ValueError(f"{reference_path.name}: named destinations differ")
        for original, copy in zip(reference, rebuilt):
            label = f"{reference_path.name}, page {original.number + 1}"
            if original.rect != copy.rect or original.get_text() != copy.get_text():
                raise ValueError(f"{label}: page geometry or extracted text differs")
            if original.get_pixmap().digest != copy.get_pixmap().digest:
                raise ValueError(f"{label}: rendered pages differ")
        print(f"{reference_path.name}: {len(reference)} pages match", flush=True)


def verify(archive_path, reference_dir, temporary_parent):
    with TemporaryDirectory(prefix="isaacs-check-", dir=temporary_parent) as tmp:
        root = Path(tmp)
        with ZipFile(archive_path) as archive:
            if archive.testzip() is not None:
                raise ValueError("The source archive failed its CRC check")
            for name in archive.namelist():
                parts = PurePosixPath(name).parts
                if not parts or parts[0] != "work" or ".." in parts or "\\" in name or ":" in name:
                    raise ValueError(f"Unexpected archive path {name!r}")
            archive.extractall(root)
        work = root / "work"
        for script in ("build_pdfs.py", "verify_edition.py"):
            subprocess.run([sys.executable, "-X", "utf8", str(work / "tools" / script)],
                           cwd=work, check=True)
        for job, filename in DOCUMENTS.items():
            compare(reference_dir / filename, work / "tex" / "build" / f"{job}.pdf")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--pdf-dir", type=Path, help="Directory with the released PDFs (default: archive directory)")
    parser.add_argument("--temp-dir", type=Path, help="Parent directory for the temporary clean build")
    args = parser.parse_args()
    verify(args.archive, args.pdf_dir or args.archive.parent, args.temp_dir)
