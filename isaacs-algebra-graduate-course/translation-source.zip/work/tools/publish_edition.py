"""Copy verified PDFs and pack the editable edition beside them for delivery."""
import argparse
import csv
import hashlib
import os
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile
from build_ledger import WORK
from package_sources import package

FILES={"translation":"Isaacs_Algebra_ZH.pdf","solutions":"Isaacs_Exercises_ZH.pdf",
       "errata-zh":"Isaacs_Errata_ZH.pdf","errata-en":"Isaacs_Errata_EN.pdf"}
SOURCES="Isaacs_Editable_Sources.zip"
COMPLETE="Isaacs_GSM100_Complete.zip"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def publish(folder):
    folder=Path(folder).resolve()
    folder.mkdir(parents=True,exist_ok=True)
    with (WORK/"qa"/"pdf-verification.csv").open(encoding="utf-8-sig",newline="") as f:
        checked={r["文件"]:r["SHA256"] for r in csv.DictReader(f)}
    for name,filename in FILES.items():
        src=WORK/"tex"/"build"/(name+".pdf")
        if digest(src)!=checked.get(name):
            raise ValueError(f"Re-run the PDF validation before releasing {name}.")
        dst=folder/filename
        temp=dst.with_suffix(".pdf.tmp")
        shutil.copyfile(src,temp)
        if digest(temp)!=checked[name]:
            raise IOError(f"Incomplete copy of {filename}")
        os.replace(temp,dst)
    package(folder/SOURCES)
    dest=folder/COMPLETE
    temp=dest.with_suffix(".zip.tmp")
    members=[*FILES.values(),SOURCES]
    with ZipFile(temp,"w",compression=ZIP_DEFLATED,compresslevel=6) as z:
        for filename in members:
            z.write(folder/filename,filename,compress_type=ZIP_STORED if filename==SOURCES else ZIP_DEFLATED)
    with ZipFile(temp) as z:
        if z.namelist()!=members or z.testzip() is not None:
            raise IOError("The publication package failed its contents check.")
        for filename in members:
            if hashlib.sha256(z.read(filename)).hexdigest()!=digest(folder/filename):
                raise IOError(f"Package member mismatch: {filename}")
    os.replace(temp,dest)
    print(dest, dest.stat().st_size, digest(dest))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory")
    publish(parser.parse_args().directory)
