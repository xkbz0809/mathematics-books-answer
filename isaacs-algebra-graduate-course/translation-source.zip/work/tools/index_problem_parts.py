"""Cross-check printed lettered subproblems against maintained chapter text and log OCR boundaries."""
from pathlib import Path
import unicodedata,re
from build_ledger import WORK,START,FIRST,COUNT,CONTINUED,dump,read_tex,item_parts

# The scan confirms these numbers where OCR loses a stop or reads "21." as "2L".
EXCEPT={(140,19):(9,6),(353,25):(21,1),(353,44):(21,6),
        (354,10):(21,8),(354,19):(21,11),(517,29):(30,7)}
NORM=str.maketrans({"l":"1","L":"1","I":"1","i":"1"})
def number(text):
    m=re.match(r"^([0-9IiLl]{1,2})\s*[·\.:。•,]\s*([0-9IiLl]{1,2})(?=\s|[A-Z])",text)
    if not m:
        m=re.match(r"^(\d)[Ll](\d{1,2})\s",text)
        if m and m[1]=="1": return 11,int(m[2])
    if not m:
        m=re.match(r"^(\d{1,2})\s+(\d{1,2})\s",text)
    return (int(m[1].translate(NORM)),int(m[2].translate(NORM))) if m else None

def inspect(ch,a,first,count):
    _,exercises=read_tex(ch,"ch")
    current=0
    records={}
    misses=[]
    for off,first_id in enumerate(first):
        p=a+off
        if not first_id or p in CONTINUED:
            current=(next((i for i in first[off:] if i),count+1)-1)
        else:
            current=0
        end=next((i for i in first[off+1:] if i),count+1)-1
        lines=(WORK/"ocr"/f"p{p:04}.txt").read_text(encoding="utf8").splitlines()
        start=next((i for i,s in enumerate(lines) if off==0 and re.fullmatch(r"\s*problems\s*",s,re.I)),0)
        seen=set()
        for idx,text in enumerate(lines[start:],start):
            t=unicodedata.normalize("NFKC",text).strip()
            pair=EXCEPT.get((p,idx)) or number(t)
            if pair and pair[0]==ch and first_id and first_id<=pair[1]<=end:
                if pair[1]>current:
                    current=pair[1]
                    seen.add(current)
                continue
            if current==0:
                continue
            m=re.match(r"^([a-h])\s*[\.:·)。]\s*(?=.{3}|\s*$)",t)
            if m:
                records.setdefault(current,[]).append((m[1],p))
        if first_id:
            for i in set(range(first_id,end+1))-seen:
                misses.append(f"{ch}.{i}({p})")
    out=[]
    diffs=[]
    for i in range(1,count+1):
        observed=records.get(i,[])
        labels=''.join(c for c,p in observed)
        expected=item_parts(exercises[i]) if i in exercises else None
        if (labels and labels!="abcdefgh"[:len(labels)]) or (expected is not None and labels!=expected):
            diffs.append(f"{ch}.{i}:{labels or '-'} vs {expected or '-'}")
        for c,p in observed:
            out.append([ch,f"{ch}.{i}",c,p-13,p])
    return out,misses,diffs

if __name__=="__main__":
    subparts=[]
    for ch,(a,first,n) in enumerate(zip(START,FIRST,COUNT),1):
        items,miss,diff=inspect(ch,a,first,n)
        subparts.extend(items)
        print(ch,"unrecognized",','.join(miss) or "none","differences",'; '.join(diff) or "none")
    dump("ocr_lettered_parts.csv",["章","原题","OCR辨认的小问_比对用","印刷页","PDF页"],subparts)
    print(len(subparts),"lettered OCR records")