"""Rebuild cross-reference tables and normalize notation in the Chinese edition."""
import json
from pathlib import Path
import re
from build_ledger import CHAPTER_START, WORK

TEX = WORK / "tex"
# The index retains the order of the English original.
CHINESE = {
    "西罗": "西洛", "最小多项式": "极小多项式", "雅各布森": "雅可布森",
    r"\emph{交换子}": r"\emph{换位子}", "交换子恒等式": "换位子恒等式",
    "所有交换子属于": "所有换位子属于", "其交换子群包含": "其换位子群包含",
}
HISTORIC = {
    "Artin--Schreier": "阿廷–施赖尔", "Artin–Schreier": "阿廷–施赖尔",
    "Artin–Rees": "阿廷–里斯", "Wedderburn--Artin": "韦德伯恩–阿廷",
    "Jordan--Hölder": "若尔当–赫尔德", "Jordan–Hölder": "若尔当–赫尔德",
    "Krull--Schmidt": "克鲁尔–施密特", "Krull–Schmidt": "克鲁尔–施密特",
    "Lasker--Noether": "拉斯克–诺特", "Lasker–Noether": "拉斯克–诺特",
    "Galois": "伽罗瓦", "Sylow": "西洛", "Jacobson": "雅可布森",
    "Noether": "诺特", "Dedekind": "戴德金", "Artin": "阿廷",
    "Hilbert": "希尔伯特", "Wedderburn": "韦德伯恩", "Krull": "克鲁尔",
    "Frattini": "弗拉蒂尼",
}

def write_changed(p, new):
    old = p.read_text(encoding="utf-8-sig")
    if old != new:
        p.write_text(new, encoding="utf-8")

def normalize(s, names=False):
    for old, new in CHINESE.items():
        s=s.replace(old,new)
    if names:
        for old,new in HISTORIC.items():
            s=re.sub(r"(?<![A-Za-z/])"+re.escape(old)+r"(?![A-Za-z，/])\s*(?=[\u3400-\u9fff$（])",new,s)
    return s

def tables():
    trans={n:re.search(r"\\BookChapter\{\d+\}\{(.*)\}",
                        (TEX/f"ch{n:02}.tex").read_text(encoding="utf-8-sig").splitlines()[0])[1]
           for n in range(1,31)}
    sol={n:TEX/f"sol{n:02}.tex" for n in range(1,31)}
    for n,p in sol.items():
        if p.is_file():
            s=p.read_text(encoding="utf-8-sig")
            s=re.sub(r"^\\BookChapter\{\d+\}\{.*\}",lambda m:rf"\BookChapter{{{n}}}{{{trans[n]}}}",s,count=1)
            write_changed(p,s)
    out=[r"\chapter*{原书目录}\addcontentsline{toc}{chapter}{原书目录}",
         r"\noindent 保留原书目录（纸本 ix--xii，PDF 第 10--13 页）的起始页。章号与原页码均可点击。",
         r"\begin{longtable}{@{}p{17mm}p{93mm}r@{}}\toprule 章 & 标题 & 原页\\\midrule\endhead"]
    for n,original in enumerate(CHAPTER_START,1):
        if n in (1,16):
            part,pg=("第一编","1") if n==1 else ("第二编","231")
            label="非交换代数" if n==1 else "交换代数"
            out.append(r"\multicolumn{2}{l}{\bfseries "+part+r"\quad "+label+
                       r"}&\textbf{\OriginalPageRef{"+pg+r"}}\\[2pt]")
        out.append(rf"\ChapRef{{{n}}} & {trans[n]} & \OriginalPageRef{{{original-13}}}"+r"\\")
    out.extend([r"\addlinespace \multicolumn{2}{l}{\hyperref[book:subjectindex]{索引}} & \OriginalPageRef{507}\\\bottomrule",r"\end{longtable}"])
    (TEX/"source_contents.tex").write_text("\n".join(out)+"\n",encoding="utf-8")

def main():
    for p in [*TEX.glob("ch[0-9][0-9].tex"),*TEX.glob("sol[0-9][0-9].tex"),TEX/"front.tex",TEX/"backcover.tex",*(WORK/"index").glob("idx*.txt")]:
        text=p.read_text(encoding="utf-8-sig")
        write_changed(p,normalize(text,p.name in ("front.tex","backcover.tex") or p.name.startswith("idx")))
    for p in (WORK/"qa").glob("err[0-9][0-9].json"):
        entries=json.loads(p.read_text(encoding="utf-8-sig"))
        changed=False
        for e in entries:
            for key in ("where_zh","fix_zh","why_zh"):
                val=normalize(e[key])
                if val!=e[key]:
                    e[key]=val
                    changed=True
        if changed:
            p.write_text(json.dumps(entries,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    tables()

if __name__=="__main__":
    main()
