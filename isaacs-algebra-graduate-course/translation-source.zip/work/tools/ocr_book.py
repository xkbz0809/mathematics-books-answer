"""Build page OCR from the supplied scan. All page numbers are one-based."""
from __future__ import annotations

import argparse
import asyncio
import csv
import hashlib
import json
import os
import re
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import pymupdf
from winrt.windows.globalization import Language
from winrt.windows.graphics.imaging import BitmapDecoder, BitmapPixelFormat
from winrt.windows.media.ocr import OcrEngine
from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream

WORK = Path(__file__).resolve().parents[1]
BOOK = WORK.parent
SOURCE = next(BOOK.glob("*.pdf"))
OUT = WORK / "ocr"
INDEX = WORK / "index"
source_doc = None
engine = None


def init_worker():
    global source_doc, engine
    source_doc = pymupdf.open(SOURCE)
    engine = (OcrEngine.try_create_from_language(Language("en-US"))
              or OcrEngine.try_create_from_user_profile_languages())
    if not engine:
        raise RuntimeError("No installed OCR language can read the scan")


async def read_page(pdf_page):
    page = source_doc[pdf_page - 1]
    if not page.get_images() and not page.get_text().strip():
        return []
    scale = 1620 / page.rect.width
    pix = page.get_pixmap(matrix=pymupdf.Matrix(scale, scale), colorspace=pymupdf.csGRAY)
    stream = InMemoryRandomAccessStream()
    writer = DataWriter(stream)
    writer.write_bytes(pix.tobytes("png"))
    await writer.store_async()
    writer.detach_stream()
    stream.seek(0)
    decoder = await BitmapDecoder.create_async(stream)
    bitmap = await decoder.get_software_bitmap_async()
    result = await engine.recognize_async(bitmap)
    rows = []
    for line in result.lines:
        words = []
        for word in line.words:
            r = word.bounding_rect
            words.append([word.text, round(r.x / scale, 1), round(r.y / scale, 1),
                          round((r.x+r.width) / scale, 1), round((r.y+r.height) / scale, 1)])
        rows.append({"text": line.text, "words": words})
    bitmap.close()
    stream.close()
    return rows


def ocr_page(n):
    jp = OUT / f"p{n:04}.json"
    tp = jp.with_suffix(".txt")
    if jp.exists() and tp.exists():
        return n
    lines = asyncio.run(read_page(n))
    jp.with_suffix(".json.tmp").write_text(json.dumps(lines, ensure_ascii=False), encoding="utf-8")
    tp.with_suffix(".txt.tmp").write_text("\n".join(r["text"] for r in lines)+"\n", encoding="utf-8")
    jp.with_suffix(".json.tmp").replace(jp)
    tp.with_suffix(".txt.tmp").replace(tp)
    return n


def write_index(doc):
    toc = [(depth, title.rstrip("\0").strip(), page) for depth, title, page in doc.get_toc()]
    edition = "GSM 100 · AMS 2009 · ISBN 978-0-8218-4799-2"
    roman = "iv v vi vii viii ix x xi xii".split()
    rows = []
    moves = {}
    for level, title, page in toc:
        moves.setdefault(page, []).append((level,title))
    part = chapter = section = ""
    for n in range(1,len(doc)+1):
        for level,title in moves.get(n,[]):
            if level == 1:
                part,chapter,section=title,"",""
            elif level == 2:
                chapter,section=title,""
            else:
                section=title
        if n in (1,2,3,4,14,15,244,245,519,530):
            printed="未标页码"
        elif 5<=n<=13:
            printed=roman[n-5]
        else:
            printed=str(n-13)
        nominal = str(n-13) if 14<=n<=529 else ""
        rows.append([edition, n, printed,nominal,part,chapter,section,
                     len(doc[n-1].get_text()),len(doc[n-1].get_images())])
    with (INDEX / "pages.csv").open("w",encoding="utf-8-sig",newline="") as f:
        out=csv.writer(f);out.writerow(["版本","PDF顺序页","印刷页码_按版式初排","阿拉伯序列推知页码","编或材料","章","节或题组_末个起点","可提取字符","图像数"]);out.writerows(rows)
    with (INDEX / "bookmarks.csv").open("w",encoding="utf-8-sig",newline="") as f:
        out=csv.writer(f);out.writerow(["层级","原书签","PDF顺序页"]);out.writerows(toc)
    (INDEX/"source.sha256").write_text(hashlib.sha256(SOURCE.read_bytes()).hexdigest()+"  "+SOURCE.name+"\n", encoding="utf-8")
    return toc


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--jobs",type=int,default=1)
    parser.add_argument("--pages",nargs="*",type=int)
    opts=parser.parse_args()
    for directory in (OUT,INDEX): directory.mkdir(parents=True,exist_ok=True)
    with pymupdf.open(SOURCE) as doc:
        toc=write_index(doc)
        groups=[p for _,t,p in toc if t=="Problems"]
        last=len(doc)
        launch=[16,83,155,246,339,431]
        first_areas=[j for a in launch for j in range(a,a+4)]
        covers=[j for j in range(1,16)]
        priority=covers+first_areas+[j for p in groups for j in range(p,min(last+1,p+5))]
        pages=opts.pages or list(dict.fromkeys(priority+list(range(1,last+1))))
    if opts.jobs==1:
        init_worker()
        for n in pages: print(ocr_page(n),flush=True)
    else:
        with ProcessPoolExecutor(max_workers=opts.jobs,initializer=init_worker) as pool:
            for i,n in enumerate(pool.map(ocr_page,pages,chunksize=1),1):
                if i%20==0 or i==len(pages): print(f"OCR {i}/{len(pages)}",flush=True)


if __name__ == "__main__":
    main()

