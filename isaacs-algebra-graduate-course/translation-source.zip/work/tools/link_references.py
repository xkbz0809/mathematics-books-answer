"""Repair scan metadata and attach references to the original numbered objects."""
import csv
import re
from collections import Counter
from build_ledger import WORK

TEX = WORK / "tex"
CAPTION = re.compile(r"^(?:\\end\{tikzpicture\}(?:\\\\|\\par\s*)|\\textbf\{)?(图|表)[ ~]*(\d+\.\d+)(?:\})?(?:\\par\\smallskip)?$")
TYPES = {"图": "fig", "表": "tab"}

def update_scan_index():
    path = WORK / "index" / "pages.csv"
    with path.open(encoding="utf-8-sig", newline="") as infile:
        rows = list(csv.reader(infile))
    # These headings are legible in the printed edition and absent from its digital outline.
    for row in rows[1:]:
        page = int(row[1])
        if page in (38, 50, 51):
            row[6] = "2E" if page == 38 else "3C"
    with path.open("w", encoding="utf-8-sig", newline="") as outfile:
        csv.writer(outfile).writerows(rows)

def link():
    sources = sorted(TEX.glob("ch[0-9][0-9].tex"))
    solutions = sorted(TEX.glob("sol[0-9][0-9].tex"))
    texts = {path: path.read_text(encoding="utf-8-sig") for path in sources+solutions}
    captions = set()
    statements = set()
    problems = set()
    for path in sources:
        s = texts[path]
        statements.update(re.findall(r"\\begin\{statement\}\{[^}]*\}\{(\d+\.\d+)\}", s))
        problems.update(re.findall(r"\\begin\{problem\}\{(\d+\.\d+)\}", s))
        for kind, label in re.findall(r"\\NumberedCaption\{(fig|tab)\}\{(\d+\.\d+)\}",s):
            captions.add((kind,label))
        for ln in s.splitlines():
            m = CAPTION.fullmatch(ln.strip())
            if m:
                captions.add((TYPES[m[1]],m[2]))
    if len(captions)!=17:
        raise ValueError(f"Expected fifteen figures and two tables, got {sorted(captions)}")
    words = re.compile(r"(定理|定义|推论|引理|命题|习题|图|表)([ \t~]*)(\d+\.\d+)(?!\d|\.\d)")
    def reference(m):
        noun,sep,number = m.groups()
        if noun in TYPES and (TYPES[noun],number) in captions:
            return noun+sep+r"\NumberRef{"+TYPES[noun]+"}{"+number+"}"
        if noun == "习题" and number in problems:
            return noun+sep+r"\ProbRef{"+number+"}"
        if noun not in TYPES and noun!="习题" and number in statements:
            return noun+sep+r"\StmtRef{"+number+"}"
        return m[0]
    for path, text in texts.items():
        converted=[]
        for ln in text.splitlines(keepends=True):
            m = CAPTION.fullmatch(ln.strip()) if path in sources else None
            if m:
                label = r"\NumberedCaption{"+TYPES[m[1]]+"}{"+m[2]+"}"
                ln = re.sub(r"(图|表)([ ~]*)"+re.escape(m[2]),lambda x:x[1]+x[2]+label,ln,count=1)
            ln = words.sub(reference,ln)
            converted.append(ln)
        result="".join(converted)
        if result!=text:
            path.write_text(result,encoding="utf-8")
    print(f"{len(statements)} numbered statements, {len(problems)} problems and {len(captions)} captions.")

if __name__ == "__main__":
    update_scan_index()
    link()
