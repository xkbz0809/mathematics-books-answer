"""Build a source snapshot with XeLaTeX and Biber from the project directory."""
from pathlib import Path
import argparse
import subprocess
import sys
import re

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--through", type=int, choices=range(1,10), default=9)
parser.add_argument("--proof", action="store_true", help="Build the currently available sections for proofreading")
args = parser.parse_args()
sections = (0,5,4,3,6,4,9,7,5,6)
job = "proof" if args.proof else ("bosch-zh" if args.through == 9 else f"bosch-zh-ch{args.through}")
out = root / "build" / job
out.mkdir(parents=True, exist_ok=True)
body = []
def take(name):
    if (root / "tex" / (name+".tex")).exists():
        body.append(r"\input{tex/"+name+"}")
    elif not args.proof:
        sys.exit("Missing translated unit: "+name)
take("intro-a")
for ch in range(1,args.through+1):
    if ch == 6:
        take("intro-b")
    if args.proof and not (root / "tex" / f"s{ch:02}-00.tex").exists():
        continue
    if args.proof:
        body.append(r"\setcounter{chapter}{"+str(ch-1)+"}")
    for sec in range(sections[ch]+1):
        if args.proof and sec:
            body.append(r"\setcounter{section}{"+str(sec-1)+"}")
        take(f"s{ch:02}-{sec:02}")
if args.through == 9:
    body.append(r"\backmatter\makebibliography")
    take("notation")
    take("index")
else:
    body.append(r"\backmatter\makebibliography")
bodyfile=out/"body.tex"
bodyfile.write_text("\n".join(body)+"\n",encoding="utf-8")
if not args.proof and args.through == 9:
    (root / "tex" / "body.tex").write_text(bodyfile.read_text(encoding="utf-8"), encoding="utf-8")
rel=out.relative_to(root).as_posix()
levels=["xelatex","xelatex","biber","xelatex","xelatex"]
for i,tool in enumerate(levels,1):
    if tool=="xelatex":
        call=[tool,"-no-shell-escape","-interaction=nonstopmode","-halt-on-error","-file-line-error",
              "-jobname="+job,"-output-directory="+rel,
              r"\def\boschbody{"+rel+r"/body.tex}\input{main.tex}"]
    else:
        call=[tool,"--input-directory",rel,"--output-directory",rel,job]
    p=subprocess.run(call,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=out/f"pass-{i}.txt"
    log.write_bytes(p.stdout)
    if p.returncode:
        print(p.stdout[-2300:].decode("utf-8",errors="replace"))
        sys.exit(p.returncode)
print(out/(job+".pdf"))

