from pathlib import Path
import pymupdf
from PIL import Image,ImageDraw
w=Path('工作稿/inventory'); doc=pymupdf.open(next(Path().glob('*.pdf')))
out=w/'final-review';out.mkdir(exist_ok=True)
for p0,p1 in [(309,320),(467,473),(488,491)]:
 for n in range(p0,p1+1,2):
    pages=list(range(n,min(n+2,p1+1))); shots=[]
    for p in pages:
        page=doc[p+11]
        pix=page.get_pixmap(matrix=pymupdf.Matrix(1.55,1.55),clip=pymupdf.Rect(30,45,page.rect.width-7,634),colorspace=pymupdf.csGRAY)
        shots.append(Image.frombytes('L',(pix.width,pix.height),pix.samples))
    img=Image.new('L',(sum(a.width for a in shots)+len(shots),max(a.height for a in shots)+18),255); dr=ImageDraw.Draw(img);x=0
    for p,a in zip(pages,shots):
        img.paste(a,(x,17));dr.text((x+4,1),f'page {p} / PDF {p+12}',fill=0);x+=a.width;dr.line((x,16,x,img.height),0);x+=1
    img.save(out/f'{n}.png',optimize=False)
