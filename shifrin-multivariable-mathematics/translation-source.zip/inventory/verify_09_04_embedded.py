from pathlib import Path
import pymupdf,sys
w=Path('工作稿'); out=w/'inventory'/'figure-audit'
actual=w/'build'/'shifrin-solutions.pdf'
if len(sys.argv)>1 and sys.argv[1]=='final' and not actual.is_file():
 print('Full solutions PDF pending');sys.exit(0)
p=actual if actual.is_file() and len(sys.argv)>1 else w/'inventory/final-review/check-9-solutions.pdf'
with pymupdf.open(p) as doc:
 print(p.name,doc.page_count)
 nums=[]
 for n,pag in enumerate(doc,1):
  if p==actual and n<doc.page_count-18:continue
  nvec=len(pag.get_drawings())
  if nvec<90:continue
  vals=[]
  for b in pag.get_text('dict')['blocks']:
   for ln in b.get('lines',[]):
    t=''.join(x['text'] for x in ln['spans']).strip()
    if t in ['x1','x2','x3','(a)','(b)','(c)','(d)','(e)','(f)']:
     vals.append(t)
  if vals.count('x3')==6 or (vals.count('x1')==5 and vals.count('x2')==5):
   nums.append(n)
   print(n,nvec,{k:vals.count(k) for k in dict.fromkeys(vals)})
   tag='final' if p==actual else 'chapter'
   pag.get_pixmap(matrix=pymupdf.Matrix(1.3,1.3),alpha=False).save(out/f'09-04-{tag}-{n:03}.png')
 if len(nums)!=2:print('Plate matches',nums)
