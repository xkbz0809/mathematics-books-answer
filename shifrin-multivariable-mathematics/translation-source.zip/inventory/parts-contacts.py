from pathlib import Path
import pymupdf
from PIL import Image,ImageDraw
import register
base=Path(__file__).resolve().parent
out=base/'parts'
out.mkdir(exist_ok=True)
doc=pymupdf.open(next(base.parent.parent.glob('*.pdf')))
for line in (base/'visual-pages.txt').read_text(encoding='utf8').splitlines():
    if not line or line.startswith('#'):continue
    sec,*tokens=line.split(); pages=[int(t.split(':')[0].strip('+'))for t in tokens]
    for j in range(0,len(pages),2):
        chunk=pages[j:j+2]; target=out/f'{sec}-{j//2+1}.png'
        if target.exists():continue
        arr=[]
        for p in chunk:
            page=doc[p+11]
            left=65 if p%2 else 85
            pix=page.get_pixmap(matrix=pymupdf.Matrix(1.55,1.55),clip=pymupdf.Rect(left,49,left+425,638),colorspace=pymupdf.csGRAY)
            arr.append(Image.frombytes('L',(pix.width,pix.height),pix.samples))
        img=Image.new('L',(sum(i.width for i in arr)+2, max(i.height for i in arr)+18),255); draw=ImageDraw.Draw(img); x=0
        for p,a in zip(chunk,arr):
            img.paste(a,(x,17)); draw.text((x+7,0),f'{sec} / {p}',0); x+=a.width; draw.line((x,16,x,img.height),0); x+=1
        img.save(target,optimize=False)
