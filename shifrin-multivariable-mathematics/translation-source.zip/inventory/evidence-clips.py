from pathlib import Path
import pymupdf
from PIL import Image,ImageDraw
w=Path('工作稿/inventory')
d=pymupdf.open(next(Path().glob('*.pdf')))
for n,a,b in [(401,410,640),(453,200,595),(284,490,640),(285,40,250),(392,47,265)]:
 p=d[n+11]; pix=p.get_pixmap(matrix=pymupdf.Matrix(2,2),clip=pymupdf.Rect(83 if n%2 else 102,a,505 if n%2 else 522,b),colorspace=pymupdf.csGRAY);pix.save(w/f'evidence-{n}.png')
