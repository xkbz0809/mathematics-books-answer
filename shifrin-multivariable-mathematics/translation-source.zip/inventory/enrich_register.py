"""Produce the detailed register from the verified visual tables and the original short answers."""
import re
from pathlib import Path


def ranges(first, last):
    return [chr(n) for n in range(ord(first), ord(last) + 1)]


def leaves(shape):
    if shape == "—":
        return ["整题"]
    if shape == "a,b(i–iii)":
        return ["a", "b.i", "b.ii", "b.iii"]
    if shape == "a–d各含(i)–(iii)":
        return [f"{letter}.{roman}" for letter in "abcd" for roman in ("i", "ii", "iii")]
    match = re.search(r"([A-Za-z])–([A-Za-z])", shape)
    if not match:
        raise ValueError(shape)
    return ranges(*match.groups())


def labels(text):
    if text.startswith("图") and "(" in text:
        text = text.split("(", 1)[1].split(")", 1)[0]
    values = []
    for item in text.split(","):
        if re.fullmatch(r"[a-z]–[a-z]", item):
            values.extend(ranges(item[0], item[-1]))
        elif re.fullmatch(r"[a-z]", item):
            values.append(item)
    return values


def original_selections(path):
    answers = {}
    page = None
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        mark = re.match(r"\\origpage\{(\d+)\}", line)
        if mark:
            page = int(mark[1])
        mark = re.match(r"\\shans\{(\d+\.\d+)\.(\d+)\}", line)
        if mark:
            key = (mark[1], int(mark[2]))
            if key in answers or page is None:
                raise ValueError(line)
            answers[key] = page
    return answers


def location_map(path):
    data = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        key, details = line.split(maxsplit=1)
        data[key] = []
        for expr in details.split(";"):
            name, interval = expr.rsplit("@", 1)
            bounds = [int(t) for t in interval.split("–")]
            data[key].append((name, bounds[0], bounds[-1]))
    return data


def detailed_register(here, work, order, tsv, pages, shapes, candidates):
    answers = original_selections(work / "tex" / "back-answers.tex")
    star_scope = {}
    groups_checked = []
    for line in (here / "stars-visual.txt").read_text(encoding="utf-8-sig").splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        section, *tokens = line.split()
        groups_checked.append(section)
        for item in tokens:
            match = re.fullmatch(r"(\d+)([a-n]*)", item)
            if not match:
                raise ValueError(item)
            star_scope[section,int(match[1])] = ",".join(match[2]) or "整题"
    assert groups_checked == [key for key,_,_ in order]
    assert set(star_scope) == set(answers), (set(star_scope)-set(answers),set(answers)-set(star_scope))
    selected_data = []
    for (section,number),location in answers.items():
        scope = star_scope[section,number]
        if scope != "整题":
            allowed = {v.split(".")[0] for v in leaves(shapes[section,number])}
            assert set(scope.split(",")) <= allowed, (section,number,scope)
        printed = pages[section,number][0]
        selected_data.append((section,number,scope,printed,printed+12,location,location+12))
    tsv("selected-answers.tsv",["section","exercise","asterisk_scope","question_printed","question_pdf",
            "author_answer_printed","author_answer_pdf"],selected_data)
    positions = location_map(here / "parts-locations.txt")
    notes = {
        "1.2.14": "另有同题内不编号的几何挑战。",
        "1.4.18": "两项计算之后另要求提出一般阶猜想。",
        "1.4.34": "(b) 包含三个并列给定的矩阵。",
        "2.1.7": "纸本63页的图1.18属于前方第5题。",
        "7.3.11": "纸本298的图3.15属于本题。",
        "8.6.7": "图6.3(a)–(h)为原图各面板。",
        "9.4.6": "四个矩阵按题中 A、B、C、D 的顺序登记。",
    }
    extra = {"1.2.14": "几何挑战", "1.4.18": "一般阶猜想"}
    all_rows, leaf_rows, spans, counts = [], [], {}, {}
    assert set(pages) == set(shapes)
    assert set(answers) <= set(pages)
    for (section, number), (start, text_end) in pages.items():
        key = f"{section}.{number}"
        shape = shapes[section, number]
        positions_here = positions.get(key, [])
        end = max([text_end] + [last for _, _, last in positions_here])
        spans.setdefault(section, []).extend((start, end))
        counts[section] = counts.get(section, 0) + 1
        short = answers.get((section, number))
        note = notes.get(key, "")
        detail = ";".join(f"{label}@{p}" + (f"–{q}" if p != q else "") for label, p, q in positions_here)
        all_rows.append([section, number, start, start+12, end, end+12, shape,
                         candidates.get((section,number), ""), "已核题号、原页和小问",
                         detail, short or "", short+12 if short else "", note, star_scope.get((section,number),"")])
        item_labels = leaves(shape)
        if key in extra:
            item_labels.append(extra[key])
        for label in item_labels:
            body = []
            pictures = []
            for source, p, q in positions_here:
                if source.startswith("图"):
                    if not labels(source) or label in labels(source) or label=="整题":
                        pictures.append((p,q))
                    if shape.startswith("图") and label in labels(source):
                        body.append((p,q))
                elif source=="正文" or label in labels(source) or label=="整题":
                    body.append((p,q))
            if not body:
                body = [(start, text_end)]
                # If the continuation contains only a referenced figure, the text itself ends on the first leaf.
                if pictures and text_end>start and all(lo>start for lo,hi in pictures):
                    body = [(start,start)]
            p = min(lo for lo, hi in body)
            q = max(hi for lo, hi in body)
            refs = ",".join(str(lo) if lo==hi else f"{lo}–{hi}" for lo,hi in pictures)
            pdf_refs = ",".join(str(lo+12) if lo==hi else f"{lo+12}–{hi+12}" for lo,hi in pictures)
            leaf_rows.append([section,number,label,p,p+12,q,q+12,refs,pdf_refs,note])
    tsv("exercises.tsv", ["section","number","printed_start","pdf_start","printed_end","pdf_end",
            "subparts_checked","subparts_ocr_candidates_at_printed_page","verification","subpart_locations",
            "selected_answer_printed","selected_answer_pdf","notes","asterisk_scope"],all_rows)
    tsv("subparts.tsv",["section","number","part","printed_start","pdf_start","printed_end","pdf_end",
                        "figure_printed","figure_pdf","notes"],leaf_rows)
    chapter_counts=[sum(n for key,n in counts.items() if key.startswith(f"{c}.")) for c in range(1,10)]
    body=["# 正式习题覆盖","","底本为本目录中 504 页的 Wiley 扫描件。全书 44 节均有独立的节末习题栏，题号每节重新起算。印刷 1–491 页对应 PDF 顺序第 13–503 页，PDF 第 504 页留白。", "",
          f"已按原页逐节登记 {len(all_rows)} 道编号题，各章依次为 "+ "、".join(map(str,chapter_counts))+" 道。全部题的字母、罗马数字、沿用上题的数表及分图小问已核。无字母编号的整题分别列一行。", "",
          f"小问定位表 subparts.tsv 共 {len(leaf_rows)} 行，此数包含无小问的整题、明确分列的分图与矩阵，以及第 1.2.14 题的几何挑战和第 1.4.18 题的附带猜想。第 1.4.34(b) 的三个并列矩阵保留在一个字母小问内。", "",
          f"纸本 474–487 页有 {len(answers)} 个原书选答题号。exercises.tsv 在对应题行列出书末短答的纸本页与 PDF 页，个别题只收部分小问。selected-answers.tsv 另列原书题栏中每个星号标在整题还是哪几个小问之前。整题加星时，书末也可能只选上一题已标出的个别数据。", "",
          "exercises.tsv 的页止包含题干、续文和跨页附图。subparts.tsv 分列小问文字与图的原页。OCR 候选用于返回扫描图；审定清单采用相邻的人工复核列。", "",
          "|节|编号题数|纸本习题页|PDF 顺序页|","|---|---:|---|---|"]
    for section, _, _ in order:
        lo, hi = min(spans[section]), max(spans[section])
        body.append(f"|{section}|{counts[section]}|{lo}–{hi}|{lo+12}–{hi+12}|")
    (here / "正式题组覆盖.md").write_text("\n".join(body)+"\n",encoding="utf-8")
    print(f"{len(all_rows)} numbered exercises; {len(leaf_rows)} leaf records; {len(answers)} original selected answers.")


if __name__ == "__main__":
    import register
    register.main()
