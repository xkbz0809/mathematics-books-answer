from pathlib import Path
import register
base=Path(__file__).resolve().parent
pg=register.checked_pages()
out=['# Each section was checked on scan images or in a corresponding page-by-page review.']
for row in (base/'parts-rules.txt').read_text(encoding='utf8').splitlines():
    if not row.strip() or row.startswith('#'):continue
    key,*tokens=row.split()
    info={int(t.split(':')[0]):t.split(':',1)[1]for t in tokens}
    outrow=[key]
    for n in range(1,max(i for k,i in pg if k==key)+1):
        q=info.get(n,'—')
        if len(q)==1 and q in 'abcdefghijklmnopqrs':q='a–'+q
        outrow.append(f'{n}:{q}')
    out.append(' '.join(outrow))
(base/'visual-parts.txt').write_text('\n'.join(out)+'\n',encoding='utf8')
register.main()
