from pathlib import Path
from PIL import Image,ImageDraw,ImageOps
import re
w=Path('工作稿')
def key(p):
 return [int(x) if x.isdigit() else x for x in re.split(r"(\d+)",p.name)]
files=sorted((w/'figures').glob('*.png'),key=key)
out=w/'inventory'/'figure-audit'
out.mkdir(exist_ok=True)
for base in range(0,len(files),24):
 selected=files[base:base+24]
 sheet=Image.new('RGB',(1020,930),'white')
 draw=ImageDraw.Draw(sheet)
 for idx,fn in enumerate(selected):
  im=Image.open(fn)
  if 'A' in im.getbands():
   layer=Image.new('RGBA',im.size,'white')
   layer.alpha_composite(im.convert('RGBA'))
   im=layer.convert('RGB')
  im.thumbnail((240,124))
  x=(idx%4)*255
  y=(idx//4)*155
  sheet.paste(im,(x+(255-im.width)//2,y))
  draw.text((x+3,y+126),fn.stem,fill='black')
  draw.line((x,y+144,x+254,y+144),fill='#a0a0a0')
 sheet.save(out/f'figs-{(base//24)+1:02}.png')
print(len(files),len(list(out.glob('figs*'))))
