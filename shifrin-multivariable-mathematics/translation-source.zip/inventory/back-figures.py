from pathlib import Path
from PIL import Image
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
base=Path('工作稿')
src=Image.open(base/'inventory/back/p480.png')
src.crop((482,334,744,526)).save(base/'figures/back-456.png')
theta=np.linspace(0,np.pi,91)
phi=np.linspace(0,np.pi,91)
theta,phi=np.meshgrid(theta,phi)
rad=np.sin(theta)
x=rad*np.sin(phi)*np.cos(theta); y=rad*np.sin(phi)*np.sin(theta); z=rad*np.cos(phi)
fig=plt.figure(figsize=(3.9,4.1))
ax=fig.add_subplot(111,projection='3d',proj_type='ortho')
ax.plot_surface(x,y,z,color='#b6c1c7',linewidth=0,shade=True)
ax.plot_wireframe(x,y,z,rcount=13,ccount=17,color='#374953',linewidth=0.36)
ax.plot(x[45,:],y[45,:],z[45,:],color='#222222',lw=1.3)
ax.plot(x[:,45],y[:,45],z[:,45],color='#555555',lw=0.9)
for j, (lo,hi) in enumerate([(-0.72,.73),(-.28,1.20),(-1.14,1.16)]):
    a=np.zeros(3); b=np.zeros(3); a[j]=lo; b[j]=hi
    ax.plot([a[0],b[0]],[a[1],b[1]],[a[2],b[2]],color='#222',lw=0.65)
    ax.text(*(b*1.06),('$x$','$y$','$z$')[j],fontsize=11)
ax.set_xlim(-.74,.75); ax.set_ylim(-.3,1.22); ax.set_zlim(-1.16,1.19)
ax.set_box_aspect((1.49,1.52,2.35)); ax.view_init(elev=17,azim=-57); ax.axis('off')
fig.subplots_adjust(0,0,1,1)
fig.savefig(base/'figures/back-7312.png',dpi=260,bbox_inches='tight',pad_inches=.01,facecolor='white')
