"""Cross-check proof sources against the exercise register, preserving jointly answered cases."""
import csv
import re
import sys
from collections import defaultdict,Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent
W=HERE.parent
sys.path.insert(0,str(W/'tools'))
from exercise_locations import exercise_items,get_rows
from enrich_register import leaves
rows=get_rows()
groups=defaultdict(list)
for row in rows:
    groups[row['section']].append(row)

star_rx=re.compile(r'\\(?:ast\b|star\b)|\\textasteriskcentered|\^(?:\{)?\s*(?:\\[a-z]+\{)?\*|\\textsuperscript\{\$?\s*\*|\\[*]|^\s*\*|主题星号')
def printed_star(s):
    # Multiplication signs, the dual space V^*, Hodge stars and enumitem's alph*
    # are mathematical notation, not the author's mark before a question/part.
    # Discard aligned-environment stars, which carry no problem annotation.
    s=re.sub(r"\\(?:begin|end)\{[a-zA-Z]+\*\}","",s)
    normalized=re.sub(r"\\(?:textsuperscript|textbf|sharp|mathord|mathrm)\b", "", s)
    normalized=re.sub(r"\\ast\b|\\textasteriskcentered\b", "*", normalized)
    if re.search(r"\\item\b[\[\]\(\){}\\\s\d.$^]{0,40}\*",normalized):
        return True
    if re.search(r"[\(（][a-n][\)）][\[\]\(\){}\\\s\d.$^]{0,30}\*",normalized):
        return True
    return bool(re.search(r"\*[\(\){}\\\s\d.$^]{0,20}[\(（][a-n][\)）]",normalized))


alpha_rx=re.compile(r'(?<![a-zA-Z])\(([a-nA-D])\)|（([a-nA-D])）|\\(?:mathrm|textbf)\{[\(（]([a-nA-D])[\)）]\}')
nested_rx=re.compile(r'\\begin\{enumerate\}(.*?)\\end\{enumerate\}', re.S)
def anchor_free(s):
    return re.sub(r'\\(?:hypertarget\{[^{}]*\}\{\}|label\{[^{}]*\}|origpage\{[^{}]*\}\{[^{}]*\})','',s)
def top_bodies(p,count,cache):
    starts=exercise_items(p,count,cache)
    out=[]
    for j,(f,end) in enumerate(starts):
        raw=cache[f]
        a=raw.rfind(r'\item',0,end)
        if j+1<len(starts) and starts[j+1][0]==f:
            z=raw.rfind(r'\item',end,starts[j+1][1])
        else:
            z=len(raw)
        out.append(anchor_free(re.sub(r'(?<!\\)%[^\n]*','',raw[a:z])))
    return out
def labels(s):
    found={next(i for i in g if i) for g in alpha_rx.findall(s)}
    for comma_group in re.findall(r"\(([a-n](?:\s*[,，]\s*[a-n])+?)\)",s):
        found.update(re.findall(r"[a-n]",comma_group))
    for gr in nested_rx.findall(s):
        ms=re.findall(r'\\item\b',gr)
        if ms and len(ms)<=14:
            offset=re.search(r"start=(\d+)",gr[:105])
            start=int(offset[1]) if offset else 1
            found.update(chr(96+start+i) for i in range(len(ms)))
    return found
data=[]; checks=[]; marked_list=[]; summary=[]
for section,qs in groups.items():
    ch,sec=map(int,section.split('.')); cache={}
    for kind in 'ts':
        p=W/'tex'/f'{kind}{ch:02d}-{sec:02d}.tex'
        if not p.exists():
            summary.append((section,kind,len(qs),0,0,0,'源稿尚未就位'))
            continue
        try:
            bodies=top_bodies(p,len(qs),cache)
        except (ValueError,FileNotFoundError) as e:
            summary.append((section,kind,len(qs),0,0,0,str(e)))
            continue
        nleaves=0; unseen=0
        origins=exercise_items(p,len(qs),cache)
        for row,s,(source,offset) in zip(qs,bodies,origins):
            source_line=cache[source].count("\n",0,offset)+1
            n=int(row['number']);sh=row['subparts_checked']; leafs=leaves(sh)
            if (section,n) in [('1.2',14),('1.4',18)]:leafs+=['附带任务']
            found=labels(s)
            # These explicitly reuse a preceding data table or labeled figure.
            if kind=='t' and (sh.startswith('沿用') or sh.startswith('图')):
                found.update(v.split('.')[0] for v in leafs)
            if sh=='矩阵A–D':
                matrix_slots = re.findall(r'\b([A-D])\s*&?=|\$([A-D])\$',s)
                found.update(left or right for left,right in matrix_slots)
            actual={re.split(r'\.',v)[0] for v in leafs if re.match(r'^[a-nA-D]\b',v)}
            if kind=='t':
                star=printed_star(s)
                marked_list.append((section,n,star,row['selected_answer_printed']!='',source.name,source_line))
            for leaf in leafs:
                alpha=re.split(r'\.',leaf)[0]
                if leaf=='整题':state='有对应整题'
                elif leaf=='附带任务':state='另核附带任务'
                elif alpha in found:state='文字或枚举可定位'
                else:state='须与合并叙述对照'
                nleaves+=1
                if state=='须与合并叙述对照':unseen+=1
                data.append((section,n,leaf,kind,state,source.name,source_line))
            missing=actual-found
            if missing:
                checks.append((section,n,kind,sh,','.join(sorted(missing)),s[:200]))
        summary.append((section,kind,len(qs),len(bodies),nleaves,unseen,'已按顶层题号核对'))
def save(name,head,rows):
    with (HERE/name).open('w',encoding='utf-8-sig',newline='') as out:
        wr=csv.writer(out,delimiter='\t',lineterminator='\n');wr.writerow(head);wr.writerows(rows)
save('draft-coverage-by-section.tsv',['section','book','expected_questions','source_questions','leaves','without_individual_marker','verification'],summary)
save('draft-leaf-check.tsv',['section','exercise','leaf','book','marker','tex_source','question_line'],data)
save('draft-grouped-answers.tsv',['section','exercise','book','parts','missing_surface_markers','context'],checks)
save('draft-star-check.tsv',['section','exercise','star_detected_in_draft','author_short_answer','tex_source','question_line'],marked_list)
for k in 'ts':
    sub=[z for z in summary if z[1]==k and z[3]]
    print(k,len(sub),sum(r[3] for r in sub),sum(r[4] for r in sub),sum(r[5] for r in sub))
print('selected-no-star',[f'{sec}.{n}' for sec,n,v,sa,source,line in marked_list if sa and not v])
print('star-without-selected',[f'{sec}.{n}' for sec,n,v,sa,source,line in marked_list if not sa and v])
