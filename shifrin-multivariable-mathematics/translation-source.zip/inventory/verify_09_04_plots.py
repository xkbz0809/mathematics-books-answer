from pathlib import Path
import sys
import re, json
import numpy as np
import pymupdf
from matplotlib.axes import Axes
from mpl_toolkits.mplot3d.axes3d import Axes3D
w=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(w/'tools'))
import draw_09_04 as plots
W=w/'inventory'/'figure-audit'
W.mkdir(exist_ok=True)
plots.OUT=W
systems=[
 ([[0,3],[3,-8]],[0,0],9),
 ([[3,-1],[-1,3]],[0,0],4),
 ([[16,12],[12,9]],[-3,4],5),
 ([[10,3],[3,2]],[0,0],11),
 ([[7,6],[6,-2]],[-2,4],6),
 ([[3,1,1],[1,0,2],[1,2,0]],[0,0,0],4),
 ([[4,-1,-1],[-1,3,2],[-1,2,3]],[0,0,0],6),
 ([[-1,-2,-5],[-2,2,2],[-5,2,-1]],[0,0,0],6),
 ([[2,1,1],[1,0,1],[1,1,0]],[-1,1,1],1),
 ([[3,2,4],[2,0,2],[4,2,3]],[0,0,0],8),
 ([[3,0,1],[0,-1,0],[1,0,3]],[0,2,0],0)]
rec=[]
def residual(pos,id,part):
 A,l,rhs=systems[id]
 pos=np.asarray(pos).reshape(-1,len(l))
 diff=(pos*np.matmul(pos,np.asarray(A))).sum(1)+pos@l-rhs
 return {'id':id,'piece':part,'points':len(pos),'max_abs':float(np.abs(diff).max())}
native_contour=Axes.contour
native_surface=Axes3D.plot_surface
con=0;surfaces={}
def contour(self,*args,**kwargs):
 global con
 output=native_contour(self,*args,**kwargs)
 for j,curve in enumerate(output.allsegs[0]): rec.append(residual(curve,con,j))
 con+=1
 return output
def surface(self,x,y,z,*args,**kwargs):
 id=surfaces.setdefault(self,len(surfaces))
 rec.append(residual(np.stack((x,y,z),axis=-1),5+id,len([p for p in rec if p['id']==5+id])))
 return native_surface(self,x,y,z,*args,**kwargs)
Axes.contour=contour
Axes3D.plot_surface=surface
plots.conics();plots.quadrics()
assert {x['id'] for x in rec}==set(range(11))
for i in range(11):
 pieces=[r for r in rec if r['id']==i]
 print(i, sum(x['points'] for x in pieces),len(pieces),max(x['max_abs'] for x in pieces))
 assert max(x['max_abs'] for x in pieces)<(0.002 if i<5 else 1e-10)
(W/'09-04-plot-residuals.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
for name in ('conics','quadrics'):
 path=w/'figures'/f'sol-09-04-{name}.pdf'
 if path.is_file():
  with pymupdf.open(path) as doc:
   print(name,doc.page_count, doc[0].rect, len(doc[0].get_drawings()))
   doc[0].get_pixmap(matrix=pymupdf.Matrix(1.7,1.7),alpha=False).save(W/f'09-04-{name}-actual.png')
