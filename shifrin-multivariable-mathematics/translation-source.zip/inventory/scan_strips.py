"""Create working visual strips for checking the numeral and subpart columns."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import pymupdf
import register
import sys

out=Path(__file__).resolve().parent / "strips"
out.mkdir(exist_ok=True)
doc=pymupdf.open(next(register.WORK.parent.glob("*.pdf")))
ocr=register.get_lines()
heads=register.get_headings(ocr)
for i,(key,p0,title) in enumerate(register.ORDER):
    if len(sys.argv)>1 and key.split(".")[0] not in sys.argv[1:]:
        continue
    nextkey, nextstart, _=(register.ORDER+[("end",467,"")])[i+1]
    end=nextstart-int(nextkey.endswith(".1") or nextkey=="end")
    start=heads[key][0] if key in heads else max(p0,end-8)
    for i0 in range(start,end+1,7):
        ps=list(range(i0,min(end+1,i0+7)))
        path=out/f"{key}-{ps[0]}-{ps[-1]}.png"
        if path.exists():continue
        w,h=226,905
        contact=Image.new("RGB",(w*len(ps),h),"white")
        dr=ImageDraw.Draw(contact)
        for j,num in enumerate(ps):
            page=doc[num+11]
            xi=20 if num%2 else 42
            rect=pymupdf.Rect(xi,47,xi+148,636)
            pix=page.get_pixmap(matrix=pymupdf.Matrix(1.49,1.49),clip=rect,colorspace=pymupdf.csGRAY)
            contact.paste(Image.frombytes("L",(pix.width,pix.height),pix.samples), (w*j,22))
            dr.text((w*j+4,3),f"{key}   print {num}   PDF {num+12}",fill="black")
            dr.line([(w*j,20),(w*j,h-1)],fill="red")
        contact.save(path)
