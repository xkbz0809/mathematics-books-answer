"""Rebuild the exercise and section registers from the original scan's OCR lines.

The editable visual checks below take priority over the navigational OCR.
"""
import bisect
import csv
import json
import re
from difflib import SequenceMatcher
from statistics import median
from itertools import groupby
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
SECTIONS = [
    [(1, "Vectors in R^n"), (8, "Dot Product"), (16, "Subspaces of R^n"), (23, "Linear Transformations and Matrix Algebra"), (43, "Introduction to Determinants and the Cross Product")],
    [(53, "Scalar- and Vector-Valued Functions"), (64, "A Bit of Topology in R^n"), (72, "Limits and Continuity")],
    [(81, "Partial Derivatives and Directional Derivatives"), (87, "Differentiability"), (97, "Differentiation Rules"), (104, "The Gradient"), (109, "Curves"), (120, "Higher-Order Partial Derivatives")],
    [(127, "Gaussian Elimination and the Theory of Linear Systems"), (147, "Elementary Matrices and Calculating Inverse Matrices"), (156, "Linear Independence, Basis, and Dimension"), (171, "The Four Fundamental Subspaces"), (186, "The Nonlinear Case: Introduction to Manifolds")],
    [(196, "Compactness and the Maximum Value Theorem"), (202, "Maximum/Minimum Problems"), (208, "Quadratic Forms and the Second Derivative Test"), (216, "Lagrange Multipliers"), (225, "Projections, Least Squares, and Inner Product Spaces")],
    [(244, "The Contraction Mapping Principle"), (251, "The Inverse and Implicit Function Theorems"), (261, "Manifolds Revisited")],
    [(267, "Multiple Integrals"), (276, "Iterated Integrals and Fubini’s Theorem"), (288, "Polar, Cylindrical, and Spherical Coordinates"), (298, "Physical Applications"), (309, "Determinants and n-Dimensional Volume"), (324, "Change of Variables Theorem")],
    [(333, "Motivation"), (335, "Differential Forms"), (348, "Line Integrals and Green’s Theorem"), (367, "Surface Integrals and Flux"), (379, "Stokes’s Theorem"), (393, "Applications to Physics"), (403, "Applications to Topology")],
    [(413, "Linear Transformations and Change of Basis"), (422, "Eigenvalues, Eigenvectors, and Diagonalizability"), (436, "Difference Equations and Ordinary Differential Equations"), (455, "The Spectral Theorem")],
]
ORDER = [(f"{c}.{s}", page, title) for c, sections in enumerate(SECTIONS, 1) for s, (page,title) in enumerate(sections, 1)]
EDGES = [x[1] for x in ORDER]
def tsv(name, cols, data):
    path = HERE / name
    with path.with_suffix(".new").open("w", encoding="utf-8-sig", newline="") as out:
        w = csv.writer(out,delimiter="\t",lineterminator="\n")
        w.writerow(cols)
        w.writerows(data)
    path.with_suffix(".new").replace(path)

def get_lines():
    return {int(p.stem[1:]) - 12: sorted(json.loads(p.read_text(encoding="utf-8")), key=lambda t: (t[1], t[0]))
            for p in (WORK/"ocr-layout").glob("p*.json") if int(p.stem[1:]) in range(13,479)}

def get_headings(lines):
    hd = {}
    for p, arr in lines.items():
        for x,y,x1,y1,s in arr:
            if x>130 or not re.search(r"EXERCISES\b|EXERCI5ES\b", s):
                continue
            # Captions are upper case; citations in prose are mixed case.
            key = ORDER[bisect.bisect_right(EDGES,p)-1][0]
            exp = re.search(r"EXERCISES\s+(\d)[.,\s]+(\d)\b",s)
            if exp:
                candidate=f"{exp[1]}.{exp[2]}"
                # An OCR confusion in a label must not move the exercise group.
                if any(candidate==k and abs(p-st)<35 for k,st,_ in ORDER) and abs(EDGES.index(next(st for k,st,t in ORDER if k==candidate))-(bisect.bisect_right(EDGES,p)-1))<=1:
                    key=candidate
            hd[key]=(p,round(y,1))
    return hd

def write_sections(headings):
    tsv("sections.tsv",["section","title_en","printed_start","pdf_start","next_title_printed","next_title_pdf","exercise_title_printed","exercise_title_pdf","basis"],
        [(k,title,p,p+12,(EDGES+[467])[i+1],(EDGES+[467])[i+1]+12,headings.get(k,("",))[0],headings[k][0]+12 if k in headings else "", "目录原件 PDF 5–6；下节可同页起") for i,(k,p,title) in enumerate(ORDER)])

def stop_y(key, title, arr):
    words=re.findall(r"[A-Z]{3,}",title.upper())
    targets=[s for s in words[:4] if s not in {"THE","AND","FOR","AND","THEOREM"}]
    for x,y,x1,y1,s in arr:
        if y<55 or x>138:
            continue
        caps=re.sub(r'[^A-Z]','',s)
        if len(caps)<6 or len(caps)<sum(ch.isalpha() for ch in s)*.85:
            continue
        if any(t in caps or SequenceMatcher(None,t,caps[:len(t)]).ratio()>.85 for t in targets):
            return y-2
    return 650

def group_lines(lines, key, heading):
    ix=next(i for i,s in enumerate(ORDER) if s[0]==key)
    nex=(ORDER+[("end",467,"Glossary")])[ix+1]
    p0, y0=heading
    p1=nex[1]
    if nex[0].endswith(".1") or nex[0]=="end":
        p1-=1
    result=[]
    for p in range(p0,p1+1):
        arr=lines.get(p,[])
        cutoff=stop_y(nex[0],nex[2],arr) if p==nex[1] else 650
        for x,y,x1,y1,s in arr:
            if y>=cutoff or y<51 or p==p0 and y<=y0+3:
                continue
            result.append((p,x,y,x1,y1,s))
    return result

CAND=re.compile(r"""^\s*[^A-Za-z0-9(\[]{0,5}(\d{1,2})[.,:;°](?=\s|[A-Za-z(*'"\[]|$)""")
PART=re.compile(r"(?<![A-Za-z0-9])(?:[\*#]\s*)?\(([a-t])\)")
def candidates(entries):
    result=[]
    for ix,(p,x,y,x1,y1,s) in enumerate(entries):
        m=CAND.match(s)
        if not m or not (73 if p%2 else 97)<=x<=(128 if p%2 else 155):
            continue
        num=int(m[1])
        if num<1 or num>55: continue
        result.append((ix,p,round(y,1),num,s[:60]))
    return result

def increasing(cand):
    # Start with a contiguous increase where possible; later inspect every gap.
    paths=[]
    for i,t in enumerate(cand):
        num=t[3]
        options=[(score + (5 if num-old==1 else 1) - .12*(num-old), seq+[i]) for old,score,seq in paths if old<num and num-old<=10]
        options.append((6 if num==1 else -num,[i]))
        score,seq=max(options,key=lambda k:k[0])
        paths.append((num,score,seq))
    if not paths:return []
    _,_,seq=max(paths,key=lambda t:t[1])
    return [cand[i] for i in seq]

def part_candidates(entries,start,end):
    labels={}
    for p,x,y,x1,y1,s in entries[start:end]:
        for m in PART.finditer(s):
            # A reference within a sentence does not open a subpart.
            if m.start()>0 and any(a.isalpha() for a in s[:m.start()]) and not re.match(r"^[^A-Za-z]{0,7}\(?[a-t]\)",s.lstrip()):
                continue
            letter=m.group(1)
            labels.setdefault(letter,[]).append(p)
    return labels

def provisional(lines, headings):
    data=[]
    debug={}
    for key,p,title in ORDER:
        if key not in headings:continue
        entries=group_lines(lines,key,headings[key]); cand=candidates(entries); picked=increasing(cand)
        debug[key]={"cand":cand,"pick":picked}
        for j,(idx,start,y,n,s) in enumerate(picked):
            endidx=picked[j+1][0] if j+1<len(picked) else len(entries)
            lab=part_candidates(entries,idx,endidx)
            subs=",".join(f"{a}@{','.join(map(str,dict.fromkeys(v)))}" for a,v in sorted(lab.items()))
            data.append([key,n,start,start+12,"","",subs,"OCR 原页定位；小问与跨页待复核"])
    (HERE/"ocr-candidates.json").write_text(json.dumps(debug,ensure_ascii=False),encoding="utf-8")
    return {(k,n):parts for k,n,_,_,_,_,parts,_ in data}

def checked_pages():
    result={}
    for row in (HERE/"visual-pages.txt").read_text(encoding="utf-8-sig").splitlines():
        if not row or row.startswith("#"): continue
        key,*items=row.split();prev=0
        for item in items:
            p,n=item.split(":");cont=p.endswith("+");p=int(p.rstrip("+"));n=int(n)
            if cont: result[key,prev][1]=p
            for no in range(prev+1,n+1):
                result[key,no]=[p,p]
            prev=n
    return result

def checked_parts():
    parts={}
    file=HERE/"visual-parts.txt"
    if file.exists():
        for row in file.read_text(encoding="utf-8-sig").splitlines():
            if not row or row.startswith("#"):continue
            key,*tokens=row.split()
            for item in tokens:
                n,ref=item.split(":")
                parts[key,int(n)]=ref
    return parts

def write_checked(lines, headings):
    from enrich_register import detailed_register
    pages = checked_pages()
    groups = {section: pages[section, 1][0] for section, _, _ in ORDER}
    write_sections({section: (page, 0.0) for section, page in groups.items()})
    detailed_register(HERE, WORK, ORDER, tsv, pages, checked_parts(), provisional(lines, headings))


def main():
    lines=get_lines()
    headings=get_headings(lines)
    write_checked(lines,headings)
if __name__=="__main__":
    main()
