# Shifrin《多变量数学》（2005 年版）习题解答

使用 TeX Live，在本目录连续运行三遍 xelatex shifrin-solutions.tex。
