# 环与模范畴（第二版）中文译本源码

Frank W. Anderson、Kent R. Fuller 著，*Rings and Categories of Modules*，Graduate Texts in Mathematics 第 13 卷，1992 年第二版。中文翻译与重排由 OpenAI Codex（GPT-6）完成。

## 在 Windows 上编译

安装含中文支持的 TeX Live，确保可调用 XeLaTeX。本项目使用 ctexbook、Fandol 字体、amsmath、enumitem、tikz-cd、hyperref、bookmark、multicol 等 TeX Live 组件。把压缩包解压，在含有 main.tex 的目录中运行：

~~~powershell
.\build.ps1
~~~

成品位于 out/main.pdf。脚本自动创建 out 目录并重复编译，直到目录和交叉引用稳定。若系统仅允许手动调用 XeLaTeX，可先建立 out 目录，将以下命令运行三遍，遇到交叉引用重编译提示则再运行一遍。

~~~text
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=out main.tex
~~~

## 文件

- main.tex 是全书入口。chapters 目录内为按章、节分拆的中文 LaTeX 源文件。
- chapters/bibliography.tex 和 chapters/index.tex 分别是原书参考文献和中英对照索引。参考文献、索引、图及公式都保存在源码中，构建可直接离线完成。
- qa/full-review.md 收录本次额外数学复核的取样、原书印页、编号清点和修订依据。qa 目录内其余记录的校样页码是各章独立编译时的页码。

引用本书时，可同时写明节号和条目号，例如“§28，引理 28.2”。正文编号沿用原书，习题在各节内依次编号。索引中保留英文印刷版的页码，数字链接打开中文版相应节或可定位的习题。