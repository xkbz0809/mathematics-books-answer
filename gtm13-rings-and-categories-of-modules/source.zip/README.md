# 《环与模范畴》第二版课后习题解答

中文题干与中文解答按节保存在 chapters/sec01.tex 至 chapters/sec32.tex，每个文件中先排相应的题目，再排解答。全书 8 章、32 节，共 468 道主编号习题。正文交叉引用沿用原著编号。

解压后在本目录运行 build.ps1。在已安装 XeLaTeX、中文支持、TikZ 及所需宏包的 TeX Live 环境中，亦可将 main.tex 用 XeLaTeX 连续编译三遍。脚本将 PDF 写入 out/main.pdf。main.tex 控制版式，contents.tex 列出章节顺序。编译时无需原书文件。

原书页码是英文印刷页；成品内的跨文件页码链接需要英文原扫描件 GTM13-Rings and Categories of Modules1992.pdf 与解答 PDF 位于同一目录。
