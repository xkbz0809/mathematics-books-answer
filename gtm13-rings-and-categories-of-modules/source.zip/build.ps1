$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath $PSScriptRoot
$previousEpoch = $env:SOURCE_DATE_EPOCH
$previousForce = $env:FORCE_SOURCE_DATE
try {
    $env:SOURCE_DATE_EPOCH = '1795219200'
    $env:FORCE_SOURCE_DATE = '1'
    $outDir = Join-Path $PSScriptRoot 'out'
    [void][IO.Directory]::CreateDirectory($outDir)
    $previous = ''
    for ($pass = 1; $pass -le 5; $pass++) {
        Write-Host "XeLaTeX $pass"
        & xelatex -no-shell-escape -interaction=batchmode -halt-on-error -file-line-error -output-directory=out main.tex
        if ($LASTEXITCODE -ne 0) {
            Get-Content -LiteralPath (Join-Path $outDir 'main.log') -Tail 30
            throw 'XeLaTeX failed.'
        }
        $hashes = foreach ($name in 'main.aux','main.toc') {
            (Get-FileHash -LiteralPath (Join-Path $outDir $name) -Algorithm SHA256).Hash
        }
        $current = $hashes -join ' '
        $log = [IO.File]::ReadAllText((Join-Path $outDir 'main.log'))
        if ($pass -ge 2 -and $current -eq $previous -and $log -notmatch '(?i)undefined references|may have changed|Rerun to get') {
            Write-Host "Built out/main.pdf"
            return
        }
        $previous = $current
    }
    throw 'References did not stabilize after five passes.'
}
finally {
    $env:SOURCE_DATE_EPOCH = $previousEpoch
    $env:FORCE_SOURCE_DATE = $previousForce
    Pop-Location
}