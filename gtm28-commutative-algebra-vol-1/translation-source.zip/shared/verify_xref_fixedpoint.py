"""Export both volumes and record whether their shared label snapshots changed."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent.parent
def hashes():
    return {f'volume{n}.aux':hashlib.sha256((ROOT/f'shared/xrefs/volume{n}.aux').read_bytes()).hexdigest() for n in (1,2)}
before=hashes()
for n in (1,2):
    subprocess.run([sys.executable,str(ROOT/'shared/export_crossrefs.py'),str(n),'--job','main'],check=True)
after=hashes()
record={'before':before,'after':after,'stable':before==after}
(ROOT/'shared/crossref-fixedpoint.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
