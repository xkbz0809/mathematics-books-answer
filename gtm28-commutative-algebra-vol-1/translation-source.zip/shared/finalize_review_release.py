"""Package the reviewed edition only after stable builds and reviewed raster checks."""
from pathlib import Path
from datetime import datetime
import hashlib,json,shutil,zipfile,re
import pymupdf

ROOT=Path(__file__).resolve().parent.parent
REVIEW=ROOT/'qa/review-2026-11-17'
def read(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def groups(text):
    """Read top-level brace groups without flattening nested TeX titles."""
    result=[]; depth=0; start=None
    for j,char in enumerate(text):
        if char=='{' and (j==0 or text[j-1]!='\\'):
            if depth==0:start=j+1
            depth+=1
        elif char=='}' and (j==0 or text[j-1]!='\\'):
            depth-=1
            if depth==0:result.append(text[start:j])
    assert depth==0,text
    return result

items=json.loads((REVIEW/'review-items.json').read_text(encoding='utf-8'))['items']
assert all(i['status']=='corrected' and len(i['confirmation'])>=2 for i in items)
builds={n:read(f'volume{n}/_build/report.json') for n in (1,2)}
links=read('shared/pdf-link-audit.json')
manifest=read('shared/manifest-audit.json')
terms=read('shared/terminology-audit.json')
fixed=read('shared/crossref-fixedpoint.json')
rasters=json.loads((REVIEW/'final-render-comparison.json').read_text(encoding='utf-8'))
audits=json.loads((REVIEW/'audit-inputs.json').read_text(encoding='utf-8'))
assert audits['inputs_stable']
for rel,digest in (audits['inputs']|audits['reports']).items():assert sha(ROOT/rel)==digest,rel
for n,b in builds.items():
    assert b['success'] and b['inputs_stable_during_build']
    assert not b['diagnostics']['overfull']
    for rel,digest in b['input_sha256'].items(): assert sha(ROOT/rel)==digest,rel
    for key in ('broken_links','bookmark_review','missing_label_destinations','equation_tag_presence_review',
                'numbered_object_presence_review','unnumbered_anchor_review','stale_exported_labels',
                'pages_containing_double_question_mark'):
        assert not links[str(n)][key],(n,key)
    assert not read(f'volume{n}/qa/skill-style-audit-main.json')['errors']
    assert not rasters[str(n)]['different_rendered_pages']
    assert rasters[str(n)]['final_sha256']==sha(ROOT/f'volume{n}/main.pdf')
    assert (REVIEW/f'layout-v{n}.md').is_file()
    reviewed_hash=sha(REVIEW/f'reviewed-v{n}.pdf')
    assert rasters[str(n)]['snapshot_sha256']==reviewed_hash
    assert reviewed_hash in (REVIEW/f'layout-v{n}.md').read_text(encoding='utf-8').lower()
assert fixed['stable']
for name,digest in fixed['after'].items():assert sha(ROOT/'shared/xrefs'/name)==digest
assert not manifest['missing_source_structure_labels']
assert not manifest['duplicate_labels'] and not manifest['unresolved_body_references']
for v in manifest['volumes'].values():
    assert not v['missing_body_source_page_anchors']
    for unit in v['units']:assert not unit['errors'] and not unit['repeated_page_anchors']
for key in ('conflicting_english','duplicate_keys_within_volume','not_yet_in_master'): assert not terms[key]

dest=ROOT/'delivery';dest.mkdir(exist_ok=True)
names={1:'GTM28-commutative-algebra-I-zh.pdf',2:'GTM29-commutative-algebra-II-zh.pdf'}
sources={1:'GTM-28 Commutative Algebra Volume I.pdf',2:'GTM-29 Commutative Algebra Volume II.pdf'}
source_hashes={1:'6ca72dd956dd301ff72c74606413ecf98ef5cf71237754102972df9bcfbd498d',
               2:'9e9664e88744f5dec853da174d32d4d161b7b08a43548d13820eaa47909243ce'}
pdfs=[]
for n in (1,2):
    assert sha(ROOT/sources[n])==source_hashes[n],('Original scan changed',n)
    shutil.copy2(ROOT/f'volume{n}/main.pdf',dest/names[n])
    with pymupdf.open(ROOT/sources[n]) as d: original_pages=len(d)
    pdfs.append({'volume':n,'filename':names[n],'pages':links[str(n)]['pages'],
                 'bytes':(dest/names[n]).stat().st_size,'sha256':sha(dest/names[n]),
                 'source_filename':sources[n],'source_pages':original_pages,'source_sha256':sha(ROOT/sources[n])})

counts={key:sum(i['category']==key for i in items) for key in ('translation_error','terminology_consistency','source_correction')}
for i in items:
    roman='I' if i['volume']==1 else 'II'
    aux=(ROOT/f'volume{i["volume"]}/main.aux').read_text(encoding='utf-8')
    prefix=r'\newlabel{src:'+roman+':'+str(i['source_page'])+'}'
    line=next(line for line in aux.splitlines() if line.startswith(prefix))
    fields=groups(groups(line[len(prefix):])[0])
    assert len(fields)>=4,i
    with pymupdf.open(dest/names[i['volume']]) as d:
        target=d.resolve_names()[fields[3]]
    i['translated_printed_page_near_source_anchor']=fields[1]
    i['pdf_page_near_source_anchor']=target['page']+1

baseline=json.loads((REVIEW/'baseline-manifest.json').read_text(encoding='utf-8'))
changed=[{'file':rel,'before_sha256':digest,'after_sha256':sha(ROOT/rel)} for rel,digest in baseline.items() if sha(ROOT/rel)!=digest]
declared_files={i['file'] for i in items}
declared_files.update(path for i in items for path in i.get('additional_files',[]))
assert {c['file'] for c in changed}<=declared_files,'Undocumented content change'
summary={'date':datetime.now().astimezone().isoformat(),'counts':counts,'items':items,'changed_tex':changed,
         'counting_rule':'Count independent issues; repeated occurrences of the same issue count once. Existing corrections before baseline excluded.'}
(REVIEW/'final-review-manifest.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

lines=['# GTM28、GTM29 本轮复核与修订报告','',
       '日期：2026-11-17。对照基线为本轮开始时冻结的上一版两个PDF及181个TeX文件；原文件及其哈希保存在 `qa/review-2026-11-17/baseline/`。','',
       f'本轮确认上一版新引入的实质数学误译 **{counts["translation_error"]} 项**；术语一致性问题 **{counts["terminology_consistency"]} 类，共8处**。另对照原书补正 **{counts["source_correction"]} 项**原书遗留问题，并在PDF中明示译注。这些原书问题不计入翻译引入的错误数；部分此前已在TeX注释或QA中提示，但未在成品PDF中充分说明。','',
       '计数按独立问题，不按改动的字符或出现次数；同一问题的三处底环、四处包含关系各计一项。上一交付已经修好的内容不重复计数。','',
       '## 上一版翻译错误与术语修订','',
       '|编号|位置（原书印页）|原问题及修正|确认依据|','|---|---|---|---|']
for i in items:
    if i['category']=='source_correction':continue
    lines.append(f'|{i["id"]}|第{i["volume"]}卷，第{i["source_page"]}页，{i["location"]}|{i["correction"]}|{i["evidence"]}|')
lines+=['','## 原书遗留问题的明示补正','','|编号|位置（原书印页）|修正|核验依据|','|---|---|---|---|']
for i in items:
    if i['category']!='source_correction':continue
    citations=' '.join(f'[参考资料{j+1}]({url})' for j,url in enumerate(i.get('evidence_urls',[])))
    lines.append(f'|{i["id"]}|第{i["volume"]}卷，第{i["source_page"]}页，{i["location"]}|{i["correction"]}|{i["evidence"]} {citations}|')
lines+=['','每项实质修订均有至少两次独立确认：原扫描页核对和相应定义、推导或反例检验。具体确认者、源文件及邻近译页见 `final-review-manifest.json`。来源判定以扫描页为准，OCR只是辅助。','',
        '## 本轮实际覆盖与限制','',
        '- 第一卷 I–III（原1–198）：完整中文重读与逐节英文对照，见 `review-i-iii.md`。',
        '- 第一卷 IV–V（原199–320）及第二卷七附录（原321–407）：完整中文重读与原文对照，见 `review-iv-v-apps.md`。',
        '- 第二卷 VI（原1–128）、VII §1–7（原129–203上半）：完整中文重读与原文对照，见 `review-vi-vii.md`。',
        '- 第二卷 VII §8–13（原203下半–247）：完整中文重读与原文对照，见 `review-vii-8-13.md`。',
        '- 第二卷 VIII（原248–320）：完整中文重读与原文对照，见 `review-viii.md`。',
        '- 本轮覆盖全部727页现存数学正文；疑点重新看原图。并非将727页扫描图另作一次逐页图像复验，也不把AI复核称为独立专家认证。',
        '- 前言、译本说明、读者须知及第一卷符号索引重新阅读；全书结构、术语登记与链接重新审计。原定义索引和丛书目录不另声称本轮每项原图校核。',
        '- 各分项报告仍保留未作定论的原书疑点及轻微原书印误；本报告不是原书全部错误已经清除的证明。缺失的第二卷原408页仍无法由所给扫描确认内容，未自行补造。','',
        '## 构建与成品核验','',
        f'- 修订PDF页数：第一卷 {links["1"]["pages"]} 页；第二卷 {links["2"]["pages"]} 页。',
        '- 两卷执行 XeLaTeX×2 → Biber → XeLaTeX×2；编译输入哈希稳定，未定义引用、缺字、字体形状错误、重复标签、Overfull均为0。',
        f'- Underfull计数为 {builds[1]["diagnostics"]["underfull"]} / {builds[2]["diagnostics"]["underfull"]}；结合新修改页的实际版面检查判定，没有内容越界或缺失。',
        '- 共享引用反复导出及重编达到固定点；卷内、跨卷目标、书签、式号、编号对象和无编号标题的实际目的地检查均通过。',
        '- 146个预期章/节/附录结构标签齐全；源页锚点无缺失；统一术语登记没有冲突、重复键或遗漏主表词项。',
        '- 两卷本轮变化页实际总览，新译注、公式及重要变化页另作高清查看。各自范围见 `layout-v1.md`、`layout-v2.md`。最终交付与已查看快照逐页72dpi像素比较一致。',
        '- MathTranslations样式审计0错误；保留的3类通用提示与项目安排一致：书目仍在原正文/脚注中，Windows使用Python构建脚本。','',
        '## 文件','',
        '两个成品PDF请放在同一目录，以保留跨卷链接。源包含两卷独立工程、共享术语与交叉引用、构建脚本、旧制作记录及本轮复核记录。原始扫描文件未修改。旧交付已在本地冻结备份。','']
report='\n'.join(lines)
(ROOT/'REVIEW-REPORT.md').write_text(report,encoding='utf-8')
(ROOT/'QA-REPORT.md').write_text(report,encoding='utf-8')
(ROOT/'STATUS.md').write_text(f'# 复核修订完成\n\n2026-11-17：两卷复核修订、编译、交叉引用固定点与PDF版面检查已完成。\n\n第一卷{links["1"]["pages"]}页；第二卷{links["2"]["pages"]}页。错误分类及实际覆盖见REVIEW-REPORT.md。\n',encoding='utf-8')
for name in ('QA-REPORT.md','REVIEW-REPORT.md'):shutil.copy2(ROOT/name,dest/name)

paths=set()
for name in ('README.md','STATUS.md','ISSUES.md','QA-REPORT.md','REVIEW-REPORT.md'):paths.add(ROOT/name)
for n in (1,2):
    v=ROOT/f'volume{n}'
    for name in ('main.tex','mathtranslation.cls'):paths.add(v/name)
    for sub in ('chapters','appendices','frontmatter','backmatter','graphics'):
        paths.update(p for p in (v/sub).rglob('*') if p.is_file() and p.suffix in ('.tex','.tsv','.pdf','.png','.jpg','.sty','.bib'))
    paths.add(v/'_build/report.json')
    paths.update(p for p in (v/'qa').glob('*') if p.is_file() and p.suffix in ('.md','.json'))
paths.update(p for p in (ROOT/'qa').glob('*') if p.is_file() and p.suffix in ('.md','.json'))
paths.update(p for p in REVIEW.glob('*') if p.is_file() and p.suffix in ('.md','.json'))
paths.update(p for p in (REVIEW/'evidence').glob('*') if p.is_file() and p.suffix=='.png')
for rel in ('shared/zs-common.tex','shared/glossary.tsv','shared/export_crossrefs.py','shared/prepare_release_build.py',
            'shared/audit_manifests.py','shared/audit_terminology.py','shared/audit_included_style.py','shared/audit_pdf_links.py',
            'shared/manifest-audit.json','shared/terminology-audit.json','shared/pdf-link-audit.json','shared/unnumbered-anchor-audit.json',
            'shared/crossref-fixedpoint.json','shared/translator-notes.json',
            'shared/template/README.md','shared/template/book/mathtranslation.cls','shared/template/book/graphics/logo.pdf',
            'shared/toolchain/build.py','shared/toolchain/build.sh','shared/finalize_review_release.py',
            'shared/verify_review_render.py','shared/verify_xref_fixedpoint.py','shared/run_review_audits.py',
            'shared/render_changed_pages.py','shared/collect_translator_notes.py'):
    paths.add(ROOT/rel)
paths.update((ROOT/'shared/xrefs').glob('*.aux'))
paths.update(p for p in (ROOT/'shared/inventory').glob('*') if p.suffix in ('.json','.tsv','.md'))
archive=dest/'GTM28-29-Chinese-LaTeX-sources.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(paths):
        assert path.is_file(),path
        z.write(path,path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z: assert z.testzip() is None
record={'created':datetime.now().astimezone().isoformat(),'edition':'2026-11-17 reviewed revision','pdfs':pdfs,
        'review_counts':counts,'source_archive':{'filename':archive.name,'files':len(paths),'bytes':archive.stat().st_size,'sha256':sha(archive)},
        'qa_report':{'filename':'QA-REPORT.md','sha256':sha(dest/'QA-REPORT.md')},
        'review_report':{'filename':'REVIEW-REPORT.md','sha256':sha(dest/'REVIEW-REPORT.md')},
        'validation':{'crossrefs_fixed_point':True,'stable_build_inputs':True,'all_final_pages_match_reviewed_snapshot':True,
                      'missing_source_page':'Volume II, printed 408; absent from supplied scan'},'build_reports':{str(n):builds[n] for n in (1,2)}}
(dest/'delivery-manifest.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'counts':counts,'pdfs':pdfs,'archive_files':len(paths),'changed_tex_files':len(changed)},ensure_ascii=False,indent=2))
