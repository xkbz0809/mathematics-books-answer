"""Validate final PDF destinations, source-page anchors, and equation tag presence.

The tag check is a presence test on the destination page, not mathematical proof
that the tag is beside its intended formula. Heading checks use page geometry.
"""
from pathlib import Path
import argparse, json, re
from collections import Counter
import pymupdf

p=argparse.ArgumentParser()
p.add_argument('--job1',default='main')
p.add_argument('--job2',default='main')
a=p.parse_args()
ROOT=Path(__file__).resolve().parent.parent
jobs={1:a.job1,2:a.job2}
docs={n:pymupdf.open(ROOT/f'volume{n}/{job}.pdf') for n,job in jobs.items()}
names={n:d.resolve_names() for n,d in docs.items()}
repaired=json.loads((ROOT/'shared/unnumbered-anchor-audit.json').read_text(encoding='utf-8'))
files={'GTM28-commutative-algebra-I-zh.pdf':1,'GTM29-commutative-algebra-II-zh.pdf':2,
       'volume1/working.pdf':1,'volume2/working.pdf':2,'../volume1/working.pdf':1,'../volume2/working.pdf':2}

def group(s,pos):
    while pos<len(s) and s[pos].isspace():pos+=1
    if pos>=len(s) or s[pos]!='{': return None,pos
    start=pos+1; depth=1; pos+=1
    while pos<len(s):
        if s[pos]=='\\':pos+=2;continue
        if s[pos]=='{':depth+=1
        if s[pos]=='}':
            depth-=1
            if depth==0:return s[start:pos],pos+1
        pos+=1
    return None,pos

def auxlabels(path):
    out={}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.startswith(r'\newlabel'):continue
        label,pos=group(line,len(r'\newlabel'))
        values,pos=group(line,pos)
        fields=[];pos=0
        while values and pos<len(values):
            value,pos=group(values,pos)
            if value is None:break
            fields.append(value)
        if len(fields)>=4:out[label]=fields
    return out

def norm(s):
    return re.sub(r'\s+','',s).replace('−','-').replace('′',"'").replace('’',"'").replace('″',"''").replace('”',"''").replace('_','')

result={}
for n,d in docs.items():
    bad=[]; kinds=Counter(); external=Counter();texts=[p.get_text() for p in d]
    for index,page in enumerate(d):
        for link in page.get_links():
            kinds[str(link['kind'])]+=1
            if 'nameddest' in link and link['kind']==4:
                if link['nameddest'] not in names[n]:bad.append({'page':index+1,'missing_dest':link['nameddest']})
            if link.get('file'):
                filename,sep,dest=link['file'].partition('#nameddest=')
                external[filename]+=1
                other=files.get(filename)
                if other is None:bad.append({'page':index+1,'unknown_file':filename})
                elif not sep or dest not in names[other]:bad.append({'page':index+1,'external_missing':link['file']})
    headings=[]
    for level,title,number,info in d.get_toc(False):
        dest=names[n].get(info.get('nameddest'))
        if dest is None:
            headings.append({'title':title,'problem':'missing named destination'});continue
        page=d[dest['page']];y=page.rect.height-dest['to'][1]
        blocks=page.get_text('blocks')
        candidates=[b for b in blocks if norm(title) in norm(b[4])]
        if not candidates:
            # Appendix titles deliberately span two separate text blocks.
            for i,b in enumerate(blocks[:-1]):
                if norm(title) in norm(b[4]+blocks[i+1][4]):candidates.append(b)
        if not candidates:
            headings.append({'title':title,'page':dest['page']+1,'problem':'title not located by normalized exact text'});continue
        chosen=min(candidates,key=lambda b:abs(b[1]-y))
        gap=chosen[1]-y
        if gap < -6 or gap > 110:
            headings.append({'title':title,'page':dest['page']+1,'heading_y':chosen[1],'dest_y':y,'gap':gap})
    labels=auxlabels(ROOT/f'volume{n}/{jobs[n]}.aux')
    exported=auxlabels(ROOT/f'shared/xrefs/volume{n}.aux')
    stale_export=[label for label,fields in exported.items() if labels.get(label)!=fields]
    unnumbered_review=[]; unnumbered_count=0; seen_unnumbered={}
    env_titles={'zslemma*':'引理','zscorollary*':'推论','zstheorem*':'定理','zsproposition*':'命题',
                'zsunnumberedlemma':'引理','zsunnumberedcorollary':'推论',
                'zsdefinition':'定义','zsremark':'注','zsexample':'例'}
    for entry in repaired:
        if not entry['file'].startswith(f'volume{n}/'):continue
        unnumbered_count+=1
        label=entry['label']; fields=labels.get(label)
        if not fields:
            unnumbered_review.append({'label':label,'problem':'missing aux label'});continue
        dest=names[n].get(fields[3])
        if not dest or not fields[3].startswith('section*.'):
            unnumbered_review.append({'label':label,'problem':'not an independent phantomsection','dest':fields[3]});continue
        if fields[3] in seen_unnumbered:
            unnumbered_review.append({'label':label,'problem':'shared destination','other':seen_unnumbered[fields[3]]})
        seen_unnumbered[fields[3]]=label
        page=d[dest['page']]; y=page.rect.height-dest['to'][1]
        cn=env_titles[entry['environment']]
        lines=[line for block in page.get_text('dict')['blocks'] if 'lines' in block for line in block['lines']]
        nearby=[line for line in lines if abs(line['bbox'][1]-y)<=18 and
                norm(''.join(span['text'] for span in line['spans'])).startswith(cn)]
        if not nearby:
            unnumbered_review.append({'label':label,'problem':'heading not near destination','title':cn,'page':dest['page']+1,'y':y})
        if fields[1] != page.get_label():
            unnumbered_review.append({'label':label,'problem':'aux page disagrees with destination','aux_page':fields[1],'pdf_page':dest['page']+1,'page_label':page.get_label()})
    label_bad=[];equation_missing=[];equation_count=0;source=[];object_missing=[];object_count=0
    object_types={'zstheorembase.':'定理','zslemmabase.':'引理','zscorollarybase.':'推论',
                  'zspropositionbase.':'命题','zsdefinitionbase.':'定义','zsremarkbase.':'注','zsexamplebase.':'例','zspropertybase.':'性质'}
    for label,fields in labels.items():
        dest=names[n].get(fields[3])
        if dest is None:
            label_bad.append({'label':label,'dest':fields[3]});continue
        if label.startswith('src:'):source.append(label)
        for prefix,cn in object_types.items():
            if fields[3].startswith(prefix):
                object_count+=1
                value=fields[0].replace(r'\prime',"'").replace('^','').replace('{','').replace('}','').replace('$','')
                if cn+norm(value) not in norm(texts[dest['page']]):
                    object_missing.append({'label':label,'expected':cn+value,'page':dest['page']+1})
        if label.startswith('eq:'):
            equation_count+=1
            tag=fields[0].strip('{}')
            tag=tag.replace(r'\prime',"'").replace(r'\text', '').replace('$','').replace('^','').replace('{','').replace('}','')
            if '('+norm(tag)+')' not in norm(texts[dest['page']]):
                equation_missing.append({'label':label,'tag':tag,'page':dest['page']+1})
    result[str(n)]={'pdf':str(ROOT/f'volume{n}/{jobs[n]}.pdf'),'pages':len(d),'bookmarks':len(d.get_toc()),
                    'destinations':len(names[n]),'local_labels':len(labels),'source_page_labels':len(source),
                    'link_kinds':dict(kinds),'external_link_files':dict(external),'broken_links':bad,
                    'bookmark_review':headings,'missing_label_destinations':label_bad,
                    'equation_labels':equation_count,'equation_tag_presence_review':equation_missing,
                    'numbered_object_labels':object_count,'numbered_object_presence_review':object_missing,
                    'repaired_unnumbered_labels':unnumbered_count,'unnumbered_anchor_review':unnumbered_review,
                    'stale_exported_labels':stale_export,
                    'pages_containing_double_question_mark':[i+1 for i,t in enumerate(texts) if '??' in t]}
out=ROOT/'shared/pdf-link-audit.json'
out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for n,r in result.items():
    print(n,{k:(len(v) if isinstance(v,list) else v) for k,v in r.items() if k not in ('pdf','external_link_files','link_kinds')})
