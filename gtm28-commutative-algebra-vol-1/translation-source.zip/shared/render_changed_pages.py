from pathlib import Path
import argparse,json,math
import pymupdf
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('before',type=Path);p.add_argument('after',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=True)
old=pymupdf.open(a.before);new=pymupdf.open(a.after)
pages=[i+1 for i in range(len(new)) if i>=len(old) or new[i].get_text()!=old[i].get_text()]
(a.out/'changed-pages.json').write_text(json.dumps({'before':str(a.before),'after':str(a.after),'pages':pages},indent=2),encoding='utf-8')
for start in range(0,len(pages),6):
    group=pages[start:start+6];sheet=Image.new('RGB',(900,1920),'#bbbbbb');draw=ImageDraw.Draw(sheet)
    for i,num in enumerate(group):
        pix=new[num-1].get_pixmap(dpi=95);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((430,600))
        x=10+i%2*450;y=28+i//2*640;sheet.paste(im,(x,y));draw.text((x,y-20),f'PDF {num}',fill='black')
    target=a.out/f'sheet-{start//6+1:02}.png';sheet.save(target);print(target)
print('Changed pages',pages)
