"""Prepare a formal main.tex from the current manifests; does not publish PDFs."""
from pathlib import Path
import argparse, shutil

p=argparse.ArgumentParser()
p.add_argument('--volume',type=int,choices=(1,2),required=True)
a=p.parse_args()
r=Path(__file__).resolve().parent.parent
v=r/f'volume{a.volume}'
n=a.volume
roman='I' if n==1 else 'II'
cn='一' if n==1 else '二'
other=2 if n==1 else 1
other_name='GTM29-commutative-algebra-II-zh.pdf' if n==1 else 'GTM28-commutative-algebra-I-zh.pdf'
shutil.copy2(r/'shared/template/book/mathtranslation.cls',v/'mathtranslation.cls')
body=[r'% !TeX program = xelatex',r'\documentclass{mathtranslation}',r'\input{../shared/zs-common.tex}']
if n==2:body.append(r'\renewcommand{\VolumeKey}{II}')
body += [
 r'\renewcommand{\BookTitleCN}{交换代数\\[0.3cm]第'+cn+'卷}',
 r'\renewcommand{\BookTitleEN}{Commutative Algebra, Volume '+roman+'}',
 r'\renewcommand{\OriginalAuthor}{Oscar Zariski \quad Pierre Samuel}',
 r'\renewcommand{\OriginalEdition}{'+('1958 年初版，所据原版列至 1965 年重印' if n==1 else '1960 年初版，Springer 重印本')+'}',
 r'\renewcommand{\OriginalPublisher}{'+('D. Van Nostrand / Springer GTM 28' if n==1 else 'Springer GTM 29')+'}',
 r'\renewcommand{\OriginalYear}{'+('1958' if n==1 else '1960')+'}',
 r'\renewcommand{\Translator}{Codex}',r'\renewcommand{\ModelUsed}{GPT-6}',
 r'\renewcommand{\TranslationDate}{2026-11-17}',
 r'\hypersetup{pdftitle={交换代数第'+cn+'卷（中文译本）},pdfauthor={Oscar Zariski; Pierre Samuel; Chinese translation by Codex}}',
 r'\IfFileExists{../shared/xrefs/volume'+str(other)+'.aux}{'+r'\externaldocument{../shared/xrefs/volume'+str(other)+'}['+other_name+']}{}',
 r'\begin{document}',r'\makecover',r'\frontmatter',r'\input{frontmatter/translation-note.tex}',
 r'\input{frontmatter/original-publication.tex}',r'\input{frontmatter/preface.tex}']
if n==2: body.append(r'\input{frontmatter/instructions.tex}')
body += [r'\makecontents',r'\mainmatter']
for ch in range(1 if n==1 else 6,6 if n==1 else 9):
 path=f'chapters/ch{ch:02}/chapter.tex'
 assert (v/path).is_file(),path
 body += [r'\setcounter{chapter}{'+str(ch-1)+'}',r'\input{'+path+'}']
if n==2:
 body.append(r'\setcounter{chapter}{8}')
 for app in range(1,8):
  path=f'appendices/app{app:02}/appendix.tex'
  assert (v/path).is_file(),path
  body.append(r'\input{'+path+'}')
body.append(r'\backmatter')
for name in ('notation-index','definitions-index','series-list'):
 if (v/f'backmatter/{name}.tex').exists():body.append(r'\input{backmatter/'+name+'.tex}')
body += [r'\printterminology',r'\end{document}']
(v/'main.tex').write_text('\n'.join(body)+'\n',encoding='utf-8')
print('Prepared',v/'main.tex','(not a delivery claim)')
