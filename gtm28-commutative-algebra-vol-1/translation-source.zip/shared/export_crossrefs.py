"""Export only globally distinct source-object labels for independent book builds.

Terminology/frontmatter labels belong to each volume separately and must not leak
into the other volume. A snapshot .aux is shipped with the editable project so a
single volume does not require the other volume's build products to be present.
"""
from pathlib import Path
import argparse,re
p=argparse.ArgumentParser()
p.add_argument('volume',type=int,choices=(1,2))
p.add_argument('--job',default='main')
a=p.parse_args()
root=Path(__file__).resolve().parent.parent
src=root/f'volume{a.volume}'/(a.job+'.aux')
out=root/'shared'/'xrefs'
out.mkdir(exist_ok=True)
prefixes=('ch:','sec:','thm:','lem:','cor:','prop:','def:','eq:','src:','app:','ex:','item:','cond:','fact:','rem:','case:','note:','complement:','axiom:')
lines=[]
for line in src.read_text(encoding='utf-8',errors='strict').splitlines():
    m=re.match(r'\\newlabel\{([^}]+)\}',line)
    if m and m.group(1).startswith(prefixes):
        lines.append(line)
target=out/f'volume{a.volume}.aux'
target.write_text('\\relax\n'+'\n'.join(lines)+'\n',encoding='utf-8')
print(target,len(lines),'labels')
