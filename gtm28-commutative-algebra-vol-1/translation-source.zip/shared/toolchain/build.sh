#!/usr/bin/env bash
set -euo pipefail
# Usage from a book project: bash ../shared/toolchain/build.sh full
# Or: bash build.sh full /absolute/project/path
mode="${1:-full}"
project="${2:-$PWD}"
if [[ "$mode" != "full" ]]; then
  printf 'Only full builds are supported.\n' >&2
  exit 2
fi
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
python "$script_dir/build.py" "$project" --clean
