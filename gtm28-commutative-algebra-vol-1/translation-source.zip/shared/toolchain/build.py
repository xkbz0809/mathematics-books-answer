"""XeLaTeX x2 -> biber -> XeLaTeX x2, with deterministic local diagnostics.

Usage: python build.py PATH_TO_PROJECT [--main main] [--clean]
Only known generated auxiliary files of the selected main job are removed.
"""
from pathlib import Path
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import hashlib

parser = argparse.ArgumentParser()
parser.add_argument('project', type=Path)
parser.add_argument('--main', default='main')
parser.add_argument('--clean', action='store_true')
args = parser.parse_args()
project = args.project.resolve()
stem = args.main
if Path(stem).name != stem or not (project / (stem + '.tex')).is_file():
    parser.error('main must be the stem of a .tex file inside project')
report_dir = project / '_build'
report_dir.mkdir(exist_ok=True)
def input_snapshot():
    paths=[p for p in project.rglob('*') if p.is_file() and p.suffix in ('.tex','.cls','.sty','.bib')
           and not any(part in ('qa','_build') for part in p.relative_to(project).parts)]
    paths+=list((project/'graphics').glob('*'))
    paths+=[project.parent/'shared/zs-common.tex',
            project.parent/f'shared/xrefs/volume{2 if project.name=="volume1" else 1}.aux']
    return {str(p.relative_to(project.parent)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p.is_file()}
inputs_before=input_snapshot()
if args.clean:
    for suffix in ('aux','toc','out','bbl','bcf','blg','run.xml','log','lof','lot','ind','idx','ilg'):
        candidate = project / (stem + '.' + suffix)
        if candidate.exists():
            candidate.unlink()

texbin = Path(r'D:\texlive\2026\bin\windows')
def executable(name):
    path = shutil.which(name)
    if path:
        return path
    fallback = texbin / (name + '.exe')
    if fallback.exists():
        return str(fallback)
    raise FileNotFoundError(name)

xelatex = executable('xelatex')
biber = executable('biber')
env = dict(os.environ)
env['PATH'] = str(Path(xelatex).parent) + os.pathsep + env.get('PATH','')
commands = [
    ('xelatex-1', [xelatex,'-interaction=nonstopmode','-halt-on-error','-file-line-error',stem+'.tex']),
    ('xelatex-2', [xelatex,'-interaction=nonstopmode','-halt-on-error','-file-line-error',stem+'.tex']),
    ('biber', [biber,stem]),
    ('xelatex-3', [xelatex,'-interaction=nonstopmode','-halt-on-error','-file-line-error',stem+'.tex']),
    ('xelatex-4', [xelatex,'-interaction=nonstopmode','-halt-on-error','-file-line-error',stem+'.tex'])]
steps = []
for name,command in commands:
    completed = subprocess.run(command,cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (report_dir / (name+'.log')).write_bytes(completed.stdout)
    steps.append({'step':name,'returncode':completed.returncode})
    print(name,completed.returncode,flush=True)
    if completed.returncode:
        (report_dir/'report.json').write_text(json.dumps({'steps':steps,'success':False},ensure_ascii=False,indent=2),encoding='utf-8')
        print(completed.stdout.decode('utf-8','replace')[-8000:])
        sys.exit(completed.returncode)

log = (project/(stem+'.log')).read_text(encoding='utf-8',errors='replace')
patterns = {
    'tex_errors':r'^!|^.*\.(?:tex|cls|sty):\d+:',
    'undefined':r'(?i)(?:reference|citation).*undefined|undefined control sequence',
    'missing_characters':r'Missing character:',
    'font_shape':r'Font shape.*(?:undefined|not available)',
    'overfull':r'Overfull \\[hv]box',
    'underfull':r'Underfull \\[hv]box',
    'rerun':r'Please \(re\)run Biber|Rerun to get cross-references right|Label\(s\) may have changed',
    'multiply_defined':r'multiply defined',
}
counts = {name:len(re.findall(pattern,log,re.MULTILINE)) for name,pattern in patterns.items()}
fatal_names = ('tex_errors','undefined','missing_characters','font_shape','rerun','multiply_defined')
inputs_after=input_snapshot()
changed_inputs=sorted(key for key in inputs_before.keys()|inputs_after.keys() if inputs_before.get(key)!=inputs_after.get(key))
success = all(counts[name] == 0 for name in fatal_names) and not changed_inputs
report = {'project':str(project),'main':stem,'steps':steps,'diagnostics':counts,'success':success,
          'inputs_stable_during_build':not changed_inputs,'changed_inputs':changed_inputs,
          'input_sha256':inputs_after}
(report_dir/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({key:value for key,value in report.items() if key!='input_sha256'},ensure_ascii=False,indent=2))
sys.exit(0 if success else 1)
