"""Run final audits and bind the results to unchanged review inputs."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,sys

ROOT=Path(__file__).resolve().parent.parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def inputs():
    files={ROOT/'shared/glossary.tsv',ROOT/'shared/zs-common.tex'}
    files.update((ROOT/'shared/inventory').glob('*'))
    files.update((ROOT/'shared/xrefs').glob('*.aux'))
    files.update((ROOT/'shared').glob('audit_*.py'))
    for n in (1,2):
        files.update(ROOT/f'volume{n}'/name for name in ('main.pdf','main.aux','main.tex','mathtranslation.cls'))
        for folder in ('chapters','appendices','frontmatter','backmatter'):
            files.update((ROOT/f'volume{n}/{folder}').rglob('*.tex'))
    return {p.relative_to(ROOT).as_posix():sha(p) for p in sorted(files) if p.is_file()}

commands=[['shared/audit_manifests.py'],['shared/audit_terminology.py'],
          ['shared/audit_included_style.py','1'],['shared/audit_included_style.py','2'],
          ['shared/audit_pdf_links.py']]
before=inputs()
def run(args):
    completed=subprocess.run([sys.executable,*args],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    label=Path(args[0]).stem+('-'+args[1] if len(args)>1 else '')
    (ROOT/f'qa/review-2026-11-17/{label}.log').write_bytes(completed.stdout)
    return {'command':args,'returncode':completed.returncode}
with ThreadPoolExecutor(max_workers=5) as pool:
    results=list(pool.map(run,commands))
after=inputs()
assert before==after,'Audit inputs changed during audit'
assert all(r['returncode']==0 for r in results),results
reports=['shared/manifest-audit.json','shared/terminology-audit.json','shared/pdf-link-audit.json',
         'volume1/qa/skill-style-audit-main.json','volume2/qa/skill-style-audit-main.json']
record={'inputs_stable':True,'inputs':after,'reports':{rel:sha(ROOT/rel) for rel in reports},'commands':results}
(ROOT/'qa/review-2026-11-17/audit-inputs.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({'inputs_stable':True,'commands':results},indent=2))
