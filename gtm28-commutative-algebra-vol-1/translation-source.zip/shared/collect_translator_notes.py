"""Collect visibly marked translator notes with their nearest source-page anchor."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent.parent
def braced(s,pos):
    start=pos+1;pos+=1;depth=1
    while pos<len(s):
        if s[pos]=='\\':pos+=2;continue
        if s[pos]=='{':depth+=1
        if s[pos]=='}':
            depth-=1
            if not depth:return s[start:pos],pos+1
        pos+=1
    raise ValueError('Unclosed footnote')
rows=[]
for p in sorted(ROOT.glob('volume*/**/*.tex')):
    rel=p.relative_to(ROOT)
    if rel.parts[1] not in ('chapters','appendices'):continue
    s=p.read_text(encoding='utf-8')
    for m in re.finditer(r'\\footnote\{',s):
        text,end=braced(s,m.end()-1)
        if '译注' not in text:continue
        markers=list(re.finditer(r'\\SourcePage\{(\d+)\}',s[:m.start()]))
        rows.append({'file':str(rel).replace('\\','/'),'line':s.count('\n',0,m.start())+1,
                     'nearest_source_page':int(markers[-1][1]) if markers else None,'text':text})
(ROOT/'shared/translator-notes.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False,indent=2))
