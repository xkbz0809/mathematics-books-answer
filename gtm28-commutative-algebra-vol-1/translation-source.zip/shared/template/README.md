# Shared MathTranslations book template

Prepared on 2026-11-16 for the independent GTM 28 and GTM 29 translations.

## Provenance

- Current guide checked: <https://mathtranslations.org/guide/>.
- Guide's current archive URL: <https://mathtranslations.org/static/catalog/mathtranslations-translation-template.3ea772c9d558.zip>.
- The guide was readable, but fresh archive retrieval failed (PowerShell TLS authentication error; Python HTTP 403). The identically named archive already saved in `D:/translation/An Introduction to Homological Algebra/project/upstream/` was copied here. Its identity with a fresh download has **not** been independently established.
- Saved archive SHA-256: `a90e3b05895f36a577883feb14573a0a3d9136a560ca04c3827c9a5822f568b4`.
- The archived class identifies itself as `2026/09/11 MathTranslations Chinese translation template`. It uses `ctexart`, and is preserved under `upstream/`.
- `book/mathtranslation.cls` is a documented `ctexbook` adaptation of that inspected archive, prepared locally on 2026-11-16. It is **not** represented as a downloaded official v3.1 class.

## Adaptation

The book class retains the official font roles, link colors, cover arrangement, theorem body styles, terminology registration, bibliography handling, and long-proof/exercise helper interfaces. It changes the base to native `ctexbook`, removes the legacy fake chapter-as-section mechanism, adds `makecover`, `makecontents`, and `MTFrontChapter`, and gives theorem environments independent chapter counters. Roman chapter numbers and native section hierarchy are used. Cover typography is reduced to fit long titles and author names. All placeholder metadata must be overridden in the actual project. Book-specific numbering belongs in the separate series adapter.

The terminology index uses auxiliary-file registrations; it does not require `texindy`. A separate subject index, if later added, requires its own build step.

## Use

Copy `book/mathtranslation.cls` and `book/graphics/logo.pdf` into each independent volume project. The two volumes should share the same class version, glossary, and mathematical notation adapter, but have separate `main.tex`, auxiliary files, and output PDFs.

The public sequence is:

```tex
\documentclass{mathtranslation}
% Override BookTitleCN, BookTitleEN, OriginalAuthor, OriginalEdition,
% OriginalPublisher, OriginalYear, Translator, ModelUsed, TranslationDate.
\addbibresource{references.bib}
\begin{document}
\makecover
\frontmatter
% Preface, etc. Use \MTFrontChapter{...} for anchored unnumbered chapters.
\makecontents
\mainmatter
% \chapter, \section, content.
\backmatter
\makebibliography
\printterminology
\end{document}
```

Use `\newterm{stable-key}{中文术语}{English term}` at the first formal occurrence in each independently readable volume. Do not load `biblatex` again.

## Build

Python fallback, verified for this Windows session:

```powershell
python 'D:\translation\GTM28,29\shared\toolchain\build.py' 'ABSOLUTE_PROJECT_DIRECTORY' --clean
```

This executes XeLaTeX twice, Biber, then XeLaTeX twice. It writes per-step logs and a machine-readable report into `_build/`. It builds with the project as the working directory and does not use `-output-directory`. `--clean` deletes only known generated auxiliary files for the selected main job.

The equivalent Bash wrapper is `shared/toolchain/build.sh full ABSOLUTE_PROJECT_DIRECTORY`. Git Bash cannot start in the current sandbox (Win32 signal pipe error 5), so the Python driver is the tested entry point.

`probe/main.pdf` is a minimal template test, explicitly not a translated chapter. Verification results are recorded in the toolchain report.
