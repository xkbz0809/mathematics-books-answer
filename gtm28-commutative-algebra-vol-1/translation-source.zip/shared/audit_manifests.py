"""Audit only the authored files included by chapter/appendix manifests.

This checks structural evidence, not sentence completeness or mathematical truth.
"""
from pathlib import Path
from collections import Counter, defaultdict
import re, json

ROOT = Path(__file__).resolve().parent.parent

def uncomment(s):
    return re.sub(r'(?<!\\)%[^\n]*', '', s)

def expand(path, volume, seen):
    path = path.resolve()
    if path in seen:
        raise ValueError(f'Repeated input {path}')
    seen.add(path)
    text = path.read_text(encoding='utf-8')
    pieces = []
    cursor = 0
    # Expand against the actual string to preserve offsets, excluding comment lines.
    text = uncomment(text)
    for match in re.finditer(r'\\input\{([^}]+)\}', text):
        pieces.append(text[cursor:match.start()])
        child = volume / match.group(1)
        if not child.suffix:
            child = child.with_suffix('.tex')
        pieces.append(expand(child, volume, seen))
        cursor = match.end()
    pieces.append(text[cursor:])
    return '\n'.join(pieces)

def braced(s, pos):
    while pos < len(s) and s[pos].isspace():
        pos += 1
    if pos == len(s) or s[pos] != '{':
        return None, pos
    start = pos + 1
    depth = 1
    pos += 1
    while pos < len(s):
        if s[pos] == '\\':
            pos += 2
            continue
        if s[pos] == '{':
            depth += 1
        elif s[pos] == '}':
            depth -= 1
            if not depth:
                return s[start:pos], pos + 1
        pos += 1
    return None, pos

reports = {}
labels = defaultdict(list)
allrefs = []
for n in (1, 2):
    volume = ROOT / f'volume{n}'
    manifests = sorted((volume/'chapters').glob('ch*/chapter.tex'))
    manifests += sorted((volume/'appendices').glob('app*/appendix.tex'))
    seen = set()
    sections = []
    for manifest in manifests:
        text = expand(manifest, volume, seen)
        pages = list(map(int, re.findall(r'\\SourcePage\{(\d+)\}', text)))
        envstack = []
        errors = []
        for m in re.finditer(r'\\(begin|end)\{([^}]+)\}', text):
            if m[1] == 'begin':
                envstack.append(m[2])
            elif not envstack or envstack.pop() != m[2]:
                errors.append('Environment mismatch near ' + m.group())
        errors += ['Unclosed environment '+e for e in envstack]
        for marker in re.finditer(r'\\SourcePage\{\d+\}',text):
            if len(re.findall(r'(?<!\\)\$',text[:marker.start()]))%2:
                errors.append('Source-page anchor inside inline mathematics: '+marker[0])
        for m in re.finditer(r'\\newterm\s*', text):
            pos = m.end()
            args = []
            for _ in range(3):
                arg, pos = braced(text, pos)
                args.append(arg)
            if None in args:
                errors.append('Incomplete newterm arguments near '+text[m.start():m.start()+130])
            elif not re.fullmatch(r'[A-Za-z0-9:_-]+', args[0]):
                errors.append('Non-ASCII or unsafe term key: '+args[0])
        path = str(manifest.relative_to(ROOT)).replace('\\','/')
        for label in re.findall(r'\\label\{([^}]+)\}', text):
            labels[label].append(path)
        for m in re.finditer(r'\\ZSbisSection\s*', text):
            pos=m.end()
            args=[]
            for _ in range(3):
                arg,pos=braced(text,pos)
                args.append(arg)
            if args[2]: labels[args[2]].append(path)
        part_counts=Counter()
        for app in re.findall(r'\\ZSAppendixPart\{(\d+)\}',text):
            part_counts[app]+=1
            labels[f'sec:App:{app}:{part_counts[app]}'].append(path)
        for ref in re.findall(r'\\(?:ref|eqref|pageref|autoref)\*?\{([^}]+)\}', text):
            allrefs.append((ref,path))
        for ref in re.findall(r'\\hyperref\[([^]]+)\]', text):
            allrefs.append((ref,path))
        for ch,sec in re.findall(r'\\SourceSectionRef\{([^}]+)\}\{([^}]+)\}',text):
            allrefs.append((f'sec:{ch}:{sec}',path))
        for ch in re.findall(r'\\SourceChapterRef\{([^}]+)\}',text):
            allrefs.append((f'ch:{ch}',path))
        for page in re.findall(r'\\SourcePageRef\{([^}]+)\}',text):
            allrefs.append((f'src:{"I" if n==1 else "II"}:{page}',path))
        sections.append({'manifest':path,'source_pages':sorted(set(pages)),
                         'repeated_page_anchors':[p for p,c in Counter(pages).items() if c>1],
                         'formula_tags':len(re.findall(r'\\tag\*?\{',text)),
                         'footnotes_including_translator_notes':len(re.findall(r'\\footnote\{',text)),
                         'errors':errors})
        for page in pages:
            labels[f'src:{"I" if n==1 else "II"}:{page}'].append(path)
        # Appendices receive labels through ZSAppendix rather than explicit label.
        for app in re.findall(r'\\ZSAppendix\{(\d+)\}',text):
            labels['app:'+app].append(path)
    present = {p for item in sections for p in item['source_pages']}
    reports[str(n)] = {'included_files':sorted(str(p.relative_to(ROOT)).replace('\\','/') for p in seen),
                       'units':sections,
                       'missing_body_source_page_anchors':sorted(set(range(1,321 if n==1 else 408))-present)}

expected=[]
for unit in json.loads((ROOT/'shared/inventory/structure.json').read_text(encoding='utf-8')):
    ch=unit['chapter']
    if ch=='Appendices':
        expected += ['app:'+str(s['section']) for s in unit['sections']]
    else:
        expected.append('ch:'+ch)
        for s in unit['sections']:
            sec=str(s['section'])
            expected.append('app:'+ch if sec=='appendix' else f'sec:{ch}:{sec}')
result = {'scope':'Included body manifests only; missing references can still target front/back matter.',
          'volumes':reports,
          'expected_source_structure_labels':len(expected),
          'missing_source_structure_labels':[key for key in expected if key not in labels],
          'duplicate_labels':{k:v for k,v in labels.items() if len(v)>1},
          'unresolved_body_references':[{'label':r,'file':p} for r,p in allrefs if r not in labels]}
(ROOT/'shared/manifest-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
for n,r in reports.items():
    print(f'Volume {n}: {len(r["included_files"])} included files; {len(r["missing_body_source_page_anchors"])} missing source-page anchors; '+
          f'{sum(len(u["errors"]) for u in r["units"])} syntax findings')
print(f'{len(result["duplicate_labels"])} duplicate labels; {len(result["unresolved_body_references"])} unresolved references')
