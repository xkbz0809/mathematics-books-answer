"""Compare every delivered-page raster with the snapshots actually reviewed."""
from pathlib import Path
import hashlib,json
import pymupdf

ROOT=Path(__file__).resolve().parent.parent
REVIEW=ROOT/'qa/review-2026-11-17'
result={}
for n in (1,2):
    final=ROOT/f'volume{n}/main.pdf'
    snapshot=REVIEW/f'reviewed-v{n}.pdf'
    with pymupdf.open(final) as new, pymupdf.open(snapshot) as old:
        differences=[]
        for i in range(max(len(new),len(old))):
            if i>=len(new) or i>=len(old):
                differences.append(i+1)
            elif new[i].get_pixmap(dpi=72).samples!=old[i].get_pixmap(dpi=72).samples:
                differences.append(i+1)
        result[str(n)]={'pages':len(new),'snapshot_pages':len(old),
            'different_rendered_pages':differences,'dpi':72,
            'snapshot_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
            'final_sha256':hashlib.sha256(final.read_bytes()).hexdigest()}
(REVIEW/'final-render-comparison.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
assert all(not r['different_rendered_pages'] for r in result.values())
