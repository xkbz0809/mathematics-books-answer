"""Run the unmodified skill auditor on only a volume's included release sources.

The generated audit-context.tex lists actual aux labels not declared literally in
these sources (macro-created anchors and cross-volume labels). This supplies the
context the generic regex auditor cannot infer; no unresolved label is invented.
The authoritative link check is separately performed against both actual PDFs.
"""
from pathlib import Path
import argparse, importlib.util, re, shutil, json
ROOT=Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('volume',type=int,choices=(1,2));p.add_argument('--job',default='main');a=p.parse_args()
v=ROOT/f'volume{a.volume}'
stage=ROOT/f'_audit/volume{a.volume}-{a.job}'
stage.mkdir(parents=True,exist_ok=True)
seen=set()
def collect(path):
    path=path.resolve()
    if path in seen:return
    seen.add(path)
    s=path.read_text(encoding='utf-8')
    s=re.sub(r'(?<!\\)%[^\n]*','',s)
    for relative in re.findall(r'\\input\{([^}]+)\}',s):
        child=v/relative
        if not child.suffix:child=child.with_suffix('.tex')
        if child.exists():collect(child)
collect(v/f'{a.job}.tex')
seen.add(v/'mathtranslation.cls')
literal=set();copied=[]
for src in sorted(seen):
    if src.is_relative_to(v):relative=src.relative_to(v)
    else:relative=Path('shared')/src.name
    target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,target);copied.append(str(relative))
    active=re.sub(r'(?<!\\)%[^\n]*','',src.read_text(encoding='utf-8'))
    literal.update(re.findall(r'\\label\{([^}]+)\}',active))
actual=set()
for path in (v/f'{a.job}.aux',ROOT/f'shared/xrefs/volume{3-a.volume}.aux'):
    actual.update(re.findall(r'\\newlabel\{([^}]+)\}',path.read_text(encoding='utf-8')))
context=actual-literal
(stage/'audit-context.tex').write_text('% Audit context from compiled aux, not production TeX.\n'+'\n'.join(r'\label{'+s+'}' for s in sorted(context))+'\n',encoding='utf-8')
copied.append('audit-context.tex')
log=v/f'{a.job}.log'
if log.exists():shutil.copy2(log,stage/f'{a.job}.log')
tool=Path(r'C:\Users\lenovo\.codex\skills\mathtranslations\scripts\audit_latex.py')
spec=importlib.util.spec_from_file_location('skill_auditor',tool);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
errors,warnings=mod.audit(stage,'mathtranslations')
report={'scope':str(stage),'copied_files':copied,'aux_context_labels':len(context),'errors':errors,'warnings':warnings}
(v/f'qa/skill-style-audit-{a.job}.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('Errors:',len(errors),'Warnings:',len(warnings))
print('\n'.join('ERROR '+s for s in errors))
print('\n'.join('WARNING '+s for s in warnings))
