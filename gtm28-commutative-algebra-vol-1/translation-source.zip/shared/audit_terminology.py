"""Report actual introductions across both books, including nested TeX arguments."""
from pathlib import Path
import csv,json,re
from collections import defaultdict
ROOT=Path(__file__).resolve().parent.parent
def arg(s,pos):
    while pos<len(s) and s[pos].isspace():pos+=1
    if pos>=len(s) or s[pos]!='{':return None,pos
    start=pos+1;pos+=1;depth=1
    while pos<len(s):
        if s[pos]=='\\':pos+=2;continue
        if s[pos]=='{':depth+=1
        if s[pos]=='}':
            depth-=1
            if depth==0:return s[start:pos],pos+1
        pos+=1
    return None,pos
by=defaultdict(list)
keys=defaultdict(list)
for path in sorted(ROOT.glob('volume*/**/*.tex')):
    relative=path.relative_to(ROOT)
    if relative.parts[1] not in ('chapters','appendices'):continue
    s=re.sub(r'(?<!\\)%[^\n]*','',path.read_text(encoding='utf-8'))
    for m in re.finditer(r'\\newterm\s*',s):
        pos=m.end();vals=[]
        for _ in range(3):v,pos=arg(s,pos);vals.append(v)
        if None in vals:continue
        key,cn,en=vals
        row={'key':key,'chinese':cn,'english':en,'file':str(relative).replace('\\','/')}
        by[en.casefold()].append(row)
        keys[(relative.parts[0],key)].append(row)
conflicts={en:rows for en,rows in by.items() if len({r['chinese'].removesuffix('的') for r in rows})>1}
allow={'extension':({'扩张','延拓'},'域/环的扩张；映射/赋值的延拓'),
       'independent':({'无关','独立'},'模的无关性；赋值的独立性'),
       'complete':({'完全','完备'},'VI完全模型/完全集；VIII拓扑完备；附录整相关的完全')}
resolved={}
for en,(forms,reason) in allow.items():
    if en in conflicts and {r['chinese'].removesuffix('的') for r in conflicts[en]}<=forms:
        resolved[en]={'reason':reason,'occurrences':conflicts.pop(en)}
duplicates={str(key):rows for key,rows in keys.items() if len(rows)>1}
master=list(csv.DictReader((ROOT/'shared/glossary.tsv').open(encoding='utf-8'),delimiter='\t'))
existing={r['english'].casefold() for r in master}
missing={en:rows for en,rows in by.items() if en not in existing}
result={'introductions':sum(map(len,by.values())),'distinct_english':len(by),'conflicting_english':conflicts,'contextual_distinctions':resolved,
        'duplicate_keys_within_volume':duplicates,'not_yet_in_master':missing}
(ROOT/'shared/terminology-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('Introductions',result['introductions'],'Distinct English',len(by),'Missing master',len(missing))
print('Conflicting English:',json.dumps(conflicts,ensure_ascii=False))
print('Duplicate keys:',json.dumps(duplicates,ensure_ascii=False))
print('Missing terms:',json.dumps(list(missing),ensure_ascii=False))
