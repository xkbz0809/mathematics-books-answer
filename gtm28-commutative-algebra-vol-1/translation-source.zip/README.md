# Zariski–Samuel《交换代数》两卷中文翻译工程

两卷分别编排，正文保持原书章号 I–V 与 VI–VIII。第二卷另含七个附录。统一术语表在 `shared/glossary.tsv`，源书页码与PDF位置在 `shared/inventory/`。

工程采用用户提供的两份扫描PDF。原文字层及OCR仅辅助识读，公式和符号以扫描页为准。原件保持不变。第II卷扫描在原407页之后直接接原409页，原408页不在文件中；没有据此虚构该页内容。

完成范围与检查结果见 `STATUS.md` 和 `QA-REPORT.md`；正式成品为 `delivery/` 中的两份PDF。`working.pdf` 和 `qa/` 内的快照是制作中间文件；各卷 `main.pdf` 是正式源文件的构建输出。

2026-11-17 复核修订的独立问题计数、修正说明及范围见 `REVIEW-REPORT.md`。本轮证据在 `qa/review-2026-11-17/`，上一交付的本地冻结备份在其 `baseline/` 子目录；这个备份不重复收入新版源码包。

## 文件组织

- `volume1/main.tex`、`volume2/main.tex`：两个独立主文件。
- 各卷 `chapters/`、`frontmatter/`、`backmatter/`：正文与前后材料。
- `volume2/appendices/`：七个附录。
- `shared/zs-common.tex`：原编号、原页锚点及跨卷引用公共定义。
- 各卷 `mathtranslation.cls`：由所检查模板适配的项目副本；不是声称官方发布的新版本。
- `shared/xrefs/`：另一卷的已导出标签，使单卷可独立编译。
- 各卷 `qa/*-review.md`：分章与附录的校对记录。记录保留过程和范围，较早的待办由后续补充说明更新。
- `ISSUES.md`：原书旧约定与疑点入口；不等同于全书数学勘误表。

## 构建

需要 Python 3 和含 XeLaTeX、Biber、ctex、Fandol 字体、CM Unicode 字体、tikz-cd 的 TeX Live。视觉检查脚本另用 PyMuPDF 与 Pillow。Windows 环境用 `shared/toolchain/build.py`，执行 XeLaTeX 两遍、Biber、XeLaTeX两遍。原书参考文献分散于正文和脚注，保留原位置；没有额外捏造独立参考文献表。

在工程根目录运行：

```powershell
python shared/toolchain/build.py volume1 --main main --clean
python shared/toolchain/build.py volume2 --main main --clean
python shared/export_crossrefs.py 1 --job main
python shared/export_crossrefs.py 2 --job main
python shared/toolchain/build.py volume1 --main main
python shared/toolchain/build.py volume2 --main main
python shared/export_crossrefs.py 1 --job main
python shared/export_crossrefs.py 2 --job main
```

若更改正文、标题或任何影响锚点的内容，需重新导出标签，并重新编译引用该卷的另一卷。重复最后四行，直到导出前后的两个共享 aux 文件均不再改变。新增锚点可能改变后续自动目标的名字，旧链接即使仍能打开，也可能跳错位置。最终应再次运行 `shared/audit_pdf_links.py`，核对两个实际PDF中的目的地和共享标签是否一致。构建报告同时记录输入文件哈希，若构建期间源文件改变，则不判为通过。

```powershell
python shared/audit_manifests.py
python shared/audit_terminology.py
python shared/audit_included_style.py 1
python shared/audit_included_style.py 2
python shared/audit_pdf_links.py
```

`audit_included_style.py` 调用当前已安装 MathTranslations skill 的原审计脚本；其路径是本机路径，迁移工程时可改为新的安装路径。它将真实纳入的文件复制到审计目录，用实际aux补足正则工具无法推断的宏生成标签及跨卷标签，不编造未定义引用。最终PDF的链接另外按实际目的地验证。

成品两PDF应置于同一个文件夹，保留文件名 `GTM28-commutative-algebra-I-zh.pdf` 与 `GTM29-commutative-algebra-II-zh.pdf`。跨卷跳转是否打开另一PDF，取决于阅读器对本地文件链接的支持。
