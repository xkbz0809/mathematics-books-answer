# 前部材料检查

- 原书范围：PDF 1–9 已逐页渲染并目视.
- preface.tex：原书 v–viii 完整翻译；四页段落、题辞、署名地点、资助脚注均保留. 将 OCR 丢失的次数公式按 PDF 8 恢复为 sum e_i f_i = n；将 OCR 的 Hubert、printing 拼写、姓名与合同号依图像恢复.
- original-publication.tex：题名、合作作者、原出版社地址、版权及印次信息已译. Springer 城市列表已按 PDF 2 图像补入.
- 未编译、未作独立复核；跨卷第 VII 章引用待第二卷生成后用 xr-hyper 连接.
- 当前不是完成稿，不能据此宣布前部材料全部交付.
