# 阿贝尔定理：问题与解答——中文译本

V. B. Alekseev 著，根据 V. I. Arnold 教授的讲课编写。

依据用户提供的 2004 年英文版 PDF（281 页）翻译，覆盖序言、前言、引言、群论、复数、352 道问题及其提示/解答/答案、F. Aicardi 的黎曼曲面图绘、A. Khovanskii 的《方程的显式可解性》附录、V. I. Arnold 的附录、参考文献与原书索引。作者名以原书书名页为准。

## 阅读与修改

- `main.tex` 是编译入口，`chapters/` 保存分章正文。
- `figures/` 保存从原书恢复的几何图与重建的 TikZ-CD 图示。
- `术语表.md` 与正文首次定义、书末术语索引对应。
- `校对记录.md` 记录核查范围、排版差异和已知限制；`译注汇总.md` 集中列出正文译注。
- 题号可跳转到对应解答，解答号可跳回题目。章节、图、表、公式采用实际交叉引用。
- 中文重排页码与原书不同。原书索引保留英文条目与原书页码，并明确标识其页码含义。

## 编译

使用完整的 TeX Live 2026 与 XeLaTeX。Windows 可在本目录运行 `编译.ps1`，或在终端依次运行三遍：

```text
xelatex -interaction=nonstopmode -halt-on-error -file-line-error main.tex
```

输出为本目录的 `main.pdf`。前两遍生成目录与交叉引用，第三遍稳定页码。本次交付的具体编译与检查结果见 `校对记录.md`。

## 内容与排版依据

以用户提供的 PDF 为正文、公式、图表的内容依据；同目录 Markdown 只作辅助录入。原书疑似错误保留，并用明确标注的译注说明；没有用数学上更合理的公式无声替换原文。

排版遵循 [MathTranslations 指南](https://mathtranslations.org/guide/) 和用户指定的 [mathtranslations-skill](https://github.com/libinyam/mathtranslations-skill)，资源核查日期为 2026-09-20。正文保留原书问题、图、表和公式编号。普通几何图优先忠实裁取，节点与箭头图使用 `tikzcd` 重建。

模板与标识的许可保留在 `模板-LICENSE.txt`、`模板-NOTICE.md` 中；该模板许可不适用于原书内容。原书版权信息保留于译本前部。`来源校验.json` 记录输入和模板文件的 SHA-256 校验值。
