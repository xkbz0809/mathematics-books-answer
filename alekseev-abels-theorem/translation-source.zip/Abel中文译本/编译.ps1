$ErrorActionPreference = 'Stop'
$texEngine = (Get-Command xelatex -ErrorAction Stop).Source
Push-Location -LiteralPath $PSScriptRoot
try {
    foreach ($pass in 1..3) {
        & $texEngine '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' 'main.tex'
        if ($LASTEXITCODE -ne 0) {
            throw "第 $pass 次编译失败，请查看 main.log。"
        }
    }
    Write-Host '编译完成：main.pdf'
}
finally {
    Pop-Location
}
