# 《Artin 代数表示论》课后习题解答源码

Auslander、Reiten、Smalø 著，1995 年精装版页序。编译入口 answers.tex，solutions 目录含第 I 至 XI 章共 104 道习题的中文解答。使用含 CTeX、TikZ、TikZ-cd、AMS-LaTeX 和 Windows 中文字体的 TeX Live，连续运行三遍 xelatex answers.tex。
