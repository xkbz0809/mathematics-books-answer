# 《Artin 代数表示论》中文译稿

Maurice Auslander、Idun Reiten、Sverre O. Smalø 著。Cambridge Studies in Advanced Mathematics，第 36 卷。本项目以用户所给的 1995 年精装版页序扫描本为底本。索引末两页据用户提供的修订版截图补录，原件、版次辨认依据及截图来源见 `records/edition.md`。

## 重编 PDF

在含有 `source` 子目录的目录中运行以下命令。环境需安装 Python 3、XeLaTeX、CTeX、TikZ、TikZ-cd、AMS-LaTeX 和可供 CTeX 的 Windows 中文字体。版面由 `preamble.tex` 统筹。

```powershell
python source/build.py
```

编译程序先从共用勘误记录生成中英条目，再各编译三次。输出位于 `work/build/final`。也可在命令末尾指定下表的一个或多个编译名。

| 编译名 | 入口 | 内容 |
|---|---|---|
| book | book.tex | 全书中译，含原题、译注、书目、索引 |
| answers | answers.tex | 11 章、104 道正式习题中文解答 |
| errata-zh | errata-zh.tex | 中文勘误 |
| errata-en | errata-en.tex | 英文勘误 |

## 修改与定位

`chapters` 收录按章维护的译文，`solutions` 收录按原题号维护的解答。各原页标记依次给出印刷页和从 1 起算的扫描顺序页。扫描原件、书目和两个索引截图的页码映射见 `records/original-pages.csv`。

中英文勘误共用 `records/*-errata.tex` 的原始条目。调整一条时沿用其编号，并检查同号译注及涉及的解答。编号允许有间隔。按原书页排序的 `records/ordered.tex` 以及两种语言的计数由编译脚本生成。

`records` 中各章的题单列有题号、小问和原页。各章的 `*-final-review.md` 记录独立数学复核。`Back-final-review.md` 涵盖卷首与书末。原书中另列的 13 条猜想及 11 个问题作为书末材料收入译本。

成册后可安装 PyMuPDF，再从同一目录运行 `python work/final_audit.py`。程序输出每章页码映射、PDF 书签、勘误标记、链接、内嵌字体及供目视检查的图页。源稿压缩包中保留本次核查结果 `source/records/final-pdf-audit.json`。
