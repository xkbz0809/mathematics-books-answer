# 底本与补充截图

原书为 Maurice Auslander、Idun Reiten、Sverre O. Smalø 著 *Representation Theory of Artin Algebras*，剑桥高等数学研究丛书第 36 卷。原扫描分页与 1995 年精装版（ISBN 978-0-521-41134-9，xiv + 423 页）相符，见书评 https://doi.org/10.1112/S0024609396232448 。扫描无可辨的印次、版权说明，未另行断定印次。

原件无可用文本层。目录 vii–ix 对应 PDF 4–6，导言 xi–xiv 对应 PDF 8–11。正文及书末纸本 1–421 对应 PDF 12–432。参考文献从 413 起，会议文集在 420，索引从 421 开始。PDF 3、7 仅有无可辨书文的痕迹。

用户提供的 P424.jpg、P425.jpg 页眉分别标 424 和 425，与出版商修订版索引的页序一致。续文在原扫描末条 faithful functor 之后从 faithful module 开始，以 valued quiver of an algebra 结束。两页分别有 97 和 79 个词条，译文沿用其实际次序与正文引页。修订版索引第一页增加了 Auslander–Reiten formula 等词条，不能据正文页码相同推断索引逐字相同。1995 年版 422–423 的原页图未曾提供。修订版索引见 https://assets.cambridge.org/97805215/99238/index/9780521599238_index.pdf 。

| 文件 | 大小（字节） | SHA-256 |
|---|---:|---|
| Auslandereptesentation.pdf | 15952808 | 543887842048f3d5f1805e76a8103f33555b30d672a751f4696f404434d2176e |
| P424.jpg | 324662 | 3ea1e586838cab68d241418031cb7f24c6804009e519ac41cf32aa401bf74dcf |
| P425.jpg | 125225 | 4c990f84f21556f6a9139b2ebcbb203a3cd902603fe1e7b949c07f8c4bb85bc9 |
