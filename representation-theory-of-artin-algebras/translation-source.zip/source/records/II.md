# 第 II 章审校
底本为 Auslander–Reiten–Smalø 用户扫描件。纸本 26–48 页对应 PDF 37–59 页。五节起页分别为 26、32、37、39、43。章末习题起页 45，注记见 47–48。正文和题干在 chapters/II.tex，解答在 solutions/II.tex。初稿及作者复算完成，独立终审另录。
|题号|纸本 / PDF|最末级作答单元|
|---|---|---|
|1|45 / 56|(a)–(d)|
|2|45 / 56|整题|
|3|45–46 / 56–57|(a)–(c) 在 45，(d)–(f) 在 46|
|4|46 / 57|(a)–(d)|
|5|46 / 57|(a)–(c)|
|6|46–47 / 57–58|题干 46，(a)–(d) 47|
|7|47 / 58|(a)、(b)(a)、(b)(b)|
|8|47 / 58|(a)–(e)|
合计 8 题、30 个最末级作答单元，均已解答。
|ID|纸本/PDF|位置|原书短摘|中文修正及理由|English correction and evidence|
|---|---|---|---|---|---|
|E02-001|30/41|II.1 定理 1.2 证明第一段|$\bar\phi_{A,B}(f)=\phi_B f\phi_A$|应为 $\phi_B^{-1} f\phi_A$；$\phi_B:GF(B)\to B$ 而目标是 $GF(B)$。|Use $\phi_B^{-1} f\phi_A$. Since $\phi_B$ maps $GF(B)$ to $B$, its inverse is needed to reach $GF(B)$.|
|E02-002|30/41|II.1 定理 1.2 第一交换图下|$F(t)=f$；$h=FG(t)$|应为 $F(t)=h$ 与 $h=FG(f)$。图下横箭的类型是 $FG(M)\to FG(N)$；$t=G(f)$ 位于 $\mathcal C$。|Read $F(t)=h$ and $h=FG(f)$. The bottom arrow has the endpoints of $F(t)$, and $t=G(f)$ is a morphism in the source category of $F$.|
|E02-003|31/42|II.1 定理 1.2 证明第三段首句|$\epsilon:1_{\mathcal D}\to GF$|改作 $1_{\mathcal C}\to GF$；$GF$ 作用于 $\mathcal C$。|Use $1_{\mathcal C}$, since $GF$ is an endofunctor on $\mathcal C$.|
|E02-004|35/46|II.2 命题 2.5 证明首段末|$e_P(P_i)\simeq Q_i$ for $i=1,2$|应为 $i=0,1$；投射展示的两项为 $Q_1,Q_0$。|Read $i=0,1$, the two indices in the projective presentation $Q_1\to Q_0\to X$.|
|E02-005|41/52|II.4 命题 4.3 证明第二段首个复合|$\operatorname{Hom}_{\Lambda}(-,\Lambda^{\mathrm{op}})$ on $\mathcal P(\Lambda^{\mathrm{op}})$|取右模同态 $\operatorname{Hom}_{\Lambda^{\mathrm{op}}}(-,\Lambda)$，其输入为右模。|Use $\operatorname{Hom}_{\Lambda^{\mathrm{op}}}(-,\Lambda)$ on the category of right projectives. Right-linear maps are needed at this stage of the double dual.|
|E02-007|46/57|II 习题 3(f)|$\coprod_{i=1}^n$|外层上限应为 $m$，题设定义了 $m$ 个不同素因子，$n$ 是群的指数。|The outer index runs to $m$, the number of defined distinct prime factors. The integer $n$ is the group exponent.|
|E02-010|46–47/57–58|习题 6 的滤过及 (c)、(d)|$0=M_0\subset M_1\subset\cdots\subset M_n=M$|第 I 章第 2 页许零因子。$0=M_0=M_1\subsetneq M_2=k$ 满足半单性与题设极小性，却有 $M_1\subseteq\operatorname{soc}^0M$ 且 $n=2>1$。对 (c)、(d) 删重复项并重新编号。|Delete repetitions and renumber for (c) and (d). The filtration $0,0,k$ satisfies all hypotheses, but fails (c) at $i=1$ and has $n=2$ instead of one.|
|E02-008|47/58|II 习题 7(a)|$\operatorname{Mod}\Lambda/C$ is not a preadditive category|补 $C\ne0$，并解释为一般不封闭。$C=0$ 时切片是模范畴。$C\ne0$ 时从 $1_C$ 到 $0\to C$ 无态射。|Assume $C\ne0$ and interpret failure of closure as a general statement. For $C=0$ the slice is the module category itself. Otherwise the Hom set from $1_C$ to $0\to C$ is empty.|
|E02-009|47/58|II 习题 8(a)|for each isomorphism $f:Q\to P$|改为投射模范畴的满态射。同构恒有右逆，但箭图 $1\to2$ 的 $S_1$ 不嵌入左正则模。该范畴内的满态射由 $\operatorname{Hom}_\Lambda(\operatorname{coker}f,\Lambda)=0$ 判定。|Replace “isomorphism” by “epimorphism in $\mathcal P(\Lambda)$”. Isomorphisms always split, but $S_1$ for the path algebra $1\to2$ does not embed in the left regular module. The corrected assertion follows by testing the cokernel against $\Lambda$.|

复查纸本 42（PDF 53）命题 4.6 的表示：原书明确将 $P^*$ 视为左 $\Lambda^{\mathrm{op}}$-模，在此约定下 $\mathfrak rP^*=P^*\mathfrak r$（右 $\Lambda$-模记号）。原式成立。初稿候选编号 E02-006 已撤回，保留其他编号。

