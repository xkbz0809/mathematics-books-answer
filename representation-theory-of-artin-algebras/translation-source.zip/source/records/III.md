# 第 III 章审校

底本为 Auslander–Reiten–Smalø《Representation Theory of Artin Algebras》的用户扫描件。纸本 49–99 页连续对应 PDF 60–110 页。四节起页为 49、70、79、83。章末习题始于 94 页，第 19 题与注记至 99 页。每页页首与正文续接已在 chapters/III.tex 登记，逐题解答在 solutions/III.tex。本记录登记作者复算及原页核对，交叉终审另录。

|题号|纸本/PDF|最末级作答单元|
|---|---|---|
|1|94 / 105|整题|
|2|94 / 105|(a)–(c)|
|3|94–95 / 105–106|(a)–(b)|
|4|95 / 106|(a)–(d)|
|5|95 / 106|(a)–(d)|
|6|95 / 106|(a)–(e)|
|7|95–96 / 106–107|(a)–(b)，后者含可分解情形|
|8|96 / 107|(a)–(d)|
|9|96 / 107|(a)–(c)|
|10|97 / 108|(a)–(d)|
|11|97 / 108|整题|
|12|97 / 108|(a)–(d)|
|13|97 / 108|(a)–(c)|
|14|97 / 108|整题|
|15|97 / 108|整题，含原命题反例及最佳修正|
|16|98 / 109|(a)–(d)|
|17|98 / 109|整题|
|18|98 / 109|(a)–(b)|
|19|98–99 / 109–110|(a)–(f)|

共 19 题、55 个最末级作答单元，第 3 题题干在 94 页、两小问在 95 页。题 7 两小问在 96 页。题 19(a)–(d) 在 98 页、续注和 (e)–(f) 在 99 页。

勘误的双语 TeX 数据源为 III-errata.tex。

|编号|纸本/PDF|位置|原书短摘|中文修正与证据|English correction and evidence|
|---|---|---|---|---|---|
|E03-001|51/62|III.1 引理 1.2，$f$ 的假设|a map $f:\Sigma\oplus V\to\Lambda$|须要求 $f$ 可加。取 $\Sigma=V=\Lambda=k$，$f(s,v)=s+sv$；在 $\Sigma$ 上为恒等，在 $V$ 上为零，两限制满足要求，但 $f(1,1)=2$，双加延拓在该点应为一。|Require $f$ to be additive. With $\Sigma=V=\Lambda=k$ and $f(s,v)=s+sv$, the restrictions are the identity and zero. Any additive extension takes $(1,1)$ to $1$, whereas this map takes it to $2$.|
|E03-020|56,75/67,86|III.1 不可分解与单表示定义；III.2 单三元组定义|no proper nonzero subobjects|需对象自身非零。零表示无真非零子对象且不能分成两非零对象，但零向量空间不是单模。|Require the object itself to be nonzero. The zero representation satisfies both printed conditions while its associated module is zero and not simple.|
|E03-002|57/68|III.1 定理 1.5 前，函子 $H$ 的态射式|$h_i(\alpha b)$|改作 $h_j(\alpha b)$，下一式的输入应仍为 $b$。若 $\alpha:i\to j$，则 $\alpha b\in e_jB$，从而 $f'_\alpha h_i(b)=h_j f_\alpha(b)$。|Use $h_j(\alpha b)$ and retain $b$ in the subsequent equation. For $\alpha:i\to j$, the element $\alpha b$ belongs to $e_jB$, so $f'_\alpha h_i(b)=h_jf_\alpha(b)$.|
|E03-003|58/69|III.1 定理 1.5 证明，页首交换图|$\xi_i:V(j)\to F(V,f)$|改为 $\xi_j$，直和嵌入的下标由源空间 $V(j)$ 决定。|Use $\xi_j$. The inclusion into the direct sum has source $V(j)$.|
|E03-004|65/76|III.1 定理 1.9 前一段的最后一句|every finite dimensional algebra over an algebraically closed field $k$ is elementary|补上「基本」。$M_2(k)$ 的根为零且不是域的直积，故虽有限维却不初等。推论 1.10 已明确假设基本。|Insert “basic”. The algebra $M_2(k)$ has zero radical and is not a product of copies of $k$. Corollary 1.10 explicitly assumes basicness.|
|E03-005|65/76|III.1 定理 1.9(a) 证明，倒数四行|$a_i\in A\cap\mathfrak r^m$|应为 $a_i\in A\cap\mathfrak r^{m-1}$。由 $\alpha_i=a_i+a'_i\in\mathfrak r^{m-1}$、$a'_i\in\mathfrak r^m$ 只得到这个幂次；原式会迫使每个 $\alpha_i\in\mathfrak r^m$、每个乘积 $\alpha_i\beta_i=0$。|Use $a_i\in A\cap\mathfrak r^{m-1}$. We only know $\alpha_i\in\mathfrak r^{m-1}$ and $a_i'\in\mathfrak r^m$. The printed exponent forces every $\alpha_i\beta_i$ into $\mathfrak r^{m+1}=0$.|
|E03-007|69/80|III.1 命题 1.14 证明的 Hom 维数等式|$\operatorname{Hom}_\Lambda(P_j,\mathfrak rP_i/\mathfrak r^2P_j)$|分母应为 $\mathfrak r^2P_i$。求的是 $\mathfrak rP_i$ 的顶层；当 $j\ne i$，正则模的这两个列模甚至是不同直和项。|The denominator is $\mathfrak r^2P_i$, since the module in this calculation is the top of $\mathfrak rP_i$. For distinct $i,j$ the columns of the regular module lie in distinct direct summands.|
|E03-008|69--70/80--81|III.1 命题 1.15 后，相反代数的赋值与维数式|the valuations are the same; $\operatorname{Ext}^1_{\Lambda^{\mathrm{op}}}(DS_i,DS_j)$|在按箭方向书写的有序对中，$(a,b)$ 要变为 $(b,a)$。对偶把核为 $S_j$、商为 $S_i$ 的短正合列反转成核 $DS_i$、商 $DS_j$ 的列，故相反代数的扩张变元须为 $(DS_j,DS_i)$，两个端点的维数也互换。|Reverse the ordered pair and use $\operatorname{Ext}^1_{\Lambda^{\mathrm{op}}}(DS_j,DS_i)$. Duality takes an extension with kernel $S_j$ and quotient $S_i$ to one with kernel $DS_i$ and quotient $DS_j$, interchanging the two endomorphism ring actions.|
|E03-009|70/81|III.1 命题 1.15 后第一个例|$\mathfrak r(\Lambda e_1)\simeq\Lambda e_2$|应为 $\mathfrak r(\Lambda e_1)\simeq S_2$。在 $T_3(k)/(E_{31})$ 中左端仅以 $\bar E_{21}$ 为基，右边所印投射模以 $\bar E_{22},\bar E_{32}$ 为基。|Use $\mathfrak r(\Lambda e_1)\simeq S_2$. In $T_3(k)/(E_{31})$ the left side is spanned by $\bar E_{21}$, whereas $\Lambda e_2$ has basis $\bar E_{22},\bar E_{32}$.|
|E03-010|75/86|III.2 命题 2.3 前子对象的定义|$f'=f\|_{M\otimes_T A'}$|应写 $jf'=f(1_M\otimes i)$，其中 $i:A'\hookrightarrow A,j:B'\hookrightarrow B$。张量不必保持单射。例如 $T=k[t]/(t^2), M=T/(t), A'=(t)\subset T=A$ 时，张量后的映射为零而源为 $k$。|Write $jf'=f(1_M\otimes i)$ for the two inclusions $i,j$. Tensoring $(t)\hookrightarrow T$ by $M=T/(t)$ over $T=k[t]/(t^2)$ gives a zero map with nonzero source.|
|E03-011|82/93|III.3 反变 Hom 函子段末及下一段首|$g:A'\to A$; $\operatorname{Hom}_k(A,G)$|写作 $g:A\to A'$ 才能预合成为 $\operatorname{Hom}_k(A',B)\to\operatorname{Hom}_k(A,B)$。下一段第二变元应是群模 $B$；群 $G$ 本身没有指定的 $k$-空间结构。|Use $g:A\to A'$ for precomposition from $\operatorname{Hom}_k(A',B)$ to $\operatorname{Hom}_k(A,B)$. The next paragraph concerns $\operatorname{Hom}_k(A,B)$, since $B$ is a vector space and no vector space structure is given on $G$.|
|E03-012|85--86/96--97|III.4 条件 (i)--(iv) 与模结构的逆构造|an operation of $G$ on $Y$ satisfying (i), (ii), (iii) and (iv)|还应要求每个 $\sigma$ 可加。取 $R=\Lambda=\mathbb F_2,\ Y=\mathbb F_2^3$。只交换 $e_1,e_2$ 而固定其余向量的对合满足四条，却固定 $e_1+e_3$ 而将 $e_1$ 送到 $e_2$，故不可加。|Require each group element to act additively. On $\mathbb F_2^3$ the involution that interchanges only $e_1,e_2$ and fixes all remaining vectors meets (i)--(iv) for $R=\Lambda=\mathbb F_2$. It fixes $e_1+e_3$ and $e_3$ but moves $e_1$, so it is not additive.|
|E03-021|90/101|III.4 命题 4.6 证明|for all x in Λ, c in C and x in X|首个变元是 λ。投射维数有限时取达到该长度的分解，一般 R-代数未必有投射盖。|Quantify λ in Λ. A resolution attaining the projective dimension suffices when finite, and the infinite case is immediate.|
|E03-013|90/101|III.4 引理 4.8 证明，$h_Y(\lambda y)$ 的中间等式|$\sum_\sigma\sigma\,\sigma^{-1}(\lambda)\otimes\sigma^{-1}(y)$|最后一项应为 $\sigma^{-1}(y/n)$。施用张量平衡关系只移走 $\sigma^{-1}(\lambda)$，归一化因子 $1/n$ 保留。|Replace the last factor by $\sigma^{-1}(y/n)$. The balancing relation moves only $\sigma^{-1}(\lambda)$ across the tensor symbol and leaves $1/n$ in place.|
|E03-014|93/104|III.4 命题 4.12 的 (a) 推 (b)，自同态环的作用|$\Gamma$-$\operatorname{End}_\Lambda(X)$-bimodule|用作右环时应写 $\operatorname{End}_\Lambda(X)^{\mathrm{op}}$。原给出的操作 $h(\gamma\otimes x)=\gamma\otimes h(x)$ 是左作用。它与 $\Gamma$ 的左作用交换，取相反环后成为所需右作用。|Use $\operatorname{End}_\Lambda(X)^{\mathrm{op}}$ on the right. The displayed operation $h(\gamma\otimes x)=\gamma\otimes h(x)$ is a left action commuting with the left $\Gamma$-action, hence a right action of the opposite ring.|
|E03-015|97/108|III 章习题 12(b)|the proper left ideals of $\Lambda$ are [the listed nonzero ideals]|应把零理想列入。$\Lambda\ne0$，故零理想是真左理想；原列每项都有非零矩阵。|Add the zero ideal. It is proper because $\Lambda\ne0$, and every listed ideal contains a nonzero matrix.|
|E03-016|97/108|III 章习题 15|$\operatorname{gl.dim}\Lambda\le2$|在原假设下最佳上界为三。取 $k(1\to2\to3\to4)/J^2$，按前二及后二顶点分块，两角均为遗传单箭道路代数。$\operatorname{rad}P_i=S_{i+1}$ 给出 $\operatorname{pd}S_1=3$。一般情形，投射 $T$-模的 $(P,0)$ 在三角环上投射维数至多二，故 $\operatorname{pd}(X,0)\le3$；$\operatorname{pd}(0,Y)\le1$，以短正合列得全体模的上界。|The sharp bound is three. In $k(1\to2\to3\to4)/J^2$, the two consecutive pairs of vertices give hereditary corners and $\operatorname{rad}P_i=S_{i+1}$ gives $\operatorname{pd}S_1=3$. In general $(P,0)$ for projective $T$-modules has projective dimension at most two, hence $(X,0)$ at most three. The submodule $(0,Y)$ has projective dimension at most one, giving the upper bound for every triple.|
|E03-017|98/109|III 章习题 16(a)|$g\ne0$|乘法群单位写 $1$，且根本无需排除单位。若 $g$ 的阶为 $p^m$，则 $(1-g)^{p^m}=1-g^{p^m}=0$。|The multiplicative group identity is $1$ and need not be excluded. If $g$ has order $p^m$, then $(1-g)^{p^m}=1-g^{p^m}=0$.|
|E03-018|98/109|III 章习题 16(d) 的提示|$Z(G)$ is nontrivial for each finite group $G$|改为每个非平凡有限 $p$-群。$S_3$ 的中心平凡，原说法错误；修正说法由类方程模 $p$ 得到。|Use every nontrivial finite $p$-group. The finite group $S_3$ has trivial center. The corrected claim follows from the class equation modulo $p$.|
|E03-019|98/109|III 章习题 18，群作用公式|$g(ae_1+be_1+c\alpha+d\beta)$|输入的第二项应为 $be_2$。在原式中 $(a,b)=(1,0),(0,1)$ 给同一输入 $e_1$ 却要求输出 $e_2,e_1$，不可能定义映射。|Replace the second summand by $be_2$. With the printed expression, $(a,b)=(1,0)$ and $(0,1)$ give the same input $e_1$ but demand different outputs $e_2,e_1$.|

独立复核纸本 68 页（PDF 79）命题 1.13 证明的箭端。原扫描放大可见公式为 $P_j=\Lambda e_j$ 到 $P_i=\Lambda e_i$，下标正确，初稿候选 E03-006 撤回，保留后续编号。
