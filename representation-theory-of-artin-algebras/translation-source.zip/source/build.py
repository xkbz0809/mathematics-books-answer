"""Build all four books with XeLaTeX. Run from any directory with Python 3."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OUTPUT = HERE.parent / "work" / "build"
TITLES = ("book", "answers", "errata-zh", "errata-en")

def tex_inputs(target):
    return target.read_text(encoding="utf-8-sig").splitlines()

def compile_title(title, quick=False):
    job = title
    out = OUTPUT / ("preview" if quick else "final") / title
    out.mkdir(parents=True, exist_ok=True)
    target = HERE / (title + ".tex")
    if quick and title in ("book", "answers"):
        body = []
        for line in tex_inputs(target):
            if line.startswith((r"\input{chapters/", r"\input{solutions/")):
                rel = line[len(r"\input{"):-1] + ".tex"
                if not (HERE / rel).is_file():
                    continue
            body.append(line)
        target = out / (title + ".tex")
        target.write_text("\n".join(body) + "\n", encoding="utf-8")
    env = os.environ.copy()
    env["max_print_line"] = "240"
    for run in range(1, 2 if quick else 4):
        transcript = out / f"pass-{run}.txt"
        with transcript.open("wb") as trace:
            code = subprocess.run(
                ["xelatex", "-interaction=nonstopmode", "-file-line-error", "-halt-on-error",
                 f"-jobname={job}", f"-output-directory={out}", str(target)],
                cwd=HERE, env=env, stdout=trace, stderr=subprocess.STDOUT
            ).returncode
        if code:
            print(transcript.read_text(encoding="utf-8", errors="replace")[-2400:], flush=True)
            raise SystemExit(code)
        print(f"{title}: pass {run} complete", flush=True)
    print(out / (job + ".pdf"), flush=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("title", nargs="*", metavar="TITLE")
    parser.add_argument("--preview", action="store_true", help="Check current draft with one pass; do not publish")
    arg = parser.parse_args()
    subprocess.run([sys.executable, str(HERE / "assemble_records.py")], check=True)
    for name in (arg.title or TITLES):
        if name not in TITLES:
            parser.error(f"Unknown title {name}")
        compile_title(name, arg.preview)

