from pathlib import Path
import json
import re
import sys

import pymupdf

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
RECORDS = SOURCE / "records"
OUT = ROOT / "work" / "build" / "final"
QADIR = ROOT / "work" / "final-qa"
CHAPTERS = ["I","II","III","IV","V","VI","VII","VIII","IX","X","XI"]
RANGES = [1,26,49,100,136,191,224,257,313,335,365,406]
TITLES = ["book","answers","errata-zh","errata-en"]
CODE = re.compile(r"E(?:[0-9]{2}|[A-Z]{1,3})-[0-9]{3}")
INPUT = re.compile(r"\\input\{([^{}]+)\}")
NUMBER = re.compile(r"\\ars(?:front)?page\{([\d–—-]+)\}\{([\d–—-]+)\}")

def all_tex(path, stack=()):
    if path in stack:
        raise ValueError(f"Recursive TeX input {path}")
    value = path.read_text(encoding="utf-8-sig")
    def load_input(match):
        child = SOURCE / match.group(1)
        if not child.suffix:
            child = child.with_suffix(".tex")
        if not child.is_file():
            raise ValueError(f"{path.name}: missing {child}")
        return all_tex(child, stack + (path,))
    return INPUT.sub(load_input, value)

def page_nums(s):
    ns = [int(n) for n in re.findall(r"\d+", s)]
    return set(range(ns[0], ns[-1] + 1))

def extract_questions(tex, chapter):
    marks = re.findall(r"\\arsanswer\{"+chapter+r"\}\{(\d+)\}", tex)
    if marks:
        return [int(mark) for mark in marks]
    headings = re.findall(r"\\(?:section|subsection|paragraph)\*?\{([^\n]{1,170})",tex)
    result = []
    for head in headings:
        m = re.search(r"(?:习题\s*"+chapter+r"[.\s]*|习题\s*|"+chapter+r"\.)(\d{1,2})(?:\D|$)",head)
        if m:
            result.append(int(m.group(1)))
    return sorted(set(result))

def main():
    QADIR.mkdir(parents=True,exist_ok=True)
    valid = set(CODE.findall((RECORDS/"ordered.tex").read_text(encoding="utf-8")))
    report = {"confirmed_errata":len(valid), "source_chapters":{}, "documents":{}}
    scan_misses = []
    all_body_marks = set()
    for i,c in enumerate(CHAPTERS):
        text = all_tex(SOURCE/"chapters"/(c+".tex"))
        ans = all_tex(SOURCE/"solutions"/(c+".tex"))
        marked = set()
        bad = []
        for paper, scan in NUMBER.findall(text):
            p, q = page_nums(paper), page_nums(scan)
            marked |= p
            if {n+11 for n in p} != q:
                bad.append([paper,scan])
        all_body_marks |= marked
        missing = sorted(set(range(RANGES[i],RANGES[i+1]))-marked)
        scan_misses.extend(missing)
        report["source_chapters"][c] = {"unmarked_printed_pages":missing,"incorrect_scan_mappings":bad,
            "solution_headings":extract_questions(ans,c),"review_present":(RECORDS/(c+"-final-review.md")).exists()}
    expected_tex = set(CODE.findall(all_tex(SOURCE/"book.tex")))
    report["body_missing_erratum_labels"] = sorted(valid - expected_tex)
    report["body_labels_without_errata"] = sorted(expected_tex - valid)
    known_sources = set()
    for title in TITLES:
        folder = OUT / title
        p = folder / (title+".pdf")
        doc = pymupdf.open(p)
        texts = [page.get_text() for page in doc]
        ids = set(CODE.findall("\n".join(texts).replace("−","-").replace("‐","-")))
        font_refs = {font[0]:font for page in doc for font in page.get_fonts()}
        fonts = [{"xref":ref,"base":entry[3],"embedded":bool(doc.extract_font(ref)[3])} for ref,entry in font_refs.items() if ref>0]
        log = (folder/(title+".log")).read_text(encoding="utf-8",errors="replace")
        boxes = [line for line in log.splitlines() if "Overfull" in line]
        missing_chars = sorted({line[:110] for line in log.splitlines() if "Missing character:" in line})
        toc=doc.get_toc()
        originals = {}
        if hasattr(doc, "resolve_names"):
            originals = {k:v.get("page") for k,v in doc.resolve_names().items() if k.startswith("orig:")}
        digest = {"pages":len(doc),"bookmarks":len(toc),"fonts":fonts,"page_labels":doc.get_page_labels(),
                  "overfull_boxes":boxes,"missing_glyphs":missing_chars,"original_page_anchor_count":len(originals)}
        if title=="answers":
            entries = [label for level, label, page in toc if re.fullmatch(r"习题 [IVX]+\.\d+",label)]
            digest["exercise_bookmark_count"] = len(entries)
            digest["exercise_bookmarks"] = entries
        if title.startswith("errata"):
            digest["printed_id_count"] = len(ids)
            digest["missing_ids"] = sorted(valid-ids)
            digest["extra_ids"] = sorted(ids-valid)
        if title=="book":
            book_text=all_tex(SOURCE/"book.tex")
            linked=set(re.findall(r"\\hyperlink\{(orig:\d+)\}",book_text))
            digest["unresolved_index_links"] = sorted(linked-set(originals))
            digest["index_tail"] = {"found":any("valued quiver of an algebra" in t.lower() for t in texts[-5:]),"screenshot_pages":[424,425]}
            digest["missed_identifiers_in_pdf"] = sorted(valid-ids)
        thumb = QADIR / title
        thumb.mkdir(exist_ok=True)
        selections = set([0,min(2,len(doc)-1),len(doc)//2,len(doc)-2,len(doc)-1])
        if title in ("book","answers"):
            for level, label, page in toc:
                if level==1 and page>0:
                    selections.add(min(page,len(doc)-1))
        for i in sorted(p for p in selections if 0<=p<len(doc)):
            doc[i].get_pixmap(matrix=pymupdf.Matrix(1.1,1.1),alpha=False).save(thumb/f"{i+1:04d}.png")
        report["documents"][title]=digest
        (QADIR/(title+"-text.txt")).write_text("\n\f\n".join(texts),encoding="utf-8")
        doc.close()
    (QADIR/"audit.json").write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps({"confirmed_errata":len(valid),"source_missing_marks":scan_misses,"missing_body_notes":report["body_missing_erratum_labels"],"stale_body_notes":report["body_labels_without_errata"],"docs":{k:{key:v[key] for key in ["pages","bookmarks","missing_glyphs","unresolved_index_links","missing_ids","extra_ids","missed_identifiers_in_pdf","index_tail"] if key in v} for k,v in report["documents"].items()}},ensure_ascii=False))

if __name__=="__main__":
    main()

