# 第二卷中文习题解答源码

本项目是 *Elements of the Representation Theory of Associative Algebras, Volume 2: Tubes and Concealed Algebras of Euclidean Type* 的独立中文习题解答，不是原作者的官方答案。解答作者与原题作者在封面和编写说明中分别标明。

覆盖第 X—XIV 章全部 61 题，依次为 8、10、14、13、16 题。原题辨析写在对应解答中，既有中文译本与原版 PDF 未被本项目改写。请以最终检查记录中的实际状态为准；“可编译”和“已完成数学复核”是不同的检查项。

## 文件

- `main.tex`：唯一整册入口；`chapters/`：逐章解答及必要片段。
- `mathtranslation.cls`、`preamble.tex`、`solution_preamble.tex`、`logo.pdf`：与第二卷译本一致的排版基础及解答专用格式。
- `references.bib`：题目来源与正文使用的参考文献。
- `book_links.tex`、`volume1_links.tex`：已有译本中的目标名映射。
- `glossary.tsv`：沿用的系列术语表。
- `tools/`：构建、检查和精确计算程序。
- `qa/`：逐章复核说明及整数、有理数计算证书；`source/`：定位和链接所需的小型数据。

发行源码包只需要上述维护与复现文件。页面渲染图片、临时构建目录、缓存、原版整书 PDF、已有译本及已有译本源码压缩包不应重复收入本解答源码包。

## 构建

需要 TeX Live 2026（或含所需宏包的相近版本）、XeLaTeX、Biber 及 Python 3。字体使用 TeX Live 自带的 Fandol 与 Computer Modern Unicode。精确计算程序使用 Python 的整数与 `fractions.Fraction`，不需要浮点近似或商业计算软件。PDF 自动检查另需 PyMuPDF。

可选的全页联系图工具 `tools/render_review.py` 另需 Pillow；它不参与正文构建或精确数学计算。Unix 环境也可用 `bash tools/build.sh full` 调用同样的五步构建。

在本目录执行：

```powershell
python -B -X utf8 tools/build.py main --out-dir build/release
python -B -X utf8 tools/verify_solutions.py --pdf build/release/main.pdf --aux build/release/main.aux --log build/release/main.log
```

完整构建顺序为 XeLaTeX 两遍、Biber、XeLaTeX 两遍。首次构建以及改变模板或主文件结构后，请用新的空输出目录，以免旧辅助文件参与编译。输出 PDF 为 `build/release/main.pdf`。数学复核与页面视觉复核的说明保存在 `qa/`；自动检查不会代替这两项工作。

第 X—XI 章的主要精确证书可以依次重跑 `tools/ch10_ch11_exact.py`、`tools/ch10_ch11_representations.py`、`tools/ch10_ch11_bound_tau.py`，路基证书由 `tools/ch10_ex7_paths.py` 生成。这些程序按自身位置定位项目，已在项目外的当前目录调用并核实证书逐字节一致。其余计算程序及对应 JSON 文件按章或题号命名。正式构建与整册检查使用上面的统一入口。

## 外部 PDF 链接

最终解答 PDF 放置在第二卷工程根目录，名称为 `结合代数表示论基础_第2卷_全书习题解答_中文.pdf`。同目录的 `结合代数表示论基础_第2卷_中文译本.pdf` 是 `bookref` 外链的目标。第一卷链接指向相邻的第一卷目录。

源码包独立构建不需要这两份译本，但外链需目标文件存在才可打开。也可以在 `main.tex` 载入 `solution_preamble` **之前**通过 `\newcommand{\BookTwoPDF}{…}`、`\newcommand{\VolumeOnePDF}{…}` 指定目标路径。链接使用 PDF 的命名目标，不依赖重排后的页码。

## 原题问题及证据

本册区分原题的字面断言、能够证明的修正版、解答中的计算和编者自己的说明。不成立的题目不能用修正版证明冒充原题证明。有限矩阵证书记录坐标顺序、表示、态射、关系及核验结果。原版 PDF 始终是辨认题图与关系的权威；编写过程中的图片仅用于核对，不是正文公式或图形的替代品。
