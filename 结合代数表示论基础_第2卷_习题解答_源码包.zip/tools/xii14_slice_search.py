from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json,itertools
from fractions import Fraction as F
from ch10_ch11_exact import tr,inv,integer
from ch10_ch11_representations import hom
D=json.loads((ROOT/'qa/xii14_postprojectives.json').read_text());C=D['C'];E=integer(inv(tr(C)))
def pair(x,y):return sum(x[i]*E[i][j]*y[j]for i in range(9)for j in range(9))
def decode(r):return r['d'],{tuple(map(int,a.split(','))):[[F(x)for x in row]for row in M]for a,M in r['a'].items()}
reps={(m,i):decode(D['representations'][f'{m},{i}'])for m in range(7)for i in range(9)}
cand=[[ (m,i)for m in range(7)]for i in range(9)]
cache={}
def dimhom(a,b):
 if(a,b)not in cache:cache[a,b]=len(hom(reps[a],reps[b]))
 return cache[a,b]
def compatible(a,b):
 x,y=reps[a][0],reps[b][0];u,v=pair(x,y),pair(y,x)
 return u in[0,1]and v in[0,1]and not(u and v)and dimhom(a,b)==u and dimhom(b,a)==v
order=[4,8,7,6,5,3,2,1,0];chosen={};full=0;answers=[]
def dfs(k):
 global full
 if k==9:
  full+=1;T=[chosen[i]for i in range(9)];H=[[pair(reps[a][0],reps[b][0])for b in T]for a in T]
  try:Ein=integer(inv(tr(H)))
  except StopIteration:return False
  if not all(Ein[i][i]==1 for i in range(9)):return False
  if not all(Ein[i][j]in[0,-1]for i in range(9)for j in range(9)if i!=j):return False
  edges=[(i,j)for i in range(9)for j in range(9)if Ein[i][j]==-1]
  if len(edges)!=8:return False
  neigh=[[]for i in range(9)]
  for a,b in edges:neigh[a].append(b);neigh[b].append(a)
  if sorted(map(len,neigh))!=[1,1,1,2,2,2,2,2,3]:return False
  c=next(i for i in range(9)if len(neigh[i])==3);lengths=[]
  for v in neigh[c]:
   pre=c;l=1
   while len(neigh[v])==2:pre,v=v,next(x for x in neigh[v]if x!=pre);l+=1
   lengths.append(l)
  if sorted(lengths)!=[1,2,5]:return False
  ans={'T_tau_indices':T,'T_dimensions':[reps[t][0]for t in T],'Hom':H,'Euler_End':Ein,'arrows_End':edges,'arm_lengths':lengths};answers.append(ans);print('FOUND',ans,flush=True)
  return True
 i=order[k]
 for a in cand[i]:
  if not all(compatible(a,b)for b in chosen.values()):continue
  chosen[i]=a
  if dfs(k+1):return True
  del chosen[i]
 return False
dfs(0)
print('fullsets',full,'homcomputations',len(cache),'answers',len(answers),flush=True)
(ROOT/'qa/xii14_slice_search.json').write_text(json.dumps({'answers':answers,'fullsets':full,'homcomputations':len(cache)},indent=2),encoding='utf-8')

