from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json,math
from fractions import Fraction as F
from xii14_explore import B,O,n
from bound_quiver_exact import dual
from ch10_ch11_representations import hom,compose,nonzero,PIVOTS
from ch10_ch11_exact import inv,tr,integer
A=json.loads((ROOT/'qa/xii14_slice_search.json').read_text())['answers'][0]
indices=list(map(tuple,A['T_tau_indices'])); cur=[B.projective(i)for i in range(n)]; R={}; details={}
for m in range(7):
 print('verify level',m,flush=True)
 for i,X in enumerate(cur):
  B.validate(X)
  if(m,i)in indices:R[m,i]=X;_,details[m,i]=B.tau(X,True)
 if m<6:cur=[dual(O.tau(dual(X)))for X in cur]
T=[R[k]for k in indices]
H=[[len(hom(X,Y))for Y in T]for X in T]
assert H==A['Hom']
assert all(details[k]['pd_le_1']for k in indices)
E=integer(inv(tr(B.C)))
assert H==[[sum(X[0][i]*E[i][j]*Y[0][j]for i in range(n)for j in range(n))for Y in T]for X in T]
maps={(i,j):hom(T[j],T[i])[0]for i,j in A['arrows_End']};paths=[]
for i,j in A['arrows_End']:
 stack=[([i,j],maps[i,j])]
 while stack:
  p,f=stack.pop();assert nonzero(f)
  vals=[x for M in f for row in M for x in row];assert all(x.denominator==1 for x in vals)
  content=math.gcd(*(int(x)for x in vals));assert content==1
  paths.append({'path':p,'matrix_content':content})
  for a,b in A['arrows_End']:
   if a==p[-1]:stack.append((p+[b],compose(f,maps[a,b])))
assert set(PIVOTS)<={'1','-1'}
def serrep(R):return {'dimensions':R[0],'arrows':{f'{i},{j}':[[str(x)for x in row]for row in M]for(i,j),M in R[1].items()}}
def sermap(f):return [[[str(x)for x in row]for row in M]for M in f]
out={'source_printed_page':142,'source_pdf_page':156,'vertex_order':['z','a','b1','b2','s','c1','c2','u','v'],'T_tau_indices':indices,'T_representations':[serrep(X)for X in T],'presentations':[details[k]for k in indices],'Hom':H,'Cartan_B':B.C,'Euler_B':E,'End_quiver':A['arrows_End'],'End_arrow_maps':{f'{i},{j}':sermap(f)for(i,j),f in maps.items()},'nonzero_paths':paths,'Gaussian_pivot_set':sorted(set(PIVOTS)),'field_independent':'All Gaussian pivots are units +1/-1 and every path-product matrix has integer content 1.'}
(ROOT/'qa/xii14_exact_certificate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print('presentations',out['presentations']);print('verified',len(paths),'paths, pivots',out['Gaussian_pivot_set'])
