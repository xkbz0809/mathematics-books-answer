from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json
from bound_quiver_exact import Algebra,dual,hom
from ch10_ch11_exact import inv,integer,mm,tr
n=9
# zero based: z,a,b1,b2,s,c1,c2,u,v
arr=[(4,1),(1,0),(4,3),(3,2),(2,0),(4,6),(6,5),(5,0),(5,7),(6,8)]
rels=[[(1,(4,1,0)),(1,(4,3,2,0)),(1,(4,6,5,0))],[(1,(6,5,7))],[(1,(4,6,8))]]
B=Algebra(n,arr,rels);O=B.opposite()
if __name__=='__main__':
 print('Cartan',B.C,flush=True)
 reps={};details={};cur=[B.projective(i)for i in range(n)]
 for m in range(10):
  print('LEVEL',m,[r[0]for r in cur],flush=True)
  for i,R in enumerate(cur):
   B.validate(R);reps[m,i]=R
   back,info=B.tau(R,True);details[m,i]=info
   if m:assert back[0]==reps[m-1,i][0]
  cur=[dual(O.tau(dual(R)))for R in cur]
 def ser(R):return {'d':R[0],'a':{f'{i},{j}':[[str(x)for x in row]for row in M]for (i,j),M in R[1].items()}}
 (ROOT/'qa/xii14_postprojectives.json').write_text(json.dumps({'C':B.C,'representations':{f'{m},{i}':ser(R)for (m,i),R in reps.items()},'presentations':{f'{m},{i}':d for (m,i),d in details.items()}},indent=2),encoding='utf-8')
