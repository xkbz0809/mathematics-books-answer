"""Insert the already verified explicit finite vector tables into chapter XIII."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
data=json.loads((ROOT/'qa/ch13_dimensions.json').read_text('utf-8'))
def tup(v):return '('+','.join(map(str,v))+')^t'
intro=r'''
\paragraph{第 6--12 题共同使用的维数公式.}
若一个秩为 $r$ 的非齐次管，其管口维数按 $\Phi$ 的循环顺序为
$\boldsymbol v=(v_1,\ldots,v_r)$，则 $\sum v_i=h$，而该管内不可分解模的全部维数向量为
\begin{align}\label{sol:XIII:all-dimensions}
 mh\quad(m\ge1),\qquad
 mh+v_i+v_{i+1}+\cdots+v_{i+s-1}
 \quad(m\ge0,\ 1\le s<r,\ i\bmod r).
\end{align}
原因是管中每个不可分解模为正则单列对象，其合成因子按管口循环依次出现；把正则长度除以 $r$，整圈贡献 $mh$，余下连续 $s$ 项贡献所列和. 逆向的循环约定给出的全部连续和集合相同. 齐次管只贡献 $mh$.

以下各题均给出\emph{完整}的管口循环表，故结合\eqref{sol:XIII:all-dimensions} 即为显式的全体维数分类. 为方便复核，同时给出从典范定向到题图的汇点反射顺序. 顺序按从左到右执行，应用第 5 题；每一步仅将第 $a$ 个坐标换成
\begin{align*}(s_ax)_a=\sum_{j\sim a}x_j-x_a.
\end{align*}
正根基向量 $h$ 不变. 表中箭头表示 $\Phi v_i=v_{i+1}$，最后一项回到第一项. 不同管可能产生相同维数 $mh$，所以这里分类的是维数向量，并非声称这些维数唯一决定所有不可分解模.
'''
descriptions={
 6:r'将中心点编号为 $1$，左上、左中、左下、右侧四个叶点依次为 $2,3,4,5$. 箭为 $1\to j$（$2\le j\le5$）. 此时 $h=(2,1,1,1,1)^t$.',
 7:r'沿用第 6 题编号，唯一反向的箭为 $5\to1$. 根基向量仍为 $h=(2,1,1,1,1)^t$. 对第 6 题作汇点 $5$ 处反射，便把末坐标 $x_5$ 换为 $x_1-x_5$.',
 8:r'保留原题 $1,\ldots,6$ 的编号，箭为 $1\to2,3\to2,3\to4,5\to4,5\to6,6\to1$. 根基向量为 $h=(1,1,1,1,1,1)^t$.',
 9:r'将左上、左下两叶编号为 $1,2$，中间横链从左到右为 $3,4,5,6,7$，右上、右下两叶为 $8,9$. 因而箭为 $1\to3,3\to2,3\to4,4\to5,6\to5,6\to7,8\to7,9\to7$.',
 10:r'中心编号为 $1$，左臂从内到外为 $2,3$，右臂从内到外为 $4,5$，上臂从内到外为 $6,7$. 箭为 $1\to2,2\to3,1\to4,5\to4,1\to6,7\to6$.',
 11:r'将横链从左到右编号为 $1,\ldots,7$，上方叶点编号为 $8$. 箭为 $2\to1,2\to3,4\to3,4\to8,4\to5,6\to5,6\to7$.',
 12:r'将横链从左到右编号为 $1,\ldots,8$，上方叶点编号为 $9$. 箭为 $1\to2,2\to3,3\to9,3\to4,4\to5,6\to5,7\to6,7\to8$.'}
canonical={
 6:r'典范定向为 $1\to2,1\to3,4\to1,5\to1$，其管口为四个薄分叉表示、中心单模和全图薄表示（表 XIII.2.6 的 $m=4$ 情形）',
 7:r'从第 6 题再作 $s_5$ 即得本题；或者从典范定向 $1\to2,1\to3,4\to1,5\to1$ 出发',
 8:r'取典范定向 $3\to2\to1$ 与 $3\to4\to5\to6\to1$，两臂长度为 $2,4$；其两个管口循环的向量集合分别为 $\{e_2,h-e_2\}$ 与 $\{e_4,e_5,e_6,h-e_4-e_5-e_6\}$',
 9:r'典范定向为 $3\to1,3\to2,4\to3,5\to4,6\to5,7\to6,8\to7,9\to7$；由表 XIII.2.6 取四个薄分叉向量、$e_3,\ldots,e_7$ 及全 $1$ 向量',
 10:r'取每条臂均指向中心 $1$ 的典范定向，使用表 XIII.2.12 的三组管口向量',
 11:r'取各臂均指向中心 $4$ 的典范定向，使用第 4 题修正后的表 XIII.2.16. 原表顶点 $(1,2,3,4,5,6,7,8)$ 在这里依次改标为 $(4,3,2,1,8,5,6,7)$',
 12:r'取各臂均指向中心 $3$ 的典范定向，使用表 XIII.2.20. 原表顶点 $(1,2,3,4,5,6,7,8,9)$ 在这里依次改标为 $(3,2,1,9,4,5,6,7,8)$'}
pieces=[intro]
for no in range(6,13):
 d=data[str(no)];cycles=sorted(d['mouth_cycles'],key=lambda x:(len(x),x))
 pieces.append(f'\n\\Sol{{XIII}}{{{no}}}\n'+descriptions[no]+'\n')
 if no>=9:pieces.append('正根基向量为\n\\begin{align*}h='+tup(d['h'])+'.\\end{align*}\n')
 pieces.append('全部非齐次管口维数循环如下：\n')
 for j,cyc in enumerate(cycles,1):
  pieces.append('\\begin{align*}\n')
  for k,v in enumerate(cyc):
   pieces.append('v_{'+str(j)+','+str(k+1)+'}&='+tup(v)+(r',\\' if k<len(cyc)-1 else '.')+'\n')
  pieces.append('\\end{align*}\n')
 pieces.append('对每一行循环取\\eqref{sol:XIII:all-dimensions} 中的全部连续和，再加所有 $mh$（$m\\ge1$），就是答案. ')
 pieces.append(f'长度小于管秩的不同连续和共有 ${d["root_count"]}$ 个；上表不要求读者再求解任何未列出的方程.\n\n')
 pieces.append('核验与完备性如下. '+canonical[no]+'，依次在汇点\n\\begin{align*}'+','.join(map(str,d['sink_reflections']))+'\\end{align*}\n反射，即得题图及上述循环（第 7 题也可只执行第 6 题之后的 $s_5$）.\n' if no==7 else '核验与完备性如下. '+canonical[no]+'，依次在汇点\n\\begin{align*}'+','.join(map(str,d['sink_reflections']))+'\\end{align*}\n反射，即得题图及上述循环.\n')
 pieces.append('每个向量的亏量为零、二次型值为 $1$；每个循环的和为 $h$，且相邻项由 Coxeter 变换连接. 反射等价保证这些就是全部非齐次管口，并保留所有齐次管. 因而\\eqref{sol:XIII:all-dimensions} 同时证明所列每个维数都能实现，以及没有遗漏.\n')
 if no==6:
  pieces.append(r'''也可把答案压缩成一条坐标公式：除 $mh$（$m\ge1$）外，全体向量为
\begin{align*}(2m+1,m+\varepsilon_2,m+\varepsilon_3,m+\varepsilon_4,m+\varepsilon_5)^t,
\quad m\ge0,\quad \varepsilon_j\in\{0,1\},\quad\sum_{j=2}^5\varepsilon_j=2.
\end{align*}
''')
 if no==7:
  pieces.append(r'''相应的坐标公式为：除 $mh$（$m\ge1$）外，全体向量为
\begin{align*}&(2m+1,m+\varepsilon_2,m+\varepsilon_3,m+\varepsilon_4,m+\varepsilon_5)^t,\\
&m\ge0,\quad \varepsilon_j\in\{0,1\},\quad\varepsilon_2+\varepsilon_3+\varepsilon_4-\varepsilon_5=1.
\end{align*}
''')
content=''.join(pieces)
p=ROOT/'chapters/ch13.tex';t=p.read_text('utf-8')
if '% DIMENSION_SOLUTIONS_INSERTION' in t:
 t=t.replace('% DIMENSION_SOLUTIONS_INSERTION',content)
else:
 start=t.index(r'\paragraph{第 6--12 题共同使用的维数公式.}')
 end=t.index(r'\Sol{XIII}{13}',start)
 t=t[:start]+content+'\n'+t[end:]
p.write_text(t,'utf-8')
print('Inserted 7 exercise solutions with all explicit mouth vectors.')
