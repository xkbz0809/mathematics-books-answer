from pathlib import Path
import json,itertools,sys
from exact_linear import det,nullspace,primitive,dump
ROOT=Path(__file__).resolve().parents[1]
# Numbering is given by each displayed arrow list; all indices are one-based.
cases={
 6:(9,[(1,2),(2,3),(4,3),(3,5),(5,6),(6,7),(7,8),(6,9)],[(4,9)]),
 7:(8,[(1,4),(2,4),(3,4),(4,5),(4,6),(6,7),(4,8)],[(1,5),(2,8),(3,6),(1,7)]),
 8:(10,[(1,2),(3,4),(5,4),(5,1),(5,7),(6,5),(6,8),(7,9),(8,7),(8,10)],[(6,7),(6,2)]),
 9:(10,[(1,4),(4,7),(4,5),(3,5),(3,6),(6,10),(5,2),(5,9),(8,5),(10,9)],[(1,7),(3,2),(8,9),(3,9)]),
 10:(9,[(2,3),(3,1),(3,5),(7,3),(7,8),(8,6),(6,5),(5,4),(9,7)],[(7,5),(6,4),(9,8),(2,1)]),
 11:(9,[(2,1),(3,2),(3,4),(5,4),(5,8),(4,7),(6,3),(8,7),(8,9)],[(6,4),(5,7)]),
 12:(9,[(1,2),(2,3),(1,8),(8,9),(3,6),(6,9),(4,3),(4,7),(7,6),(5,4)],[(1,9),(4,6),(5,3)])}

def gram(n,arrows,rels):
 G=[[2*int(i==j) for j in range(n)]for i in range(n)]
 for sign,edges in [(-1,arrows),(1,rels)]:
  for a,b in edges:G[a-1][b-1]+=sign;G[b-1][a-1]+=sign
 return G
def q(G,x):return sum(x[i]*G[i][j]*x[j]for i in range(len(x))for j in range(len(x)))//2
def run():
 out={}
 for k,(n,arrows,rels) in cases.items():
  G=gram(n,arrows,rels);v=None
  if k in (7,8,9):
   for x in itertools.product(range(4),repeat=n):
    if any(x) and q(G,x)<=0:v=x;break
  out[k]={'n':n,'arrows':arrows,'relations_endpoints':rels,'G':G,'kernel':[primitive(x)for x in nullspace(G)],'leading_minors':[det([r[:m]for r in G[:m]])for m in range(1,n+1)],'witness':v}
  print(k,dump({a:b for a,b in out[k].items()if a not in ('G','arrows','relations_endpoints')}))
 n,a,r=cases[12];G=gram(n,a,r[:-1])
 out['12base']={'G':G,'kernel':[primitive(x)for x in nullspace(G)],'leading_minors':[det([z[:m]for z in G[:m]])for m in range(1,n+1)]}
 (ROOT/'qa/ch14_bound_forms.json').write_text(json.dumps(dump(out),ensure_ascii=False,indent=2),'utf-8')
if __name__=='__main__':run()
