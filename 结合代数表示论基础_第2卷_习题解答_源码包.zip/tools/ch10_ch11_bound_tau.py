from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json,sys
from ch10_ch11_representations import null,rref,mm,tr,zeros,hom

def cols(M,n):return tr(M) if M else [[] for i in range(n)]
def rank(M,n):return len(rref(M,n)[1])
def solve(A,b):
 n=len(A[0])if A else 0;R,piv=rref([list(r)+[v]for r,v in zip(A,b)],n+1);x=[F(0)]*n
 for r,p in zip(R,piv):
  assert p<n,'inconsistent';x[p]=r[-1]
 return x

def subrep(rep,K):
 d,ar=rep;nd=[len(M[0])if M else 0 for M in K];new={}
 for (a,b),M in ar.items():
  prod=mm(M,K[a]) if M and d[a] else zeros(d[b],nd[a])
  images=[solve(K[b],[row[j]for row in prod])for j in range(nd[a])]
  new[(a,b)]=cols(images,nd[b])
 return nd,new

def incoming_top(rep):
 d,ar=rep;out=[]
 for v in range(len(d)):
  incoming=[]
  for (a,b),M in ar.items():
   if b==v:incoming+=cols(M,d[a])
  basis=list(incoming);old=rank(basis,d[v]);tops=[]
  for j in range(d[v]):
   e=[F(i==j)for i in range(d[v])];r=rank(basis+[e],d[v])
   if r>old:tops.append(e);basis.append(e);old=r
  out.append(tops)
 return out

def allpaths(n,ar):
 paths={(i,i):[i]for i in range(n)};changed=True
 while changed:
  changed=False
  for (i,j),p in list(paths.items()):
   for a,b in ar:
    if a==j and(i,b)not in paths:paths[(i,b)]=p+[b];changed=True
 return paths

def evalpath(rep,p,v):
 for a,b in zip(p,p[1:]):v=[sum(x*y for x,y in zip(row,v))for row in rep[1][(a,b)]]
 return v

def projective_cover(rep,C,paths):
 d,ar=rep;tops=incoming_top(rep);gens=[(i,g)for i,T in enumerate(tops)for g in T];supports=[[k for k,(i,g)in enumerate(gens)if C[v][i]]for v in range(len(d))]
 coverd=list(map(len,supports));coverar={};maps=[]
 for v in range(len(d)):
  images=[evalpath(rep,paths[(gens[k][0],v)],gens[k][1])for k in supports[v]]
  maps.append(cols(images,d[v]))
 for a,b in ar:coverar[(a,b)]=[[F(i==j)for j in supports[a]]for i in supports[b]]
 return (coverd,coverar),maps,gens,supports

def tau(rep,C):
 n=len(C);paths=allpaths(n,rep[1]);P0,cover,g0,s0=projective_cover(rep,C,paths)
 K=[cols(null(M,P0[0][v]),len(null(M,P0[0][v])))for v,M in enumerate(cover)]
 # K should have ambient dimension P0(v) rows and nullity columns.
 K=[tr(null(M,P0[0][v])) if null(M,P0[0][v]) else zeros(P0[0][v],0)for v,M in enumerate(cover)]
 ker=subrep(P0,K);P1,cv1,g1,s1=projective_cover(ker,C,paths)
 assert P1[0]==ker[0],('kernel not projective',P1[0],ker[0])
 # coefficient of path top(P0) -> top(P1) in the presentation.
 coeff=zeros(len(g0),len(g1))
 for k,(i,g)in enumerate(g1):
  amb=[sum(x*y for x,y in zip(row,g))for row in K[i]]
  for a,c in zip(s0[i],amb):coeff[a][k]=c
 # injective summands and the Nakayama image map.
 si0=[[k for k,(i,g)in enumerate(g0)if C[i][v]]for v in range(n)]
 si1=[[k for k,(i,g)in enumerate(g1)if C[i][v]]for v in range(n)]
 I1d=list(map(len,si1));I1ar={(a,b):[[F(i==j)for j in si1[a]]for i in si1[b]]for a,b in rep[1]}
 nu=[[[coeff[a][b]for b in si1[v]]for a in si0[v]]for v in range(n)]
 L=[tr(null(M,I1d[v]))if null(M,I1d[v])else zeros(I1d[v],0)for v,M in enumerate(nu)]
 T=subrep((I1d,I1ar),L)
 return T,{'P0':[i+1 for i,g in g0],'P1':[i+1 for i,g in g1],'presentation_coefficients':[[str(x)for x in row]for row in coeff]}

def thin(n,edges,v):return list(v),{(a-1,b-1):[[F(1)]]if v[a-1]and v[b-1]else zeros(v[b-1],v[a-1])for a,b in edges}
if __name__=='__main__':
 (ROOT/'qa').mkdir(exist_ok=True)
 data=json.loads((ROOT/'qa/ch10_ch11_exact.json').read_text());out={}
 specs={
 'XI8':(6,[(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[[[0,1,1,1,0,0],[0,0,0,0,0,1],[1,0,1,0,1,0]],[[0,0,1,1,1,1],[1,1,1,0,0,0]],[[1,1,1,1,1,1],[0,0,1,0,0,0]]]),
 'XI9':(7,[(1,7),(7,2),(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[[[0,0,0,0,0,0,1],[0,1,1,1,0,0,0],[0,0,0,0,0,1,0],[1,0,1,0,1,0,0]],[[0,0,1,0,0,0,0],[1,1,1,1,1,1,1]],[[0,0,1,1,1,1,0],[1,1,1,0,0,0,1]]]),
 'XI10':(7,[(1,2),(5,2),(5,6),(2,3),(3,4),(3,7),(6,7)],[[[0,1,1,0,1,1,1],[1,1,1,1,0,0,0]],[[1,1,1,1,1,1,1],[0,1,0,0,0,0,0],[0,0,1,0,0,0,0]],[[0,1,1,1,1,0,0],[0,0,0,0,0,1,0],[1,1,1,0,0,0,1]]])}
 for key,(n,edges,cycles)in specs.items():
  rows=[]
  for cycle in cycles:
   reps=[thin(n,edges,v)for v in cycle]
   orth=[[len(hom(M,N))for N in reps]for M in reps];assert orth==[[int(i==j)for j in range(len(reps))]for i in range(len(reps))]
   for i,M in enumerate(reps):
    T,proof=tau(M,data[key]['C']);N=reps[(i+1)%len(reps)];H=hom(T,N)
    assert T[0]==N[0]and len(H)==1 and all(H[0][v][0][0]for v,x in enumerate(T[0])if x),(key,M[0],T[0],N[0])
    proof.update({'dimension':M[0],'tau_dimension':T[0],'iso_vertex_scalars':[str(H[0][v][0][0])for v,x in enumerate(T[0])if x]});rows.append(proof)
  out[key]=rows;print(key,'DTr and orthogonality verified',len(rows))
 (ROOT/'qa/ch10_ch11_bound_tau.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
