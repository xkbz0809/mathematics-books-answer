"""Exact Gaussian elimination over Q(t), recording only pivots invertible
over every field when t != 0,1. No numerical parameter sampling is used."""
from fractions import Fraction as F
def trim(a):
 a=list(map(F,a))
 while len(a)>1 and not a[-1]:a.pop()
 return tuple(a)
def add(a,b):return trim([(a[i]if i<len(a)else 0)+(b[i]if i<len(b)else 0)for i in range(max(len(a),len(b)))])
def neg(a):return tuple(-x for x in a)
def mul(a,b):
 c=[F(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def divrem(a,b):
 a=list(a);q=[F(0)]*max(1,len(a)-len(b)+1)
 while len(a)>=len(b) and any(a):
  k=len(a)-len(b);z=a[-1]/b[-1];q[k]=z
  for i,x in enumerate(b):a[k+i]-=z*x
  a=list(trim(a))
 return trim(q),trim(a)
def gcd(a,b):
 while any(b):a,b=b,divrem(a,b)[1]
 return tuple(x/a[-1]for x in a)
class RF:
 def __init__(self,n=0,d=(1,)):
  if isinstance(n,RF):self.n,self.d=n.n,n.d;return
  if not isinstance(n,(tuple,list)):n=(n,)
  n=trim(n);d=trim(d);assert any(d)
  if not any(n):self.n,self.d=(F(0),),(F(1),);return
  g=gcd(n,d);n=divrem(n,g)[0];d=divrem(d,g)[0];z=d[-1]
  self.n,self.d=tuple(x/z for x in n),tuple(x/z for x in d)
 def __bool__(self):return any(self.n)
 def __neg__(self):return RF(neg(self.n),self.d)
 def __add__(self,o):
  o=RF(o);return RF(add(mul(self.n,o.d),mul(o.n,self.d)),mul(self.d,o.d))
 __radd__=__add__
 def __sub__(self,o):return self+-RF(o)
 def __rsub__(self,o):return RF(o)+-self
 def __mul__(self,o):
  o=RF(o);return RF(mul(self.n,o.n),mul(self.d,o.d))
 __rmul__=__mul__
 def __truediv__(self,o):
  o=RF(o);return RF(mul(self.n,o.d),mul(self.d,o.n))
 def __eq__(self,o):o=RF(o);return self.n==o.n and self.d==o.d
 def __str__(self):return str([str(x)for x in self.n])+'/'+str([str(x)for x in self.d])
 def allowed(self):
  for p in(self.n,self.d):
   if not any(p):return False
   while len(p)>1 and not p[0]:p=p[1:]
   while len(p)>1 and sum(p)==0:p=divrem(p,(-1,1))[0]
   if len(p)!=1 or p[0] not in (1,-1):return False
  return True
T=RF((0,1));PIVOTS=[]
def rr(A,n):
 A=[[RF(x)for x in row]for row in A];piv=[];i=0;cols=list(range(n))
 while i<min(len(A),n):
  cand=[(r,c)for r in range(i,len(A))for c in range(i,n)if A[r][c]and A[r][c].allowed()]
  if not cand:
   assert not any(A[r][c]for r in range(i,len(A))for c in range(i,n)), 'need nonunit pivot'
   break
  r,c=min(cand,key=lambda p:len(A[p[0]][p[1]].n)+len(A[p[0]][p[1]].d))
  A[i],A[r]=A[r],A[i]
  for row in A:row[i],row[c]=row[c],row[i]
  cols[i],cols[c]=cols[c],cols[i]
  p=A[i][i];PIVOTS.append(str(p));A[i]=[x/p for x in A[i]]
  for j in range(len(A)):
   if j!=i and A[j][i]:
    z=A[j][i];A[j]=[x-z*y for x,y in zip(A[j],A[i])]
  piv.append(cols[i]);i+=1
 return A,cols,i
def null(A,n):
 A,cols,r=rr(A,n);ans=[]
 for j in range(r,n):
  v=[RF(0)for _ in range(n)];v[cols[j]]=RF(1)
  for i in range(r):v[cols[i]]=-A[i][j]
  ans.append(v)
 return ans
def tr(A):return list(map(list,zip(*A)))
def mm(A,B):return [[sum(x*y for x,y in zip(row,col))for col in zip(*B)]for row in A]
def eye(n):return [[RF(i==j)for j in range(n)]for i in range(n)]
def zeros(r,c):return [[RF(0)for _ in range(c)]for _ in range(r)]
def flag_hom(M,N):
 # Lists of embedding matrices into the central spaces, first entry identity.
 dm=len(M[0]);dn=len(N[0]);eq=[]
 for U,V in zip(M,N):
  annih=null(tr(V),dn)
  for a in annih:
   for u in tr(U):eq.append([a[i]*u[j]for i in range(dn)for j in range(dm)])
 return null(eq,dm*dn)
