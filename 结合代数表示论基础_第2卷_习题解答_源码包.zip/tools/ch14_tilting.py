from pathlib import Path
import json,itertools
from ch10_ch11_exact import data,inv,tr,mm,pair
from ch10_ch11_representations import postprojs,hom,compose,nonzero,ratio,serial,PIVOTS,null
ROOT=Path(__file__).resolve().parents[1]

def candidates(A,B,maxm,number=5):
 n=len(A['C']);Pi=inv(A['Phi']);E=A['E'];ds=tr(A['C']);cs=[]
 for m in range(maxm+1):
  for i,d in enumerate(ds):cs.append((m,i+1,tuple(map(int,d))))
  ds=tr(mm(Pi,tr(ds)))
 def hh(a,b):
  m,i,x=a;t,j,y=b
  if m>t:return 0
  z=list(y)
  for k in range(m):z=[sum(row[t]*z[t] for t in range(len(z)))for row in A['Phi']]
  return z[i-1]
 H=[[hh(a,b)for b in cs]for a in cs]
 Ex=[[H[i][j]-pair(a[2],E,b[2])for j,b in enumerate(cs)]for i,a in enumerate(cs)]
 C=B['C'];out=[];chosen=[];seen=set()
 def rec(k):
  if k==n:
   key=tuple(sorted(chosen))
   if key not in seen:out.append([cs[c]for c in chosen]);seen.add(key)
   return len(out)>=number
  for c,a in enumerate(cs):
   if c in chosen or H[c][c]!=1 or Ex[c][c]:continue
   if any(H[x][c]!=C[j][k]or H[c][x]!=C[k][j]or Ex[x][c]or Ex[c][x]for j,x in enumerate(chosen)):continue
   chosen.append(c)
   if rec(k+1):return True
   chosen.pop()
  return False
 rec(0);return out

def certify(n,arr,barr,rel,keys):
 A=data(n,arr);B=data(n,barr,[(p[0],p[-1])for p in rel[:1]])
 reps=postprojs(n,[(a-1,b-1)for a,b in arr],max(m for m,i in keys))
 T=[reps[tuple(k)]for k in keys];HB=[[hom(x,y)for y in T]for x in T];H=[[len(x)for x in row]for row in HB]
 assert H==B['C'],(keys,'Hom mismatch',H,B['C'])
 Ext=[[H[i][j]-pair(x[0],A['E'],y[0])for j,y in enumerate(T)]for i,x in enumerate(T)]
 assert not any(z for row in Ext for z in row)
 maps={(a,b):HB[b-1][a-1][0]for a,b in barr}
 def pm(p):
  f=maps[(p[-2],p[-1])]
  for k in range(len(p)-3,-1,-1):f=compose(maps[(p[k],p[k+1])],f)
  return f
 fp=[pm(p)for p in rel];flat=[[x for M in f for row in M for x in row]for f in fp]
 coeff=null(tr(flat),len(rel));assert len(coeff)==1 and all(coeff[0]),coeff
 # Every pair of canonical branches spans Hom(T_sink,T_source).
 assert len(HB[rel[0][-1]-1][rel[0][0]-1])==2
 paths=[[a,b]for a,b in barr];at=0
 while at<len(paths):
  p=paths[at];paths.extend(p+[b]for a,b in barr if a==p[-1]);at+=1
 assert all(nonzero(pm(p))for p in paths)
 return {'summands':keys,'dimensions':[x[0]for x in T],'Hom':H,'Ext1':Ext,'branch_dependency':list(map(str,coeff[0])),'representations':[serial(t)for t in T],'arrows':{f'{a}->{b}':[[[str(x)for x in row]for row in M]for M in f]for (a,b),f in maps.items()},'all_paths_nonzero':True}

def run():
 out={}
 for n,arr,maxm,paths in [(6,[(3,1),(3,2),(4,3),(5,4),(6,4)],3,[[6,2,1],[6,3,1],[6,5,4,1]]),(7,[(3,1),(3,2),(4,3),(5,4),(6,5),(7,5)],4,[[7,2,1],[7,3,1],[7,6,5,4,1]])]:
  barr=[edge for p in paths for edge in zip(p,p[1:])];A=data(n,arr);B=data(n,barr,[(n,1)])
  found=candidates(A,B,maxm,5);out[n]=[]
  for cand in found:
   keys=[(m,i)for m,i,d in cand];print(n,keys,flush=True)
   cert=certify(n,arr,barr,paths,keys);out[n].append(cert);print('verified',cert['branch_dependency'],flush=True)
 out['pivots']=sorted(set(PIVOTS))
 (ROOT/'qa/ch14_tilting.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
if __name__=='__main__':run()
