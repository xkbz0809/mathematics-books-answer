"""Check the closed row formulas in XII.2 against exact matrix inversion."""
from pathlib import Path
import json
from ch10_ch11_exact import data
ROOT=Path(__file__).resolve().parents[1]
records=[]
for p,q,r in [(2,2,m-2)for m in range(4,13)]+[(2,3,3),(2,3,4),(2,3,5)]:
 n=p+q+r-1;arms=[];nextv=1
 for s in (p,q,r):arms.append(list(range(nextv,nextv+s-1)));nextv+=s-1
 w=n-1;arr=[]
 for a in arms:
  vertices=[w]+list(reversed(a))+[0];arr+=list(zip(vertices,vertices[1:]))
 D=data(n,[(a+1,b+1)for a,b in arr],[(w+1,1)])
 Phi=[[0]*n for i in range(n)]
 Phi[0][0]=-1;Phi[0][w]=-1
 for arm in arms:Phi[0][arm[0]]=1
 for a in arms:
  for k,i in enumerate(a):
   Phi[i][0]-=1;Phi[i][w]-=1
   for b in arms:
    if b!=a:Phi[i][b[0]]+=1
   Phi[i][a[k+1]if k+1<len(a)else w]+=1
 Phi[w][0]=-2
 for a in arms:Phi[w][a[0]]+=1
 assert D['Phi']==Phi
 assert all(sum(row)==1 for row in Phi)
 records.append({'pqr':[p,q,r],'n':n,'Cartan':D['C'],'Phi':Phi,'fixed_all_ones':True})
(ROOT/'qa/ch12_coxeter_check.json').write_text(json.dumps(records,indent=2),'utf-8')
print('Closed Coxeter row formulas and fixed radical vector verified for',len(records),'instances.')
