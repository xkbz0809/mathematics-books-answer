#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ "${1:-full}" != "full" ]]; then
  echo 'Usage: bash tools/build.sh full' >&2
  exit 2
fi
cd -- "$task_root"
python3 -B -X utf8 tools/build.py main --out-dir build/release
