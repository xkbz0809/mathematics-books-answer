"""Finite acyclic bound quiver representations over exact rational arithmetic."""
from fractions import Fraction as F
from collections import defaultdict
from ch10_ch11_representations import zeros,rref,null,tr,mm,hom
from ch10_ch11_bound_tau import incoming_top,subrep,evalpath

class Algebra:
 def __init__(self,n,arrows,relations):
  self.n=n;self.arrows=arrows;self.relations=relations
  paths=[(i,)for i in range(n)];k=0
  while k<len(paths):
   p=paths[k];paths.extend(p+(b,)for a,b in arrows if a==p[-1]);k+=1
  by=defaultdict(list)
  for p in paths:by[p[0],p[-1]].append(p)
  rels=defaultdict(list)
  for relation in relations:
   start=relation[0][1][0];end=relation[0][1][-1]
   for pre in paths:
    if pre[-1]!=start:continue
    for post in paths:
     if post[0]!=end:continue
     row=defaultdict(F)
     for c,p in relation:row[pre[:-1]+tuple(p)+post[1:]]+=F(c)
     rels[pre[0],post[-1]].append(row)
  self.basis={};self.red={}
  for ij,ps in by.items():
   rows=[[r[p]for p in ps]for r in rels[ij]];R,piv=rref(rows,len(ps));free=[j for j in range(len(ps))if j not in piv]
   self.basis[ij]=[ps[j]for j in free]
   for j,p in enumerate(ps):
    v=[F(0)]*len(free)
    if j in free:v[free.index(j)]=F(1)
    else:
     k=piv.index(j)
     for a,b in enumerate(free):v[a]=-R[k][b]
    self.red[p]=v
  self.C=[[len(self.basis.get((i,j),[]))for i in range(n)]for j in range(n)]
 def opposite(self):return Algebra(self.n,[(b,a)for a,b in self.arrows],[[(c,tuple(reversed(p)))for c,p in r]for r in self.relations])
 def projective(self,i):
  d=[len(self.basis.get((i,v),[]))for v in range(self.n)];ar={}
  for a,b in self.arrows:
   cs=[self.red[p+(b,)]for p in self.basis.get((i,a),[])]
   ar[a,b]=tr(cs)if cs else zeros(d[b],0)
  return d,ar
 def injective(self,i):
  d=[len(self.basis.get((v,i),[]))for v in range(self.n)];ar={}
  for a,b in self.arrows:
   ar[a,b]=[self.red[(a,)+p]for p in self.basis.get((b,i),[])]
  return d,ar
 def cover(self,rep):
  d,ar=rep;tops=incoming_top(rep);gens=[(i,g)for i,L in enumerate(tops)for g in L]
  slots=[[(k,p)for k,(i,g)in enumerate(gens)for p in self.basis.get((i,v),[])]for v in range(self.n)]
  pd=list(map(len,slots));pa={};f=[]
  for v in range(self.n):
   cs=[evalpath(rep,list(p),gens[k][1])for k,p in slots[v]];f.append(tr(cs)if cs else zeros(d[v],0))
  for a,b in self.arrows:
   mat=zeros(pd[b],pd[a]);off={}
   for t,(k,p)in enumerate(slots[b]):off[k,p]=t
   for j,(k,p)in enumerate(slots[a]):
    i=gens[k][0]
    for q,c in zip(self.basis.get((i,b),[]),self.red[p+(b,)]):mat[off[k,q]][j]=c
   pa[a,b]=mat
  return (pd,pa),f,gens,slots
 def tau(self,rep,details=False):
  P0,f0,g0,s0=self.cover(rep)
  K=[tr(null(M,P0[0][v]))if null(M,P0[0][v])else zeros(P0[0][v],0)for v,M in enumerate(f0)]
  ker=subrep(P0,K);P1,f1,g1,s1=self.cover(ker)
  coeff={}
  for j,(i,g)in enumerate(g1):
   amb=[sum(x*y for x,y in zip(row,g))for row in K[i]]
   for (k,p),c in zip(s0[i],amb):
    if c:coeff[k,j,p]=c
  si0=[[(k,p)for k,(i,g)in enumerate(g0)for p in self.basis.get((v,i),[])]for v in range(self.n)]
  si1=[[(k,p)for k,(i,g)in enumerate(g1)for p in self.basis.get((v,i),[])]for v in range(self.n)]
  id1=list(map(len,si1));ia={}
  for a,b in self.arrows:
   M=zeros(id1[b],id1[a]);idx={s:k for k,s in enumerate(si1[a])}
   for row,(k,p)in enumerate(si1[b]):
    for q,c in zip(self.basis[(a,g1[k][0])],self.red[(a,)+p]):M[row][idx[k,q]]=c
   ia[a,b]=M
  nu=[]
  for v in range(self.n):
   M=zeros(len(si0[v]),len(si1[v]));idx={s:k for k,s in enumerate(si1[v])}
   for row,(k,q)in enumerate(si0[v]):
    for (a,b,p),c in coeff.items():
     if a!=k:continue
     cat=q+p[1:]
     for z,w in zip(self.basis[v,g1[b][0]],self.red[cat]):M[row][idx[b,z]]+=c*w
   nu.append(M)
  L=[tr(null(M,id1[v]))if null(M,id1[v])else zeros(id1[v],0)for v,M in enumerate(nu)]
  T=subrep((id1,ia),L)
  if details:return T,dict(P0=[i for i,g in g0],P1=[i for i,g in g1],pd_le_1=P1[0]==ker[0])
  return T
 def validate(self,rep):
  d,ar=rep
  for r in self.relations:
   a=r[0][1][0];b=r[0][1][-1];M=zeros(d[b],d[a])
   for c,p in r:
    for j in range(d[a]):
     v=[F(i==j)for i in range(d[a])];w=evalpath(rep,p,v)
     for i,x in enumerate(w):M[i][j]+=c*x
   assert not any(x for row in M for x in row)
  return True

def dual(rep):
 d,ar=rep
 return d,{(b,a):tr(M)if M else zeros(d[a],d[b])for (a,b),M in ar.items()}
