from fractions import Fraction as F
from itertools import product
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def tr(A):return list(map(list,zip(*A)))
def mm(A,B):return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def eye(n):return [[int(i==j) for j in range(n)] for i in range(n)]
def inv(A):
 n=len(A);M=[[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(A)]
 for j in range(n):
  k=next(k for k in range(j,n) if M[k][j]);M[j],M[k]=M[k],M[j];c=M[j][j];M[j]=[x/c for x in M[j]]
  for k in range(n):
   if k!=j:
    c=M[k][j];M[k]=[a-c*b for a,b in zip(M[k],M[j])]
 return [row[n:] for row in M]
def integer(A):return [[int(x) if x.denominator==1 else str(x) for x in row] for row in A]
def cartan(n,arrows,relations=[]):
 N=[[0]*n for i in range(n)]
 for i,j in arrows:N[i-1][j-1]+=1
 E=eye(n)
 for i in range(n):
  for j in range(n):E[i][j]-=N[i][j]
 for i,j in relations:E[i-1][j-1]+=1
 return integer(inv(tr(E))),E

def data(n,arrows,relations=[]):
 C,E=cartan(n,arrows,relations);Phi=[[-x for x in row] for row in mm(tr(C),inv(C))]
 return dict(C=C,E=E,Phi=integer(Phi))
def pair(x,E,y):return sum(x[i]*E[i][j]*y[j] for i in range(len(x)) for j in range(len(x)))
def tilts(A,B,maxm=3):
 n=len(A['C']);Pi=inv(A['Phi']);E=A['E'];ds=tr(A['C']);candidates=[]
 for m in range(maxm+1):
  for i,d in enumerate(ds):candidates.append((m,i+1,tuple(map(int,d))))
  ds=tr(mm(Pi,tr(ds)))
 def hom(a,b):
  m,i,x=a;n,j,y=b
  if m>n:return 0
  z=list(y)
  for k in range(m):z=[sum(row[t]*z[t] for t in range(len(z))) for row in A['Phi']]
  return z[i-1]
 H=[[hom(a,b) for b in candidates]for a in candidates]
 Ex=[[H[i][j]-pair(a[2],E,b[2]) for j,b in enumerate(candidates)]for i,a in enumerate(candidates)]
 C=B['C'];out=[];chosen=[]
 def rec(k):
  if k==n:
   out.append([candidates[c] for c in chosen]);return len(out)>=3
  for c,a in enumerate(candidates):
   if c in chosen or H[c][c]!=1 or Ex[c][c]:continue
   if any(H[x][c]!=C[j][k] or H[c][x]!=C[k][j] or Ex[x][c] or Ex[c][x] for j,x in enumerate(chosen)):continue
   chosen.append(c)
   if rec(k+1):return True
   chosen.pop()
  return False
 rec(0)
 return out

if __name__ == "__main__":
 (ROOT/'qa').mkdir(exist_ok=True)
 A5=data(6,[(3,1),(3,2),(4,3),(5,4),(6,4)])
 A6=data(7,[(3,1),(3,2),(4,3),(5,4),(6,5),(7,5)])
 AE=data(7,[(3,2),(2,1),(5,4),(4,1),(7,6),(6,1)])
 B8=data(6,[(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[(4,5)])
 B9=data(7,[(1,7),(7,2),(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[(1,2),(4,5)])
 B10=data(7,[(1,2),(5,2),(5,6),(2,3),(3,4),(3,7),(6,7)],[(5,7)])
 A4=data(5,[(1,2),(1,3),(5,2),(5,4),(4,3)])
 result={'XI6':A4,'XI7':A5,'XI8':B8,'XI9':B9,'XI10':B10,'sourceA8':A5,'sourceA9':A6,'sourceA10':AE}
 for key,A,B in [('XI8',A5,B8),('XI9',A6,B9),('XI10',AE,B10)]:
  result[key]['tilting_candidates']=tilts(A,B,4)
  print(key,result[key]['tilting_candidates'],flush=True)
 for name,A,h in [('XI6',A4,[1]*5),('XI7',A5,[1,1,2,2,1,1])]:
  P=eye(len(h))
  for d in range(1,25):
   P=mm(P,A['Phi']);N=[[P[i][j]-int(i==j) for j in range(len(h))]for i in range(len(h))]
   coeff=N[0]
   if any(coeff) and all(N[i][j]==h[i]*coeff[j] for i in range(len(h))for j in range(len(h))):
    A['defect_number']=d;A['defect']=coeff;break
 (ROOT/'qa/ch10_ch11_exact.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
