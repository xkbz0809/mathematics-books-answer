"""Check full exercise coverage, rendered anchors, references and preservation.

This check does not claim mathematical or visual proofreading. Its JSON records
those limits explicitly. Run from anywhere; relative arguments are project-local.
"""
from pathlib import Path
import argparse, collections, hashlib, json, re, sys
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {'X': 8, 'XI': 10, 'XII': 14, 'XIII': 13, 'XIV': 16}
EXPECTED_IDS = [f'{ch}.{i}' for ch, n in EXPECTED.items() for i in range(1, n+1)]

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def local(path):
    p = Path(path)
    return p if p.is_absolute() else ROOT/p

def without_comments(s):
    return '\n'.join(re.split(r'(?<!\\)%', line, maxsplit=1)[0] for line in s.splitlines())

def active_sources(path, files, missing, stack=()):
    if path in stack:
        missing.append('recursive input: ' + str(path)); return ''
    if not path.exists():
        missing.append(str(path)); return ''
    s = without_comments(path.read_text(encoding='utf-8'))
    files.append(path.relative_to(ROOT).as_posix())
    def expand(m):
        name = m.group(1)
        if '\\' in name or '#' in name: return m.group(0)
        p = ROOT/name
        if not p.suffix: p = p.with_suffix('.tex')
        return active_sources(p, files, missing, stack+(path,))
    return re.sub(r'\\(?:input|include)\s*\{([^{}]+)\}', expand, s)

def parse_map(path, prefix):
    s = path.read_text(encoding='utf-8')
    return dict(re.findall(r'\\csname '+prefix+r'@([^\\]+)\\endcsname\{([^{}]+)\}', s))

def normalize(s): return re.sub(r'\s+', '', s)

def main():
    global EXPECTED, EXPECTED_IDS
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--entry', default='main.tex')
    ap.add_argument('--chapters', default='X,XI,XII,XIII,XIV', help='explicit unit-check scope; default is the complete book')
    ap.add_argument('--pdf', default='build/release/main.pdf')
    ap.add_argument('--aux', default='build/release/main.aux')
    ap.add_argument('--log', default='build/release/main.log')
    ap.add_argument('--reference-dir', default=str(ROOT.parent), help='directory beside the released solutions PDF')
    ap.add_argument('--check-preservation', action='store_true', help='require and hash all original protected files')
    ap.add_argument('--source-only', action='store_true')
    ap.add_argument('--output', default='qa/final_verification.json')
    args = ap.parse_args()
    chosen=args.chapters.split(',')
    if any(ch not in EXPECTED for ch in chosen) or len(chosen)!=len(set(chosen)):
        ap.error('--chapters must list distinct chapter names from X,XI,XII,XIII,XIV')
    EXPECTED={ch:EXPECTED[ch] for ch in chosen}
    EXPECTED_IDS=[f'{ch}.{i}'for ch,n in EXPECTED.items()for i in range(1,n+1)]
    failures, files, missing = [], [], []
    s = active_sources(local(args.entry), files, missing)
    ids = [f'{c}.{i}' for c,i in re.findall(r'\\Sol\{([XIV]+)\}\{(\d+)\}', s)]
    counts = collections.Counter(x.split('.')[0] for x in ids)
    duplicate_ids = [x for x,c in collections.Counter(ids).items() if c>1]
    if ids != EXPECTED_IDS: failures.append('exercise coverage or order differs from the requested manifest')
    if missing: failures.append('missing or recursive TeX input')
    placeholders = re.findall(r'(?i)\bTODO\b|\bTBD\b|[A-Z_]*(?:_INSERTION|_PLACEHOLDER)|待补(?:充|写)|尚未完成|此处略去证明', s)
    if placeholders: failures.append('unresolved placeholder phrase in active TeX sources')
    bookmap, volmap = parse_map(ROOT/'book_links.tex','BookTwo'), parse_map(ROOT/'volume1_links.tex','VolOne')
    bookrefs = {x for x in re.findall(r'\\bookref\{([^{}]+)\}',s) if '#' not in x} | {f'{c}:ex{i}' for c,i in re.findall(r'\\Sol\{([XIV]+)\}\{(\d+)\}',s)}
    volrefs = {x for x in re.findall(r'\\volone\{([^{}]+)\}',s) if '#' not in x}
    badbook, badvol = sorted(bookrefs-bookmap.keys()), sorted(volrefs-volmap.keys())
    if badbook or badvol: failures.append('external reference key missing from its mapping')
    report = {
        'purpose': 'structural and rendered navigation checks; not a substitute for mathematical or visual review',
        'expected': EXPECTED, 'source_files': files, 'missing_inputs': missing,
        'exercise_ids': ids, 'exercise_counts': dict(counts), 'exercise_total':len(ids),
        'duplicate_exercise_ids': duplicate_ids, 'placeholder_matches':placeholders,
        'references': {'volume2_distinct':len(bookrefs),'volume1_distinct':len(volrefs),
            'unmapped_volume2':badbook,'unmapped_volume1':badvol},
    }
    if not args.source_only:
        import pymupdf
        pdf, aux, log = local(args.pdf), local(args.aux), local(args.log)
        if not all(p.exists() for p in (pdf,aux,log)):
            failures.append('PDF, aux or log is missing')
        else:
            a=aux.read_text(encoding='utf-8'); lg=log.read_text(encoding='utf-8',errors='replace')
            labels=set(re.findall(r'\\newlabel\{([^{}]+)\}',a))
            required_labels={f'sol:{c}:{i}'for c,n in EXPECTED.items()for i in range(1,n+1)}
            refs={x for x in re.findall(r'\\(?:ref|eqref|pageref)\*?\{([^{}]+)\}',s) if '#' not in x}
            unresolved=sorted(refs-labels)
            if required_labels-labels: failures.append('missing compiled exercise labels')
            if unresolved: failures.append('unresolved local reference keys')
            issues=[line for line in lg.splitlines() if any(p in line for p in (
                'LaTeX Warning: Reference','LaTeX Warning: Citation','There were undefined references',
                'multiply defined','Missing character:','Overfull \\hbox','Overfull \\vbox','! LaTeX Error'))]
            if issues: failures.append('final build log has a missing reference, glyph, error or overflow')
            doc=pymupdf.open(pdf); names=doc.resolve_names(); toc=doc.get_toc(False)
            headings=[]; badanchors=[]
            for level,title,page,dest in toc:
                ident=re.fullmatch(r'习题\s*([XIV]+)\.(\d+)',title)
                if not ident: continue
                sid=f'{ident[1]}.{ident[2]}'; headings.append(sid)
                pi=page-1; matches=[]
                if 0<=pi<len(doc):
                    for b in doc[pi].get_text('dict')['blocks']:
                        for line in b.get('lines',[]):
                            text=''.join(z['text']for z in line['spans'])
                            if normalize(text)==f'习题{sid}':matches.append(line['bbox'])
                nd=names.get(dest.get('nameddest',''),{})
                # MuPDF resolves PDF named-destination y in bottom-origin coordinates.
                y=doc[pi].rect.height-nd['to'][1] if nd.get('to') and 0<=pi<len(doc) else None
                ok=nd.get('page')==pi and any(y is not None and -4<=box[1]-y<=30 for box in matches)
                if not ok:badanchors.append({'exercise':sid,'page':page,'destination':dest.get('nameddest'),'heading_boxes':matches,'target_y_from_top':y})
            if headings!=EXPECTED_IDS: failures.append('exercise bookmarks do not match the requested exercises in order')
            if badanchors: failures.append('exercise bookmark fails rendered heading/anchor check')
            internal_bad=[]; external=[]; target_cache={}; external_bad=[]; external_missing=[]
            refdir=Path(args.reference_dir)
            for pi,page in enumerate(doc):
                for link in page.get_links():
                    if link.get('nameddest') and link['nameddest'] not in names:
                        internal_bad.append({'page':pi+1,'destination':link['nameddest']})
                    target=link.get('file')
                    if not target:continue
                    target=unquote(target);external.append(target)
                    filename,sep,fragment=target.partition('#')
                    if not sep or not fragment.startswith('nameddest='):continue
                    targetpath=(refdir/filename).resolve(); dest=fragment[len('nameddest='):]
                    if not targetpath.exists():external_missing.append(str(targetpath));continue
                    if targetpath not in target_cache:
                        with pymupdf.open(targetpath)as td:target_cache[targetpath]=set(td.resolve_names())
                    if dest not in target_cache[targetpath]:external_bad.append({'file':str(targetpath),'destination':dest})
            if internal_bad or external_bad:failures.append('compiled PDF link names a nonexistent destination')
            report['build']={'pdf':str(pdf),'sha256':sha256(pdf),'pages':len(doc),'compiled_solution_labels':len(required_labels&labels),'missing_solution_labels':sorted(required_labels-labels),'unresolved_local_references':unresolved,'log_issues':issues}
            report['navigation']={'bookmarks_total':len(toc),'exercise_bookmarks':headings,'bad_heading_anchors':badanchors,'bad_internal_links':internal_bad,'external_link_annotations':len(external),'external_targets_verified':sum(len(v)for v in target_cache.values()),'bad_external_destinations':external_bad,'external_pdf_files_unavailable':sorted(set(external_missing)),'external_availability_note':'Missing reference PDFs are allowed for independent source builds; existing destinations are verified when available.'}
            doc.close()
    protected=ROOT/'qa/input_preservation.json'
    if protected.exists():
        status={}
        for name,expected in json.loads(protected.read_text('utf-8')).items():
            p=Path(args.reference_dir)/name
            if p.exists():
                actual=sha256(p);status[name]={'expected':expected,'actual':actual,'unchanged':actual==expected}
                if actual!=expected:failures.append('protected input changed: '+name)
            else:
                status[name]={'available':False}
                if args.check_preservation:failures.append('protected input missing: '+name)
        report['protected_inputs']=status
    elif args.check_preservation:failures.append('input preservation manifest missing')
    report['failures']=failures;report['passed']=not failures
    out=local(args.output);out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps({'passed':report['passed'],'exercise_total':len(ids),'failures':failures,'report':str(out)},ensure_ascii=False))
    return int(bool(failures))

if __name__=='__main__':raise SystemExit(main())
