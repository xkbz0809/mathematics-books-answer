"""Create a small, independently buildable upload package; never delete inputs."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1]
PDF_NAME='结合代数表示论基础_第2卷_全书习题解答_中文.pdf'
ZIP_NAME='结合代数表示论基础_第2卷_习题解答_数译上传源码包.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('action',choices=['prepare','pack']);ap.add_argument('--stage',default='build/upload_source');a=ap.parse_args()
 stage=(ROOT/a.stage).resolve()
 assert stage.is_relative_to(ROOT/'build') and stage!=ROOT/'build','Stage must be a child of project build directory.'
 if a.action=='prepare':
  check=json.loads((ROOT/'qa/final_verification.json').read_text('utf-8'))
  assert check['passed'] and check['exercise_total']==61
  assert not stage.exists(),'Use a new staging directory; existing files are never deleted.'
  stage.mkdir(parents=True)
  names=['main.tex','preamble.tex','solution_preamble.tex','book_links.tex','volume1_links.tex','mathtranslation.cls','logo.pdf','references.bib','glossary.tsv','README.md','task.md','computation-record.json']
  selected=[ROOT/name for name in names]
  selected += [p for p in (ROOT/'chapters').rglob('*.tex')]
  selected += [p for p in (ROOT/'tools').glob('*') if p.suffix in ('.py','.sh') and not p.name.startswith(('build_xii14','build_ch10_ch11_unit'))]
  selected += [p for p in (ROOT/'source').rglob('*') if p.is_file()and p.suffix in ('.json','.tsv','.md')]
  selected += [p for p in (ROOT/'qa').glob('*')if p.is_file()and p.suffix in ('.json','.md')]
  for src in selected:
   assert src.is_file(),src
   dst=stage/src.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
  shutil.copy2(ROOT/'build/release/main.pdf',stage/PDF_NAME)
  manifest={'date':'2026-11-16','volume':2,'kind':'independent Chinese exercise solutions, not official answers','exercise_counts':{'X':8,'XI':10,'XII':14,'XIII':13,'XIV':16},'total':61,'pdf':PDF_NAME,'pdf_sha256':sha(stage/PDF_NAME),'included':'editable TeX, template, bibliography, exact calculation code/certificates, review records, final PDF','excluded':'original English book, previous translation, rendered-page caches, TeX intermediate files','source_files':len(selected),'original_files_preserved':True}
  (stage/'qa/acceptance_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),'utf-8')
  print(json.dumps({'stage':str(stage),'source_files':len(selected),'PDF':PDF_NAME},ensure_ascii=False))
 else:
  assert stage.is_dir()
  rebuild=json.loads((stage/'qa/rebuild_verification.json').read_text('utf-8'));assert rebuild['passed']
  import pymupdf
  with pymupdf.open(stage/PDF_NAME)as p,pymupdf.open(stage/'build/release/main.pdf')as q:
   assert len(p)==len(q)
   assert [x.get_text()for x in p]==[x.get_text()for x in q]
   page_count=len(p)
  files=[p for p in stage.rglob('*')if p.is_file()and 'build' not in p.relative_to(stage).parts and p.suffix not in ('.pyc',)]
  zpath=ROOT.parent/ZIP_NAME
  with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
   for p in sorted(files):z.write(p,p.relative_to(stage).as_posix())
  with zipfile.ZipFile(zpath)as z:
   assert z.testzip()is None
   assert hashlib.sha256(z.read(PDF_NAME)).hexdigest()==sha(stage/PDF_NAME)
  shutil.copy2(stage/PDF_NAME,ROOT.parent/PDF_NAME)
  report={'pdf':str(ROOT.parent/PDF_NAME),'pdf_pages':page_count,'pdf_sha256':sha(ROOT.parent/PDF_NAME),'archive':str(zpath),'archive_bytes':zpath.stat().st_size,'archive_sha256':sha(zpath),'archive_entries':len(files),'zip_crc':'passed','independent_rebuild_text_and_page_count':'identical','mathematical_review':'see per-chapter reports; no claim of formal proof-assistant verification'}
  (ROOT/'qa/delivery.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
  print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
