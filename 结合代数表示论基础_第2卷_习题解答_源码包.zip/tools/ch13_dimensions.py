from pathlib import Path
from itertools import product
from collections import deque
import json
from exact_linear import eye,mm,mv,transpose,inverse,nullspace,primitive,dump
ROOT=Path(__file__).resolve().parents[1]

def matrices(n,arrows):
 E=eye(n)
 for i,j in arrows:E[i-1][j-1]-=1
 G=[[E[i][j]+E[j][i]for j in range(n)]for i in range(n)]
 h=primitive(nullspace(G)[0]);h=h if min(h)>=0 else [-x for x in h]
 C=transpose(inverse(E));Phi=[[-x for x in row]for row in mm(transpose(C),inverse(C))]
 defect=[sum(h[i]*E[i][j]for i in range(n))for j in range(n)]
 return E,G,h,Phi,defect

def roots(n,arrows):
 E,G,h,Phi,defect=matrices(n,arrows)
 defect=list(map(int,defect))
 q=lambda v:sum(t*t for t in v)-sum(v[i-1]*v[j-1]for i,j in arrows)
 roots=[v for v in product(*(range(t+1)for t in h))if sum(x*y for x,y in zip(v,defect))==0 and q(v)==1]
 unused=set(roots);cycles=[]
 while unused:
  v=min(unused);cycle=[v];unused.remove(v);w=tuple(map(int,mv(Phi,v)))
  while w!=v:assert w in unused,(v,w);cycle.append(w);unused.remove(w);w=tuple(map(int,mv(Phi,w)))
  if [sum(x[i]for x in cycle)for i in range(n)]==h:cycles.append(cycle)
 sums=set()
 for cycle in cycles:
  r=len(cycle)
  for start in range(r):
   for length in range(1,r):sums.add(tuple(sum(cycle[(start+k)%r][j]for k in range(length))for j in range(n)))
 assert sums==set(roots),(len(sums),len(roots))
 return dict(n=n,arrows=arrows,h=h,Phi=Phi,defect=defect,mouth_cycles=cycles,positive_regular_roots_below_h=roots,root_count=len(roots))

CASES={
 6:(5,[(1,2),(1,3),(1,4),(1,5)]),
 7:(5,[(1,2),(1,3),(1,4),(5,1)]),
 8:(6,[(1,2),(3,2),(3,4),(5,4),(5,6),(6,1)]),
 9:(9,[(1,3),(3,2),(3,4),(4,5),(6,5),(6,7),(8,7),(9,7)]),
 10:(7,[(1,2),(2,3),(1,4),(5,4),(1,6),(7,6)]),
 11:(8,[(2,1),(2,3),(4,3),(4,8),(4,5),(6,5),(6,7)]),
 12:(9,[(1,2),(2,3),(3,9),(3,4),(4,5),(6,5),(7,6),(7,8)])}

CANONICAL={
 6:[(1,2),(1,3),(4,1),(5,1)],7:[(1,2),(1,3),(4,1),(5,1)],
 8:[(3,2),(2,1),(3,4),(4,5),(5,6),(6,1)],
 9:[(3,1),(3,2),(4,3),(5,4),(6,5),(7,6),(8,7),(9,7)],
 10:[(3,2),(2,1),(5,4),(4,1),(7,6),(6,1)],
 11:[(1,2),(2,3),(3,4),(7,6),(6,5),(5,4),(8,4)],
 12:[(1,2),(2,3),(8,7),(7,6),(6,5),(5,4),(4,3),(9,3)]}

def reflection_path(n,start,end):
 start=tuple(sorted(start));end=tuple(sorted(end));pending=deque([(start,[])]);seen={start}
 while pending:
  ar,seq=pending.popleft()
  if ar==end:return seq
  for a in range(1,n+1):
   if any(i==a for i,j in ar):continue
   nxt=tuple(sorted((j,i)if j==a else(i,j)for i,j in ar))
   if nxt not in seen:seen.add(nxt);pending.append((nxt,seq+[a]))
 raise AssertionError('no sink-reflection sequence')

def main():
 out={}
 for no,(n,ar) in CASES.items():
  d=roots(n,ar);out[no]=d
  seq=reflection_path(n,CANONICAL[no],ar);d['canonical_arrows']=CANONICAL[no];d['sink_reflections']=seq
  canonical=roots(n,CANONICAL[no]);cs=canonical['mouth_cycles'];edges=ar
  images=[]
  for cycle in cs:
   image=[]
   for v in cycle:
    v=list(v)
    for a in seq:v[a-1]=sum(v[b-1]for i,b in edges if i==a)+sum(v[i-1]for i,b in edges if b==a)-v[a-1]
    image.append(tuple(v))
   images.append(image)
  assert {x for c in images for x in c}=={x for c in d['mouth_cycles']for x in c}
  d['canonical_mouth_cycles']=cs
  print(no,'h=',d['h'],'defect=',d['defect'],'roots=',d['root_count'])
  print('cycles=',d['mouth_cycles'],'reflections=',seq)
 # Exact matrix identities in Exercise 1. The inequalities concern operators.
 out['exercise1']={}
 for m in (5,6,7,8,9,10):
  ar=[(3,1),(3,2)]+[(i+1,i)for i in range(3,m-1)]+[(m,m-1),(m+1,m-1)]
  E,G,h,Phi,defect=matrices(m+1,ar);d=m-2 if m%2==0 else 2*(m-2);factor=1 if m%2==0 else 2
  delta=[-factor,-factor]+[0]*(m-3)+[factor,factor]
  target=[[int(i==j)+h[i]*delta[j]for j in range(m+1)]for i in range(m+1)]
  P=eye(m+1);earlier=[]
  for j in range(1,d+1):
   P=mm(P,Phi)
   if j<d:
    assert P!=target
    pos=next((a,b)for a in range(m+1)for b in range(m+1)if P[a][b]!=target[a][b])
    earlier.append([j,*pos,int(P[pos[0]][pos[1]]-target[pos[0]][pos[1]])])
  assert P==target
  out['exercise1'][m]={'Phi':Phi,'d':d,'h':h,'delta':delta,'earlier_unequal_entries_0based':earlier}
 (ROOT/'qa/ch13_dimensions.json').write_text(json.dumps(dump(out),ensure_ascii=False,indent=2),'utf-8')
if __name__=='__main__':main()
