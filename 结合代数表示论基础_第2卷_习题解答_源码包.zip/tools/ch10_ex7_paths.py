from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json
(ROOT/'qa').mkdir(exist_ok=True)
ar={'a':(3,1),'b':(3,2),'r':(1,4),'e':(1,5),'x':(2,4),'s':(2,5),'g':(4,3),'d':(5,3)}
binrel=[('rg','ed'),('xg','sd'),('ar','bx'),('ae','bs')];zerorel=['rgb','gbs','sda','dar']
paths={0:[str(i)for i in range(1,6)]}
for L in range(1,8):
 if L==1:paths[L]=list(ar)
 else:paths[L]=[p+a for p in paths[L-1]for a,(u,v)in ar.items()if ar[p[-1]][1]==u]
output={};basis=[]
for L,ps in paths.items():
 par={p:p for p in ps};zero=set()
 def find(p):
  if par[p]!=p:par[p]=find(par[p])
  return par[p]
 def union(p,q):par[find(p)]=find(q)
 for p in ps:
  for a,b in binrel:
   for k in range(L-len(a)+1):
    if p[k:k+len(a)]==a:union(p,p[:k]+b+p[k+len(a):])
  if any(z in p for z in zerorel):zero.add(p)
 zeroset={find(p)for p in zero};groups=defaultdict(list)
 for p in ps:
  if find(p)not in zeroset:groups[find(p)].append(p)
 classes=list(groups.values());output[str(L)]=classes
 for cl in classes:basis.append(cl)
 print(L,classes)
(ROOT/'qa/ch10_ex7_path_basis.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
