from fractions import Fraction as F
from math import lcm,gcd
from functools import reduce

def transpose(A):return [list(c) for c in zip(*A)]
def eye(n):return [[F(i==j) for j in range(n)] for i in range(n)]
def mm(A,B):return [[sum(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def mv(A,x):return [sum(a*b for a,b in zip(row,x)) for row in A]
def rref(A):
 M=[[F(x) for x in row] for row in A];piv=[];i=0
 if not M:return M,piv
 for j in range(len(M[0])):
  k=next((k for k in range(i,len(M)) if M[k][j]),None)
  if k is None:continue
  M[i],M[k]=M[k],M[i];v=M[i][j];M[i]=[x/v for x in M[i]]
  for k in range(len(M)):
   if k!=i and M[k][j]:v=M[k][j];M[k]=[x-v*y for x,y in zip(M[k],M[i])]
  piv.append(j);i+=1
  if i==len(M):break
 return M,piv

def nullspace(A):
 M,piv=rref(A);n=len(A[0]);out=[]
 for j in range(n):
  if j in piv:continue
  v=[F(0)]*n;v[j]=F(1)
  for i,k in enumerate(piv):v[k]=-M[i][j]
  out.append(v)
 return out

def primitive(v):
 m=lcm(*(x.denominator for x in v));v=[int(x*m) for x in v];g=reduce(gcd,v);return [x//g for x in v]
def det(A):
 M=[[F(x) for x in row] for row in A];v=F(1);n=len(M)
 for i in range(n):
  k=next((k for k in range(i,n) if M[k][i]),None)
  if k is None:return F(0)
  if k!=i:M[i],M[k]=M[k],M[i];v=-v
  q=M[i][i];v*=q
  for k in range(i+1,n):
   t=M[k][i]/q
   for j in range(i+1,n):M[k][j]-=t*M[i][j]
 return v

def inverse(A):
 n=len(A);R,piv=rref([list(a)+b for a,b in zip(A,eye(n))]);assert piv[:n]==list(range(n));return [row[n:] for row in R]
def ldl(A):
 n=len(A);L=eye(n);D=[]
 for i in range(n):
  d=F(A[i][i])-sum(L[i][k]**2*D[k] for k in range(i));D.append(d)
  if not d:continue
  for j in range(i+1,n):L[j][i]=(F(A[j][i])-sum(L[j][k]*L[i][k]*D[k] for k in range(i)))/d
 assert mm(mm(L,[[D[i] if i==j else 0 for j in range(n)] for i in range(n)]),transpose(L))==A
 return L,D

def dump(x):
 if isinstance(x,F):return int(x) if x.denominator==1 else str(x)
 if isinstance(x,list):return [dump(y) for y in x]
 if isinstance(x,dict):return {k:dump(v) for k,v in x.items()}
 return x

if __name__=='__main__':
 assert F(1,3)+F(1,6)==F(1,2)
 A=[[2,-1,0],[-1,2,-1],[0,-1,2]];assert det(A)==4;assert mm(A,inverse(A))==eye(3)
 assert primitive(nullspace([[2,-2],[-2,2]])[0])==[1,1]
 print('Exact Fraction arithmetic, determinant, inverse and kernel smoke checks passed.')
