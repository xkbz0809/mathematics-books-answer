from pathlib import Path
import json
from ch13_symbolic import RF,T,eye,mm,zeros,flag_hom,PIVOTS
from ch13_dimensions import matrices
from exact_linear import mv
ROOT=Path(__file__).resolve().parents[1]
u=[[1],[0]];v=[[0],[1]];w=[[1],[1]]
U=[[1,0],[0,1],[0,0]];V=[[0,0],[1,0],[0,1]];S=[[1,0],[1,1],[0,1]]
def up(n,k):return [[int(i==j)for j in range(k)]for i in range(n)]
def down(n,k):return [[int(i==j+n-k)for j in range(k)]for i in range(n)]
def flags(d,parent,maps):
 out=[None]*len(d);out[0]=eye(d[0])
 def embed(i):
  if out[i]is not None:return out[i]
  p=parent[i];B=embed(p);A=maps.get(i)
  if A is None:
   assert not d[i] or d[i]==d[p]==1,(i,d)
   A=[[1]]if d[i] else zeros(d[p],0)
  assert len(A)==d[p]and all(len(r)==d[i]for r in A),(i,A,d)
  out[i]=mm(B,A)if d[p]else zeros(d[0],d[i]);return out[i]
 for i in range(1,len(d)):embed(i)
 return out

def families():
 p6={1:0,2:1,3:0,4:3,5:0,6:5}
 specs6=[
 ('inf1',[1,1,0,1,0,1,0],{}),('inf2',[2,1,1,1,1,1,1],{1:u,3:w,5:v}),
 ('zero1',[1,1,1,0,0,1,0],{}),('zero2',[1,0,0,1,0,1,1],{}),('zero3',[1,1,0,1,1,0,0],{}),
 ('one1',[1,1,0,0,0,1,1],{}),('one2',[1,1,1,1,0,0,0],{}),('one3',[1,0,0,1,1,1,0],{}),
 ('generic',[3,2,1,2,1,2,1],{1:U,2:u,3:[[T,1],[1,1],[1,0]],4:u,5:V,6:v})]
 p7={1:0,2:1,3:2,4:0,5:0,6:5,7:6}
 specs7=[
 ('inf1',[2,1,1,0,1,2,1,1],{1:u,4:w,5:eye(2),6:v}),('inf2',[2,2,1,1,1,1,1,0],{1:eye(2),2:u,4:w,5:v}),
 ('zero1',[1,1,0,0,1,1,0,0],{}),('zero2',[1,1,1,0,0,1,1,0],{}),('zero3',[2,1,1,1,1,1,1,1],{1:u,4:w,5:v}),
 ('one1',[1,0,0,0,1,1,1,0],{}),('one2',[1,1,0,0,0,1,1,1],{}),('one3',[1,1,1,0,1,0,0,0],{}),('one4',[1,1,1,1,0,1,0,0],{}),
 ('generic',[4,3,2,1,2,3,2,1],{1:up(4,3),2:U,3:u,4:[[1,T],[1,0],[1,1],[0,1]],5:down(4,3),6:V,7:v})]
 p8={1:0,2:1,3:0,4:0,5:4,6:5,7:6,8:7}
 specs8=[
 ('inf1',[3,2,1,2,2,2,1,1,0],{1:V,2:v,3:S,4:U,5:eye(2),6:u}),
 ('inf2',[3,2,1,1,3,2,2,1,1],{1:V,2:v,3:[[1],[1],[1]],4:eye(3),5:U,6:eye(2),7:u}),
 ('zero1',[2,2,1,1,1,1,1,0,0],{1:eye(2),2:v,3:w,4:u}),
 ('zero2',[2,1,1,1,2,1,1,1,0],{1:v,3:w,4:eye(2),5:u}),
 ('zero3',[2,1,0,1,2,2,1,1,1],{1:v,3:w,4:eye(2),5:eye(2),6:u}),
 ('one1',[1,1,0,1,1,0,0,0,0],{}),('one2',[1,1,1,0,1,1,0,0,0],{}),
 ('one3',[1,0,0,1,1,1,1,0,0],{}),('one4',[1,1,0,0,1,1,1,1,0],{}),
 ('one5',[2,1,1,1,1,1,1,1,1],{1:v,3:w,4:u}),
 ('generic',[6,4,2,3,5,4,3,2,1],{1:down(6,4),2:down(4,2),3:[[T,1,0],[0,0,1],[1,1,0],[1,0,1],[1,1,0],[0,1,0]],4:up(6,5),5:up(5,4),6:up(4,3),7:U,8:u})]
 return {6:(p6,specs6),7:(p7,specs7),8:(p8,specs8)}

def main():
 result={}
 for typ,(parent,specs)in families().items():
  fs=[flags(d,parent,maps)for name,d,maps in specs];H=[]
  for i,M in enumerate(fs):
   row=[]
   for j,N in enumerate(fs):
    h=flag_hom(M,N);row.append(len(h))
    assert len(h)==int(i==j),(typ,specs[i][0],specs[j][0],len(h))
   H.append(row)
  n=len(specs[0][1]);ar=[(i+1,p+1)for i,p in parent.items()];E,G,hh,Phi,defect=matrices(n,ar)
  ds=[d for name,d,maps in specs];assert all(sum(x*y for x,y in zip(d,defect))==0 for d in ds)
  orbit={}
  for name,d,maps in specs[:-1]:
   nxt=list(map(int,mv(Phi,d)));hits=[name2 for name2,d2,maps2 in specs[:-1]if d2==nxt];assert len(hits)==1
   orbit[name]=hits[0]
  result[typ]={'labels':[s[0]for s in specs],'dimensions':ds,'Hom_dimensions':H,'tau_dimensions':orbit,'h':hh,'defect':[int(x)for x in defect],
  'central_subspace_embeddings':[[[[str(x)for x in row]for row in A]for A in f]for f in fs]}
  print('E',typ,'verified symbolic Hom identity',len(fs),'x',len(fs),flush=True)
 result['allowed_pivots']=sorted(set(PIVOTS));result['assumption']='t!=0,1; pivots are products of +/-1,t,t-1 and inverses; valid in every characteristic'
 (ROOT/'qa/ch13_flags.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
if __name__=='__main__':main()
