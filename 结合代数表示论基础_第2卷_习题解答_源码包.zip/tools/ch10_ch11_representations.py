from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import json
from ch10_ch11_exact import tr,mm,eye

PIVOTS=[]

def zeros(r,c):return [[F(0)]*c for _ in range(r)]
def rref(A,ncols=None):
 A=[list(map(F,r)) for r in A];nc=len(A[0]) if A else ncols;pv=[];i=0
 for j in range(nc):
  k=next((k for k in range(i,len(A)) if A[k][j]),None)
  if k is None:continue
  A[i],A[k]=A[k],A[i];c=A[i][j];PIVOTS.append(str(c));A[i]=[x/c for x in A[i]]
  for k in range(len(A)):
   if k!=i:
    c=A[k][j];A[k]=[a-c*b for a,b in zip(A[k],A[i])]
  pv.append(j);i+=1
  if i==len(A):break
 return A,pv

def null(A,ncols):
 R,pv=rref(A,ncols);free=[j for j in range(ncols)if j not in pv];out=[]
 for j in free:
  v=[F(0)]*ncols;v[j]=1
  for i,k in enumerate(pv):v[k]=-R[i][j]
  out.append(v)
 return out

def refl(rep,a):
 d,ar=rep;n=len(d);out=[b for x,b in ar if x==a];assert all(y!=a for x,y in ar)
 M=[row for b in out for row in ar[(a,b)]];total=sum(d[b]for b in out)
 if d[a]:Q=null(tr(M) if M else [[] for _ in range(d[a])],total)
 else:Q=eye(total)
 nd=list(d);nd[a]=len(Q);na={k:v for k,v in ar.items() if k[0]!=a};off=0
 for b in out:
  na[(b,a)]=[row[off:off+d[b]]for row in Q];off+=d[b]
 return nd,na

def projective(n,arrows,i):
 reach={i};changed=True
 while changed:
  old=len(reach)
  for a,b in arrows:
   if a in reach:reach.add(b)
  changed=len(reach)>old
 d=[int(j in reach)for j in range(n)]
 ar={(a,b):[[F(1)]] if d[a]and d[b] else zeros(d[b],d[a])for a,b in arrows}
 return d,ar

def source_order(n,arrows):
 ans=[]
 while len(ans)<n:
  ans.append(next(i for i in range(n)if i not in ans and all(a in ans for a,b in arrows if b==i)))
 return ans

def postprojs(n,arrows,upto):
 order=source_order(n,arrows);allreps={};cur=[projective(n,arrows,i)for i in range(n)]
 for m in range(upto+1):
  for i,r in enumerate(cur):allreps[(m,i+1)]=r
  cur=[r for r in cur]
  for a in order:cur=[refl(r,a)for r in cur]
 return allreps

def hom(M,N):
 dm,am=M;dn,an=N;n=len(dm);off=[];q=0
 for i in range(n):off.append(q);q+=dm[i]*dn[i]
 equations=[]
 for a,b in am:
  for i in range(dn[b]):
   for j in range(dm[a]):
    row=[F(0)]*q
    for k in range(dn[a]):row[off[a]+k*dm[a]+j]+=an[(a,b)][i][k]
    for k in range(dm[b]):row[off[b]+i*dm[b]+k]-=am[(a,b)][k][j]
    equations.append(row)
 out=[]
 for v in null(equations,q):out.append([[[v[off[i]+a*dm[i]+b]for b in range(dm[i])]for a in range(dn[i])]for i in range(n)])
 return out

def compose(f,g):
 out=[]
 for x,y in zip(f,g):
  r=len(x);c=len(y[0])if y else 0
  if y:out.append(mm(x,y))
  else:out.append([[]for _ in range(r)])
 return out

def nonzero(f):return any(x for A in f for row in A for x in row)
def ratio(f,g):
 pairs=[(a,b)for A,B in zip(f,g)for r,s in zip(A,B)for a,b in zip(r,s)]
 z=next((a/b for a,b in pairs if b),None)
 assert z is not None and all(a==z*b for a,b in pairs)
 return z

def serial(r):return {'dimensions':r[0],'arrows':{f'{a+1}->{b+1}':[[str(x)for x in row]for row in M]for (a,b),M in r[1].items()}}

if __name__=='__main__':
 (ROOT/'qa').mkdir(exist_ok=True)
 data=json.loads((ROOT/'qa/ch10_ch11_exact.json').read_text(encoding='utf-8'))
 specs={
 'XI8':(6,[(3,1),(3,2),(4,3),(5,4),(6,4)],[(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[([4,6,5],[4,3,5])]),
 'XI9':(7,[(3,1),(3,2),(4,3),(5,4),(6,5),(7,5)],[(1,7),(7,2),(1,3),(4,3),(4,6),(3,2),(3,5),(6,5)],[([1,7,2],[1,3,2]),([4,6,5],[4,3,5])]),
 'XI10':(7,[(3,2),(2,1),(5,4),(4,1),(7,6),(6,1)],[(1,2),(5,2),(5,6),(2,3),(3,4),(3,7),(6,7)],[([5,2,3,7],[5,6,7])])}
 output={}
 for key,(n,arr,barr,rels) in specs.items():
  arr=[(a-1,b-1)for a,b in arr];cand=data[key]['tilting_candidates'][0];reps=postprojs(n,arr,max(t[0]for t in cand));T=[reps[(m,i)]for m,i,d in cand]
  assert all(r[0]==dim for r,(m,i,dim)in zip(T,cand)),(key,'dimension')
  HB=[[hom(x,y)for y in T]for x in T];H=[[len(x)for x in row]for row in HB]
  assert H==data[key]['C'],(key,H)
  maps={(a,b):HB[b-1][a-1][0]for a,b in barr}
  def pathmap(path):
   result=maps[(path[-2],path[-1])]
   for k in range(len(path)-3,-1,-1):result=compose(maps[(path[k],path[k+1])],result)
   return result
  relation_ratios=[]
  for p,q in rels:
   fp,fq=pathmap(p),pathmap(q);assert nonzero(fp)and nonzero(fq)
   relation_ratios.append(str(ratio(fp,fq)))
  paths=[[a,b]for a,b in barr];at=0
  while at<len(paths):
   p=paths[at];paths.extend(p+[b]for a,b in barr if a==p[-1]);at+=1
  assert all(nonzero(pathmap(p))for p in paths)
  output[key]={'T_candidates':cand,'T_matrices':[serial(t)for t in T],'Hom_dimensions':H,'all_nontrivial_path_products_nonzero':True,'path_count':len(paths),'relation_ratios_before_arrow_rescaling':relation_ratios,'arrow_maps':{f'{a}->{b}':[[[str(x)for x in row]for row in A]for A in m]for (a,b),m in maps.items()}}
  print(key,'verified',len(paths),'paths ratios',relation_ratios,flush=True)
 output['gaussian_pivot_values']=sorted(set(PIVOTS))
 (ROOT/'qa/ch10_ch11_representation_verification.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
