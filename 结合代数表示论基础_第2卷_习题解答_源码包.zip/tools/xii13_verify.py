"""Exact DTr verification for XII.13, including its two parallel arrows.

All arithmetic uses fractions. The explicit basis of the 13-dimensional algebra
is reduced by gamma*alpha=0, rho*beta=0, sigma*alpha=sigma*beta.
"""
from pathlib import Path
import json
from fractions import Fraction as F
from ch10_ch11_representations import zeros,tr,mm,null,rref,PIVOTS
from ch10_ch11_bound_tau import solve,rank
from ch10_ch11_exact import data,pair
from exact_linear import det

ROOT=Path(__file__).resolve().parents[1]
ar={'a':(1,0),'b':(1,0),'g':(2,1),'s':(3,1),'r':(4,1)}
ends={f'e{i}':(i,i)for i in range(5)}|ar|{'gb':(2,0),'sa':(3,0),'ra':(4,0)}
bas={(i,j):[p for p,ab in ends.items()if ab==(i,j)]for i in range(5)for j in range(5)}
def mul(p,q):
 if ends[p][1]!=ends[q][0]:return None
 if p.startswith('e'):return q
 if q.startswith('e'):return p
 return {('g','b'):'gb',('s','a'):'sa',('s','b'):'sa',('r','a'):'ra'}.get((p,q))
def matvec(A,x):return [sum(a*b for a,b in zip(row,x))for row in A]
def columns(vectors,rows):return tr(vectors)if vectors else zeros(rows,0)
def evalpath(rep,p,x):
 if p.startswith('e'):return x
 for a in p:x=matvec(rep[1][a],x)
 return x
def injective(i):
 d=[len(bas[v,i])for v in range(5)];maps={}
 for a,(u,v)in ar.items():maps[a]=[[F(mul(a,q)==p)for p in bas[u,i]]for q in bas[v,i]]
 return d,maps
def top(rep):
 d,maps=rep;out=[]
 for v in range(5):
  rows=[]
  for a,(u,w)in ar.items():
   if w==v:rows+=tr(maps[a])if maps[a]else [[]for i in range(d[u])]
  old=rank(rows,d[v]);new=[]
  for j in range(d[v]):
   e=[F(i==j)for i in range(d[v])];rk=rank(rows+[e],d[v])
   if rk>old:rows.append(e);new.append(e);old=rk
  out.append(new)
 return out
def cover(rep):
 d,_=rep;gens=[(i,g)for i,L in enumerate(top(rep))for g in L]
 slots=[[(k,p)for k,(i,g)in enumerate(gens)for p in bas[i,v]]for v in range(5)]
 pd=list(map(len,slots));maps={};f=[]
 for v in range(5):f.append(columns([evalpath(rep,p,gens[k][1])for k,p in slots[v]],d[v]))
 for a,(u,v)in ar.items():maps[a]=[[F(k==l and mul(p,a)==q)for k,p in slots[u]]for l,q in slots[v]]
 return (pd,maps),f,gens,slots
def subrep(rep,K):
 d,maps=rep;nd=[len(x[0])if x else 0 for x in K];out={}
 for a,(u,v)in ar.items():
  images=mm(maps[a],K[u])if d[u]else zeros(d[v],nd[u])
  out[a]=columns([solve(K[v],[row[j]for row in images])for j in range(nd[u])],nd[v])
 return nd,out
def tau(rep):
 P0,f,g0,s0=cover(rep)
 K=[columns(null(A,P0[0][v]),P0[0][v])for v,A in enumerate(f)]
 ker=subrep(P0,K);P1,_,g1,s1=cover(ker);coeff={}
 for j,(i,g)in enumerate(g1):
  amb=matvec(K[i],g)
  for (k,p),c in zip(s0[i],amb):
   if c:coeff[k,j,p]=c
 si0=[[(k,p)for k,(i,g)in enumerate(g0)for p in bas[v,i]]for v in range(5)]
 si1=[[(k,p)for k,(i,g)in enumerate(g1)for p in bas[v,i]]for v in range(5)]
 d=list(map(len,si1));maps={}
 for a,(u,v)in ar.items():maps[a]=[[F(k==l and mul(a,q)==p)for k,p in si1[u]]for l,q in si1[v]]
 nu=[]
 for v in range(5):
  mat=zeros(len(si0[v]),len(si1[v]));idx={s:i for i,s in enumerate(si1[v])}
  for row,(k,q)in enumerate(si0[v]):
   for (i,j,p),c in coeff.items():
    z=mul(q,p)
    if i==k and z:mat[row][idx[j,z]]+=c
  nu.append(mat)
 L=[columns(null(M,d[v]),d[v])for v,M in enumerate(nu)]
 result=subrep((d,maps),L)
 return result,{'P0':[i+1 for i,g in g0],'P1':[i+1 for i,g in g1], 'pd_le_1':P1[0]==ker[0], 'coefficients':{f'{i},{j},{p}':str(c)for(i,j,p),c in coeff.items()}}
def hom(M,N):
 dm,am=M;dn,an=N;off=[];count=0
 for i in range(5):off.append(count);count+=dm[i]*dn[i]
 eq=[]
 for a,(u,v)in ar.items():
  for i in range(dn[v]):
   for j in range(dm[u]):
    row=[F(0)]*count
    for k in range(dn[u]):row[off[u]+k*dm[u]+j]+=an[a][i][k]
    for k in range(dm[v]):row[off[v]+i*dm[v]+k]-=am[a][k][j]
    eq.append(row)
 return [[[[x[off[i]+a*dm[i]+b]for b in range(dm[i])]for a in range(dn[i])]for i in range(5)]for x in null(eq,count)]
def validate(M):
 d,ma=M
 for p,q in [('ga',None),('rb',None),('sa','sb')]:
  start=ar[p[0]][0]
  for j in range(d[start]):
   x=[F(i==j)for i in range(d[start])];u=evalpath(M,p,x);v=evalpath(M,q,x)if q else [0]*len(u)
   assert u==v
def rep(d,values):
 maps={a:values.get(a,zeros(d[v],d[u]))for a,(u,v)in ar.items()};M=(d,maps);validate(M);return M
def ser(M):return {'dimension':M[0],'arrows':{a:[[str(x)for x in row]for row in A]for a,A in M[1].items()}}
def check_hereditary_tilting():
 from ch10_ch11_representations import hom as hhom,postprojs
 edges=[(i,0)for i in range(1,5)]
 def thin(s):
  d=[int(i in s)for i in range(5)]
  return d,{(a,b):[[F(1)]]if d[a]*d[b]else zeros(d[b],d[a])for a,b in edges}
 T=[thin([0,1]),([3,2,1,1,1],{(1,0):[[F(1),F(0)],[F(0),F(1)],[F(0),F(0)]],(2,0):[[F(0)],[F(0)],[F(1)]],(3,0):[[F(1)],[F(0)],[F(1)]],(4,0):[[F(0)],[F(1)],[F(1)]]}),thin([0,1,2]),thin([0,1,3]),thin([0,1,4])]
 H=[[len(hhom(x,y))for y in T]for x in T]
 E=data(5,[(a+1,b+1)for a,b in edges])['E']
 Ex=[[H[i][j]-pair(x[0],E,y[0])for j,y in enumerate(T)]for i,x in enumerate(T)]
 assert H==[[1,2,1,1,1],[0,1,1,1,1],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]]
 assert not any(v for row in Ex for v in row)
 R=postprojs(5,edges,2)[(2,2)];assert R[0]==T[1][0]
 isos=hhom(R,T[1]);assert len(isos)==1
 determinants=[det(M)for M in isos[0]];assert all(abs(x)==1 for x in determinants)
 (ROOT/'qa/xii13_tilting_check.json').write_text(json.dumps({'Hom':H,'Ext1':Ex,'T2_tau_inverse':2,'T2_base_projective_vertex':1,'T2_iso_determinants':list(map(str,determinants)),'pivots':sorted(set(PIVOTS))},indent=2),'utf-8')
def main():
 check_hereditary_tilting()
 I=[injective(i)for i in range(5)]
 U0=rep([1,3,1,1,1],{'a':[[1,-1,0]],'b':[[1,0,0]],'g':[[-1],[-1],[1]],'s':[[1],[0],[0]],'r':[[0],[1],[0]]})
 U=[None,U0,I[0]]
 # U2,U3,U4 are supported on the middle vertex and one of the sources.
 leaves=[]
 for leaf,name in [(2,'g'),(3,'s'),(4,'r')]:
  d=[0]*5;d[1]=d[leaf]=1;leaves.append(rep(d,{name:[[1]]}))
 targets={1:U0,2:leaves[0],3:leaves[1],4:leaves[2]};records={}
 for i in range(1,5):
  A,pa=tau(I[i]);validate(A);B,pb=tau(A);validate(B)
  H=hom(B,targets[i]);assert len(H)==1
  iso=H[0];ds=[det(m)if m else F(1)for m in iso];assert all(ds)
  records[i+1]={'injective':ser(I[i]),'tau':ser(A),'tau2':ser(B),'presentations':[pa,pb],'tau2_target_iso_determinants':list(map(str,ds))}
  print('I',i+1,'tau',A[0],'tau2',B[0],'iso',ds,flush=True)
 assert set(PIVOTS)<={'1','-1'}
 records['pivots']=sorted(set(PIVOTS))
 (ROOT/'qa/xii13_DTr_check.json').write_text(json.dumps(records,indent=2),'utf-8')
if __name__=='__main__':main()
