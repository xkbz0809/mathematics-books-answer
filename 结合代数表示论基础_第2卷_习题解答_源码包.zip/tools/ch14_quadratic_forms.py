from exact_linear import *
from itertools import product
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def squares(x):return sum(t*t for t in x[1:])
forms={
 '2a':(5,lambda x:squares(x)-sum(x[1:5])*x[5]),
 '2b':(7,lambda x:squares(x)+x[1]*x[2]+x[3]*x[4]+x[5]*x[6]-sum(x[1:7])*x[7]),
 '2c':(8,lambda x:squares(x)+x[2]*(x[3]+x[4])-(x[1]+x[2]+x[3])*x[6]-(x[2]+x[3]+x[4])*x[7]-(x[2]+x[4]+x[5])*x[8]),
 '2d':(9,lambda x:squares(x)+x[1]*x[2]+x[1]*x[4]+x[3]*x[4]+sum(x[i]*x[j] for i in range(5,9) for j in range(i+1,9))-sum(x[1:9])*x[9]),
 '2e':(9,lambda x:squares(x)+x[4]*x[5]+x[4]*x[6]+x[5]*x[6]+x[7]*x[9]+x[8]*x[9]-x[1]*(x[4]+x[5]+x[6]+x[7]+x[9])-x[2]*(x[7]+x[8]+x[9])-x[3]*(x[8]+x[9])),
 '3a':(5,lambda x:squares(x)+(x[1]+x[2])*(x[3]+x[4])-sum(x[1:5])*x[5]),
 '3b':(5,lambda x:squares(x)+x[2]*x[4]-(x[1]+x[2])*x[3]-(x[1]+x[2]+x[4])*x[5]),
 '3c':(6,lambda x:squares(x)+x[1]*(x[2]+x[3]+x[4]+x[5])+(x[2]+x[3])*(x[4]+x[5])-sum(x[1:6])*x[6]),
 '3d':(6,lambda x:squares(x)+x[4]*x[1]+x[5]*x[1]+x[6]*x[2]+x[6]*x[3]-x[2]*x[1]-x[3]*x[1]-x[6]*x[1]-x[4]*x[2]-x[5]*x[2]-x[4]*x[3]-x[5]*x[3]-x[6]*x[4]-x[6]*x[5]),
 '3e':(6,lambda x:squares(x)+x[1]*x[3]+x[2]*x[3]+x[2]*x[4]-(x[1]+x[2]+x[3])*x[5]-(x[1]+x[2]+x[4])*x[6])}
result={}
for name,(n,q) in forms.items():
 G=[[2 if i==j else q([0]+[int(k==i)+int(k==j) for k in range(n)])-2 for j in range(n)] for i in range(n)]
 ker=[primitive(v) for v in nullspace(G)];mins=[det([row[:k] for row in G[:k]]) for k in range(1,n+1)]
 row={'G':G,'kernel':ker,'leading_principal_minors':mins}
 if name.startswith('2'):
  assert len(ker)==1 and all(x>0 for x in ker[0]) and all(x>0 for x in mins[:-1]) and mins[-1]==0
  L,D=ldl([a[:-1] for a in G[:-1]]);row['LDL_D_deleted_last']=D
 else:
  witness=next((list(x) for x in product(range(4),repeat=n) if any(x) and 0 in x and q([0]+list(x))<=0),None)
  row['proper_support_witness']=witness;row['witness_value']=q([0]+witness) if witness else None
  if witness is None:
   print('no proper-support witness',name)
 result[name]=row;print(name,dump(row))
for key,deleted in [('3a',0),('3c',1)]:
 G=result[key]['G'];ix=[i for i in range(len(G))if i!=deleted]
 B=[[G[i][j]for j in ix]for i in ix]
 ms=[det([r[:k]for r in B[:k]])for k in range(1,len(B)+1)]
 assert all(x>0 for x in ms)
 result[key]['positive_definite_deleted_coordinate']=deleted+1
 result[key]['deleted_principal_minors']=ms
G=result['3c']['G'];H=result['3d']['G'];sg=[1,-1,-1,1,1,1]
assert all(G[i][j]*sg[i]*sg[j]==H[i][j]for i in range(6)for j in range(6))
result['3cd_congruence']={'unimodular_diagonal':sg,'verified':True}
(R/'qa/ch14_quadratic_forms.json').write_text(json.dumps(dump(result),ensure_ascii=False,indent=2),encoding='utf-8')
