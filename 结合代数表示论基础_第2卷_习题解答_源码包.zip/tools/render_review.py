"""Render every release page to contact sheets for human visual inspection."""
from pathlib import Path
import argparse,json
import pymupdf
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--pdf',default='build/release/main.pdf');ap.add_argument('--out',default='qa/release_visual');a=ap.parse_args()
d=pymupdf.open(ROOT/a.pdf);out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
for start in range(0,len(d),6):
 ims=[]
 for i in range(start,min(start+6,len(d))):
  p=d[i].get_pixmap(matrix=pymupdf.Matrix(.8,.8));im=Image.frombytes('RGB',[p.width,p.height],p.samples);ims.append((i+1,im))
 w=max(im.width for n,im in ims);h=max(im.height for n,im in ims)
 sheet=Image.new('RGB',(3*w,2*(h+25)),'#c8c8c8');dr=ImageDraw.Draw(sheet)
 for k,(n,im)in enumerate(ims):
  x=(k%3)*w;y=(k//3)*(h+25);sheet.paste(im,(x,y+25));dr.text((x+10,y+5),str(n),fill='black')
 sheet.save(out/f'sheet_{start+1:03}_{min(start+6,len(d)):03}.png')
print(json.dumps({'pages':len(d),'sheets':len(list(out.glob('sheet_*.png'))),'output':str(out)},ensure_ascii=False))
