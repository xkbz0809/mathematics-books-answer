from pathlib import Path
import json,itertools
from ch10_ch11_exact import data,pair
from ch10_ch11_representations import postprojs,hom,compose,nonzero,ratio,serial,PIVOTS
ROOT=Path(__file__).resolve().parents[1]
arr=[(3,1),(3,2),(4,3),(5,4),(6,5),(7,5)]
keys=[(2,2),(3,1),(4,2),(2,4),(0,6),(1,7),(2,6)]
barr=[(1,2),(2,3),(1,4),(4,3),(7,4),(4,5),(7,6),(6,5)]
A=data(7,arr);B=data(7,barr,[(1,3),(7,5)])
reps=postprojs(7,[(a-1,b-1)for a,b in arr],4)
raw=[reps[k]for k in keys];rawH=[[len(hom(x,y))for y in raw]for x in raw]
p=next(p for p in itertools.permutations(range(7))if all(rawH[p[i]][p[j]]==B['C'][i][j]for i in range(7)for j in range(7)))
T=[raw[i]for i in p];HB=[[hom(x,y)for y in T]for x in T];H=[[len(x)for x in row]for row in HB]
Ex=[[H[i][j]-pair(x[0],A['E'],y[0])for j,y in enumerate(T)]for i,x in enumerate(T)]
assert not any(x for row in Ex for x in row)
maps={(a,b):HB[b-1][a-1][0]for a,b in barr}
def pm(p):
 f=maps[(p[-2],p[-1])]
 for k in range(len(p)-3,-1,-1):f=compose(maps[(p[k],p[k+1])],f)
 return f
ratios=[str(ratio(pm(p),pm(q)))for p,q in [([1,2,3],[1,4,3]),([7,4,5],[7,6,5])]]
paths=[[a,b]for a,b in barr];at=0
while at<len(paths):
 path=paths[at];paths.extend(path+[b]for a,b in barr if a==path[-1]);at+=1
assert all(nonzero(pm(p))for p in paths)
out={'summands_in_C7_vertex_order':[keys[i]for i in p],'dimensions':[x[0]for x in T],'Hom':H,'Ext1':Ex,'relation_ratios':ratios,'representations':[serial(x)for x in T],'maps':{f'{a}->{b}':[[[str(x)for x in row]for row in M]for M in f]for (a,b),f in maps.items()},'pivots':sorted(set(PIVOTS))}
(ROOT/'qa/ch14_c7.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),'utf-8')
print(out['summands_in_C7_vertex_order']);print(H);print(ratios)
