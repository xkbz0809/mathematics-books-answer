from pathlib import Path
import json,itertools,math
from fractions import Fraction as F
R=Path(__file__).resolve().parents[1]
# Vertex numbering is row-major as drawn in the exercises.
D={7:(10,[(0,2),(0,3),(2,7),(7,8),(3,8),(3,4),(1,5),(1,6),(5,9),(6,9),(5,4)],[(0,8),(1,9)]),8:(7,[(1,0),(1,2),(0,3),(1,4),(2,5),(4,3),(4,5),(4,6)],[(1,3),(1,5)]),9:(8,[(1,0),(1,2),(0,3),(1,4),(2,5),(4,3),(4,5),(6,4),(6,7),(7,5)],[(1,3),(1,5),(6,5)]),10:(9,[(1,0),(2,1),(1,3),(2,4),(4,3),(4,5),(6,4),(6,7),(7,5),(8,7)],[(6,3),(2,3),(6,5)])}
def null(A):
 A=[[F(x) for x in r] for r in A];m=len(A);p=[];k=0
 for j in range(m):
  z=next((i for i in range(k,m) if A[i][j]),None)
  if z is None:continue
  A[k],A[z]=A[z],A[k];v=A[k][j];A[k]=[x/v for x in A[k]]
  for i in range(m):
   if i!=k:
    v=A[i][j];A[i]=[x-v*y for x,y in zip(A[i],A[k])]
  p.append(j);k+=1
 free=[j for j in range(m) if j not in p];assert len(free)==1
 h=[F(0)]*m;h[free[0]]=1
 for i,j in enumerate(p):h[j]=-A[i][free[0]]
 l=math.lcm(*(x.denominator for x in h));h=[int(x*l) for x in h];g=math.gcd(*h);return [x//g for x in h]
gs=json.loads((R/'source/ch12_frame_catalog.json').read_text(encoding='utf8'));over={}
out={}
for k,(n,ar,rel) in D.items():
 E=[[int(i==j) for j in range(n)] for i in range(n)]
 for i,j in ar:E[i][j]-=1
 for i,j in rel:E[i][j]+=1
 h=null([[E[i][j]+E[j][i] for j in range(n)] for i in range(n)])
 de=[sum(h[i]*E[i][j] for i in range(n)) for j in range(n)]
 matches=[];uv={frozenset(e) for e in ar};deg=[sum(i in e for e in uv) for i in range(n)]
 for g in gs:
  if len(g['nodes'])!=n:continue
  ed=over.get(str(g['number']),{}).get('edges',g['edges']);ae=[e for e in ed if e['style']!='dotted'];guv={frozenset((e['a'],e['b'])) for e in ae};gd=[sum(i in e for e in guv) for i in range(n)]
  if sorted(gd)!=sorted(deg) or len(guv)!=len(uv):continue
  cand=[[j for j in range(n) if gd[j]==deg[i] and int(g['nodes'][j]['label'])==h[i]] for i in range(n)]
  for perm in itertools.product(*cand):
   if len(set(perm))<n:continue
   if {frozenset((perm[i],perm[j])) for i,j in ar}!=guv:continue
   for rev in [False,True]:
    ga={(e['a'],e['b']) for e in ae if e['style']=='arrow'}
    pa={(perm[j],perm[i]) if rev else (perm[i],perm[j]) for i,j in ar}
    if ga<=pa:matches.append([g['number'],rev,list(perm)])
 out[k]={'n':n,'arrows':ar,'relation_endpoints':rel,'Euler':E,'h':h,'defect':de,'frame_matches':matches}
 print(k,'h',h,'defect',de,'matches',matches)
(R/'qa/ch12_exact_data.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
