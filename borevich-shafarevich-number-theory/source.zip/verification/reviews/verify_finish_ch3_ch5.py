"""Independent finite cross-checks; these supplement, and do not replace, proofs."""
from pathlib import Path
from itertools import combinations, product
from math import gcd, isqrt, factorial, prod, comb
from fractions import Fraction
import json

def isprime(n):
    return n>=2 and all(n%j for j in range(2,isqrt(n)+1))
def primerange(a,b):
    return [p for p in range(a,b) if isprime(p)]
def legendre(a,p):
    t=pow(a,(p-1)//2,p)
    return -1 if t==p-1 else t
def factorint(n):
    ans={}
    for p in primerange(2,isqrt(n)+2):
        while n%p==0:
            ans[p]=ans.get(p,0)+1;n//=p
    if n>1:ans[n]=ans.get(n,0)+1
    return ans
BERNOULLI=[Fraction(1)]
def bernoulli(n):
    while len(BERNOULLI)<=n:
        j=len(BERNOULLI)
        BERNOULLI.append(-sum(Fraction(comb(j+1,k))*BERNOULLI[k] for k in range(j))/(j+1))
    return BERNOULLI[n]

OUT=Path(__file__).resolve().parent
report={}

def class_number(D):
    assert D<0 and D%4 in (0,1)
    forms=[]
    for a in range(1,isqrt((-D)//3)+1):
        for b in range(-a,a+1):
            if (b*b-D)%(4*a): continue
            c=(b*b-D)//(4*a)
            if c<a or gcd(gcd(a,b),c)>1: continue
            if (abs(b)==a or a==c) and b<0: continue
            forms.append((a,b,c))
    return len(forms)

ps=primerange(3,74)
count=0
for p in ps:
    for q in [2]+ps:
        if p%4==q%4: continue
        D=-p*q if q!=2 else -8*p
        assert (class_number(D)%4==0)==(legendre(q,p)==1),(p,q,D)
        count+=1
report['3.8.26']={'prime_pairs_checked':count,'p_max':73,'q_max':73,'all_pass':True}
cases=[]
for r in [1,2,3]:
    for qs in combinations([5,13,17,29,37,41],r):
        d=prod(qs)
        if d%8!=1: continue
        h=class_number(-4*int(d))
        assert h%(2**(r+1))==0,(qs,h)
        cases.append({'primes':list(qs),'class_number':h,'genus_count':2**r})
report['3.8.27']=cases
primitive_reps={}
for n in [3,9,27,81,11,121,33,99]:
    reps=[]
    for y in range(-isqrt(n//2),isqrt(n//2)+1):
        xx=n-2*y*y
        x=isqrt(xx)
        if x*x==xx:
            reps += [(xx,y) for xx in ({x,-x} if x else {0}) if gcd(xx,y)==1]
    omega=len(factorint(n))
    assert len(reps)==2**(omega+1),(n,reps)
    primitive_reps[str(n)]={'count':len(reps),'solutions':reps}
report['3.8.19']=primitive_reps
report['3.8.21']={'class_number_discriminant_minus12':class_number(-12)}
assert class_number(-12)==1

def mul3(a,b):
    out=[0]*3
    for i in range(3):
        for j in range(3):
            out[(i+j)%3]+=a[i]*b[j]*(6 if i+j>=3 else 1)
    return tuple(out)
lam=(2,-1,0); mu=(-1,1,0); nu=(13,8,3); eps=(1,-6,3)
candidates=[]
for h in [mu,nu]:
    a=mul3(lam,h)
    for j in range(3):
        candidates.append(a); a=mul3(a,eps)
expected=[(-2,3,-1),(88,-3,-25),(934,-981,257),(8,3,-2),(134,-81,4),(-1468,-813,892)]
assert candidates==expected
desc=[]
for A,B,C in candidates:
    assert B%3==0 and C%3!=0
    primitive_zeros=[]
    for u,v,w in product(range(27),repeat=3):
        if u%3==v%3==w%3==0: continue
        X=u**3+6*v**3+36*w**3+36*u*v*w
        Y=3*u*u*v+18*u*w*w+18*v*v*w
        Z=3*u*u*w+3*u*v*v+18*v*w*w
        if (C*X+B*Y+A*Z)%27==0: primitive_zeros.append((u,v,w))
    assert not primitive_zeros
    desc.append({'ABC':[A,B,C],'primitive_zeros_mod27':0})
report['3.7.23']={'six_candidates':desc,'primitive_residue_triples_per_candidate':27**3-9**3}

def finite_series_check(p):
    m=(p-1)//2; n=m+1
    one=[1]+[0]*(n-1)
    def mul(a,b):
        c=[0]*n
        for i,x in enumerate(a):
            for j,y in enumerate(b[:n-i]): c[i+j]=(c[i+j]+x*y)%p
        return c
    def power(a,e):
        z=one[:]
        while e:
            if e&1:z=mul(z,a)
            a=mul(a,a);e//=2
        return z
    def inv(a):
        c=[pow(a[0],-1,p)]+[0]*(n-1)
        for k in range(1,n): c[k]=-c[0]*sum(a[j]*c[k-j] for j in range(1,k+1))%p
        return c
    zeta=[1,1]+[0]*(n-2)
    xi=one[:]
    for k in range(1,p):
        S=[0]*n
        for j in range(k):
            zj=power(zeta,j)
            S=[(a+b)%p for a,b in zip(S,zj)]
        e=((p+1)//2*(1-k))%p
        theta=mul(power(zeta,e),S)
        if k%2==0:theta=[-a%p for a in theta]
        if legendre(k,p)==1:theta=inv(theta)
        xi=mul(xi,theta)
    xi=power(xi,p-1)
    x=xi[:];x[0]=(x[0]-1)%p
    result=[0]*n;term=one[:]
    for k in range(1,p):
        term=mul(term,x)
        coef=(-1 if k%2==0 else 1)*pow(k,-1,p)
        result=[(a+coef*b)%p for a,b in zip(result,term)]
    B=bernoulli(m)
    coeff=2*B.numerator*pow(B.denominator*factorial(m),-1,p)%p
    expected=[0]*m+[coeff]
    assert result==expected,(p,result,expected)
    return {'p':p,'first_possible_degree':m,'coefficient_mod_p':coeff,'computed_L_coefficients':result}
report['5.6.1']=[finite_series_check(p) for p in [5,13,17,29,37,41,53]]

power_sum_cases=[]
for p in primerange(5,200):
    m=(p-1)//2
    left=sum(pow(x,m,p) for x in range(1,m+1))%p
    right=2*(legendre(2,p)-2)*bernoulli(m+1)
    assert right.denominator%p!=0
    right_mod=right.numerator*pow(right.denominator,-1,p)%p
    assert left==right_mod,p
    power_sum_cases.append(int(p))
report['5.8.3']={'primes_checked':power_sum_cases,'p3_left':1,'p3_right_mod3':2}
bn_cases=[]
for q in primerange(3,60):
    if isprime(2*q+1):continue
    B=bernoulli(2*q)
    assert B.denominator==6 and B.numerator%4==3 and B>0
    bn_cases.append(int(q))
report['5.8.9']={'q_checked':bn_cases,'all_denominators_6_and_numerators_3_mod4':True}
ku_cases=[]
for p in [5,7,11,13,17,19]:
    for j in range(0,4):
        q=1+j*(p-1)
        z=bernoulli(2*q)/(2*q)
        assert z.numerator%p!=0 and z.denominator%p!=0
        assert z.numerator*pow(z.denominator,-1,p)%p==pow(12,-1,p)
        ku_cases.append([p,q])
report['5.8.10']={'p_q_pairs':ku_cases,'all_kummer_residues_equal_1_over_12':True}

def add(*ps):
    z={}
    for p in ps:
        for k,v in p.items():z[k]=z.get(k,0)+v
    return {k:v for k,v in z.items() if v}
def scale(p,c):return {k:v*c for k,v in p.items() if v*c}
def mul(p,q):
    z={}
    for (i,j),a in p.items():
        for (k,l),b in q.items():
            key=(i+k,j+l);z[key]=z.get(key,0)+a*b
    return {k:v for k,v in z.items() if v}
def cube(p):return mul(mul(p,p),p)
A={(3,0):1,(0,3):1,(1,2):-3};B={(2,1):3,(1,2):-3}
x=add(A,B);y=add(scale(B,2),scale(A,-1))
abdiff={(2,1):1,(1,2):-1};N={(2,0):1,(1,1):-1,(0,2):1}
assert add(x,y)==scale(abdiff,9)
assert add(mul(x,x),scale(mul(x,y),-1),mul(y,y))==scale(cube(N),3)
assert add(cube(x),cube(y))==scale(mul(abdiff,cube(N)),27)
report['5.7.1']={'coefficient_sum_norm_and_cubic_product_symbolically_verified':True,
    'proof_review':'Three locations of the factor 5 each yield a new primitive solution with strictly smaller v_3(z).'}

(OUT/'finish_ch3_ch5_exact_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n','utf-8')
print('All independent exact checks passed; report:',OUT/'finish_ch3_ch5_exact_checks.json')
