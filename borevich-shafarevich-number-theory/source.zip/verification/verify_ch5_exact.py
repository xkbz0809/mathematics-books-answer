from pathlib import Path
from fractions import Fraction as F
from math import comb, gcd, isqrt
import json, sys
W=Path(__file__).parent
assert F(1,3)+F(1,6)==F(1,2)
B=[F(1)]
for n in range(1,65):
    B.append(-sum(F(comb(n+1,j))*B[j] for j in range(n))/F(n+1))
def modrat(x,m):
    return (x.numerator*pow(x.denominator,-1,m))%m
def prime(p):
    return p>=2 and all(p%d for d in range(2,isqrt(p)+1))
def legendre(a,p):
    r=pow(a%p,(p-1)//2,p)
    return -1 if r==p-1 else r
def determinant(A):
    a=[[F(x) for x in row] for row in A];n=len(a);det=F(1)
    for k in range(n):
        pivot=next((i for i in range(k,n) if a[i][k]),None)
        if pivot is None:return F(0)
        if pivot!=k:a[k],a[pivot]=a[pivot],a[k];det=-det
        piv=a[k][k];det*=piv
        for i in range(k+1,n):
            ratio=a[i][k]/piv
            for j in range(k,n):a[i][j]-=ratio*a[k][j]
    return det
checks=[]
def check(name,actual,expected):
    assert actual==expected,(name,actual,expected)
    checks.append({'check':name,'actual':str(actual),'expected':str(expected),'passed':True})
check('B32',B[32],F(-7709321041217,510))
check('B32 numerator / 37',(-B[32]).numerator//37,208360028141)
check('B32 numerator divisible by37',B[32].numerator%37,0)
check('7 relative class number determinant',determinant([[5,1,3],[1,3,-5],[3,-5,-1]]),-196)
for p in [p for p in range(5,61) if prime(p)]:
    m=(p-1)//2
    check(f'5.8.3 p={p}',sum(pow(x,m,p) for x in range(1,m+1))%p,
          modrat(2*(legendre(2,p)-2)*B[m+1],p))
    check(f'5.8.5 p={p}',sum(pow(x,-1,p*p) for x in range(1,p))%(p*p),0)
for m in range(2,33):
    check(f'5.8.8 m={m}',modrat(2*B[2*m],4),1)
check('5.4.2 D=-20 character sum',sum([1,3,7,9])-sum([11,13,17,19]),-40)
check('5.4.2 D=-23 character sum',sum(x*legendre(x,23) for x in range(1,23)),-69)
# The p=3 counterexample is retained as evidence, not treated as a passing identity.
counter={'exercise':'5.8.3','p':3,'lhs':1,'rhs':modrat(2*(legendre(2,3)-2)*B[2],3)}
assert counter['lhs']!=counter['rhs']
result={'backend':'Python '+sys.version.split()[0],'arithmetic':'exact fractions and integers',
        'evidence_level':'exact-check / bounded-check','checks':checks,
        'bernoulli_0_to_64':[str(x) for x in B],'counterexample':counter,
        'limitations':'Finite checks accompany, and do not replace, the general proofs in the solutions.'}
(W/'reviews/ch5_exact_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'all_passed':True,'B32':str(B[32]),'counterexample':counter},ensure_ascii=False))

