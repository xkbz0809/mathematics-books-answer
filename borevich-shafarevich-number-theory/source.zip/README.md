# Borevich–Shafarevich《数论》习题解答源码

署名：小可本州。Number_Theory_Solutions_zh.tex 为独立 LaTeX 源码。使用带 Fandol 与 CM Unicode 字体的 TeX Live，连续运行三遍 xelatex -interaction=nonstopmode -halt-on-error Number_Theory_Solutions_zh.tex。
