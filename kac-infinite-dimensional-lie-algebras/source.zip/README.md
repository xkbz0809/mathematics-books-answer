# 《无穷维李代数》第三版章末习题中文解答

本册覆盖 Victor G. Kac 英文第三版、1995 年修订重印本的 14 章、344 道编号习题。第 14 章在 14.23 后接 14.25。题旁的页码是英文印刷页码，首页为扫描 PDF 第 24 页。若要从解答打开对应原页，请把输出 PDF 与原扫描件 `Infinite-Dimensional Lie Algebras (Victor G. Kac).pdf` 放在同一目录，使用支持跨文件跳转的本地 PDF 阅读器。

## 编译

需要 Python 3、PyMuPDF、XeLaTeX，以及 ctex、Fandol 字库和主文件列出的 TeX 宏包。在解压后的 Kac-solutions 目录运行

```powershell
python -X utf8 build.py
python -X utf8 review/verify_booklet.py
```

第一条命令生成带习题书签和逐题原书链接的中文解答 PDF。第二条检查实际生成的页码链接、每道题的书签位置、全册文字边界与逐题互审记录。编译和这项结构检查均可独立于原扫描件进行。

## 内容与复核

`main.tex` 控制排版，`chapters` 收录十四章的解答，`original-pages.tex` 保存逐题原书印页。`review` 内有三份按题号列出的独立数学互审记录，合计 344 道；`exercise-revisions.json` 保存 64 道题的中英文修订、原页与勘误编号。数值核查的假设和范围写在对应记录中。

原书标为公开问题的题目分别讨论已有定理、反例及仍未取得一般解答的部分。3.19 区分对群元素逐个局部有限与对整个单参数群共同局部有限。3.25 和 10.23 分别写明已核实的分类范围。13.37 引用 Legros 的预印本，所引定理的归一化和范围已核对，本册未独立重跑该预印本的计算。
