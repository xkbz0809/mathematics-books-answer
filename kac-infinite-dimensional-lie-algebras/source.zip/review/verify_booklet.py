"""Check printed-page links, heading locations, review coverage, and page bounds of the finished booklet."""
from pathlib import Path
import argparse
import collections
import hashlib
import json
import re
import pymupdf as fitz

BASE = Path(__file__).resolve().parents[1]
NAME = "无穷维李代数（第三版）-章末习题中文解答.pdf"
ORIGINAL = "Infinite-Dimensional Lie Algebras (Victor G. Kac).pdf"
EXPECTED = [16, 11, 25, 14, 28, 13, 29, 17, 21, 23, 22, 24, 39, 62]
REVIEW_FILES = ["crossreview-01-03-and-14-by-representations.md", "crosscheck-04-07-12.md", "independent-08-11-13.md"]

def validate(pdf):
    places = dict(re.findall(r"\\Place\{(\d+\.\d+)\}\{(\d+)\}", (BASE / "original-pages.tex").read_text(encoding="utf8")))
    numbered = []
    for chapter, count in enumerate(EXPECTED, start=1):
        tex = (BASE / "chapters" / f"ch{chapter:02d}.tex").read_text(encoding="utf8")
        ids = re.findall(r"\\Sol\{(\d+\.\d+)\}", tex)
        printed_ids = [f"{chapter}.{j}" for j in range(1, count + 1 + (chapter == 14)) if (chapter,j) != (14,24)]
        assert ids == printed_ids, chapter
        numbered.extend(ids)
    assert numbered == list(places) and len(numbered) == 344
    reviews = {}
    for name in REVIEW_FILES:
        rows = re.findall(r"^\|\s*(\d+\.\d+)\s*\|", (BASE/"review"/name).read_text(encoding="utf8"), re.M)
        reviews[name] = [n for n in rows if n != "14.24"]
    assert collections.Counter(n for a in reviews.values() for n in a) == collections.Counter(numbered), "review coverage"
    with fitz.open(pdf) as doc:
        toc = doc.get_toc(False)
        assert [t[0] for t in toc].count(1) == 14
        exact = [(t.split()[0], physical-1, dest) for level,t,physical,dest in toc if level == 2]
        assert [t[0] for t in exact] == numbered
        refs = []
        named = doc.resolve_names()
        for page in doc:
            assert len(page.get_text().strip()) > 3, page.number
            for w in page.get_text("words"):
                assert w[0] >= 22 and w[2] <= page.rect.width-22 and w[1] >= 15 and w[3] <= page.rect.height-12, (page.number+1,w)
            for link in sorted(page.get_links(),key=lambda l:(round(l["from"].y0,1),l["from"].x0)):
                ref = link["xref"]
                if doc.xref_get_key(ref,"A/S")[1] == "/GoToR":
                    assert doc.xref_get_key(ref,"A/F")[1] == ORIGINAL
                    target = re.fullmatch(r"\[(\d+)\s*/Fit\]",doc.xref_get_key(ref,"A/D")[1])
                    assert target and doc.xref_get_key(ref,"A/NewWindow")[1] == "true"
                    refs.append((page.number,int(target[1]),link["from"]))
                elif link.get("kind") == fitz.LINK_NAMED:
                    assert link.get("nameddest") in named
                elif link.get("kind") == fitz.LINK_GOTO:
                    assert 0 <= link["page"] < len(doc)
                elif link.get("uri"):
                    assert "original-page.invalid" not in link["uri"]
        assert len(refs) == len(exact)
        gaps=[]
        for (n, page_no, dest),(ref_page, target, box) in zip(exact,refs):
            assert target == int(places[n])+22 and page_no == ref_page, (n,target,ref_page)
            page=doc[page_no]
            y=page.rect.height-dest["to"].y
            words=[w for w in page.get_text("words") if w[4].rstrip(".") == n and w[0]<90 and abs(w[1]-box.y0)<16]
            assert len(words)==1, (n,page_no+1,words)
            gap=words[0][1]-y
            assert -0.8<=gap<=30,(n,page_no+1,gap)
            gaps.append(gap)
        return dict(pages=len(doc), chapters=14, exercises=len(exact), by_chapter=EXPECTED, chapter_and_exercise_bookmarks=len(toc), confirmed_heading_positions=len(gaps), bookmark_to_heading_gap_pt=[round(min(gaps),2),round(max(gaps),2)], original_file=ORIGINAL, per_exercise_original_links=len(refs), all_original_pages_checked=True, independent_review_counts={k:len(v) for k,v in reviews.items()}, all_page_bounds_checked=True, sha256=hashlib.sha256(pdf.read_bytes()).hexdigest())

if __name__ == "__main__":
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--pdf",type=Path,default=BASE/NAME)
    ap.add_argument("--report",type=Path)
    args=ap.parse_args()
    report=validate(args.pdf)
    data=json.dumps(report,ensure_ascii=False,indent=2)
    if args.report:
        args.report.write_text(data+"\n", encoding="utf8")
    print(data)
