from pathlib import Path
from itertools import product
from math import gcd,lcm
from collections import Counter
import numpy as np
from functools import lru_cache

@lru_cache(None)
def idet(rows):
    if not rows: return 1
    return sum((-1)**j*v*idet(tuple(r[:j]+r[j+1:] for r in rows[1:]))
               for j,v in enumerate(rows[0]) if v)
def det(M):
    return idet(tuple(tuple(map(int,r)) for r in M))

def chain(m):
    return [(i,i+1) for i in range(m-1)]
def star(*arms):
    edges=[]; nxt=1
    for a in arms:
        last=0
        for _ in range(a-1):
            edges.append((last,nxt));last=nxt;nxt+=1
    return edges
def fdiag(m):
    yield 'A'+str(m),chain(m)
    if m>=4:yield 'D'+str(m),star(m-2,2,2)
    for p in [3,4,5]:
        if m==p+3:yield 'E'+str(m),star(p,3,2)
    if m==2:yield 'A1~',[(0,1),(0,1)]
    if m>=3:yield 'A~',chain(m)+[(m-1,0)]
    if m==5:yield 'D4~',star(2,2,2,2)
    if m>=6:
        dist=m-5
        yield 'D~',chain(dist+1)+[(0,dist+1),(0,dist+2),(dist,dist+3),(dist,dist+4)]
    for name,p,q,r in [('E6~',3,3,3),('E7~',4,4,2),('E8~',6,3,2)]:
        if m==p+q+r-2:yield name,star(p,q,r)
def matrix(m,e):
    A=2*np.eye(m,dtype=np.int64)
    for i,j in e:A[i,j]-=1;A[j,i]-=1
    return A
def arm_lengths(A):
    adj=[set(j for j in range(len(A)) if j!=i and A[i,j]!=0) for i in range(len(A))]
    assert np.min(A)==-1
    v,=[i for i,row in enumerate(adj) if len(row)==3]
    out=[]
    for u in adj[v]:
        old=v; count=1
        while len(adj[u])==2:
            old,u=u,(adj[u]-{old}).pop();count+=1
        assert len(adj[u])==1
        out.append(count)
    return sorted(out)
copies=Counter(); isos=Counter()
for n in range(3,11):
    m=n-1; U=np.array(list(product(range(3),repeat=m)),dtype=np.int64)
    for nam,E in fdiag(m):
        B=matrix(m,E)
        adj=np.array([[(-1)**(i+j)*det(np.delete(np.delete(B,j,axis=0),i,axis=1)) for j in range(m)] for i in range(m)],dtype=np.int64);target=2*det(B)+1
        cand=U[np.sum((U@adj)*U,axis=1)==target]
        for u in cand:
            M=np.vstack([np.column_stack([B,-u]),np.append(-u,2)])
            if any(np.linalg.eigvalsh(np.delete(np.delete(M,i,axis=0),i,axis=1)).min() < -1e-6 for i in range(n)):continue
            for k in range(1,n):
                import itertools
                assert all(det(M[np.ix_(j,j)])>=0 for j in itertools.combinations(range(n),k))
            copies[n]+=1
            assert n==10 and arm_lengths(M)==[1,2,6]
            isos[(n,nam)]+=1
print('4.5',copies,isos)
orders=[1,2,3,4,5,6,7,8,9,10,12,14,18]
results={}
for m in sorted({lcm(i,j) for i in orders for j in orders}):
    U=[i for i in range(m) if gcd(i,m)==1]; out=set()
    for a in range(m):
      for b in range(a,m):
        if gcd(a,gcd(b,m))!=1:continue
        ss=[0,a,b]; dif=Counter((ss[i]-ss[j])%m for i in range(3) for j in range(3) if i!=j)
        if any(dif[(k*d)%m]!=v for d,v in dif.items() for k in U):continue
        reps=[tuple(sorted(((v-q)*sign)%m for v in ss)[1:]) for q in ss for sign in (1,-1)]
        out.add(min(reps))
    if out:results[m]=sorted(out)
print('8.12',results)

