"""Build the Chinese solutions and turn printed-page citations into local PDF links."""
from pathlib import Path
import os
import argparse
import re
import shutil
import subprocess
import pymupdf as fitz

HERE = Path(__file__).resolve().parent
BOOK = "Infinite-Dimensional Lie Algebras (Victor G. Kac).pdf"
OUTPUT = "无穷维李代数（第三版）-章末习题中文解答.pdf"

def build(output):
    out = HERE / "build"
    out.mkdir(exist_ok=True)
    env = dict(os.environ, SOURCE_DATE_EPOCH="1795219200", FORCE_SOURCE_DATE="1", TZ="UTC")
    for _ in range(2):
        args = ["xelatex", "-halt-on-error", "-file-line-error", "-interaction=nonstopmode", "-output-directory=build", "main.tex"]
        with (out/"compile.txt").open("wb") as log:
            rc = subprocess.run(args, cwd=HERE, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
        if rc:
            print((out/"compile.txt").read_text(encoding="utf8",errors="replace")[-3500:])
            raise SystemExit(rc)
    mapping = dict(re.findall(r"\\Place\{([\d.]+)\}\{(\d+)\}", (HERE/"original-pages.tex").read_text(encoding="utf8")))
    ids = [a for f in sorted((HERE/"chapters").glob("ch[0-9][0-9].tex")) for a in re.findall(r"\\Sol\{([\d.]+)\}", f.read_text(encoding="utf8"))]
    if len(ids) != 344 or list(mapping) != ids or len(set(ids)) != 344:
        raise ValueError("章末题号、原书页索引与 344 题清单不符。")
    with fitz.open(out/"main.pdf") as doc:
        refs = []
        for page in doc:
            for link in sorted(page.get_links(),key=lambda l:(round(l["from"].y0,1),l["from"].x0)):
                target = re.fullmatch(r"https://original-page\.invalid/(\d+)",link.get("uri","") or "")
                if target:
                    printed = int(target[1])
                    refs.append(printed)
                    action = "<< /S /GoToR /F "+fitz.get_pdf_str(BOOK)+f" /D [{printed+22} /Fit] /NewWindow true >>"
                    doc.xref_set_key(link["xref"],"A",action)
        assert refs == [int(mapping[x]) for x in ids], (len(refs),len(ids))
        assert len(doc.get_toc()) == 358, len(doc.get_toc())
        temp=out/"solutions-linked.pdf"
        doc.save(temp,garbage=4,deflate=True,no_new_id=True)
    with fitz.open(temp) as doc:
        links=[l for p in doc for l in p.get_links()]
        assert sum(doc.xref_get_key(l['xref'],'A/S')[1]=='/GoToR' for l in links)==344
        exercises = [t for t in doc.get_toc() if re.match(r'\d+\.\d+\s', t[1])]
        assert len(exercises) == len(ids)
        for title_id,(depth,title,page) in zip(ids,exercises):
            assert title.startswith(title_id+" ") and page>0
        print(f"{len(doc)} pages, {len(doc.get_toc())} bookmarks, 344 source-page links")
    shutil.copyfile(temp, output)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--output",type=Path,default=HERE/OUTPUT)
    build(p.parse_args().output)

