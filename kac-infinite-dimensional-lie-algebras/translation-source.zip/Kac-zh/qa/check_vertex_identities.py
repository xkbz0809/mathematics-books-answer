"""Exact finite polynomial and Taylor-series checks; Python standard library only."""
from fractions import Fraction as F
N=8
class P:
    def __init__(self,value=0):
        if isinstance(value,P): self.c=value.c.copy()
        elif isinstance(value,dict): self.c={k:F(v) for k,v in value.items() if v}
        else:self.c={(0,)*N:F(value)} if value else {}
    @staticmethod
    def var(i):
        m=[0]*N;m[i]=1
        return P({tuple(m):1})
    def __add__(self,b):
        b=P(b);c=self.c.copy()
        for m,v in b.c.items():c[m]=c.get(m,F(0))+v
        return P(c)
    __radd__=__add__
    def __neg__(self):return P({m:-v for m,v in self.c.items()})
    def __sub__(self,b):return self+-P(b)
    def __rsub__(self,b):return P(b)+-self
    def __mul__(self,b):
        b=P(b);c={}
        for a,x in self.c.items():
            for d,y in b.c.items():
                m=tuple(i+j for i,j in zip(a,d));c[m]=c.get(m,F(0))+x*y
        return P(c)
    __rmul__=__mul__
    def __truediv__(self,n):return P({m:v/n for m,v in self.c.items()})
    def __pow__(self,n):
        out=P(1)
        for _ in range(n):out=out*self
        return out
    def __eq__(self,b):return self.c==P(b).c
    def coeff(self,i,k):
        return P({tuple(0 if j==i else a for j,a in enumerate(m)):v for m,v in self.c.items() if m[i]==k})
    def even(self):return P({m:v for m,v in self.c.items() if sum(m[:6])%2==0})
D=[P.var(i) for i in range(6)]
y1,y3=P.var(6),P.var(7)
def schur(xs,n):
    if n<0:return P(0)
    h=[P(1)]
    for m in range(1,n+1):
        h.append(sum(k*xs[k-1]*h[m-k] for k in range(1,m+1))/m)
    return h[n]
dt=[-D[j-1]/j for j in range(1,7)]
assert 2*schur(dt,2)==D[0]**2-D[1]  # First MKP hierarchy, n=1, y=0.
assert 12*(2*schur(dt,4)-D[0]*D[2]).even()==D[0]**4+3*D[1]**2-4*D[0]*D[2]
p2=2*schur(dt,3)-D[0]*D[1]
assert p2==-D[0]**3/3-2*D[2]/3
p11=2*schur(dt,3)+2*schur(dt,2)*D[0]-D[0]**3/2
m1=(3,0,0,0,0,0,0,0);m3=(0,0,1,0,0,0,0,0)
assert p2.c[m1]*p11.c[m3]-p2.c[m3]*p11.c[m1]!=0
kdv_y=[4*y1,0,4*y3,0]
kdv_d=[-2*D[0],0,-2*D[2]/3,0]
base=sum(schur(kdv_y,n)*schur(kdv_d,n) for n in range(1,5))-8*(y1*D[0]+3*y3*D[2])
kdv=(base*(1+y1*D[0])*(1+y3*D[2])).coeff(6,1).coeff(7,1)
assert kdv==F(16,3)*(D[0]**4-4*D[0]*D[2])
# Adjacent charges m=n+1. Extract y=0 and [y1^2] from the generating series.
nls_y=[2*y1,0,0,0]
nls_d=[-2*D[0],-D[1],-2*D[2]/3,-D[3]/2]
exponential=1+y1*D[0]+y1**2*D[0]**2/2
def nls_middle(lower):
    return sum(schur(nls_y,j)*schur(nls_d,j) for j in range(lower,3))*exponential
assert (P(1)-nls_middle(0)).coeff(6,0)==0
assert (P(1)-nls_middle(1)).coeff(6,0)==1
first=((1+2*y1*D[0])*exponential).coeff(6,2)
second=nls_middle(0).coeff(6,2)
assert first-second==2*(D[0]**2+D[1])
# Cubic Taylor jets in q, with exact rational coefficients.
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(c,a):return tuple(c*x for x in a)
def mul(a,b):return tuple(sum(a[j]*b[i-j] for j in range(i+1)) for i in range(4))
def inv(a):
    b=[1/a[0]]
    for i in range(1,4):b.append(-sum(a[j]*b[i-j] for j in range(1,i+1))/a[0])
    return tuple(b)
def derivative(a):return (a[1],2*a[2],3*a[3],F(0))
for a in map(F,[-2,-1,1,2]):
    for q in map(F,[F(1,3),1,2,7]):
        qjet=(q,F(1),F(0),F(0));den=(1+q,F(1),F(0),F(0))
        u=scale(8*a*a,mul(qjet,inv(mul(den,den))))
        dx=lambda f:scale(2*a,mul(qjet,derivative(f)))
        dtq=lambda f:scale(2*a**3,mul(qjet,derivative(f)))
        def residue(f):return dtq(f)[0]-F(3,2)*f[0]*dx(f)[0]-F(1,4)*dx(dx(dx(f)))[0]
        assert residue(u)==0
        if a==2 and q==F(1,3):assert residue(scale(1/a,u))!=0
# The odd principal sl2 matrix has trace pairing -2.
def matmul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
for t in [F(1),F(2),F(-3)]:
    B=[[F(0),F(1)],[-t,F(0)]];C=matmul(B,B)
    assert (C[0][0]+C[1][1])/t==-2
print('KP even symbol, independent cubic symbols and KdV y1*y3 coefficient: OK')
print('NLS quadratic symbol and exact KdV soliton checks at 16 parameter pairs: OK')
print('Principal odd dual-basis trace sign: OK')
