"""Compare printed root coordinates with the fundamental-chamber inequalities.

Run with Python 3 from any directory. The input tables are read-only. H2 is
folded by its diagram involution. In H3, writing k=(a,b,c), Ak<=0 implies
2b<=2a+c and 2c<=b, hence b<=4a/3 and c<=b/2. These bounds make the search
exhaustive without borrowing a coordinate cutoff from the printed tables.
"""
from collections import Counter
from pathlib import Path
import re

H2 = ((2, -3), (-3, 2))
H3 = ((2, -2, 0), (-2, 2, -1), (0, -1, 2))
TABLE = Path(__file__).resolve().parents[1] / 'graphics' / 'ch11-root-tables.tex'
ENTRY = re.compile(r'\\krootentry\{([\d,]+)\}\{(\d+)\}\{(\d+)\}')


def matrix_times(cartan, point):
    return tuple(sum(x*y for x, y in zip(row, point)) for row in cartan)


def belongs(cartan, point):
    image = matrix_times(cartan, point)
    return max(image) <= 0 and sum(x*y for x, y in zip(point, image)) < 0


def report(name, expected, rows):
    printed = Counter(rows)
    missing = sorted(expected - printed.keys())
    extra = sorted(printed.keys() - expected)
    duplicate = {p: n for p, n in printed.items() if n > 1}
    print(f'{name}: expected {len(expected)}, printed {len(rows)}, in range {len(expected & printed.keys())}')
    print(f'  missing ({len(missing)}): {missing}')
    print(f'  extra ({len(extra)}): {extra}; duplicates: {duplicate}')
    return len(missing), extra, duplicate


def main():
    text = TABLE.read_text(encoding='utf-8-sig')
    parsed = [(tuple(map(int, coord.split(','))), int(norm), int(mult))
              for coord, norm, mult in ENTRY.findall(text)]
    h2 = [p for p, _, _ in parsed if len(p) == 2]
    h3 = [p for p, _, _ in parsed if len(p) == 3]
    assert len(parsed) == len(h2) + len(h3)
    h2_chamber = {(a, b) for a in range(1, 22) for b in range(a+1)
                  if belongs(H2, (a, b))}
    h3_chamber = {(a, b, c) for a in range(1, 15) for b in range(4*a//3+1)
                  for c in range(b//2+1) if belongs(H3, (a, b, c))}
    assert report('H2 printed', h2_chamber, h2) == (13, [(22, 15)], {})
    raw = report('H3 printed', h3_chamber, h3)
    misprint, candidate = (12, 15, 5), (12, 12, 5)
    assert (misprint, 35, 17893) in parsed and candidate not in h3
    for p in (misprint, candidate):
        image = matrix_times(H3, p)
        half_norm = -sum(x*y for x, y in zip(p, image))//2
        print(f'  {p}: Ak={image}, -(k^t Ak)/2={half_norm}')
    corrected = [candidate if p == misprint else p for p in h3]
    assert report('H3 with coordinate interpreted', h3_chamber, corrected) == (23, [], {})
    assert raw == (24, [misprint], {})


if __name__ == '__main__':
    main()
