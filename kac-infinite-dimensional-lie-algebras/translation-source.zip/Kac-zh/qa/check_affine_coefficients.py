"""Exact Laurent coefficients through q^18 and Sugawara finite sums."""
from collections import defaultdict
N=18
def factor(p,d,j):
 s=defaultdict(int,p)
 for (x,z),c in p.items():
  if x+d<=N:s[x+d,z+j]-=c
 return {k:v for k,v in s.items() if v}
p={(0,0):1};q={(0,0):1};
for n in range(1,N+2):
 for d,j in [(n,0),(n,-1),(n-1,1)]:p=factor(p,d,j);q=factor(q,d,j)
 for d,j in [(2*n-1,2),(2*n-1,-2)]:q=factor(q,d,j)
a={};b={}
for m in range(-30,31):
 i=m*(m-1)//2
 if i<=N:a[i,m]=(-1 if m%2 else 1)
 i=(3*m*m+m)//2
 if i<=N:b[i,-3*m]=1;b[i,3*m+1]=-1
print('Jacobi triple',p==a,'quintuple',q==b)
if q!=b:print('difference',[(k,v,b.get(k)) for k,v in q.items() if v!=b.get(k)][:10]);
assert p==a and q==b
for m in range(1,51):assert sum(j*(m-j) for j in range(m))==(m**3-m)//6
print('Sugawara central term m=1..50: pass')
