"""Check Exercise 8.16 directly from its TeX entries over Laurent polynomials."""
from pathlib import Path
import re

chapter = (Path(__file__).resolve().parents[1] / "chapters/ch08.tex").read_text(encoding="utf-8")
entries = re.findall(r"L_\{8s(?:\+\d)?\}&=\\begin\{pmatrix\}(.*?)\\end\{pmatrix\}", chapter)
assert len(entries) == 8
matrices = []
for entry in entries:
    flat = []
    for item in re.split(r"&|\\\\", entry):
        if item == "0":
            flat.append((0, 0))
        else:
            m = re.fullmatch(r"(-?)(2?)t\^\{2s(?:\+(\d+))?\}", item)
            assert m, item
            flat.append(((-1 if m[1] else 1) * int(m[2] or 1), int(m[3] or 0)))
    assert len(flat) == 9
    matrices.append(flat)

for i in range(8):
    for j in range(8):
        target = matrices[(i + j) % 8]
        ratio = None
        for row in range(3):
            for col in range(3):
                value = {}
                for a, b, sign in [(i, j, 1), (j, i, -1)]:
                    for k in range(3):
                        u, p = matrices[a][3*row+k]
                        v, q = matrices[b][3*k+col]
                        value[p+q] = value.get(p+q, 0) + sign*u*v
                terms = {e:c for e,c in value.items() if c}
                coeff, exp = target[row*3+col]
                exp += 2*((i+j)//8)
                if not coeff:
                    assert not terms, (i, j, terms)
                    continue
                assert set(terms) <= {exp} and terms.get(exp, 0) % coeff == 0
                scalar = terms.get(exp, 0) // coeff
                assert ratio is None or ratio == scalar
                ratio = scalar
        assert ratio is not None
print("64/64 residue pairs: commutator equals an integer multiple of the required basis element.")
