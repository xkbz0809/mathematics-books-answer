"""Finite A1 Verlinde checks for levels 1 through 9."""
import math
# Independent fusion check using the A1 discrete sine transform for all levels 1 through 9.
maxerr=0.;nchecks=0
for k in range(1,10):
    S=[[math.sqrt(2/(k+2))*math.sin(math.pi*(i+1)*(j+1)/(k+2)) for j in range(k+1)] for i in range(k+1)]
    for i in range(k+1):
      for j in range(k+1):
       for s in range(k+1):
        val=sum(S[i][e]*S[j][e]*S[s][e]/S[0][e] for e in range(k+1));expected=int(abs(i-j)<=s<=i+j and (i+j+s)%2==0 and i+j+s<=2*k);maxerr=max(maxerr,abs(val-expected));nchecks+=1
print('FUSION',nchecks,maxerr);assert maxerr<1e-12
