"""Independent finite tests for the transcribed signs, exponents and root data."""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from math import comb

bound = 12

def factor(p, i, j):
    out = Counter(p)
    for (a,b), n in p.items():
        if a+i <= bound and b+j <= bound:
            out[a+i,b+j] -= n
    return {m:c for m,c in out.items() if c}

def polynomial(factors):
    p = {(0,0):1}
    for i,j in factors:
        p = factor(p,i,j)
    return p

def collect(terms):
    p = Counter()
    for i,j,c in terms:
        if 0 <= i <= bound and 0 <= j <= bound:
            p[i,j] += c
    return {m:c for m,c in p.items() if c}

indices = list(range(-bound-1,bound+2))
triple = polynomial((i,j) for n in range(1,bound+2)
                     for i,j in ((n,n),(n-1,n),(n,n-1)))
for sign in [1,-1]:
    assert triple == collect((m*(m+sign)//2,m*(m-sign)//2,(-1)**(m%2)) for m in indices)
five = polynomial((i,j) for n in range(1,bound+2)
                  for i,j in ((2*n,n),(2*n-1,n-1),(2*n-1,n),(4*n-4,2*n-1),(4*n,2*n-1)))
terms = [(3*m*m-2*m,(3*m*m+m)//2,1) for m in indices]
terms += [(3*m*m-4*m+1,(3*m*m-m)//2,-1) for m in indices]
assert five == collect(terms)

# Rank one: pairings for the affine translation, on the hyperplane of level m.
def translate(v, k):
    m,x,d = v
    return (m, x+m*k, d-2*x*k-m*k*k)
def norm(v):
    m,x,d = v
    return 2*x*x+2*m*d
for v in product(range(-2,3), repeat=3):
    for a,b in product(range(-2,3),repeat=2):
        assert norm(translate(v,a)) == norm(v)
        assert translate(translate(v,b),a) == translate(v,a+b)

# Standard coordinates in section 6.7.
short = [1,-1,0]
long = [1,1,-2]
assert F(sum(x*x for x in short),3)==F(2,3)
assert F(sum(x*x for x in long),3)==2
assert 112+2**7==240                 # E8, even number of minus signs
assert 8*7+comb(8,4)==126            # E7, four minus signs
assert 6*5+2*comb(6,3)+2==72         # E6, three of each sign
assert pow(2,4,9)==7 and (-1)**((9*9-1)//8)==1
print("Jacobi triple product in both variable orders and quintuple product, all 169 coefficients each: OK")
print("Affine rank-one translations: 3125 compositions and norm checks: OK")
print("G2 root lengths and E6/E7/E8 root counts: OK; exercise 10.18 counterexample: 7 != 1 (mod 9)")
