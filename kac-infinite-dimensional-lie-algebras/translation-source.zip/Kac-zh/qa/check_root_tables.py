"""Recompute every printed H2 and H3 entry using the Weyl denominator.

The bounds include each source coordinate. All series operations are exact
in the rectangular truncation of the multivariable formal power series ring.
"""
from collections import deque
from functools import reduce
from itertools import product
from math import gcd
from pathlib import Path
import re

def multiplicities(cartan, bound):
    zero = (0,) * len(bound)
    # beta = rho - w(rho). Left multiplication by r_i increases length
    # exactly when its change in coordinate i is positive.
    denominator = {zero: 1}
    queue = deque([zero])
    while queue:
        point = queue.popleft()
        for i, row in enumerate(cartan):
            step = 1 - sum(a * b for a, b in zip(row, point))
            if step <= 0 or point[i] + step > bound[i]:
                continue
            nxt = list(point)
            nxt[i] += step
            nxt = tuple(nxt)
            if nxt not in denominator:
                denominator[nxt] = -denominator[point]
                queue.append(nxt)
            else:
                assert denominator[nxt] == -denominator[point]
    terms = [(g, d) for g, d in denominator.items() if g != zero]
    # Apply the total-degree Euler derivation E to R.
    # -ER/R = sum_{alpha,k>=1} ht(alpha) mult(alpha) x^(k alpha).
    log_deriv = {zero: 0}
    mult = {zero: 0}
    for beta in sorted(product(*(range(b + 1) for b in bound)), key=sum)[1:]:
        total = -sum(beta) * denominator.get(beta, 0)
        for gamma, d in terms:
            rest = tuple(b - g for b, g in zip(beta, gamma))
            if min(rest) >= 0:
                total -= d * log_deriv[rest]
        log_deriv[beta] = total
        divisor = reduce(gcd, beta)
        for k in range(2, divisor + 1):
            if divisor % k == 0:
                smaller = tuple(b // k for b in beta)
                total -= sum(smaller) * mult[smaller]
        assert total % sum(beta) == 0
        mult[beta] = total // sum(beta)
    return mult

data = (Path(__file__).resolve().parents[1] / 'graphics/ch11-root-tables.tex').read_text(encoding='utf-8')
rows = [(tuple(map(int, coords.split(','))), int(norm), int(mult))
        for coords, norm, mult in re.findall(r'\\krootentry\{([\d,]+)\}\{(\d+)\}\{(\d+)\}', data)]
for n, matrix in [(2, [[2, -3], [-3, 2]]), (3, [[2, -2, 0], [-2, 2, -1], [0, -1, 2]])]:
    chunk = [row for row in rows if len(row[0]) == n]
    assert len(chunk) == len({row[0] for row in chunk})
    bound = tuple(max(row[0][i] for row in chunk) for i in range(n))
    result = multiplicities(matrix, bound)
    errors = []
    for coords, printed_norm, printed_mult in chunk:
        norm = -sum(x*y*a for x, row in zip(coords, matrix) for y, a in zip(coords, row)) // 2
        if (norm, result[coords]) != (printed_norm, printed_mult):
            errors.append((coords, printed_norm, printed_mult, norm, result[coords]))
    print(f'H{n}: {len(chunk)} rows, {2*len(chunk)} checks, differences (coords, print norm, print mult, calc norm, calc mult): {errors}')
