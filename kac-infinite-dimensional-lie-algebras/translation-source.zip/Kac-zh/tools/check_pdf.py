"""Validate rendered numbering, named links, section bookmark positions and page bounds."""
from pathlib import Path
from collections import Counter
import argparse,json,re,hashlib
import pymupdf as fitz
root=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser()
ap.add_argument('--pdf',type=Path,default=root/'main.pdf')
ap.add_argument('--aux',type=Path,default=root/'build/main.aux')
ap.add_argument('--report',type=Path,default=root/'qa/pdf-validation.json')
a=ap.parse_args();doc=fitz.open(a.pdf);names=doc.resolve_names()
texts=[p.get_text() for p in doc];compact=[''.join(t.split()) for t in texts]
def groups(s):
 out=[];d=0;start=None
 for i,c in enumerate(s):
  if c=='{' and (i==0 or s[i-1]!='\\'):
   if d==0:start=i+1
   d+=1
  elif c=='}' and (i==0 or s[i-1]!='\\'):
   d-=1
   if d==0:out.append(s[start:i])
 return out
labels={}
for line in a.aux.read_text(encoding='utf-8').splitlines():
 if not line.startswith(r'\newlabel{'):continue
 g=groups(line[len(r'\newlabel'):])
 if len(g)>=2:
  v=groups(g[1])
  if len(v)>=4:labels[g[0]]=v
errors=[];anchors=0;number_checks=0
for key,v in labels.items():
 if key.endswith('@cref'):continue
 dest=names.get(v[3])
 if not dest:errors.append(('label destination',key,v[3]));continue
 anchors+=1;p=dest['page']
 if not 0<=p<len(doc):errors.append(('label page',key,p));continue
 if doc[p].get_label()!=v[1]:errors.append(('printed page',key,v[1],doc[p].get_label()))
 if re.match(r'^(?:eq|ex|sec|thm|prop|lem|cor|def|rem):\d',key):
  number_checks+=1
  expected=re.match(r'\d+(?:\.\d+)*',key.split(':',1)[1])[0]
  actual=re.sub(r'[{}$\s]','',v[0])
  actual_number=re.search(r'\d+(?:\.\d+)*',actual)
  if not actual_number or actual_number[0]!=expected:errors.append(('aux number',key,v[0]))
  x,y=dest.get('to',(0,0));top=doc[p].rect.height-y
  nearby=doc[p].get_text(clip=fitz.Rect(0,max(0,top-16),doc[p].rect.width,min(doc[p].rect.height,top+70)))
  if expected not in ''.join(nearby.split()):
   if expected not in compact[p]:errors.append(('rendered number',key,p+1,expected))
source=json.loads((root/'qa/source-validation.json').read_text(encoding='utf-8'))
alltext=''.join(compact);tags=[]
for item in source['equations']:
 tag=item['tag']
 m=re.match(r'\d+\.\d+\.\d+',tag)
 if m:
  base=m[0];ok=bool(re.search(r'\('+re.escape(base)+r'(?:[A-Za-z0-9]+)?\)',alltext))
  if not ok:errors.append(('equation tag not visible',tag,item['file']))
  tags.append(base)
 else:
  # The six transformation-family tags are T1, T2 and T1^- through T4^-.
  base=re.sub(r'\$|[{}^]','',tag)
  if '('+base+')' not in ''.join(compact).replace('−','-'):errors.append(('equation family tag not visible',tag,item['file']))
  tags.append(base)
bookmarks=doc.get_toc(False);section_checks=0;section_geometry=[]
for _,title,page,target in bookmarks:
 m=re.fullmatch(r'§(\d+\.\d+)',title)
 if not m:continue
 section_checks+=1;p=page-1;dest=names.get(target.get('nameddest',''))
 if not dest:errors.append(('bookmark destination',title));continue
 top=doc[p].rect.height-dest['to'][1]
 hits=[w for w in doc[p].get_text('words') if w[4]=='§'+m[1]+'.']
 if not hits:errors.append(('bookmark heading text',title,page));continue
 gap=min(abs(w[1]-top) for w in hits)
 if gap>22:section_geometry.append((title,page,round(gap,2)))
if section_geometry:errors.append(('bookmark position',section_geometry))
links=Counter();unresolved=[];bounds=[]
for i,p in enumerate(doc):
 for link in p.get_links():
  links[link['kind']]+=1
  if link['kind']==fitz.LINK_GOTO and not 0<=link['page']<len(doc):unresolved.append((i+1,link))
  if link['kind']==fitz.LINK_NAMED and link.get('nameddest') not in names:unresolved.append((i+1,link))
 for w in p.get_text('words'):
  if w[0]<25 or w[2]>p.rect.width-25 or w[1]<20 or w[3]>p.rect.height-15:
   bounds.append((i+1,list(w[:4]),w[4]))
if unresolved:errors.append(('unresolved links',unresolved[:15]))
if bounds:errors.append(('text outside printable page',bounds[:15]))
for n in range(1,560):
 if 'bib:ref'+str(n).zfill(3) not in names:errors.append(('bibliography entry destination',n))
report={'pdf':a.pdf.name,'pages':len(doc),'sha256':hashlib.sha256(a.pdf.read_bytes()).hexdigest(),
 'labels_checked':anchors,'rendered_number_checks':number_checks,'equation_tags_checked':len(tags),
 'bookmarks':len(bookmarks),'section_bookmark_checks':section_checks,'named_destinations':len(names),
 'link_kinds':dict(links),'bibliography_destinations':559,'out_of_page_text':bounds,'errors':errors}
a.report.parent.mkdir(parents=True,exist_ok=True);a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print({k:v for k,v in report.items() if k not in ['errors','out_of_page_text']})
print('ERRORS',errors[:30])
if errors:raise SystemExit(1)
