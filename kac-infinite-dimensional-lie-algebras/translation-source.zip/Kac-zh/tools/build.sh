#!/usr/bin/env bash
set -euo pipefail
python -X utf8 tools/build.py "$@"
