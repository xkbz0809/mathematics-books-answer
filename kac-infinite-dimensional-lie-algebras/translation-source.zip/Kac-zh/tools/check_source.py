"""Check active source closure, labels, references, numbered objects and file identity."""
from pathlib import Path
from collections import Counter
import re,json,hashlib
root=Path(__file__).resolve().parents[1]
seen=set();files=[]
def visit(p):
 p=p.resolve()
 if p in seen:return
 seen.add(p);files.append(p)
 s=p.read_text(encoding='utf-8')
 for name in re.findall(r'\\input\{([^{}#]*)\}',s):
  q=(root/name).with_suffix('.tex')
  assert q.exists(),(p,name)
  visit(q)
visit(root/'main.tex')
texts={p.relative_to(root).as_posix():re.sub(r'(?<!\\)%[^\n]*','',p.read_text(encoding='utf-8')) for p in files}
alltext='\n'.join(texts.values())
labels=Counter(re.findall(r'\\label\{([^{}#]*)\}',alltext))
refs=[]
for name,s in texts.items():
 for p in [r'\\(?:eqref|ref|pageref|autoref)\{([^{}#]*)\}',r'\\hyperref\[([^]#]*)\]']:
  refs.extend((name,m[1]) for m in re.finditer(p,s))
 for cmd,prefix in [('ksref','sec:'),('kchapterref','ch:'),('cteq','eq:'),('cseq','eq:'),('cftab','tab:4.')]:
  refs.extend((name,prefix+m[1]) for m in re.finditer(r'\\'+cmd+r'\{([^{}#]*)\}',s))
 refs.extend((name,m[1]+':'+m[2]) for m in re.finditer(r'\\korig\{([^{}#]*)\}\{([^{}#]*)\}',s))
duplicates={k:v for k,v in labels.items() if v>1}
missing=sorted(set((f,k) for f,k in refs if k not in labels))
# Collect actual equation tags, including their roman or subscript extensions.
equations=[]
for name,s in texts.items():
 for m in re.finditer(r'\\tag\{([^{}\n]*)\}',s):
  if '#' not in m[1]:equations.append({'file':name,'tag':m[1]})
chapters=[]
for i in range(1,15):
 s='\n'.join(v for k,v in texts.items() if k==f'chapters/ch{i:02}.tex' or i==14 and k=='chapters/ch14-exercises.tex')
 ex=sorted(int(m[1]) for m in re.finditer(r'\\label\{ex:'+str(i)+r'\.(\d+)\}',s))
 sec=[m[1] for m in re.finditer(r'\\ksec\{('+str(i)+r'\.\d+)\}',s)]
 tag=[e['tag'] for e in equations if e['tag'].startswith(str(i)+'.')]
 chapters.append({'chapter':i,'sections':sec,'exercises':ex,'exercise_count':len(ex),'equation_count':len(tag)})
source=root.parent/'Infinite-Dimensional Lie Algebras (Victor G. Kac).pdf'
if source.exists():
 identity={'file':source.name,'bytes':source.stat().st_size,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'available':True}
else:
 identity={'file':source.name,'available':False,'note':'Original PDF is not part of the editable translation bundle.'}
report={'active_files':list(texts),'label_count':len(labels),'reference_count':len(refs),'duplicates':duplicates,'missing_references':missing,'chapters':chapters,'equations':equations,'source':identity}
(root/'qa/source-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print('Active TeX files',len(files),'labels',len(labels),'references',len(refs),'equation tags',len(equations))
print('Duplicate labels',duplicates)
print('Missing references',missing)
print('Chapter / sections / exercises / equation tags')
for c in chapters:print(c['chapter'],len(c['sections']),c['exercise_count'],c['equation_count'])
print('SOURCE',identity)
expected=[16,11,25,14,28,13,29,17,21,23,22,24,39,62]
assert [c['exercise_count'] for c in chapters]==expected
assert sum(len(c['sections']) for c in chapters)==195
assert len(equations)==563
assert len(re.findall(r'\\kn(?:row|wide)\{',texts['back-index.tex']))==402
assert texts['back-conferences.tex'].count(r'\item ')==18
if duplicates or missing:raise SystemExit(1)
