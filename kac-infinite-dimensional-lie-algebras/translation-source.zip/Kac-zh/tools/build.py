"""Build the book with XeLaTeX and Biber from any working directory."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('mode',nargs='?',default='full',choices=['full'])
parser.add_argument('--build-dir',default='build')
options=parser.parse_args()
build = (root / options.build_dir).resolve()
if build.parent != root or not build.name.isascii():
    parser.error('Use one ASCII build-directory name immediately below the project.')
build.mkdir(exist_ok=True)
command = ["xelatex", "-interaction=nonstopmode", "-file-line-error", "-halt-on-error",
           "-output-directory="+build.name, "main.tex"]

def run(args):
    task_env=os.environ.copy()
    task_env['LC_ALL']='C'
    task_env['LANG']='C'
    task_env.update(SOURCE_DATE_EPOCH='1795219200', FORCE_SOURCE_DATE='1', TZ='UTC')
    result = subprocess.run(args, cwd=root, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, env=task_env)
    (build / ('biber-console.txt' if args[0]=='biber' else 'xelatex-console.txt')).write_bytes(result.stdout)
    if result.returncode:
        sys.stderr.buffer.write(result.stdout[-6000:])
        raise SystemExit(result.returncode)

run(command)
run(command)
if (root / "references.bib").exists() and (build / "main.bcf").exists():
    run(["biber", "--input-directory", build.name, "--output-directory", build.name, "main"])
run(command)
run(command)
shutil.copy2(build / "main.pdf", root / "main.pdf")
print('Built '+str(root/'main.pdf'))
