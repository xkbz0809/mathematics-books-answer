"""Run with Python, PyMuPDF and a XeLaTeX installation including ctex.
Builds the exercise book. Keep the named Chinese translation alongside the result."""
from pathlib import Path
import re,json,subprocess
import pymupdf as fitz
ROOT=Path(__file__).resolve().parent
NAME="高等微积分（第三版）课后习题全解.pdf"
COMPANION="高等微积分（第三版）中文译本.pdf"
def build():
    for _ in range(2):
        p=subprocess.run(["xelatex","-halt-on-error","-file-line-error","-interaction=batchmode","main.tex"],cwd=ROOT)
        if p.returncode:
            raise RuntimeError((ROOT/"main.log").read_text("utf8",errors="replace")[-2800:])
    links=json.loads((ROOT/"book-links.json").read_text("utf8"))
    expected={}
    for f in sorted((ROOT/"sections").glob("s*.tex")):
        t=f.read_text("utf8")
        ids=re.findall(r'\\Question\{([\d-]+)\}',t)
        assert len(ids)==t.count(r'\Solution'),f.name
        for k in ids:
            assert 'q'+k not in expected,k
            expected['q'+k]=1
    assert len(expected)==770,len(expected)
    with fitz.open(ROOT/'main.pdf') as d:
        dest=d.resolve_names()
        assert all(k in dest for k in expected),set(expected)-set(dest)
        for page in d:
            for item in page.get_links():
                uri=item.get("uri","")
                if not uri:continue
                m=re.fullmatch(r"https://buck-ref.invalid/(\d+)",uri)
                if not m: raise ValueError(uri)
                name=fitz.get_pdf_str(links[m[1]])
                fname=fitz.get_pdf_str(COMPANION)
                action=f"<< /S /GoToR /D {name} /F << /Type /Filespec /F {fname} /UF {fname} >> /NewWindow true >>"
                d.xref_set_key(item["xref"],"A",action)
        d.save(ROOT/NAME,garbage=4,deflate=True)
    print(ROOT/NAME,flush=True)
if __name__=="__main__":build()
