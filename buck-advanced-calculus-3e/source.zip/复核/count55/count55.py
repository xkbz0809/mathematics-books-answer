"""Certify the number of terms starting with k=2 needed to exceed 10.
Python 3.12+ and python-flint 0.9.0. Run: python count55.py
Two text outputs are placed beside this script. Arb uses ball arithmetic.
"""
from math import factorial, isqrt
from pathlib import Path
import sys
from time import monotonic

out = Path(__file__).resolve().parent
try:
    from flint import arb, arb_series, ctx
except ModuleNotFoundError:
    sys.path.insert(0, str(out.parent / "numeric-libs"))
    from flint import arb, arb_series, ctx

M = 12000
p = 1600
ctx.dps = 4500
ctx.cap = 2 * p
ctx.threads = 2
start = monotonic()

def stage(name):
    print(f"{name} [{monotonic() - start:.1f} s]", flush=True)

def sum_to_cutoff():
    # Compute the prime logs once; log(ab)=log(a)+log(b).
    factors = list(range(M + 1))
    for d in range(2, isqrt(M) + 1):
        if factors[d] == d:
            for k in range(d * d, M + 1, d):
                if factors[k] == k:
                    factors[k] = d
    logs = [arb(0)] * (M + 1)
    H = arb(0)
    for k in range(2, M + 1):
        d = factors[k]
        logs[k] = arb(k).log() if d == k else logs[d] + logs[k // d]
        H += 1 / (k * logs[k])
    return H, logs[M]

H, L = sum_to_cutoff()
stage("Finite sum")
one_plus_t = arb_series([1, 1])
# Coefficient a[j] of 1/((1+t)(log(M)+log(1+t))).
# f^(j)(M)/j! = a[j] / M^(j+1).
a = (one_plus_t * (L + one_plus_t.log())).inv()
stage("Taylor coefficients")
constant = H - L.log() - 1 / (2 * M * L)
inv_square = 1 / arb(M * M)
factor = inv_square
for j in range(1, p + 1):
    constant -= (arb.bernoulli(2 * j) / (2 * j)) * a[2 * j - 1] * factor
    factor *= inv_square
# By Cauchy's bound on |z-x|=x/2 and the Fourier bound of B_(2p),
# |R| <= 8(2p-1)!/[(pi M)^(2p) log(M/2)].
error = arb(8 * factorial(2 * p - 1)) / arb(3 * M) ** (2 * p)
assert error < arb(10) ** (-4700)
constant += arb(0, error.upper())
stage("Euler-Maclaurin constant")
X = ((10 - constant).exp()).exp()
count = (X - arb(1)/2).floor().unique_fmpz()
assert count is not None and count > 1

def certified_excess(n):
    x = arb(n)
    Lx = x.log()
    # Convex trapezoidal error gives the lower and upper bounds on H_n.
    delta = (Lx + 1) / (8 * x**2 * Lx**2)
    upper = constant + Lx.log() + 1 / (2 * x * Lx) - 10
    return upper + arb(-delta/2, (delta/2).upper())

before = certified_excess(count)       # count - 1 terms, ending at k=count.
after = certified_excess(count + 1)    # count terms, ending at k=count+1.
assert before < 0 and after > 0
s = str(count)
assert len(s) == 4322
(out / "term-count.txt").write_text(s + "\n", encoding="ascii")
cert = (
    f"M = {M}\np = {p}\nArb decimal working precision = {ctx.dps}\n"
    f"Euler-Maclaurin remainder upper bound = {error.str(14)}\n"
    f"C enclosed = {constant.str(30)}\n"
    f"C certified ball radius upper bound = {constant.rad().str(10)}\n"
    f"X - 1/2 - term count = {(X-arb(1)/2-arb(count)).str(30)}\n"
    f"H_(term count) - 10 = {before.str(25)}\n"
    f"H_(term count+1) - 10 = {after.str(25)}\n"
    f"Decimal digits of minimum term count = {len(s)}\n"
)
(out / "certificate.txt").write_text(cert, encoding="ascii")
stage("Opposite signs certified")
print(cert)
