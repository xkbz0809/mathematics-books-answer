"""Build the Chinese edition. Run from any directory with Python and TeX Live."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
engine = ["xelatex", "-halt-on-error", "-interaction=nonstopmode", "-file-line-error", "main.tex"]
for step, command in enumerate((engine, engine, ["biber", "main"], engine, engine), 1):
    process = subprocess.run(command, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if process.returncode:
        sys.stdout.buffer.write(process.stdout[-4500:])
        raise SystemExit(process.returncode)
    print(f"{step}/5  {command[0]} OK", flush=True)
print(root / "main.pdf")
