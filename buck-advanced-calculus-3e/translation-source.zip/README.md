# 高等微积分（第三版）中文译本

本项目对应 R. Creighton Buck 著、Ellen F. Buck 协作的 *Advanced Calculus* 第三版（McGraw-Hill，1978）。章节、定理、习题及书末提示沿用原书编号。符号表和原书索引保留英文原版印刷页码，点击数字可到达译本的相应章节。译者增补的说明标作译注或译校注。

## 编译

解压全部文件。在安装了完整 TeX Live 和 Python 3 的系统中，在本目录执行：

```
python build.py
```

编译入口是 `main.tex`，成品为 `main.pdf`。脚本按顺序运行 XeLaTeX 两遍、Biber 一遍和 XeLaTeX 两遍。所用中文字体为 TeX Live 自带的 Fandol 字体，西文字体为 Computer Modern Unicode。各节的可编辑译文在 `chapters` 中，图件在 `figures` 中。编译不依赖原书扫描件、OCR 模型或联网服务。

