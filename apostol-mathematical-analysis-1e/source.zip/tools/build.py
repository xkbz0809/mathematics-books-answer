"""Reproducible Chinese translation build. Run with Python 3; XeLaTeX must be on PATH.

No original PDF or input sources are modified. All TeX compilation happens in
the project directory, avoiding TeX's non-ASCII output-directory limitation.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--entry', default='main.tex')
args = parser.parse_args()
entry = root / args.entry
if entry.parent != root or not entry.is_file():
    raise SystemExit('Entry must be an existing TeX file at the project root.')
engine = shutil.which('xelatex')
if not engine:
    raise SystemExit('XeLaTeX not found. Install TeX Live or add it to PATH.')
job = entry.stem
qa = root / 'qa'
qa.mkdir(exist_ok=True)
for ext in ['aux', 'toc', 'out', 'log', 'bcf', 'run.xml']:
    (root / f'{job}.{ext}').unlink(missing_ok=True)
passes = []
for i in range(1, 4):
    proc = subprocess.run([engine, '-interaction=nonstopmode', '-halt-on-error',
                           '-file-line-error', entry.name], cwd=root,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (qa / f'{job}-pass-{i}.txt').write_bytes(proc.stdout)
    passes.append({'pass': i, 'exit_code': proc.returncode})
    if proc.returncode:
        print(proc.stdout.decode('utf-8', errors='replace')[-6000:])
        break
log = (root / f'{job}.log').read_text(encoding='utf-8', errors='replace')
patterns = {
    'errors': r'^!|^.*\.tex:\d+:.*(?:Error|Undefined control sequence|Missing)',
    'missing_characters': r'Missing character:.*',
    'undefined_references': r'.*(?:Reference|Citation).*undefined.*',
    'multiply_defined': r'.*multiply defined.*',
    'rerun': r'.*(?:Rerun to get|Label\(s\) may have changed).*',
    'overfull': r'Overfull \\[hv]box.*',
    'underfull': r'Underfull \\[hv]box.*',
}
findings = {k: re.findall(p, log, re.MULTILINE) for k, p in patterns.items()}
pdf = root / f'{job}.pdf'
report = {'entry': entry.name, 'engine': engine, 'passes': passes,
          'pdf_exists': pdf.is_file(), 'findings': findings,
          'source_fidelity': 'Not established by compilation. See chapter QA records.'}
if pdf.is_file():
    report['pdf_sha256'] = hashlib.sha256(pdf.read_bytes()).hexdigest()
(qa / f'{job}-build.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
sys.exit(0 if all(p['exit_code'] == 0 for p in passes) and not any(findings[k]
    for k in ['errors', 'missing_characters', 'undefined_references', 'multiply_defined', 'rerun']) else 1)
