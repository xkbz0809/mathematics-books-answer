"""Independent double-precision checks of selected derived integral formulas.
These are numerical evidence, not proofs; exact residue derivations are in answers/.
"""
from pathlib import Path
import json,sys,math,scipy
from scipy.integrate import quad

r=Path(__file__).resolve().parents[1]
smoke,error=quad(lambda x:x*x,0,1)
assert abs(smoke-1/3)<1e-13
cases=[]
def check(name,f,lower,upper,expected,**opts):
    actual,error=quad(f,lower,upper,epsabs=1e-11,epsrel=1e-11,limit=400,**opts)
    residual=abs(actual-expected)
    cases.append({'exercise':name,'actual':actual,'quadrature_error_estimate':error,
                  'derived_value':expected,'absolute_residual':residual,'passed':residual<1e-9})
for a,b in [(2.0,1.0),(3.0,0.7)]:
    check('16-26',lambda t:1/(a+b*math.cos(t))**2,0,2*math.pi,2*math.pi*a/(a*a-b*b)**1.5)
    check('16-29',lambda t:math.sin(t)**2/(a+b*math.cos(t)),0,2*math.pi,2*math.pi*(a-math.sqrt(a*a-b*b))/(b*b))
for a in [0.2,0.6,-0.4]:
    check('16-27',lambda t:math.cos(2*t)/(1-2*a*math.cos(t)+a*a),0,2*math.pi,2*math.pi*a*a/(1-a*a))
for a in [0.2,0.6]:
    check('16-28 corrected',lambda t:(1+math.cos(3*t))/(1-2*a*math.cos(t)+a*a),0,2*math.pi,2*math.pi*(a*a-a+1)/(1-a))
check('16-30',lambda x:1/(x*x+x+1),-math.inf,math.inf,2*math.pi/math.sqrt(3))
check('16-31 corrected',lambda x:x**6/(1+x**4)**2,-math.inf,math.inf,3*math.pi*math.sqrt(2)/8)
check('16-32',lambda x:x*x/((x*x+4)**2*(x*x+9)),0,math.inf,math.pi/200)
for m,n in [(1,2),(1,3),(2,3),(3,5)]:
    check(f'16-33 m={m},n={n}',lambda x:x**(2*m)/(1+x**(2*n)),0,math.inf,math.pi/(2*n)/math.sin((2*m+1)*math.pi/(2*n)))
for a,m in [(1.0,0.4),(2.0,1.2)]:
    check('16-36b',lambda x:1/(x**4+a**4),0,math.inf,
          math.pi/(2*a**3)*math.exp(-m*a/math.sqrt(2))*math.sin(m*a/math.sqrt(2)+math.pi/4),weight='cos',wvar=m)
report={'python':sys.version,'scipy':scipy.__version__,'smoke_test_passed':True,'precision':'binary64',
        'cases':cases,'all_passed':all(x['passed'] for x in cases),
        'limitations':'Selected parameter values and quadrature error estimates only. No numerical test proves the symbolic formulas or all parameter cases.'}
(r/'qa/root-integral-numerical-checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({'cases':len(cases),'all_passed':report['all_passed'],'maximum_absolute_residual':max(x['absolute_residual'] for x in cases)},indent=2))
raise SystemExit(0 if report['all_passed'] else 1)
