from pathlib import Path
import json,re,argparse,hashlib
r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--chapters',nargs='*',type=int);p.add_argument('--allow-incomplete',action='store_true');a=p.parse_args()
m=json.loads((r/'qa/exercise-manifest.json').read_text(encoding='utf-8'))
chosen=a.chapters or list(range(1,17));missing=[];included=[]
for c in m['chapters']:
 if c['chapter'] not in chosen:continue
 out=[r'\setcounter{chapter}{'+str(c['chapter']-1)+'}',r'\chapter{'+c['title']+'}']
 for x in m['exercises']:
  if x['chapter']!=c['chapter']:continue
  f=r/x['answer_file']
  if not f.exists() or not f.read_text(encoding='utf-8').strip():missing.append(x['id']);continue
  included.append(x['id'])
  # The seven-row question display must stay with its group and exercise heading.
  if x['id']=='12-15':out.append(r'\clearpage')
  context=(r/x['context_file']).read_text(encoding='utf-8').strip()
  if context:out.extend([r'\Needspace{10\baselineskip}',r'\input{'+x['context_file']+'}'])
  out += [r'\exerciseheading{'+f'{x["chapter"]:02}-{x["number"]}'+'}{'+x['id']+'}{'+x['source_printed_page_start']+'}',r'\begin{problemstatement}',r'\input{'+x['question_file']+'}',r'\end{problemstatement}',r'\begin{answerbody}',r'\input{'+x['answer_file']+'}',r'\end{answerbody}']
 (r/'chapters'/f'ch{c["chapter"]:02}.tex').write_text('\n'.join(out)+'\n',encoding='utf-8')
entry='main.tex' if not a.chapters else 'check-'+('-'.join(f'{i:02}' for i in chosen))+'.tex'
main=[r'\input{preamble.tex}',r'\begin{document}',r'\frontmatter',r'\input{frontmatter.tex}',r'\mainmatter']+[r'\input{chapters/ch'+f'{i:02}'+'.tex}' for i in chosen]+[r'\end{document}']
(r/entry).write_text('\n'.join(main)+'\n',encoding='utf-8')
d={'entry':entry,'chapters':chosen,'included_exercises':included,'included_count':len(included),'missing_exercises':missing,'complete':not missing,'status':'assembled_not_mathematically_verified'}
(r/'qa/assembly.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in d.items() if k!='included_exercises'},ensure_ascii=False))
if missing and not a.allow_incomplete:raise SystemExit(1)
