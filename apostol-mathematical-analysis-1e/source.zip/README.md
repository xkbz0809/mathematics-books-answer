# Apostol《数学分析》第一版全书习题解答（中文）

本工程提供原书16章499道编号习题及全部小问的中文题文与完整解答，当前版本为v1.0。习题9-13的一般情形已补齐：先按原书的分割加细定义证明任意有界积分子下的乘积可积性，再完成恒等式和Cauchy–Schwarz不等式。499道题及小问均已完成并交叉复核，当前没有保留的未完成题。解答由Codex编写，它不是作者或出版社的官方解答。

原扫描为1957年第一版、1964年第四次印刷。题号和“原书印刷页”沿用原书，解答册自行分页。题文、解答分别保存，原题中确有问题的条件或结论在解答中明确讨论，不默改题文。转录偏离原扫描的差错另见 qa/question-source-corrections.json。

## 编译

需要Python 3和含XeLaTeX的TeX Live；字体使用TeX Live自带的Fandol和Latin Modern。无须原扫描PDF，无须网络服务，无须商业字体。

在本目录执行：

    python tools/assemble.py
    python tools/build.py

第一步核对499题并生成章节入口；第二步运行三轮XeLaTeX，生成main.pdf。命令行须能找到xelatex。也可以直接对现有main.tex运行三轮XeLaTeX。

## 编辑

- questions/：逐题中文题文。
- contexts/：原书在题组前给出的共同标题、条件或说明。
- answers/：逐题中文解答。文件名如09-013.tex代表9-13。
- chapters/、main.tex：汇编入口，由assemble.py生成。
- preamble.tex、frontmatter.tex：版式和编写说明。
- book-labels.tex：原书定理、公式和习题编号的对应关系。
- qa/：覆盖清单、独立数学复核、编译和版面等不同层次的记录。

编辑后重新汇编、编译。原书定理引用以原编号显示；本册习题之间的交叉引用与PDF中的题号书签可点击。

## 核对范围

逐题数学交叉复核、原扫描疑点回看、编译、PDF页面检查各自提供不同证据。它们不等于出版社审定或形式化证明。原题错误、定义约定以及仍需明确的解释条件，均在对应解答中写出，详见交付核对说明。

tools/verify_root_integrals.py用于重新运行18个留数积分的辅助数值检查，需要SciPy；它不参与书籍编译，也不代替书内解析证明。编译本书仅需Python标准库和TeX Live。
