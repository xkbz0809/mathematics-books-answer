# 《数学分析：高等微积分的现代方法》中文重排源码

原著：Tom M. Apostol，*Mathematical Analysis: A Modern Approach to Advanced Calculus*。底本版权页为 1957 年，第四次印刷为 1964 年，属于第一版。译文及重排由 Codex 制作；核查范围另见交付说明。

本工程包含完整 16 章、260 个编号节、499 道原书习题、87 幅原书插图、6 条脚注、原书参考文献、特殊符号索引和总索引。书中原有的习题提示与答案照录；没有另外编写习题解答。

## 内容依据

原扫描 PDF 是最终依据。中文翻译以先行完成并封存的英文重排源码为工作底本。原书自身的错误、遗漏条件、历史性定义与异常记号均按原文保留；没有借翻译之机校正数学内容。

原 PDF 共 584 页，SHA-256：

`36fb26d793d294720294faf6c7f891b4c668bd4391da8df21567ba804c1c9538`

原扫描不包含在此源码包中，也不参与编译。`SOURCE-IDENTITY.json` 记录底本与英文阶段标识。

`\sourcepage{PDF页}{原印刷页}` 保存来源定位。目录和索引里的数字仍是原书印刷页码，点击后跳到本重排版中相应原页内容的位置；它们不是新 PDF 的物理页码。阅读器书签则指向本版的相应标题。

正文、定理、证明、习题、图题与脚注已翻译。参考文献的作者、书名、刊名和出版项保留原文，便于识别文献。数学家姓氏统一保留拉丁拼写。普通插图使用原扫描的裁图；其中有英文单词的 12 幅图在图下附对应中文，图内几何、箭头与数学标记保留。

## 文件与编译

- `main.tex`：完整书稿入口。
- `preamble.tex`：基于 `ctexbook` 的排版设置。
- `chapters/ch01.tex` 至 `ch16.tex`：全部章节。
- `frontmatter/`、`backmatter/`：出版信息、前言、目录与两个索引。
- `assets/`：编译所用的 87 幅插图和原出版者标记。
- `figure-text-translations.tex`：图内英文词的中文对照。
- `glossary.tsv`：本项目术语表。
- `tools/build.py`：清理辅助文件并运行三次 XeLaTeX。

需要 Python 3，以及包含 XeLaTeX、ctex、Fandol 字体和常用数学宏包的 TeX Live。验证环境为 Windows、Python 3.13、TeX Live 2026。Fandol 与 Latin Modern 字体随 TeX Live 提供，无需原扫描或外部付费字体。

在解压后本文件所在目录打开 PowerShell，执行：

```powershell
python tools/build.py
```

输出为本目录的 `main.pdf`。构建记录写入 `qa/main-build.json`；该记录证明构建状况，不代表独立的全文数学正确性证明。只改内容后也应运行完整三遍构建，以更新交叉引用和书签。

本工程直接在当前目录构建，避免对含中文路径使用 TeX 的 `-output-directory`。源码包经过独立解压重建核验；具体成品版本和核验范围见同批交付说明。
