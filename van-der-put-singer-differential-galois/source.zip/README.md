# 《线性微分方程的伽罗瓦理论》习题详解源码
使用 XeLaTeX，主文件为 linear-solutions-release.tex。Linux/macOS 可运行 `bash build.sh`；Windows PowerShell 可运行 `.\\build.ps1`。需要安装 ctex、Fandol 字体、AMS、mathtools、TikZ/PGF、mathrsfs、enumitem、graphicx、hyperref、needspace 等常见 TeX Live/MiKTeX 宏包。
各解答按原书编号，双重定位使用原书印刷页码与从封面开始计算的扫描 PDF 页序。这里不包含原书扫描。各章下的复核记录和验证脚本是补充资料，不是编译依赖。
