# Appendix A.44–A.50 verification
- Read exact printed exercise blocks from appendix-ocr/p366,p369,p370,p371.png (physical PDF pages 387,390,391–392); all 2+2+4+4 subparts represented.
- Applied DG-L-063, 479 (torus hint), 018, 019 (left multiplication and defining ideal), 482 (determinant basis). The scan of A.50(1),(2) does print the overbars. No new printed errata found.
- Checked character orthogonality by coefficient comparison, dual-number intersection in characteristic zero, all four Jordan cases (including a = 1 and b = 0), derivative on determinant localization, torsor right-action contravariance, and CRT in the second tensor-factor algebra structure.
- XeLaTeX twice; no overfull box, missing glyph or TeX errors. Visually inspected page 2.
