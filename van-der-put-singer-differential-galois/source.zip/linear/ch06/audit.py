"""Check local formulas on a mixed-valuation basis and a negative twist."""
import sympy as s
x,z=s.symbols('x z', nonzero=True)
m=[-2,0,3]
f=[x**-2*(1+x),1+2*x,x**3*(1+x**2)]
W=s.det(s.Matrix([[s.diff(y,x,j) for y in f] for j in range(len(f))]))
power=sum(m)-len(m)*(len(m)-1)//2
assert s.limit(W*x**(-power),x,0)==s.prod(m[j]-m[i] for i in range(len(m)) for j in range(i+1,len(m)))
B=s.Matrix([[s.simplify(x**(-m[i])*y) for y in [f[i],x*s.diff(f[i],x),x*s.diff(x*s.diff(f[i],x),x)]] for i in range(len(m))])
assert B.subs(x,0)==s.Matrix([[mi**j for j in range(len(m))] for mi in m])
h=(z**2+1)/(z-1)**3
assert s.limit(z*h,z,s.oo)==1
assert s.simplify(s.diff(x**3,x)/x**3-3/x)==0
print('Versatile Wronskian, Euler reduction, order at infinity, and negative twist checked.')
