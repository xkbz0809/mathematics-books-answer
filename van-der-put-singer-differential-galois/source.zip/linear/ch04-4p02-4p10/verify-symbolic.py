"""Independent exact substitutions for Exercises 4.2 and 4.10."""
import sympy as s

z = s.symbols("z")
a, b, c = s.symbols("a b c")
T = lambda y: s.expand(
    (z**2 + 2*z - 2)*s.diff(y,z,3)
    -(z**2 + 4*z)*s.diff(y,z,2)
    +(2*z + 4)*s.diff(y,z)-2*y
)
assert T(a+b*z+c*z**2) == -2*a+4*b
for y in [(z+1)**-1, (z+1)**-2]:
    assert s.simplify(s.diff(y,z,2)+4*s.diff(y,z)/(z+1)+2*y/(z+1)**2)==0

# This logarithmic derivative tests a high-order pole, the degree-zero
# polynomial part at infinity, and a simple pole at an ordinary point.
h = 1-z**-2
u = h + 1/(z-2)
R = lambda v: s.diff(v,z)+v**2-2*h*v+h**2-s.diff(h,z)
assert s.simplify(R(u)) == 0
v = s.Function("v")(z)
assert s.simplify(R(v+h) - (s.diff(v,z)+v**2)) == 0
print("Exact symbolic checks passed.")
