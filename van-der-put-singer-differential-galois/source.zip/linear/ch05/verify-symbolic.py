"""Independent symbolic and arithmetic checks for exercises 5.7, 5.11."""
import math
import sympy as s
z = s.symbols("z")
r = s.log(z-1)-s.log(z)
A = s.Matrix([[1/z, 1/(z-1)], [0, 0]])
F = s.Matrix([[z, z*r], [0, 1]])
assert all(s.simplify(t)==0 for t in F.diff(z)-A*F)
assert s.simplify(s.diff(r,z)-1/(z*(z-1))) == 0

# Analytic continuation in the (f,g) basis, then in (f, i*g).
i = s.I
P = s.diag(1,i)
U = s.Matrix([[1,2],[0,1]])
V = s.Matrix([[1,0],[-2,1]])
assert P.inv()*s.Matrix([[1,-2*i],[0,1]])*P == U
assert P.inv()*s.Matrix([[1,0],[-2*i,1]])*P == V
assert (U*V).trace()==-2

# Test exact elementary reduction on congruence-compatible primitive
# columns, including both sign branches.
checked = 0
for a0 in range(-59,60):
    if a0 % 4 != 1:
        continue
    for c0 in range(-60,61,2):
        if math.gcd(a0,c0) != 1:
            continue
        a,c = a0,c0
        while c:
            height=max(abs(a),abs(c))
            if abs(a)>abs(c):
                a += 2*c*round(-s.Rational(a,2*c))
            else:
                c -= 2*a*round(s.Rational(c,2*a))
            assert max(abs(a),abs(c)) < height
        assert a == 1
        checked += 1
print(f"Exact symbolic checks and {checked} integer column reductions passed.")
