"""Symbolic cross-checks of the explicit systems in Exercise 1.36."""
import sympy as s

t,Y=s.symbols('t Y', nonzero=True)
z=t**2
r=z+s.Rational(5,16)/z**2
u1=-1/(4*z)+t
u2=-1/(4*z)-t
Dt=lambda f:s.diff(f,t)/(2*t)+u1*Y*s.diff(f,Y)
y1,y2=Y,1/(t*Y)
assert all(s.cancel(Dt(u)+u**2-r)==0 for u in (u1,u2))
assert all(s.cancel(Dt(Dt(y))-r*y)==0 for y in (y1,y2))
assert s.cancel(y1*Dt(y2)-Dt(y1)*y2)==-2
assert s.cancel(z*y1*y2)==t
a=s.symbols('a', nonzero=True)
g=s.Matrix([[0,-1/a],[a,0]])
assert g.det()==1 and g*g==-s.eye(2)

z,Y,I=s.symbols('z Y I',nonzero=True)
D=lambda f:s.diff(f,z)+z*Y*s.diff(f,Y)+Y**-2*s.diff(f,I)
y1,y2=Y,Y*I
assert all(s.cancel(D(D(y))-(z**2+1)*y)==0 for y in (y1,y2))
assert s.cancel(y1*D(y2)-D(y1)*y2)==1
assert s.cancel(D(y2)-z*y2)==Y**-1

A,B,D,E,r=s.symbols('A B D E r')
det=A*E-B*D
assert s.expand(sum(s.diff(det,x)*dx for x,dx in zip((A,B,D,E),(D,E,r*A,r*B))))==0
print('Riccati pairs, two explicit PV rings, Wronskians and disconnected component signs verified.')
