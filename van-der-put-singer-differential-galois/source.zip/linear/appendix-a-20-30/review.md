# Appendix A.20–A.30 solutions review
Exact targets were checked against the printed scan/OCR pairs: A.20 354/375, A.22 355/376, A.25 355–357/376–378, A.27 358/379, A.30 359/380. These are five exercise blocks, not every numerical label between their endpoints.

- A.20: product ring, strict topology comparison, and CRT decomposition with Galois hypothesis and a nongalois counterexample; DG-L-465, DG-L-006.
- A.22: both statements, including coefficient/point action, geometry (reducedness, geometric points) and perfectness; DG-L-007.
- A.25: all parts of integrality, both inductive normalization steps (also the printed finite-field remark), and weak/strong Nullstellensatz; DG-L-469, DG-L-470 already recorded.
- A.27: all four assertions; uses the finite residue extension established in A.25 and Nakayama applied to the appropriate finite quotient module.
- A.30: the unique-singular-point calculation works including characteristics 2 and 3. Algebraic branch formulas are field-independent; the requested sketch explicitly uses the real model. Standalone three-page XeLaTeX output built twice; preview page 3 was visually checked.
- No additional mathematical erratum established.
