"""Compute the Jordan and skew-operator identities independently."""
from collections import defaultdict
from math import comb, factorial
import sympy as sp

L, z, T = sp.symbols('L z T')
N = sp.zeros(4)
for j in range(3):
    N[j+1,j] = 1
U = sum((L**j * N**j / factorial(j) for j in range(4)), sp.zeros(4))
V = U.subs(L,-L)
assert (U*V).applyfunc(sp.simplify) == sp.eye(4)
assert sp.diff(U,L) == N*U
D = lambda f: z*sp.diff(f,z)

def ore(A,B):
    result=defaultdict(lambda:sp.S(0))
    for i,a in A.items():
        for j,b in B.items():
            Dj=b
            for k in range(i+1):
                result[i+j-k]+=a*comb(i,k)*Dj
                Dj=D(Dj)
    return {i:sp.expand(val) for i,val in result.items() if sp.expand(val)!=0}

def poly(A):
    return sum(a*T**i for i,a in A.items())

R={0:1/z,1:z,2:sp.S(1)}
assert sp.expand(poly(ore(R,{0:z}))-z*poly(R).subs(T,T+1))==0
assert poly(ore(R,{0:z})).subs(z,0)==1
F={0:sp.S(1),1:z,2:sp.S(1)}
H={1:sp.S(2),2:z}
assert sp.expand(poly(ore(F,H)).subs(z,0)-poly(F).subs(z,0)*poly(H).subs(z,0))==0
print('Jordan block, right normalization, and reduction modulo z verified.')
