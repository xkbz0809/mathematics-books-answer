"""Independent Stokes sign and semisimple block-recursion checks."""
import mpmath as mp
import sympy as s

# Independent initial-value entire functions for r=z^m.
# N=m+2: A=0F1(1−1/N,z^N/N²), B=z*0F1(1+1/N,z^N/N²).
mp.mp.dps=50
for m in (1,3):
    N=m+2
    k=mp.mpf(N)/2
    c=mp.exp(mp.pi*mp.j*m/2)
    W0=2*c
    R=mp.mpf(100)
    Y={}
    for j in range(-1,N+1):
        d=mp.pi*j/k
        z=R*mp.exp(-mp.j*d)
        X=R**N/N**2
        pref= R**(-mp.mpf(m)/4)*mp.exp(mp.j*m*d/4)
        dom=(c if j%2==0 else 1)*pref*mp.exp(R**k/k)
        alpha=mp.hyper([], [1-1/mp.mpf(N)], X)/dom
        beta=z*mp.hyper([], [1+1/mp.mpf(N)], X)/dom
        Y[j]=((-1)**j*W0*beta, -(-1)**j*W0*alpha)
    product=mp.eye(2)
    coeffs=[]
    for j in range(N):
        p,q=Y[j-1]
        r,t=Y[j+1]
        sj=(-1)**j*(p*t-q*r)/W0
        coeffs.append(sj)
        St=mp.eye(2)
        if j%2==0:
            St[0,1]=sj
        else:
            St[1,0]=sj
        product=St*product
    gamma_inv=mp.matrix([[0,1],[-1,0]])
    assert max(abs(value) for value in product-gamma_inv) < mp.mpf('0.01')
    if m==1:
        assert max(abs(x-y) for x,y in zip(coeffs,[1,-1,1])) < mp.mpf('0.01')
    print(f'm={m}, limiting-ray Stokes coefficients (checked at radius 100):',
          [mp.nstr(x,5) for x in coeffs])

# Repeated semisimple spectrum and independent generic cross-block variables.
a,b,c,d=s.symbols('a b c d')
lam=[0,0,1]
D=s.diag(*lam)
T=s.Matrix([[0,0,a],[0,0,b],[c,d,0]])
def pr(M, is_diag):
    return s.Matrix(3,3,lambda i,j:M[i,j] if (lam[i]==lam[j])==is_diag else 0)
def inv_ad(M):
    return s.Matrix(3,3,lambda i,j:M[i,j]/(lam[i]-lam[j]) if lam[i]!=lam[j] else 0)
prev=s.eye(3)
off=inv_ad(T)
for n in range(1,5):
    coeff=off+pr(off*T,True)/n
    assert (D*coeff-coeff*D-prev*T+(n-1)*prev).applyfunc(s.expand)==s.zeros(3)
    prev=coeff
    off=inv_ad(pr(coeff*T-n*coeff,False))
print('Repeated-spectrum formal marking recurrence verified to degree four.')
