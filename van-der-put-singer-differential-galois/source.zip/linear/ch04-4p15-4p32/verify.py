"""Symbolic/finite-group checks for the Chapter 4 solutions, not substitutes for proofs."""
import sympy as s
from math import comb, prod
z,t,m=s.symbols('z t m')
I=s.I
Q=s.Rational
def oe(A,B):
    o=[0]*(len(A)+len(B)-1)
    for i,a in enumerate(A):
        for j,b in enumerate(B):
            for r in range(i+1):
                o[i-r+j]+=a*comb(i,r)*s.diff(b,z,r)
    return [s.expand(v) for v in o]
h=1+z*z
q=[h,0,1]
assert [s.expand(v+int(j==0)) for j,v in enumerate(oe(q,q))]==[4+2*z*z+z**4,4*z,2+2*z*z,0,1]
assert oe([h-I,0,1],[I*z,1])==oe([I*z,1],[h+I,0,1])
assert oe([-I*z,1],[I*z,1])==[I+z*z,0,1]
assert oe([z,1],[-1,z])==[-z,z*z,z]
assert oe([z+1/z,1],[-1/z,1])==[-1,z,1]
a=(3-4*z)/(16*z*z)
w=s.sqrt(z)
assert s.simplify(s.diff(w,z,3)+4*a*s.diff(w,z)+2*s.diff(a,z)*w)==0
for sg in [-1,1]:
    u=1/(4*z)+sg/(2*s.sqrt(z))
    assert s.simplify(s.diff(u,z)+u*u+a)==0

# 4.32: obtain the resonant coefficients directly from the expanded rational L(z^t)/z^(t-3).
e0=[Q(-1,2),0,Q(1,2)]
e1=[Q(-6,7),Q(-5,7),Q(-3,7)]
ei=[Q(8,7),Q(9,7),Q(11,7)]
rows=[(e0,[Q(-3,4),Q(-1,4),0],ei,[Q(5273,10976)])]
claimed=[[Q(1045,686)],[Q(2433,1372)+sg*3*s.sqrt(21)/392 for sg in [-1,1]]]+[[Q(j,2744)] for j in (1317,1205,1149,3375,3263,3207)]
indices=[(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
for (j,i),roots in zip(indices,claimed):
    ee=[list(e0),list(e1),list(ei)]
    ee[j][i]+=1
    rows.append((*ee,roots))
for idx,(u,v,w,expected) in enumerate(rows):
    assert sum(map(sum,[u,v,w]))==3
    E=[s.Poly(prod(t-r for r in e),t) for e in [u,v,w]]
    A,B=[3+e.nth(2) for e in E[:2]]
    C,D=[e.nth(1)-2+b for e,b in zip(E,[A,B])]
    J=E[2].nth(1)-2+A+B-C-D
    U,V=[e.nth(0) for e in E[:2]]
    W=-E[2].nth(0)-U-V
    scaled=t*(t-1)*(t-2)+(A+B*z/(z-1))*t*(t-1)
    scaled+=(C+D*z*z/(z-1)**2+J*z/(z-1))*t
    scaled+=U+V*z**3/(z-1)**3+z*(W*(z-Q(1,2))+m)/(z-1)**2
    pp=s.Poly(s.series(scaled,z,0,3).removeO(),z)
    l=Q(-1,2)
    p=[pp.nth(i) for i in range(3)]
    if idx==2:
        poly=p[1].subs(t,l)*p[1].subs(t,l+1)-p[0].subs(t,l+1)*p[2].subs(t,l)
    else:
        poly=p[1].subs(t,l)
    assert s.Poly(poly,m).degree()==len(expected)
    assert all(s.simplify(poly.subs(m,r))==0 for r in expected)
    print(idx,'no-log obstruction:',s.factor(poly))

from itertools import product
def mat(A,B):
    a,b,c,d=A;e,f,g,h=B
    return tuple(i%7 for i in (a*e+b*g,a*f+b*h,c*e+d*g,c*f+d*h))
def norm(A): return min(A,tuple((-x)%7 for x in A))
id0=(1,0,0,1); I0=norm(id0)
S=(0,6,1,0)
G={norm((a,b,c,d)) for a,b,c,d in product(range(7),repeat=4) if (a*d-b*c)%7==1}
assert len(G)==168
def order(g):
    a=I0
    for j in range(1,169):
        a=norm(mat(a,g))
        if a==I0:return j
    assert False
for a,n in [(2,7),(3,4),(4,4)]:
    U=(1,a,0,1); Uinv=(1,(-a)%7,0,1)
    g1=norm(mat(S,Uinv))
    assert norm(mat(mat(S,g1),U))==I0
    assert (order(S),order(g1),order(U))==(2,n,7)
    reached={I0}
    stack=[I0]
    for r in stack:
        for j in [S,U]:
            g=norm(mat(r,j))
            if g not in reached:
                stack.append(g); reached.add(g)
    assert reached==G
# Basis conjugation in the a=2 instance.
B=(1,0,1,1)
assert mat((0,1,6,2),B)==mat(B,(1,1,0,1))
print('Ore identities, Riccati roots, all 10 table-parameter values and finite triple cases verified.')
