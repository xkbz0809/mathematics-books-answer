# Linear Appendix A.35, A.36, A.39, A.41, A.43

Original scan compared directly: A.35 print361/PDF382; A.36 print361–362/PDF382–383; A.39 print364/PDF385; A.41 print365/PDF386; A.43 print365–366/PDF386–387. All enumerated items and subitems addressed. Two XeLaTeX passes clean; five extracted headings checked; three pages visually checked. No new errata.

- A.35: closed relative to GL, explicit inverse coordinates.
- A.36: checked direction of every arrow, tensor product and multiplication on four maps, evaluation followed by inclusion (existing DG-L-472), all dual group axioms.
- A.39: characters by group-like units, Laurent monomial argument, all determinant powers, and reduction of closed kernel/center. Clarifies commutator group DG-L-476.
- A.41: lattice equations by Vandermonde; all four scalar/Jordan/torsion cases; triangular, monomial and full infinite cases; finite projective classification and lift argument ensure generation of the central kernel with no third generator.
- A.43: basis-dependent index calculation and invertibility by antipode, plus separate canonical inverse-evaluation construction and equivariant maps. Correctly handles left coaction order and transpose caveat DG-L-478.
