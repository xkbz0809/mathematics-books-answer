﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
for ($i = 0; $i -lt 3; $i++) {
  & xelatex -halt-on-error -interaction=nonstopmode "linear-solutions-release.tex"
  if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed" }
}
