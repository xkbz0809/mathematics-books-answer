"""Deterministic checks of the source's recurrence and Exercise 4.28 transcription."""
import sympy as s
T,z,r = s.symbols('T z r')
for n in range(1,8):
    a = list(s.symbols(f'a0:{n}')) + [-1,0]
    da = list(s.symbols(f'da0:{n}')) + [0]
    P = -T**n + sum(a[i]*T**i / s.factorial(n-i) for i in range(n))
    DP = sum(da[i]*T**i / s.factorial(n-i) for i in range(n))
    Q = s.Poly(DP+(r-T**2)*s.diff(P,T)+(n*T+a[n-1])*P,T)
    assert Q.degree() <= n-1
    for i in range(n):
        actual = s.expand(Q.nth(i)*s.factorial(n-i))
        target = (a[i-1] if i else 0)+da[i]+a[n-1]*a[i]+(n-i)*(i+1)*r*a[i+1]
        assert s.simplify(actual-target) == 0
b = (3-4*z)/(16*z**2)
assert s.simplify(2*s.diff(b,z)-(2*z-3)/(4*z**3)) == 0
f=s.sqrt(z)
assert s.simplify(s.diff(f,z,3)+4*b*s.diff(f,z)+2*s.diff(b,z)*f)==0
print("Riccati coefficient recurrence n=1..7 and Sym² transcript both verified.")
