# Appendix A §A.2.2: exact-source audit

Source: print 368/PDF389 at “A.2.2 The Lie Algebra of a Linear Algebraic Group”, through Exercise A.48 final square on print 369/PDF390. Next heading A.2.3 starts print 370/PDF391. The A.44 exercise and A.45 lemma are in §A.2.1 and are not duplicated here.

- G and its identity component have the same local ring at the identity, since the latter is an open and closed component. In the smooth case its dimension is dim G. A formal system of local coordinates provides the tangent matrices A_i, which are a basis by their independence and cardinality r. The scan’s f is by context a matrix (not a scalar power series).
- Write a^{-1}=I−αA+α²(A²−A_1) and b^{-1}=I−αB+α²(B²−B_1). Direct multiplication modulo α³ gives I+α²(AB−BA). The injective C-algebra map C[ε]/(ε²) → C[α]/(α³), ε↦α², ensures the defining equations already vanish over the dual numbers; the determinant is a unit. The proof applies to all coefficients in the localized coordinate ring of GL_n. The adjoint action is conjugation and is compatible with the group law.
- A.47 transcribed with Zariski closure bar, upper-right b, exact reference to A.41, and both subparts. A.48 was reused verbatim from the previously checked exact-source correction appendix-a48/exercise-a48.tex. Its hint at (2) uses left multiplication (DG-L-018). In (3) the scan has uppercase A for the ideal in the generator set, but its final hint already has P ∈ I, so only the generator-set symbol requires correction (DG-L-019). The worksheet includes no exercise solutions.
- There are no new substantive errata within this exact section beyond those two pre-existing stable entries. Do not issue duplicate IDs for this local TSV.

Standalone XeLaTeX built twice, two pages, visually reviewed both pages (no overfull, missing glyphs, or unresolved references).
