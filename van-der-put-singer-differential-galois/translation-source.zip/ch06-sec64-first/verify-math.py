"""Exact independent QA of the local model for Theorem 6.15."""
import sympy as s

z, z0, L = s.symbols("z z0 L")
E = s.Matrix([[0, 1], [0, 0]])
A = s.eye(2)/3 + E
assert E**2 == s.zeros(2)
H = s.exp(L/3)*(s.eye(2)+L*E)     # exp(A L)
assert H.subs(L, 0) == s.eye(2)
assert (s.diff(H, L)/z - A*H/z).applyfunc(s.simplify) == s.zeros(2)
B = H.subs(L, 2*s.pi*s.I)
assert (H.subs(L, L+2*s.pi*s.I) - H*B).applyfunc(s.simplify) == s.zeros(2)
assert H.subs(L, -2*s.pi*s.I)*B == s.eye(2)
assert B != B.inv()
print("Corrected horizontal equation and positive-loop monodromy hold, also for a Jordan block.")

f, g = s.Function("f")(z), s.Function("g")(z)
v = s.Matrix(s.symbols("v0 v1"))

def contraction(y):
    return y.diff(z) - A*y/z

assert (contraction(f*g*v) -
        f*contraction(g*v) - s.diff(f, z)*g*v).applyfunc(s.expand) == s.zeros(2,1)
assert contraction(s.zeros(2,1)) == s.zeros(2,1)
print("Leibniz verified: the matrix term, as well as the differential term, depends on f.")

# A constant fibre vector has trivial connection in the trivial frame, but
# the meromorphic frame e/z for O(s) gives logarithmic residue -1.
assert s.diff(1/z,z)/(1/z) == -1/z
assert s.exp(2*s.pi*s.I) == 1
print("Integral shift witness: logarithmic residue changes while monodromy is still trivial.")
