"""Exact checks for DG-L-172 and the full-S3 witness for DG-L-174."""
import sympy as s
from itertools import product
t, x, U = s.symbols("t x U")
f = t**3-3*t-x
X=t**3-3*t
def D(z):
    return s.factor(s.diff(z,t)/s.diff(X,t))
def L(z):
    return s.factor((4-X**2)*D(D(z))-X*D(z)+z/9)
assert (v := [i*j*(i+j)%2 for i,j in product(range(2), repeat=2)]) == [0]*4
assert L(t)==0
assert (bad := L(1/t)) != 0
disc=s.factor(s.discriminant(f,t))
assert s.expand(disc-27*(4-x*x)) == 0
u=s.factor(D(t)/t)
assert s.factor(u-1/(3*(X+2*t)))==0
assert s.factor((1/(3*u)-X)/2-t)==0
mu=s.factor(s.resultant(f,3*(x+2*t)*U-1,t))
assert s.factor(mu.subs({x:X, U:u},simultaneous=True))==0
assert s.factor(mu.subs({x:X, U:-u},simultaneous=True)) != 0
print("F2 evaluation:", v)
print("disc =",disc,"; L(t) =",L(t),"; L(1/t) =",bad)
print("u roots cubic (up to normalization) =",mu)
