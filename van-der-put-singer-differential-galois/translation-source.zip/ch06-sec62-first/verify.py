"""Exact checks for chart gluing, residues, divisor convention and descent."""
from itertools import permutations, product
from sympy import symbols, cancel, Poly

z, w, a, b, c, p, q, r = symbols('z w a b c p q r')
assert cancel(((1/z**2).subs(z,1/w)) * (1/w).diff(w)) == -1
for n in range(-3,5):
    for degree in range(7):
        chart_coefficient = cancel(w**n*(z**degree).subs(z,1/w))
        assert chart_coefficient == w**(n-degree)
        assert (n-degree>=0)==(degree<=n)
print('The line-bundle gluing gives polynomial degree ≤ n and canonical bundle degree −2.')

# Riemann sphere residues are computed in the local coordinate w=1/z.
poles = (p,q,r); residues = (a,b,c)
f = sum(v/(z-s) for s,v in zip(poles,residues))
for s,v in zip(poles,residues):
    assert cancel((z-s)*f).subs(z,s).simplify()==v
f_w = cancel(f.subs(z,1/w)*(1/w).diff(w))
assert cancel(w*f_w).subs(w,0)==-a-b-c
regular_w=cancel(f_w.subs(c,-a-b))
assert regular_w.subs(w,0).is_finite is not False
assert Poly(regular_w.as_numer_denom()[1],w).eval(0)!=0
print('Each finite partial-fraction residue is indexed once; the residue at infinity is −Σ a_j.')

split=(5,3,1,1,-2,-7)
h=lambda n:sum(max(n+k+1,0) for k in split)
assert tuple(sorted(-n for n in range(-12,13) for _ in range(h(n)-2*h(n-1)+h(n-2))))==tuple(sorted(split))
print('Second finite differences of h⁰(M(n)) recover the multiset of splitting degrees.')

k=symbols('k',integer=True,nonnegative=True)
# In local generators of O(kS) and O((k+1)S) at x=0, inclusion is multiplication by x.
# The symbolic exponents differ by one; on the residue field the resulting map is zero.
x=symbols('x',nonzero=True)
assert cancel(x**(-k)/x**(-k-1)).powsimp(force=True)==x
assert x.subs(x,0)==0
print('The transition between consecutive divisor twists can vanish after tensoring with a skyscraper.')

# A faithful, noncommutative finite example of the deck/fibre convention in the review.
W=list(permutations(range(3)))
compose=lambda g,h:tuple(g[h[i]] for i in range(3))
inverse=lambda g:tuple(g.index(i) for i in range(3))
rho=lambda g,v:tuple(v[i] for i in inverse(g))
sample={x:(i,i**2,i**3) for i,x in enumerate(W)}
act=lambda g,b:{x:rho(g,b[compose(x,g)]) for x in W}
for g,h in product(W,repeat=2):
    assert act(g,act(h,sample))==act(compose(g,h),sample)
print('The simultaneous deck/base and fibre rule gives the required left action on sections.')
