#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
(cd "contiguous-preview"
  export TEXINPUTS=".:../ch03-sec34:../ch03-sec34/figures:${TEXINPUTS:-}"
  for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode "linear-galois-cn.tex"; done)
if [[ -d errata ]]; then (
  cd errata
  for lang in zh en; do for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode "errata-l-$lang.tex"; done; done
); fi
