"""Exact symbolic cross-check of the §4.4.1–2 formulas against scalar operators."""
from fractions import Fraction

import sympy as S

z, u, t = S.symbols('z u t')
a0, a1, b0, b1, b2, c0, c1, c2, mu = S.symbols('a0 a1 b0 b1 b2 c0 c1 c2 mu')
A = a0/z + a1/(z-1)
B = b0/z**2 + b1/(z-1)**2 + b2/(z*(z-1))
C = c0/z**3 + c1/(z-1)**3 + (c2*(z-S.Rational(1,2))+mu)/(z**2*(z-1)**2)

def equal(a,b):
    assert S.cancel(a-b)==0, (a,b)

def coeff_limit(f, k, p):
    if p == S.oo:
        return S.cancel(f.subs(z,1/u)/u**k).subs(u,0)
    return S.cancel((z-p)**k*f).subs(z,p)

def indicial(coefs,p):
    n = len(coefs)-1
    weights = (lambda d:(-1)**d*S.rf(t,d)) if p == S.oo else (lambda d:S.ff(t,d))
    s=sum(coeff_limit(f,k,p)*weights(n-k) for k,f in enumerate(coefs))
    return S.expand((-1)**n*s if p == S.oo else s)

def psum(polynomial):
    p = S.Poly(polynomial,t)
    return -p.nth(p.degree()-1)

points = [0,1,S.oo]
I2 = [indicial((S.Integer(1),A,B),p) for p in points]
I3 = [indicial((S.Integer(1),A,B,C),p) for p in points]
I2_book = [t*(t-1)+a0*t+b0, t*(t-1)+a1*t+b1, t*(t+1)-(a0+a1)*t+b0+b1+b2]
I3_book = [t*(t-1)*(t-2)+a0*t*(t-1)+b0*t+c0, t*(t-1)*(t-2)+a1*t*(t-1)+b1*t+c1, t*(t+1)*(t+2)-(a0+a1)*t*(t+1)+(b0+b1+b2)*t-(c0+c1+c2)]
for got,want in zip(I2+I3,I2_book+I3_book): equal(got,want)
assert S.expand(sum(map(psum,I2)))==1
assert S.expand(sum(map(psum,I3)))==3
for n,polys in [(2,I2),(3,I3)]:
    nn = n*(n-1)//2
    for p,I in zip(points,polys):
        # At infinity dz=-u^-2 du, so residue of -A dz is +lim(z*A).
        equal(psum(I)+(nn if p==S.oo else -nn), (+1 if p==S.oo else -1)*coeff_limit(A,1,p))
print('Indicial polynomials, finite and infinite Wronskian orders/residues, and both Fuchs sums verified.')

adjoint = (-A, B-2*S.diff(A,z), S.diff(B,z)-S.diff(A,z,2)-C)
adj_data = (-a0,-a1,b0+2*a0,b1+2*a1,b2,-c0-2*a0-2*b0,-c1-2*a1-2*b1,-c2-2*b2,-mu)
old_data = (a0,a1,b0,b1,b2,c0,c1,c2,mu)
for got, f in zip(adjoint,(A,B,C)): equal(got,f.subs(dict(zip(old_data,adj_data)), simultaneous=True))
for p,I in zip(points,I3): equal(indicial((S.Integer(1),*adjoint),p),-I.subs(t,(2 if p!=S.oo else -2)-t))
reflect = (-A.subs(z,1-z),B.subs(z,1-z),-C.subs(z,1-z))
reflect_data = (a1,a0,b1,b0,b2,c1,c0,c2,-mu)
for got, f in zip(reflect,(A,B,C)): equal(got,f.subs(dict(zip(old_data,reflect_data)), simultaneous=True))
assert [indicial((S.Integer(1),*reflect),p) for p in points]==[I3[1],I3[0],I3[2]]
print('The normalized adjoint, the opposite shift at infinity, and the reflection/accessory sign all verified.')

# Explicit determinant-one counterexample for residues of other coefficients.
y1, y2=S.sqrt(z),S.sqrt(z)*(z-1)**2
w=S.simplify(y1*S.diff(y2,z)-y2*S.diff(y1,z))
equal(w,2*z*(z-1))
a=-S.diff(w,z)/w
b=S.cancel(-(S.diff(y1,z,2)+a*S.diff(y1,z))/y1)
equal(b,3/(4*z**2)+1/(2*z*(z-1)))
assert S.residue(b,z,0)==-S.Rational(1,2)
print('The coefficient a2 can have nonintegral residue even for a finite determinant-one group.')

# §4.4.2 Fourier sums: ζ^r contributes exactly s ≡ -r mod e.
def multiplicity(eigen_powers):
    n = len(eigen_powers[0][1])
    return -n+sum((Fraction(sum((-r) % e for r in powers),e) for e,powers in eigen_powers),Fraction(0))
assert multiplicity([(1,[0])]*3)==-1
assert multiplicity([(3,[1])]*3)==1
# The local exponents of a rank-one scalar equation are the residues of dlog(y).
native=-S.Rational(2,3)*(1/z+1/(z-1))
gauged=native-2/z
get_exponents=lambda dlog: tuple(sign*coeff_limit(dlog,1,p) for sign,p in [(1,0),(1,1),(-1,S.oo)])
assert get_exponents(native)==(-S.Rational(2,3),-S.Rational(2,3),S.Rational(4,3))
assert get_exponents(gauged)==(-S.Rational(8,3),-S.Rational(2,3),S.Rational(10,3))
assert all((a-b).is_Integer for a,b in zip(get_exponents(native),get_exponents(gauged)))
print('Fourier multiplicities for the trivial and cubic characters and rational gauge example all verified.')
