from itertools import product
p=7
one=(1,0,0,1)
def norm(M):
    M=tuple(x%p for x in M)
    return min(M,tuple(-x%p for x in M))
def mul(M,N):
    a,b,c,d=M
    e,f,g,h=N
    return norm((a*e+b*g,a*f+b*h,c*e+d*g,c*f+d*h))
def inv(M):
    a,b,c,d=M
    return norm((d,-b,-c,a))
def order(g):
    h=one
    for i in range(1,169):
        h=mul(h,g)
        if h==one: return i
    raise AssertionError(g)
def reach(a,b):
    found={one}
    nexts=[one]
    for h in nexts:
        for g in (a,b):
            r=mul(h,g)
            if r not in found:
                found.add(r); nexts.append(r)
    return found
G={norm((a,b,c,d)) for a,b,c,d in product(range(p),repeat=4) if (a*d-b*c)%p==1}
assert len(G)==168
orders={g:order(g) for g in G}
pairs={(a,b) for a in G for b in G if (orders[a],orders[b],orders[mul(a,b)])==(2,3,7)}
a,b=next(iter(pairs)); assert reach(a,b)==G
# Projective GL2 supplies conjugations preserving PSL2.
projective={}
for M in product(range(p),repeat=4):
    a0,b0,c0,d0=M
    if (a0*d0-b0*c0)%p:
        n=pow(next(x for x in M if x),-1,p)
        projective[tuple(n*x%p for x in M)]=1
def conjugate(M,N):
    a,b,c,d=M
    e,f,g,h=N
    scale=pow((a*d-b*c)%p,-1,p)
    w,x,y,z=(a*e+b*g,a*f+b*h,c*e+d*g,c*f+d*h)
    return norm(scale*r for r in (w*d-x*c,-w*b+x*a,y*d-z*c,-y*b+z*a))
assert len(projective)==336
assert pairs=={(conjugate(M,a),conjugate(M,b)) for M in projective}
assert len(pairs)==336
assert {x for x in orders.values()}=={1,2,3,4,7}
print('PSL2(F7) has 168 elements; [2,3,7] has one PGL2 orbit of 336 generating triples.')
