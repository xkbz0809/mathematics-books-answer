import sympy as s
from fractions import Fraction as Q
from math import prod

t, mu = s.symbols('t mu')
R = s.Rational
E0 = (R(-1,2), 0, R(1,2))
E1 = (R(-6,7), R(-5,7), R(-3,7))
EI = (R(8,7), R(9,7), R(11,7))
rows = [
 (E0, (R(-2,3), R(-1,3), 0), EI, [R(12293,24696)]),
 (E0, (R(-3,4), R(-1,4), 0), EI, [R(5273,10976)]),
 ((R(-1,2),1,R(1,2)), E1, EI, [R(1045,686)]),
 ((R(-1,2),0,R(3,2)), E1, EI, [R(2433,1372)-3*s.sqrt(21)/392, R(2433,1372)+3*s.sqrt(21)/392]),
]
for block in (1,2):
    for col in range(3):
        ex = [list(E0),list(E1),list(EI)]
        ex[block][col] += 1
        vals = [1317,1205,1149,3375,3263,3207]
        rows.append((*ex,[R(vals[(block-1)*3+col],2744)]))

def pol(es): return s.Poly(prod(t-v for v in es),t)
for idx,(e0,e1,ei,claimed) in enumerate(rows,1):
    assert sum(sum(e) for e in [e0,e1,ei]) == 3
    assert all(len(set(e))==3 for e in [e0,e1,ei])
    e = [pol(x) for x in (e0,e1,ei)]
    a0,a1 = (3 + e[j].nth(2) for j in (0,1))
    b0,b1 = (e[j].nth(1) - 2 + a for j,a in enumerate([a0,a1]))
    c0,c1 = (e[j].nth(0) for j in (0,1))
    assert e[2].nth(2) == 3 - a0 - a1
    b2 = e[2].nth(1) - 2 + a0 + a1 - b0 - b1
    c2 = -e[2].nth(0)-c0-c1
    P0=e[0].as_expr()
    P1=-a1*t*(t-1)-b2*t-c2/2+mu
    P2=-a1*t*(t-1)+(b1-b2)*t+2*mu
    pair=[(i,j) for i in e0 for j in e0 if j>i and (j-i).is_Integer]
    assert len(pair)==1
    l,k=pair[0]
    if k-l==1: obstruction=P1.subs(t,l)
    else:
        assert k-l==2
        obstruction=P1.subs(t,l)*P1.subs(t,l+1)-P0.subs(t,l+1)*P2.subs(t,l)
    residuals=[s.simplify(obstruction.subs(mu,v)) for v in claimed]
    print(idx, 'obstruction', s.factor(obstruction), 'residuals', residuals)
    assert all(x==0 for x in residuals)
    assert s.Poly(obstruction,mu).degree() == len(claimed)
assert 1 + Q(168,2)*(1-Q(1,2)-Q(1,3)-Q(1,7))==3
chars=(
 [(0,0,0,1),(0,1,1,2),(0,1,2,3),(0,1,3,4),(3,5,6,7),(1,2,4,7)],
 [(0,0,0,1),(0,1,1,2),(0,1,2,3),(0,1,3,4),(1,2,4,7),(3,5,6,7)],
)
for ch in chars:
    for a,b,c,d in ch:
        assert (a+b+c)%d==0
def multiplicity(ch, triple):
    return -3 + sum(sum(Q((-n)%row[-1],row[-1]) for n in row[:-1])
                    for i in triple for row in [ch[i-1]])
assert [[multiplicity(ch,tr) for ch in chars] for tr in [(2,3,5),(2,4,5),(2,5,5)]] == [[0,1],[0,1],[0,2]]
print('All ten rows, 11 candidate values, multiplicities, determinants, and genus verified.')
