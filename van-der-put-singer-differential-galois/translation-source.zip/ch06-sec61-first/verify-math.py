"""Independent exact spot checks, supplementing the proofs in exact-review.md."""
import sympy as s

z, t = s.symbols("z t")

# Formal/analytic local-parameter chain rule checked with a meromorphic f.
t_of_z = z + 2*z**2 + z**3
f = t**-3 + 4*t**2 - t
assert s.cancel(s.diff(f.subs(t, t_of_z), z) -
                s.diff(f, t).subs(t, t_of_z)*s.diff(t_of_z, z)) == 0
assert s.diff(t_of_z, z).subs(z, 0) == 1
assert s.cancel((z * s.diff(t_of_z, z) / t_of_z) - (1+3*z)/(1+z)) == 0
print("Local-coordinate chain rule and unit in Euler-vector rescaling checked.")

# Contracting a genuine connection by D=h*d/dz gives a D-Leibniz rule.
F, G, h, a = [s.Function(n)(z) for n in ("F", "G", "h", "a")]
def D(u):
    return h * s.diff(u, z)
def T(u):
    return h * (s.diff(u, z) + a*u)
assert s.expand(T(F*G) - D(F)*G - F*T(G)) == 0

# With h=z, T(1) is divisible by z for every holomorphic a. The operator
# y -> z*y'+y has T(1)=1 and nevertheless obeys the D-Leibniz rule.
def witness(u):
    return z*s.diff(u, z) + u
assert s.expand(witness(F*G) - z*s.diff(F, z)*G - F*witness(G)) == 0
assert witness(s.Integer(1)) == 1
assert T(s.Integer(1)).subs(h, z).subs(z, 0) == 0
print("Unit-h recovery and h=z non-surjectivity witness checked.")

# A connection need not be flat when two coordinate derivations are present.
x, y = s.symbols("x y")
q = s.Function("q")(x, y)
def partial_x(u):
    return s.diff(u, x)
def partial_y_shift(u):
    return s.diff(u, y) + x*u
assert s.simplify(partial_x(partial_y_shift(q)) -
                  partial_y_shift(partial_x(q))) == q
print("The contraction operators of a two-variable connection need not commute.")
