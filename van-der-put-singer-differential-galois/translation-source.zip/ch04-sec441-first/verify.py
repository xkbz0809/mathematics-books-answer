"""Exact indicial finite-Galois witness and hypergeometric exponent checks."""
import sympy as s
from itertools import product
z,X=s.symbols('z X', positive=True)
f,g=1+z,s.sqrt(z)
w=s.simplify(f*s.diff(g,z)-s.diff(f,z)*g)
p=s.simplify(-s.diff(w,z)/w)
q=-1/(2*z*(1-z))
assert s.simplify(p-1/(1-z)-1/(2*z))==0
L=lambda y:s.diff(y,z,2)+p*s.diff(y,z)+q*y
assert all(s.simplify(L(h))==0 for h in (f,g))
assert s.simplify(L(s.Integer(1))-q)==0
ind=s.limit(z**2*z**(-X)*L(z**X),z,0,dir='+')
assert s.simplify(ind-X*(X-s.Rational(1,2)))==0
a,b,c=map(lambda q:s.Rational(*q),[(13,84),(1,84),(1,2)])
assert (1-c,c-a-b,a-b)==(s.Rational(1,2),s.Rational(1,3),s.Rational(1,7))
assert all(0<sum(t)<1 for t in product((0,1-c),(0,c-a-b),(a,b)))
print('Finite Galois indicial witness and irreducible hypergeometric exponent checks passed.')
