# Linear §3.1 classical Hensel unit

Exact anchor: print 62/PDF 83 at Proposition 3.3 heading, ending after the square of Example 3.6 at print 63/PDF 84; next line §3.1.1 Regular Singular Equations. Includes both parts of Proposition 3.3 proof, Lemma 3.4 and proof, Examples 3.5 and 3.6. No exercise in this bounded unit; no figures on these pages. Two-pass standalone PDF, both pages rendered and visually inspected.

Three mathematically verified errata candidates (parent to assign IDs):

1. Prop. 3.3, p. 62: λ=min_i v(a_i)/i, but original prints T=z^(−λ)E. Use T=z^λ E and divide by z^(dλ): this gives b_i=a_i z^(−iλ) and the asserted valuations. If the polynomial is a pure power T^d, 0 is already a root and λ=∞ need not be used; likewise stop the iteration if all e_i vanish after translation.
2. Example 3.5, p. 62: Q₁(1) starts from Q₁(0), not Q₀(0). Exact expansion is −2zy+z²−z(y+1)R₁−z(y−1)R₂−z²R₁R₂. Original drops z² and prints a plus on z²R₁R₂. The congruence obtained by dividing by z and reducing is −2y≡(y+1)R₁+(y−1)R₂ mod z, not the original expression with a negative sign and an extra z in the R₂ term. This agrees with R₁=R₂=−1 and the original final factorization.
3. Example 3.6, p. 63: final expression 1+z(1±z^(1/2)) is wrong. Q=P(zE*) has roots E*=1±z^(1/2), so P has roots E=z(1±z^(1/2)). This also follows at once by factoring the displayed P=(E−z)^2−z³. The exponent 1/2 is a valid incremental valuation in the normalized variable E*, distinct from the increasing cumulative exponents in the proof; no error assigned to it.

Checked proof details: in Hensel's lifting, the reduced error polynomial has degree <deg P because all factors are monic. The linear map (R₁,R₂)↦R₁F₂+R₂F₁ on the two bounded-degree spaces is injective by coprimality and surjective by dimension, so each coefficient correction is unique. This gives uniqueness of the complete factors. After a factorization over K_m, degree induction applies using the parameter z^(1/m). When the correction never factors, the integral exponents tend to infinity, so the successive approximations of the single root converge coefficientwise.
