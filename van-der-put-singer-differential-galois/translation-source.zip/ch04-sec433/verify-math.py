"""Exact checks in Q(z) and combinatorial identities for the §4.3.3 edit."""
from itertools import permutations
from math import factorial
from sympy import Matrix, symbols, diff, expand, simplify, Rational, Poly, prod, binomial
z,T=symbols('z T')
D=lambda x:diff(x,z)
a=-1/(2*z); b=-z
# Basis e², e De, (De)², with D²e=−a De−b e.
N=Matrix([[0,2,0],[-b,-a,1],[0,-2*b,-2*a]])
row=Matrix([[1,0,0]])
B=row
for _ in range(3):
    row=(row.diff(z)+row*N).applyfunc(simplify)
    B=B.col_join(row)
assert B==Matrix([[1,0,0],[0,2,0],[2*z,1/z,2],[3,8*z-Rational(1,2)/z**2,3/z]])
assert B.rank()==3
assert (Matrix([[0,-(4*z**3-1)/z**2,-3/(2*z),1]])*B).applyfunc(simplify)==Matrix([[0,0,0]])
# Differential row vectors 1, De in the two-dimensional module.
N2=Matrix([[0,1],[-b,-a]])
R0=Matrix([[0,1]])
R1=R0.diff(z)+R0*N2
R2=(R1.diff(z)+R1*N2).applyfunc(simplify)
a1=-3/(2*z); b1=1/z**2-z
assert (R2+a1*R1+b1*R0).applyfunc(simplify)==Matrix([[0,0]])
A,B0,C=[simplify(v) for v in (3*a1, D(a1)+4*b1+2*a1**2, 2*D(b1)+4*a1*b1)]
assert all(simplify(v)==0 for v in (A+9/(2*z),B0+(4*z**3-10)/z**2,C-(4*z**3-10)/z**3))
assert simplify(D(D(D(z)))+A*D(D(z))+B0*D(z)+C*z)==0
u=z**Rational(1,2)
for v in (u,-u):
    assert simplify(D(v)+v**2-v/(2*z)-z)==0
    assert simplify(D(v)-v/(2*z))==0
for m in range(1,6):
    roots=[z+j for j in range(m)]
    P=Poly(prod(T-t for t in roots),T)
    for i in range(1,m+1):
        actual=sum(prod(p[:i]) for p in permutations(roots))
        assert expand(actual-(-1)**i*factorial(i)*factorial(m-i)*P.nth(m-i))==0
# Gauged common denominator: D², m=1, y=z, representative 1.
assert D(-1/z)!=0 and D(z*(-1/z))==0 and D(D(z))==0
print('matrix ranks/left kernel; derivative operator and its symmetric square; Vieta m=1..5; Riccati roots; omitted-factor counterexample: PASS')
