"""Independent symbolic checks for source §4.2. No user-facing exercise solutions."""
from itertools import product
from math import comb
import sympy as s
z=s.symbols('z')
d1,d2,d3=s.symbols('d1 d2 d3')
H=d1+d2*z+d3*z*z
a,b,c,d,e,f=s.symbols('a b c d e f')
F=a+b*z+c*z*z
G=d+e*z+f*z*z
def der(f,n=1):return s.diff(f,z,n)
W=s.expand(F*der(G)-der(F)*G)
p20=lambda p:s.expand(W*der(p,2)-der(W)*der(p)+der(W,2)*p)
assert s.expand(der(F)*der(G,2)-der(F,2)*der(G)-der(W,2))==0
assert p20(F)==p20(G)==0
# Second family: p-p' is H if p=(1+D+D^2)H, and the other solution is e^z.
P=H+der(H)+der(H,2)
B=lambda q:s.expand(H*der(q,2)-(H+der(H))*der(q)+der(H)*q)
assert B(P)==B(s.exp(z))==0
# Differential composition for two examples (coefficient lists low degree first).
def oremul(A,B):
 out=[s.Integer(0)]*(len(A)+len(B)-1)
 for i,a in enumerate(A):
  for j,b in enumerate(B):
   for k in range(i+1):
    out[i+j-k]+=comb(i,k)*a*der(b,k)
 return [s.simplify(x) for x in out]
assert oremul([z,1],[-1,z])==[-z,z*z,z]
assert oremul([z+1/z,1],[-1/z,1])==[-1,z,1]
L=lambda p:s.simplify(der(p,2)+z*der(p)-p)
assert L(z)==0 and s.simplify(L(1/z)-(2/z**3-2/z))==0
# Pole and infinity residues in the Riccati equation.
N=s.symbols('N')
ric=lambda p:s.expand(der(p)+p*p+z*p-1)
assert ric(-z+N/z).coeff(z,0)==-N-2
assert ric(N/z).coeff(z,0)==N-1
# Local-Eisenstein counterexample: prove x ∉ P^2 by ideal membership and
# x*D^2-y factorization by the ring relation xy=u^2. D only differentiates t.
x,y,u=s.symbols('x y u')
ideal=s.groebner([x*y-u*u,x*x,x*u,u*u],x,y,u)
assert ideal.reduce(x)[1]==x
assert s.rem(x*y-u*u,x*y-u*u,x)==0
assert s.expand(oremul([-u/x,1],[u/x,1])[0]*x*x)==-u*u
print('PASS: both right-factor families; Ore products; logarithmic derivative; local criterion counterexample')
