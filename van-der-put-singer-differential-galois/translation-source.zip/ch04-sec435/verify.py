"""Independent polynomial verification of the actual counterexample; all integers/rationals exact."""
import sympy as S
x,s,a,t,b=S.symbols('x s a t b')
def D(f): return S.expand(S.diff(f,x)+a*S.diff(f,s)+x*s*S.diff(f,a)+b*S.diff(f,t)+x*t*S.diff(f,b))
f=(s*a,(s*b+a*t)/2,t*b); w=s*b-a*t
assert D(w)==0
for y in f: assert S.expand(D(D(D(y)))-4*x*D(y)-6*y)==0
wr=S.factor(S.Matrix([[y,D(y),D(D(y))] for y in f]).det()); assert S.simplify(wr/w**3)!=0 and not (S.simplify(wr/w**3).free_symbols)
q=S.factor(f[0]*f[2]-f[1]**2); assert S.expand(q+w**2/4)==0 and D(q)==0
assert S.simplify(q**2/w**4)==S.Rational(1,16)
print('All three functions satisfy y\u2034-4xy\u2032-6y=0. Wronskian relative to Airy W^3:',S.simplify(wr/w**3))
print('Quadratic relative to Airy W^2:',S.simplify(q/w**2),'; quartic relative to W^4:',S.simplify(q*q/w**4))
assert 3*S.factorial(6)//2==1080
