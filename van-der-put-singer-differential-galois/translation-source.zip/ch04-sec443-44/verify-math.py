"""Independent symbolic checks for print 134-136 (user PDF 155-157)."""
import sympy as s

z, t, mu = s.symbols("z t mu")
a0, a1, b0, b1, b2, c0, c1, c2 = s.symbols("a0 a1 b0 b1 b2 c0 c1 c2")
variables = (a0, a1, b0, b1, b2, c0, c1, c2, mu)
A = a0 / z + a1 / (z - 1)
B = b0 / z**2 + b1 / (z - 1)**2 + b2 / (z * (z - 1))
C = c0 / z**3 + c1 / (z - 1)**3 + (c2 * (z - s.Rational(1, 2)) + mu) / (z * (z - 1))**2

# Laurent coefficient identity: multiply z^(-t)L(z^t) by z^3 to avoid
# introducing any complex-power branch into the symbolic expansion.
falling = t * (t - 1)
F = falling * (t - 2) + z * A * falling + z**2 * B * t + z**3 * C
known = (
    falling * (t - 2) + a0 * falling + b0 * t + c0,
    -a1 * falling - b2 * t - c2 / 2 + mu,
    -a1 * falling + (b1 - b2) * t + 2 * mu,
    -a1 * falling + (2 * b1 - b2) * t - c1 + c2 / 2 + 3 * mu,
)
trunc = s.series(F, z, 0, len(known)).removeO().expand()
for i, P in enumerate(known):
    assert s.simplify(trunc.coeff(z, i) - P) == 0
assert s.simplify(trunc.coeff(z, 3) - (known[3] + c1)) == -c1
assert s.diff(F, mu) == z / (z - 1)**2
print("P0--P3 checked; printed P3 is too large by c1; general mu term is i*mu.")

# At the other two regular singular points the accessory portion of the
# MONIC operator retains a double pole; hence P1 is affine with nonzero
# slope at each point. In the infinity chart d/dz=-w^2*d/dw.
w = s.symbols("w")
assert s.simplify(s.diff(C, mu).subs(z, 1 + w) - 1 / (w**2 * (1 + w)**2)) == 0
assert s.simplify(s.diff(C, mu).subs(z, 1 / w) / (-w**6) + 1 / (w**2 * (1 - w)**2)) == 0
print("Accessory coefficient of P1: +1 at 0,1 and -1 at infinity.")

def resonance_matrix(lam, m, P):
    return s.Matrix(
        m, m, lambda i, j: 0 if i + 1 < j else P[i + 1 - j].subs(t, lam + j)
    )

# Check the matrices of the source and the leading-term argument for
# sample sizes. When i+1=j, the entry is P0; every entry above it is zero.
M = resonance_matrix(t, 3, known)
assert M == s.Matrix(
    [
        [known[1], known[0].subs(t, t + 1), 0],
        [known[2], known[1].subs(t, t + 1), known[0].subs(t, t + 2)],
        [known[3], known[2].subs(t, t + 1), known[1].subs(t, t + 2)],
    ]
)
assert s.expand(resonance_matrix(t, 2, known).det()) == s.expand(
    known[1] * known[1].subs(t, t + 1) - known[0].subs(t, t + 1) * known[2]
)
for m in (1, 2, 3, 4, 8, 13):
    test_P = [t**3] + [i * mu + t**2 - i for i in range(1, m + 1)]
    aux = resonance_matrix(s.Rational(-2, 7), m, test_P)
    N = aux.diff(mu)
    assert N.is_lower and N.det() == 1
print("Frobenius matrices matched for m=1,2,3; coefficient matrix of mu is unit lower triangular.")

# Finite irreducible unimodular witness: tetrahedral hypergeometric
# parameters (a,b,c)=(-1/4,-7/12,-1/2). Symmetric square, then multiply
# each solution by (z-1)z^(-1/2). Group-theoretic checks are in the review.
R = s.Rational
a, b, c = R(-1, 4), R(-7, 12), R(-1, 2)
p = (c - (a + b + 1) * z) / (z * (1 - z))
q = -a * b / (z * (1 - z))
As = 3 * p
Bs = p.diff(z) + 2 * p**2 + 4 * q
Cs = 2 * q.diff(z) + 4 * p * q
r = 1 / (z - 1) - 1 / (2 * z)
Ag = As - 3 * r
Bg = Bs - 2 * As * r + 3 * (r**2 - r.diff(z))
Cg = Cs - Bs * r + As * (r**2 - r.diff(z)) - r.diff(z, 2) + 3 * r * r.diff(z) - r**3
values = {}
for expr, witness in zip((A, B, C), (Ag, Bg, Cg)):
    values.update(s.solve(s.together(expr - witness).as_numer_denom()[0], variables, dict=True)[0])
assert all(s.cancel(expr.subs(values) - witness) == 0 for expr, witness in ((A, Ag), (B, Bg), (C, Cg)))
assert values[c1] == R(-20, 9)
lam = R(-1, 2)
assert s.expand(known[0].subs(values) - (t - lam) * (t - 1) * (t - lam - 3)) == 0
M_correct = resonance_matrix(lam, 3, known).subs(values)
M_printed = resonance_matrix(lam, 3, (*known[:3], known[3] + c1)).subs(values)
assert M_correct.det() == 0
assert M_printed.det() == R(20, 9)
print("Finite irreducible example normal data:", values)
print("m=3 determinant at the actual parameter: corrected 0, printed 20/9.")
