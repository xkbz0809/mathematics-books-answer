"""Source-level checks for Example 5.10 and Exercise 5.11."""
import mpmath as mp
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp

# Coordinate changes in the original scalar Gauss differential equation.
z, t, lam, a, b, c = s.symbols("z t lam a b c")
p = ((a + b + 1) * z - c) / (z * (z - 1))
q = a * b / (z * (z - 1))
pt = (2 * t - p.subs(z, 1 / t)) / t**2
qt = q.subs(z, 1 / t) / t**4

def euler_residue(x, px, qx):
    return s.Matrix([[0, 1], [s.limit(-x**2 * qx, x, 0), 1 - s.limit(x * px, x, 0)]])

res = [
    euler_residue(z, p, q),
    euler_residue(t, p.subs(z, 1 + t), q.subs(z, 1 + t)),
    euler_residue(t, pt, qt),
]
target = [(0, 1-c), (0, c-a-b), (a, b)]
for A, (u, v) in zip(res, target):
    assert s.expand(A.charpoly(lam).as_expr() - (lam-u)*(lam-v)) == 0
assert res == [
    s.Matrix([[0, 1], [0, 1-c]]),
    s.Matrix([[0, 1], [0, c-a-b]]),
    s.Matrix([[0, 1], [-a*b, a+b]]),
]
companion = s.Matrix([[0, 1], [-q, -p]])
A0raw = (z * companion).applyfunc(lambda w: s.limit(w, z, 0))
A1raw = ((z - 1) * companion).applyfunc(lambda w: s.limit(w, z, 1))
change = s.diag(1, -1)
assert [A0raw, A1raw, change * res[2] * change] == [
    s.Matrix([[0, 0], [a*b, -c]]),
    s.Matrix([[0, 0], [-a*b, c-a-b-1]]),
    s.Matrix([[0, -1], [a*b, a+b]]),
]
print("Euler residues, indicial roots, and minimal sign-corrected companion residues: exact.")

# B in the printed Gamma formula, with reciprocals used at Gamma poles.
mp.mp.dps = 45
j = mp.j
g, rg, sin, pi = mp.gamma, mp.rgamma, mp.sin, mp.pi

def printed_B(a, b, c):
    F = mp.exp(pi * j * (c-a-b))
    return mp.matrix([
        [1-2*j*F*sin(pi*a)*sin(pi*b)/sin(pi*c),
         -2*pi*j*F*g(2-c)*g(1-c)*rg(1-a)*rg(1-b)*rg(1+a-c)*rg(1+b-c)],
        [-2*pi*j*F*g(c)*g(c-1)*rg(c-a)*rg(c-b)*rg(a)*rg(b),
         1+2*j*F*sin(pi*(c-a))*sin(pi*(c-b))/sin(pi*c)]
    ])

def basis01(a, b, c):
    d = c-a-b
    return (
        (lambda z: mp.hyp2f1(a, b, c, z),
         lambda z: z**(1-c)*mp.hyp2f1(a-c+1, b-c+1, 2-c, z)),
        (lambda z: mp.hyp2f1(a, b, 1-d, 1-z),
         lambda z: (1-z)**d*mp.hyp2f1(c-a, c-b, 1+d, 1-z)),
    )

def from_connection(a, b, c):
    d = c-a-b
    G = mp.matrix([
        [g(c)*g(d)*rg(c-a)*rg(c-b),
         g(c)*g(-d)*rg(a)*rg(b)],
        [g(2-c)*g(d)*rg(1-a)*rg(1-b),
         g(2-c)*g(-d)*rg(1+a-c)*rg(1+b-c)]
    ])
    u, v = basis01(a, b, c)
    for w in (mp.mpf("0.22"), mp.mpf("0.5"), mp.mpf("0.77")):
        error = G * mp.matrix([f(w) for f in v]) - mp.matrix([f(w) for f in u])
        assert mp.norm(error) < mp.mpf("1e-40")
    assert abs(mp.det(G) - (c-1)/d) < mp.mpf("1e-40")
    return (G * mp.diag([1, mp.exp(2*pi*j*d)]) * G**-1).T

def independent_ode_continuation(a, b, c, basis, which):
    # Start both loops at 1/2 and traverse the corresponding circle through it
    # counterclockwise. Continue two scalar solutions by full ODE integration.
    w0 = mp.mpf("0.5")
    initial = np.array([[complex(f(w0)) for f in basis],
                        [complex(mp.diff(f, w0)) for f in basis]])
    a, b, c = map(complex, (a, b, c))

    def rhs(s, Y):
        w = which + (0.5 - which) * np.exp(2j*np.pi*s)
        dp = 2j * np.pi * (w - which)
        p = ((a + b + 1) * w - c) / (w * (w - 1))
        q = a * b / (w * (w - 1))
        return (dp * (np.array([[0, 1], [-q, -p]]) @ Y.reshape(2, 2))).reshape(4)

    sol = solve_ivp(rhs, (0., 1.), initial.reshape(4), method="DOP853",
                    rtol=1e-12, atol=2e-13)
    assert sol.success
    return np.linalg.solve(initial, sol.y[:, -1].reshape(2, 2))

def mp_to_np(M):
    return np.array([[complex(M[m, n]) for n in range(2)] for m in range(2)])

T = [
    (mp.mpf(2)/7, mp.mpf(3)/11, mp.mpf(4)/5),
    (mp.mpc(".31", ".08"), mp.mpc(".45", "-.12"), mp.mpc("1.2", ".07")),
    (mp.mpf(1), mp.mpf(1)/3, mp.mpf(1)/2),
]
for a, b, c in T:
    u, _ = basis01(a, b, c)
    d = c-a-b
    B = printed_B(a, b, c)
    assert mp.norm(B - from_connection(a, b, c)) < mp.mpf("1e-39")
    assert abs(mp.det(B) - mp.exp(2*pi*j*d)) < mp.mpf("1e-39")
    A = mp.diag([1, mp.exp(-2*pi*j*c)])
    for idx, expect in enumerate((A, B)):
        error = np.max(np.abs(independent_ode_continuation(a, b, c, u, idx) - mp_to_np(expect)))
        assert error < 5e-9, (a, b, c, idx, error)
print("All B entries, determinant, branch, and column convention agree; verified by independent ODE continuation.")

# The repeated-root example has logarithmic monodromy. Check the specific
# signs by continuing the two independent solutions, not by assuming them.
half = mp.mpf(1) / 2
special = (lambda z: mp.hyp2f1(half, half, 1, z),
           lambda z: j*mp.hyp2f1(half, half, 1, 1-z))
for idx, exact in enumerate(([[1, 2], [0, 1]], [[1, 0], [-2, 1]])):
    error = np.max(np.abs(independent_ode_continuation(half, half, 1, special, idx) - exact))
    assert error < 5e-9, (idx, error)
print("Exercise 5.11: positive-loop generators and signs verified with basis (F(z), i F(1-z)).")
