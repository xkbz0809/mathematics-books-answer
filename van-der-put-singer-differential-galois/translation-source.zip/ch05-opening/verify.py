import sympy as s
z=s.symbols('z', nonzero=True)
C1=s.diag(0,1)
P=s.Matrix([[1,1],[0,1]])
C2=P*s.diag(0,2)*P.inv()
F1=s.diag(1,z)
F2=P*s.diag(1,z**2)*P.inv()
assert z*F1.diff(z)==C1*F1 and z*F2.diff(z)==C2*F2
correct=F2*F1.inv()
wrong=F1.inv()*F2
def residual(B): return (z*B.diff(z)-C2*B+B*C1).applyfunc(s.simplify)
assert residual(correct)==s.zeros(2)
assert residual(wrong)!=s.zeros(2)
print('Gauge residual of the printed order:',residual(wrong))
