"""Checks of the corrected §6.2 formulas. Not an exercise solutions file."""
import sympy as s

z, t = s.symbols("z t")
E = s.Matrix([[0, 1], [0, 0]])
H = s.eye(2) + E/z
assert H.det() == 1
assert (H.diff(z) + E/z**2*H).applyfunc(s.cancel) == s.zeros(2)
print("A double pole in a chosen matrix is not intrinsically irregular.")

A, B, s1, s2 = s.symbols("A B s1 s2")
omega_t = -A/(t*(1-s1*t)) - B/(t*(1-s2*t))
assert s.simplify(s.limit(t*omega_t, t, 0) + A + B) == 0
for r in range(-4, 5):
    assert s.cancel(s.diff(t**r,t) - (r/t)*t**r) == 0
print("Residue at infinity and twisting factors checked.")

def delta(f):
    return z*s.diff(f, z)
for m in range(1, 8):
    for ell in range(-5, 9):
        q = z**ell
        for r in range(m):
            q = delta(q) - r*q
        assert s.cancel(q - z**m*s.diff(z**ell, z, m)) == 0
assert delta(delta(z)) - delta(z) == 0 and delta(z) == z
print("Euler falling factorial: corrected m factors, not m+1.")

# Original example at infinity. Reduction of order in the t-equation.
y = z**2 - 2
assert s.cancel(s.diff(y,z,2) - 2*y/(z*z-2)) == 0
w = y.subs(z, 1/t)
p, q = 2/t, -2/(t*t*(1-2*t*t))
assert s.cancel(s.diff(w,t,2) + p*s.diff(w,t) + q*w) == 0
ip = -t**2/(1-2*t**2)**2
assert s.cancel(s.diff(ip,t) + (2*s.diff(w,t)/w + p)*ip) == 0
assert s.cancel(ip*w**2) == -1/t**2
I = s.integrate(s.series(ip,t,0,7).removeO(),t)
assert s.series(I*w,t,0,2).removeO() == -t/3
print("At infinity the scalar coefficients have poles, but a meromorphic basis exists.")

# Ore relation and a concrete Möbius pullback of a Fuchsian equation.
phi = (2*z+1)/(z+1)           # ad-bc = 1
inv_phi = (1-z)/(z-2)
assert s.cancel(inv_phi.subs(z, phi) - z) == 0
assert s.cancel(phi.diff(z) - 1/(z+1)**2) == 0
g = (z+1)**2
f = s.Function("f")(z)
commutator = g * (s.diff(phi*f,z) - phi*s.diff(f,z))
assert s.cancel(commutator - f) == 0
assert s.cancel(phi.diff(z)**2 - 1) != 0
alpha = s.Rational(1, 3)
coeff = s.cancel(-alpha*phi.diff(z)/phi)
assert set(s.solve(s.denom(coeff), z)) == {-1, -s.Rational(1,2)}
assert phi.subs(z,0) == 1 and s.limit(phi,z,s.oo) == 2
print("Möbius pullback preserves the Ore relation and takes pole sets to inverse images.")
