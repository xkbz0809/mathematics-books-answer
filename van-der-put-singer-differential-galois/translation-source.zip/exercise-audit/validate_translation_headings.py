#!/usr/bin/env python3
"""Match scan-confirmed exercise headings to their pages in the compiled translation."""
import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
# The second dot, if followed by a digit, introduces a subpart such as 1.5.2.
# A terminal dot, as in the heading 13.8., is allowed.
PREFIX = re.compile(r"^\s*(?:习题|练习|Exercises?)\s*([A-Z0-9]+\.\d+)(?!\d|\.\s*\d)([.．]?)")
PROSE = {
    "7.6": re.compile(r"^引出了\s*k\s*阶\s*Gevrey\s*级数的概念"),
    "13.1": re.compile(r"^要求\s*f\s*可分[，,]"),
}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", default=HERE / "formal-exercise-block-index.json", type=Path)
    parser.add_argument("--pdf", default=HERE.parent / "contiguous-preview/front-linear-full-appendices.pdf", type=Path)
    parser.add_argument("--tsv", default=HERE / "translation-heading-pages.tsv", type=Path)
    args = parser.parse_args()
    exact = json.loads(args.index.read_text(encoding="utf-8"))
    entries = exact["blocks"]
    ids = [row["id"] for row in entries]
    if len(ids) != exact["confirmed_count"] or len(ids) != len(set(ids)):
        sys.exit("The scan index count is inconsistent or has duplicate IDs.")
    text = subprocess.check_output(["pdftotext", "-enc", "UTF-8", "-layout", str(args.pdf), "-"]).decode("utf-8")
    pages = text.split("\f")
    if pages and not pages[-1]:
        pages.pop()
    found = defaultdict(list)
    serial = []
    exclusions = []
    for page_no, page in enumerate(pages, 1):
        for line_no, line in enumerate(page.splitlines(), 1):
            match = PREFIX.match(line)
            if match is None:
                continue
            ident = match[1]
            rest = line[match.end():].lstrip()
            if ident in PROSE and PROSE[ident].match(rest):
                exclusions.append((ident, page_no, line_no))
                continue
            found[ident].append((page_no, line_no))
            serial.append(ident)
    missing = [i for i in ids if i not in found]
    extra = sorted(set(found) - set(ids))
    duplicate = {ident: locs for ident, locs in found.items() if len(locs) > 1}
    if missing or extra or duplicate or serial != ids:
        print(f"FAIL: missing={missing}; extra={extra}; duplicate={duplicate}; in_order={serial == ids}", file=sys.stderr)
        return 1
    with args.tsv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f, delimiter="\t", lineterminator="\n")
        writer.writerow(["Exercise ID", "Original print page", "Original scan PDF page", "Translation PDF page"])
        for row in entries:
            writer.writerow([row["id"], row["original_print_page"], row["pdf_page_1based"], found[row["id"]][0][0]])
    print(f"PASS: {len(ids)}/{exact['confirmed_count']} headings; no duplicate or unexpected heading; same order.")
    print(f"Physical translation PDF pages: {len(pages)}; counts by original unit: {dict(Counter(row['unit'] for row in entries))}")
    print(f"Excluded explicit prose references (id, physical page, extracted line): {exclusions}")
    print(f"Translation SHA256: {hashlib.sha256(args.pdf.read_bytes()).hexdigest()}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
