# Compiled Linear translation: formal exercise heading validation

**PASS: 93/93 scan-confirmed formal exercise blocks detected, in the same order, with no duplicate or unexpected heading.**

The exact baseline is formal-exercise-block-index.json (Science Press facsimile, SHA256 1b2cd508206e8cc73052492d4e5e5842b258e4817e459b8a641bdb4b1e29165d). The comparison is an independent line-start sweep on pdftotext -layout output from contiguous-preview/front-linear-full-appendices.pdf (343 pages; SHA256 fca5b69a7b87d2d9987a892381425ddf272ed3944b6e45817075f376ddb92f39). Physical PDF page counts include preliminary matter.

- The matcher accepts the terminal dot in the formal heading 13.8., and rejects references to numbered subparts such as 1.5.2.
- The two same-prefix lines explicitly classified as prose are the Gevrey discussion's reference to 7.6 (translation physical PDF p. 167) and the separability discussion's reference to 13.1 (translation physical PDF p. 271). Their actual headings are on translation physical pages 167 and 269, respectively.
- The 93-row translation-heading-pages.tsv records each heading's ID, print page, original physical scan page, and current physical translation page.
- Reproduce from this directory with python3 validate_translation_headings.py. Use --pdf and --tsv to compare a rebuilt release without overwriting this snapshot.

Scope: this verifies the presence, uniqueness and order of all formal block **headings** in the scan-confirmed index, not the correctness/completeness of every subpart, nor any exercise answer or solution status. There are no master changes.
