"""Independent algebraic verification of selected §6.5 formulas."""
from itertools import combinations_with_replacement

import sympy as sp

t = sp.symbols("t")

# The section uses δ(e_i)=sum a_ij e_j, i.e. rows indexed by the
# differentiated basis element. Under f=P e use B=(δ(P)+P A)P^-1.
a = sp.Matrix(3, 3, sp.symbols("a0:9"))
N = 6
A = a.applyfunc(lambda u: u)
for i in range(3):
    for j in range(3):
        if i != j:
            A[i, j] *= t**N
P = sp.diag(1, 1/t, 1)
B = ((t*P.diff(t)+P*A)*P.inv()).applyfunc(sp.cancel)
for i in range(3):
    assert B[i, i] == A[i, i] - int(i == 1)
    for j in range(3):
        if i != j:
            ex = N + int(j == 1) - int(i == 1)
            assert sp.simplify(B[i, j] - a[i, j]*t**ex) == 0
            assert ex >= N-1
print("Lemma 6.19: basis change shifts one residue by -1 and loses at most one t-order.")

# Integer separations of a constant Jordan block.
J = sp.eye(4)/3
for j in range(1, 4):
    J[j, j-1] = 1
P = sp.diag(*[t**(j*N) for j in range(4)])
B = ((t*P.diff(t)+P*J)*P.inv()).applyfunc(sp.cancel)
for i in range(4):
    assert B[i, i] == sp.Rational(1, 3) + i*N
    if i:
        assert B[i, i-1] == t**N
print("Lemma 6.20: shearing a Jordan block gives the stated t^N off-diagonal term.")

def defect(a):
    return len(a)*max(a) - sum(a)

for n in range(2, 7):
    for a in combinations_with_replacement(range(-4, 5), n):
        d = defect(a)
        if d:
            new = list(a)
            new[0] += 1
            assert max(a) == max(new) and defect(new) == d - 1
        width = max(v-u for u, v in zip(a,a[1:]))
        assert d <= n*(n-1)//2*width
print("Adjacent-gap bound and exact unit decrease of the defect verified on integer types.")

# Remark 6.23(4): the Laurent equation for h is measured in dt/t.
# For λ=-1 its coefficient at t^-1 vanishes for all h.
h = sum(sp.Symbol(f"h{k+5}")*t**k for k in range(-5, 4))
assert (sp.expand(t*h.diff(t)+h)).coeff(t, -1) == 0
assert (sp.expand(t*h.diff(t)+h+1/t)).coeff(t, -1) == 1

# Our two-dimensional example in the e1,e2 basis has δ(e2)=-e2+t^-1 e1.
# After choosing e2' = t e2 it is already logarithmic.
A = sp.Matrix([[0,0],[1/t,-1]])
P = sp.diag(1,t)
B = ((t*P.diff(t)+P*A)*P.inv()).applyfunc(sp.cancel)
assert B == sp.Matrix([[0,0],[1,0]])
print("Rank-two witness: logarithmic generic module, but no unipotent gauge in the printed fixed basis.")

# Residue normalization by a degree-zero principal divisor; test both
# all-integral residues and a mixed case with a nonintegral compensation.
alpha = (sp.Integer(-2), sp.Rational(1,3), sp.Rational(5,3))
beta = (sp.Integer(2), sp.Integer(-2), sp.Integer(0))
r = t**2/(t-1)**2
assert sp.residue(r.diff(t)/r,t,0) == beta[0]
assert sp.residue(r.diff(t)/r,t,1) == beta[1]
assert sum(alpha) == sum(beta) == 0
assert all(not (a+b).is_integer or a+b >= 0 for a,b in zip(alpha,beta))
assert all(a+b == 0 for a,b in zip((-3,1,2),(3,-1,-2)))

# Check the descending-pole-order procedure with λ not an integer and
# with a nonconstant holomorphic part in the logarithmic coefficient.
a = sp.Rational(1,3) + t + 2*t**2
omega = t**-4 + 2*t**-3 - 3*t**-2 + 4*t**-1 + 2 + t
h = sp.S.Zero
for q in range(-4,0):
    coeff = sp.expand(omega+t*h.diff(t)-a*h).coeff(t,q)
    h += -coeff/(q-a.subs(t,0))*t**q
out = sp.expand(omega+t*h.diff(t)-a*h)
assert all(out.coeff(t,q) == 0 for q in range(-4,0))
print("The corrected residue normalization and local triangular pole elimination work.")
