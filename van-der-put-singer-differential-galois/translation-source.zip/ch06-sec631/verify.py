"""Exact rational Ore-algebra validation of the algorithm and the printed errata."""
from math import comb
from random import Random
import sympy as S

z, X = S.symbols('z X')
P = lambda a: S.Poly(a, z, domain=S.QQ)
Z, ONE = P(0), P(1)

def interpolate(xs, ys):
    return P(S.interpolate(list(zip(xs, ys)), z))

def add(left, right):
    return tuple((left[i] if i<len(left) else Z)+(right[i] if i<len(right) else Z)
                 for i in range(max(len(left),len(right))))

def sub(left, right):
    return add(left, tuple(-p for p in right))

def mul(left, right, F):
    """Low-to-high coefficients, Ore law Δ f=f Δ+F f′."""
    res=[Z]*(len(left)+len(right)-1)
    for i,ai in enumerate(left):
        if ai.is_zero: continue
        for j,bj in enumerate(right):
            term=bj
            for l in range(i+1):
                if term.is_zero: break
                res[i+j-l]+=comb(i,l)*ai*term
                term=F*term.diff()
    return tuple(res)

def recurrence(F,D,B):
    n=len(B)
    L=[(ONE,)]
    for i in range(n):
        M=(-B[i][i]-i*P(z)*D.diff(),ONE)
        ans=mul(M,L[i],F)
        for j in range(i):
            ans=sub(ans,mul((F*D**(i-j-1)*B[i][j],),L[j],F))
        assert len(ans)==i+2 and ans[-1]==ONE
        L.append(ans)
    return L

def construct_target(n,points,seed):
    """Arbitrary coefficient data with rational local roots and random remainders."""
    k=len(points)-1
    D=P(S.prod(z-s for s in points[1:])); F=P(z)*D
    rnd=Random(seed)
    special=[]
    for s in points:
        # Intentionally allow repetitions/resonances; the factor ordering must handle them.
        h = s*D.diff().eval(s) if s else 1
        rr=[S.Rational(rnd.randint(-5,5),rnd.choice([1,1,2,3]))*h for _ in range(n)]
        if n>=3: rr[1]=rr[0]
        special.append(S.Poly(S.prod(X-r for r in rr),X,domain=S.QQ))
    result=[]
    for q in range(n):
        r=interpolate(points,[t.nth(q) for t in special])
        free=k*(n-q)-F.degree()
        if free>=0: r+=F*P(sum(rnd.randint(-3,3)*z**i for i in range(free+1)))
        assert r.degree()<=k*(n-q)
        result.append(r)
    return F,D,tuple(result+[ONE])

def solve(points,F,D,T):
    n=len(T)-1; k=len(points)-1
    B=[[Z for _ in range(n)] for _ in range(n)]
    beta={}
    for s in points:
        h=s*D.diff().eval(s) if s else 1
        poly=S.Poly(sum(p.eval(s)*X**q for q,p in enumerate(T)),X,domain=S.QQ)
        roots=[r for r,m in poly.ground_roots().items() for _ in range(m)]
        assert len(roots)==n
        beta[s]=sorted(roots,key=lambda b:b/h,reverse=True)
    for i in range(n):
        B[i][i]=interpolate(points,[beta[s][i]-i*s*D.diff().eval(s) for s in points])
    assert all((a-b).rem(F).is_zero for a,b in zip(recurrence(F,D,B)[-1],T))
    for d in range(1,n):
        modulus=F*D**(d-1)
        old=recurrence(F,D,B)[-1]
        err=tuple(p.exquo(modulus) for p in sub(old,T))
        assert all(p.is_zero for p in err[n-d:])
        unknown_values=[]
        for s in points[1:]:
            h=s*D.diff().eval(s); br=beta[s]
            P_i=[S.Poly(S.prod(X-br[j]+d*h for j in range(i+d+1,n))
                        *S.prod(X-br[j] for j in range(i)),X,domain=S.QQ)
                 for i in range(n-d)]
            coefficient_matrix=S.Matrix([[p.nth(q) for p in P_i] for q in range(n-d)])
            values=coefficient_matrix.inv()*S.Matrix([p.eval(s) for p in err[:n-d]])
            unknown_values.append(values)
        for i in range(n-d):
            B[i+d][i]=interpolate(points[1:],[r[i] for r in unknown_values])
            assert B[i+d][i].degree()<=k-1
        assert all(p.rem(modulus*D).is_zero for p in sub(recurrence(F,D,B)[-1],T))
    assert recurrence(F,D,B)[-1]==T
    return B

def check_cycle(F,D,B):
    n=len(B)
    def action(v):
        result=[]
        for j in range(n):
            p=F*v[j].diff()+B[j][j]*v[j]
            if j: p+=D*v[j-1]
            p+=P(z)*sum((B[i][j]*v[i] for i in range(j+1,n)),Z)
            result.append(p)
        return result
    action_powers=[[ONE]+[Z]*(n-1)]
    for _ in range(n): action_powers.append(action(action_powers[-1]))
    for i,Li in enumerate(recurrence(F,D,B)):
        Li_e1=[sum((coef*action_powers[q][j] for q,coef in enumerate(Li)),Z)
               for j in range(n)]
        assert Li_e1==[D**i if i==j else Z for j in range(n)]

def check_scalar_bounds(n,k,F,T):
    result=(Z,)
    power=(ONE,)
    for q,coef in enumerate(T):
        result=add(result,tuple(coef*p for p in power))
        power=mul(power,(Z,F),ONE)  # Ore law in ∂ for this step.
    assert result[n]==F**n
    for q in range(n):
        assert result[q].exquo(F**q).degree()<=k*(n-q)

true=S.Matrix([[0,-3],[1,-2]]); printed=S.Matrix([[0,-2],[1,-3]])
assert true.charpoly(X).as_expr()==X**2+2*X+3
assert printed.charpoly(X).as_expr()==X**2+3*X+2
r=[S.Rational(1,2),1,S.Rational(3,2)]
assert r[2]-r[0]==1 and 1>0>-1
print('The two-point coefficient reversal and invalid unnormalized real-part ordering are witnessed exactly.')
for size,points,seed in [(1,[0,1,3],101),(2,[0,1,2],202),(3,[0,2],303),
                         (4,[0,1,3],404),(5,[0,-1,1,3],505)]:
    F,D,T=construct_target(size,points,seed)
    B=solve(points,F,D,T)
    check_cycle(F,D,B)
    check_scalar_bounds(size,len(points)-1,F,T)
    print(f'n={size}, k={len(points)-1}: all congruences, exact equality, cyclic action and Fuchs degree bounds verified.')
