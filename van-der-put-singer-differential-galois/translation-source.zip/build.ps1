﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Build-Tex($name) {
  for ($i=0; $i -lt 3; $i++) {
    & xelatex -halt-on-error -interaction=nonstopmode $name
    if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed for $name" }
  }
}
Push-Location 'contiguous-preview'
$env:TEXINPUTS = ".;../ch03-sec34;../ch03-sec34/figures;$($env:TEXINPUTS);"
Build-Tex 'linear-galois-cn.tex'
Pop-Location
if (Test-Path errata) {
  Push-Location errata
  Build-Tex 'errata-l-zh.tex'
  Build-Tex 'errata-l-en.tex'
  Pop-Location
}
