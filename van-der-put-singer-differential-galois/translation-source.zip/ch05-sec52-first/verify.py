"""Exact elementary checks supporting the §5.2 mathematical review."""
import sympy as s

# A rank-one regular singular point can have a pole in the given matrix yet be
# locally ordinary. This is the distinction used in the erratum to §5.2(2).
z,u=s.symbols('z u',nonzero=True)
m=s.symbols('m',integer=True)
Y=s.Function('Y')(z)
g=z**m
raw=s.diff(g*Y,z)-m/z*g*Y
assert s.simplify(raw/g)==s.diff(Y,z)
# The coefficient in u=1/z is -m/u and is removed by the inverse-power gauge.
assert s.simplify((m/z).subs(z,1/u)*s.diff(1/u,u)+m/u)==0
assert s.simplify(s.exp(2*s.pi*s.I*m))==1
assert s.simplify(s.exp(2*s.pi*s.I*s.Rational(1,2)))==-1
print('Rank one: integer residues are removable in both charts; residue 1/2 gives nontrivial monodromy.')

# A simple special case used to audit the proof of an infinite-order element:
# all eigenvalues 1 and a nonzero nilpotent part rule out finite order in char 0.
X=s.symbols('X'); k=s.symbols('k',positive=True,integer=True)
N=s.Matrix([[0,1,0],[0,0,1],[0,0,0]])
I=s.eye(3)
assert (I+N).charpoly(X).as_expr()==s.expand((X-1)**3)
assert N**3==s.zeros(3) and N!=s.zeros(3)
power=I+k*N+k*(k-1)*N**2/2
assert power[0,1]==k
print('The unipotent example has characteristic polynomial (X−1)^3, but its k-th power is nonidentity for all k>0.')
