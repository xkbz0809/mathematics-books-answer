"""Independently test existence of generating triples for each table row.

Use binary tetrahedral/octahedral unit quaternion models reduced into F_97
(the group size and closure are checked), and SL_2(F_5) for the binary
icosahedral group. This is not a test of equivalence of distinct triples
or Schwarz label equivalence.
"""
from fractions import Fraction as F
from itertools import product, combinations
from collections import Counter
from pathlib import Path

D=Path(__file__).resolve().parent
A=list(product((-1,1),repeat=4))
P=97
half=pow(2,-1,P)
prim=next(a for a in range(2,P) if pow(a,48,P)!=1 and pow(a,32,P)!=1)
def quat_groups(k):
    s=pow(prim,12,P)
    invsqrt=pow((s+pow(s,-1,P))%P,-1,P)
    g0=[tuple((sgn if x==j else 0)%P for x in range(4)) for j in range(4) for sgn in (-1,1)]
    g1=[tuple(sgn*half%P for sgn in row) for row in A]
    g2=[tuple((a*invsqrt if x==j else b*invsqrt if x==i else 0)%P for x in range(4))
        for i,j in combinations(range(4),2) for a,b in product((-1,1),repeat=2)]
    g=g0+g1+(g2 if k=='O' else [])
    def qm(x,y):
        a,b,c,d=x; e,f,g,h=y
        return tuple(u%P for u in (a*e-b*f-c*g-d*h,a*f+b*e+c*h-d*g,a*g-b*h+c*e+d*f,a*h+b*g-c*f+d*e))
    A2=(P-1,0,0,0); A1=(1,0,0,0)
    def qeligible(chi,pair):
        v=[F(x) for x in pair.split(',')]
        assert all((P-1)%i.denominator==0 for i in v)
        tr=sum(pow(prim,int((P-1)*i)%(P-1),P) for i in v)%P
        if k=='O' and chi=='5' and v[0].denominator==8: tr=-tr%P
        return [x for x in g if 2*x[0]%P==tr]
    return g,A1,qm,qeligible

def ico_group():
    g=[x for x in product(range(5),repeat=4) if (x[0]*x[3]-x[1]*x[2])%5==1]
    def mm(x,y):
        a,b,c,d=x; e,f,g,h=y
        return tuple(i%5 for i in (a*e+b*g,a*f+b*h,c*e+d*g,c*f+d*h))
    e=(1,0,0,1)
    def inv(x):return (x[3],-x[1]%5,-x[2]%5,x[0])
    def cc(x):return {mm(mm(q,x),inv(q)) for q in g}
    c5a,c5b=cc((1,1,0,1)),cc((1,2,0,1))
    assert len(c5a)==len(c5b)==12 and not c5a&c5b
    cm = lambda x:{tuple(-a%5 for a in v) for v in x}
    def eligible(chi,pair):
        e1,e2=sorted(F(v)%1 for v in pair.split(','))
        r=e1.denominator
        if r in (3,4,6):return [v for v in g if (v[0]+v[3])%5=={3:4,4:0,6:1}[r]]
        if r==5: q=(e1==F(2,5))
        elif r==10: q=(e1==F(1,10))
        else: raise AssertionError(r)
        c=c5a if (q==(chi=='2')) else c5b
        return c if r==5 else cm(c)
    return g,e,mm,eligible

def check(model,rows):
    G,e,m,el=model
    gg=set(G)
    assert len(G)==len(gg) and all(m(x,y) in gg for x in G for y in G)
    N=len(G)
    inv={x:next(q for q in G if m(q,x)==e) for x in G}
    def generates(x,y):
        found={e}
        todo=[e]
        for t in todo:
            for u in (m(t,x),m(t,y)):
                if u not in found:
                    todo.append(u); found.add(u)
        return len(found)==N
    for b,g,c,a,d,f,s,*mark in rows:
        X=el(c,a)
        Y=el(c,d); Z=set(el(c,f))
        assert any(inv[m(x,y)] in Z and generates(x,y) for x in X for y in Y),(b,c,a,d,f)

data={k:[] for k in 'TOI'}
for l in (D/'tables.tsv').read_text().splitlines():
    if l.startswith('#'):continue
    k,*row=l.split('|')
    data[k].append(row)
for k,group,n in [('T',quat_groups('T'),24),('O',quat_groups('O'),48),('I',ico_group(),120)]:
    assert len(group[0])==n
    check(group,data[k])
    print(k,n,len(data[k]),'rows admit generating product-one triple')
