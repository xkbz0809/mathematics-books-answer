# 《交换代数教程》中文翻译工程

原著：Gregor Kemper, *A Course in Commutative Algebra*, Graduate Texts in Mathematics 256, Springer, 2011.

翻译依据为原始 `Commutative Algebra.pdf`（248 页，SHA-256 见 `QA/source-identity.json`）。原始 PDF 保留在交付目录中，不含在本源码包内，也不是编译依赖。原文页码、编号、公式和论证为翻译依据。完整翻译与校对状态由项目 QA 记录决定，成功编译本身不表示全书已译完或数学内容已全部校对。

## 编译

需要 XeLaTeX、Biber、TeX Live 中的 Fandol 与 Computer Modern Unicode 字体，以及 Python 3。

```powershell
python -X utf8 tools/build.py full --clean
```

有 Bash 的环境可运行 `bash tools/build.sh full`。流程为 XeLaTeX 两轮、Biber、XeLaTeX 两轮；若工程生成 `.idx` 则额外运行 texindy。每轮原始日志和 JSON 编译报告保存在 `build/`。输出为 `main.pdf`。`--clean` 只清理本工程对应作业名的辅助文件。

`main.tex` 严格包含全部 14 章、前言、引言、原书习题选解、参考文献、符号表、原书主题索引和新增中英术语索引；任何输入缺失都会使编译失败。覆盖统计与检查范围以项目 QA 记录为准。

## 模板来源

2026-11-14 检查了 [MathTranslations 制作指南](https://mathtranslations.org/guide/) 并下载[当时指南所链接的模板](https://mathtranslations.org/static/catalog/mathtranslations-translation-template.3ea772c9d558.zip)。其类为 2026-09-11 的 ctexart 版本，并已在未经改动的状态下完成基线编译。书籍工程采用本地已有 ctexbook 改编版的版面、字体、术语系统和封面，去除了先前书籍专用的连续节编号，在 `preamble.tex` 中按本书建立章内共享定理编号、章内独立习题编号。

本源码包已经包含所需的 `mathtranslation.cls`、`logo.pdf`、全部插图和构建程序，可独立编译。原始下载包、改编前类文件、基线及冒烟测试工程作为工作区的 QA 证据另行保存在 `template-original/` 与 `build/`；正式源码压缩包不混入这些无关示例和辅助文件。

正文与公式通过 `obj:X.Y`、`eq:X.Y`、`ex:X.Y`、`fig:X.Y`、`sec:X.Y`、`ch:X` 交叉引用。`\sourcepage{n}` 标记原书印刷页 `n`，供原书页码引用使用。原书主题索引与新增中英术语索引分开保留。

## 源码包范围

本包可独立编译。`chapters/` 为译文，`images/` 与 `figures/` 为编译所需图像；`QA/` 保存结构覆盖及检查记录。原书页码链接指向译文的原页标记，其位置在原页边界附近，并不表示中英文逐页同版。

本译稿为 AI 辅助翻译与自查稿。构建、编号和版式检查不等于全书经过独立数学审校；原书疑点沿原文保留，见随附《翻译与核验说明》。
