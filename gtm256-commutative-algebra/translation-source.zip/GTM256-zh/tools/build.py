"""Reproducible full XeLaTeX/Biber build; no external network needed."""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
def executable(name):
    located = shutil.which(name)
    if located:
        return located
    local = Path('D:/texlive/2026/bin/windows') / (name + '.exe')
    if local.exists():
        return str(local)
    raise RuntimeError(f'Required executable missing: {name}')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode', nargs='?', choices=['full'], default='full')
    p.add_argument('--project', type=Path, default=ROOT)
    p.add_argument('--job', default='main')
    p.add_argument('--clean', action='store_true')
    a=p.parse_args(); root=a.project.resolve(); job=a.job
    logs=root/'build'; logs.mkdir(exist_ok=True)
    if a.clean:
        for ext in ['aux','toc','out','bbl','bcf','blg','run.xml','idx','ind','ilg']:
            f=root/f'{job}.{ext}'
            if f.exists(): f.unlink()
    env=os.environ.copy()
    tex=executable('xelatex'); biber=executable('biber')
    steps=[]
    def run(label,args,extra_env=None):
        e=env.copy(); e.update(extra_env or {})
        r=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=e)
        (logs/f'{job}-{label}.log').write_bytes(r.stdout)
        steps.append({'step':label,'returncode':r.returncode,'log':f'build/{job}-{label}.log'})
        print(label,r.returncode,flush=True)
        if r.returncode:
            (logs/f'{job}-build-report.json').write_text(json.dumps({'success':False,'steps':steps},ensure_ascii=False,indent=2),encoding='utf8')
            print(r.stdout.decode('utf8','replace')[-4000:])
            raise SystemExit(r.returncode)
    texargs=[tex,'-interaction=nonstopmode','-halt-on-error','-file-line-error',f'{job}.tex']
    run('xelatex-1',texargs); run('xelatex-2',texargs)
    if (root/f'{job}.bcf').exists(): run('biber',[biber,job])
    if (root/f'{job}.idx').exists():
        run('texindy',[executable('texindy'),'-M','texindy','-I','xelatex','-C','utf8',f'{job}.idx'],{'LC_ALL':'C','LANG':'C','LC_CTYPE':'C'})
    run('xelatex-3',texargs); run('xelatex-4',texargs)
    text=(root/f'{job}.log').read_text(encoding='utf8',errors='replace')
    issues={
      'undefined_references':re.findall(r'^.*(?:Reference|Citation).*undefined.*$',text,re.M),
      'missing_characters':re.findall(r'^Missing character:.*$',text,re.M),
      'font_warnings':re.findall(r'^LaTeX Font Warning:.*$',text,re.M),
      'overfull_boxes':re.findall(r'^Overfull .*$',text,re.M),
      'pending_inputs':re.findall(r'^TRANSLATION-PENDING:.*$',text,re.M),
    }
    pdf=root/f'{job}.pdf'
    report={'success':True,'steps':steps,'issues':issues,'pdf':pdf.name,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
    (logs/f'{job}-build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({k:len(v) for k,v in issues.items()},ensure_ascii=False))
    return 0
if __name__=='__main__': sys.exit(main())
