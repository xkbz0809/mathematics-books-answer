# GTM 256 项目术语表

依据：原书术语的定义与上下文；2026-11-14 查阅 MathTranslations 指南及术语页面。下列是项目统一译法，不声称全由网站逐项核准。

| English | 中文 |
|---|---|
| affine variety | 仿射簇 |
| affine algebra | 仿射代数 |
| integral domain | 整环 |
| reduced | 约化 |
| normal | 正规 |
| regular | 正则 |
| localization | 局部化 |
| integral closure | 整闭包 |
| normalization | 正规化 |
| Noether normalization | Noether 正规化 |
| Noetherian / Artinian | Noether / Artin |
| morphism | 态射 |
| transcendence degree | 超越次数 |
| generic freeness | 泛自由性 |
| fiber | 纤维 |
| constructible set | 可构造集 |
| leading monomial / term / coefficient / ideal | 首单项式 / 首项 / 首项系数 / 首项理想 |
| monomial ordering | 单项式序 |
| normal form | 正规形 |
| elimination ideal / ordering | 消去理想 / 消去序 |
| graded reverse lexicographic ordering | 分次逆字典序 |
| associated graded ring | 伴随分次环 |
| residue field | 剩余域 |
| discrete valuation ring | 离散赋值环 |
| fractional ideal | 分式理想 |
| ideal class group | 理想类群 |
| syzygy | 合冲 |

专名原则上保留拉丁拼写，Gröbner 采用带变音符号的原拼写。
