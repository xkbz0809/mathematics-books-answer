\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{mathtranslation}[2026/11/14 GTM256 book adaptation of official 2026/09/11 template]
\LoadClass[UTF8,12pt,fontset=none,openany,oneside]{ctexbook}
% ---------- 页面、字体与数学 ----------
\RequirePackage[paper=a4paper,left=2.5cm,right=2.5cm,top=2.8cm,bottom=2.8cm]{geometry}
\RequirePackage{fontspec}
\RequirePackage{xeCJK}
\RequirePackage{amsmath,amsthm,amssymb,mathrsfs,mathtools}
\RequirePackage{graphicx,tikz,tikz-cd}
\graphicspath{{graphics/}}
\RequirePackage{array,booktabs,longtable}
\RequirePackage{etoolbox}
\RequirePackage[dvipsnames]{xcolor}
\RequirePackage[
    backend=biber,
    style=numeric,
    sorting=none,
    maxalphanames=2,
    maxbibnames=99,
    giveninits=true
]{biblatex}
\RequirePackage[
    colorlinks=true,
    bookmarksnumbered=true,
    linkcolor=MidnightBlue,
    citecolor=BrickRed, % 文献引用使用砖红色，与普通交叉引用区分
    urlcolor=MidnightBlue,
    linktoc=all
]{hyperref}

% 与模板内置 logo.pdf 的 PDF 版本保持一致，避免 xdvipdfmx 的版本警告。
\AtBeginDocument{\special{pdf:minorversion 7}}

% 英文：Computer Modern Unicode Serif
\setmainfont{cmunrm.otf}[
  BoldFont=cmunbx.otf,
  ItalicFont=cmunti.otf,
  BoldItalicFont=cmunbi.otf
]

% 中文：正文宋体；专用术语楷体；定理类环境仿宋
% 使用 TeX Live 自带 Fandol，避免依赖 macOS / Windows 专有字体.
\setCJKmainfont{FandolSong-Regular.otf}[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolKai-Regular.otf]
\newCJKfontfamily\songfont{FandolSong-Regular.otf}[BoldFont=FandolSong-Bold.otf,ItalicFont=FandolKai-Regular.otf]
\newCJKfontfamily\termfont{FandolKai-Regular.otf}
\newCJKfontfamily\theoremfont[AutoFakeBold=2,ItalicFont=FandolKai-Regular.otf]{FandolFang-Regular.otf}
\setCJKsansfont{FandolHei-Regular.otf}[BoldFont=FandolHei-Bold.otf]
\setCJKmonofont{FandolFang-Regular.otf}

\pagestyle{plain}
\setlength{\parindent}{2em}
\setlength{\parskip}{0pt}
\linespread{1.16}

% ---------- 译本元信息：实际使用时只需修改这里 ----------
% 封面标题：中文译名 + 原书名
% 右下角只显示：版次 · 出版社 · 年份 / 译者 翻译及重排 / 使用模型 / 更新时间
\newcommand{\BookTitleCN}{代数学}
\newcommand{\BookTitleEN}{Algebra}
\newcommand{\OriginalAuthor}{Serge Lang}
\newcommand{\OriginalEdition}{3rd edition}
\newcommand{\OriginalPublisher}{Springer}
\newcommand{\OriginalYear}{2002}
\newcommand{\Translator}{数译}
\newcommand{\ModelUsed}{GPT-5.6 Sol}
\newcommand{\TranslationDate}{17 Aug 2026}


% ================================================================
%                         封面
% ================================================================
\newcommand{\makecover}{%
  \hypersetup{pageanchor=false}%
  \begin{titlepage}
    \thispagestyle{empty}
    \flushleft

    \rule{\textwidth}{1.2pt} \\[0.1cm]
    \rule{\textwidth}{0.8pt} \\[1.5cm]

    {\fontsize{36pt}{46pt}\selectfont \bfseries \BookTitleCN} \\[0.8cm]
    {\fontsize{23pt}{29pt}\selectfont \textit{\BookTitleEN}} \\[1.5cm]

    \rule{\textwidth}{0.6pt} \\[2cm]

    {\Huge \textsc{\OriginalAuthor}} \\[6cm]

    \vfill

    \noindent
    \begin{minipage}[b]{0.35\textwidth}
      \raggedright
      \includegraphics[width=4.8cm]{logo.pdf}
    \end{minipage}
    \hfill
    \begin{minipage}[b]{0.61\textwidth}
      \raggedleft
      {\small \OriginalEdition · \OriginalPublisher · \OriginalYear} \\[0.25cm]
      {\normalsize \Translator\ 翻译及重排} \\[0.25cm]
      {\small Model: \ModelUsed} \\
      {\small Updated: \TranslationDate}
    \end{minipage}

    \vspace*{1cm}
  \end{titlepage}%
  \hypersetup{pageanchor=true}%
}

% ================================================================
%                         术语系统
% ================================================================
% \newterm{唯一键}{中文术语}{英文术语}
% 用于“新概念第一次出现”的位置.
% 示例：\newterm{scheme}{概型}{scheme}
% 输出：楷体“概型”（scheme）
% 同时自动记录术语索引中的中文、英文与第一次出现页码.
%
% 后续再出现“概型”时，直接正常输入“概型”即可，不要再次调用 \newterm.
% \termcn{...} 仅用于少数确有必要的术语强调，不自动进入索引.

\newcommand{\termcn}[1]{{\termfont #1}}


\newcommand{\MTTermList}{}
\newcommand{\MTRegisterTerm}[3]{%
  \g@addto@macro\MTTermList{\MTTermRow{#1}{#2}{#3}}%
}
\newcommand{\MTTermRow}[3]{%
  {\termfont #1} & #2 & \hyperref[#3]{\pageref*{#3}} \\
}

\newcommand{\newterm}[3]{%
  \@ifundefined{MT@seen@#1}{%
    \expandafter\gdef\csname MT@seen@#1\endcsname{}%
    \phantomsection
    \label{term:#1}%
    \protected@write\@auxout{}{%
      \string\MTRegisterTerm{\unexpanded{#2}}{\unexpanded{#3}}{term:#1}%
    }%
  }{}%
  {\termfont #2}（#3）%
}


% 文末自动生成术语索引.
% 表中顺序就是术语在正文中第一次出现的顺序.
\newcommand{\printterminology}{%
  \clearpage
  \phantomsection

  \MTunnumberedchapter{术语索引}

  \vspace{0.5cm}
  \begingroup
  \renewcommand{\arraystretch}{1.28}
  \begin{longtable}{>{\raggedright\arraybackslash}p{0.28\textwidth}>{\raggedright\arraybackslash}p{0.49\textwidth}>{\centering\arraybackslash}p{0.12\textwidth}}
    \toprule
    \textbf{中文术语} & \textbf{英文术语} & \textbf{页码} \\
    \midrule
    \endfirsthead
    \toprule
    \textbf{中文术语} & \textbf{英文术语} & \textbf{页码} \\
    \midrule
    \endhead
    \MTTermList
    \bottomrule
  \end{longtable}
  \endgroup
}

\newtheoremstyle{mtfang}%
  {6pt}{6pt}% 上下间距
  {\theoremfont}% 正文字体
  {0pt}% 缩进
  {\songfont\bfseries}% 标题字体统一为宋体粗体，与“例”“证明”一致
  {.}% 标题后的英文句点
  {0.5em}% 标题与正文间距
  {}%

\newtheoremstyle{mtsong}%
  {6pt}{6pt}%
  {\songfont}%
  {0pt}%
  {\songfont\bfseries}%
  {.}%
  {0.5em}%
  {}%

% ---------- proof 样式：宋体正文，以方块结束 ----------

\renewcommand{\proofname}{证明}
\renewenvironment{proof}[1][\proofname]{\par
  \pushQED{\qed}%
  \normalfont\songfont
  \topsep6\p@\@plus6\p@\relax
  \trivlist
  % 保留 amsthm 原来的标签位置；仅把证明正文向全角冒号靠近。
  \item[\hskip\labelsep\normalfont\songfont\bfseries #1：]\hspace*{-0.50em}\ignorespaces
}{%
  \popQED\endtrivlist\@endpefalse
}

\renewcommand{\qedsymbol}{\ensuremath{\square}}

% Public book interface. Source-specific counters are in preamble.tex.
\newcommand{\MTunnumberedchapter}[1]{\chapter*{#1}\addcontentsline{toc}{chapter}{#1}}
\newcommand{\makecontents}{\tableofcontents\clearpage}
\newcommand{\makebibliography}{\MTunnumberedchapter{参考文献}\printbibliography[heading=none]}
\setlength{\bibitemsep}{0.5\baselineskip}
\RequirePackage{enumitem}
\endinput


