# GTM256 · 交换代数教程习题解答源码

本仓库版收录 144 道中文题面与 125 道新编解答。原书书后 19 道选解处保留题号、题面与指向原书的提示。请使用带中文支持及 Fandol、CM Unicode 字体的 TeX Live，以及 Python 3。在源码目录运行 python -X utf8 tools/build.py full --clean。需要索引处理时请安装 texindy。
