# 书末参考文献第二轮证据复核

Sidney A. Morris，2024-08-06 版，原书书目 [1]–[429] 中已提出勘误的85条。逐条按原题名、作者、卷期、页码查阅原刊目录、馆藏版本或著者记录，区分初版、重印、先行发表和引文出处。对照依据见下表。

**结论**　85条原认定的具体错误均成立。79条沿用原有字段。EBB14、EBF04 同条增改版次或出版者，EBB29 补核作者署名，EBB09 建议限定为俄文原文；EBB07、EBF41 各补正文第二处定位。撤回0项，待核0项。EBF03、EBF56 是上一轮已撤号，未计入本轮85。EBB15 的六位年款是确定错误，两种合理的年号均附来源，不能将两种目录著录合并为同一种事实。EBB07、EBF41 书目与正文重出，已交书目主编统一。

**两处需要连带改正的刊记**

- EBB14，[366]。原书漏署 J. A. Thorpe；亦把 1967 初版年与 Springer 重印出版商拼在一起。1967年《Notices of the AMS》刊有 Scott, Foresman 的当期原广告。Springer 版目录编目页说明重印 Scott, Foresman 版；标为1976的同版书目和 MAA 著录可以佐证。建议保持 Springer-Verlag, New York 出版者，并把这一版列为1976；保留1967为 Scott, Foresman 初版年。[1967年同期广告](https://www.ams.org/journals/notices/196708/196708FullIssue.pdf)；[Springer 重印本版权页](https://unina2.on-line.it/sebina/repository/catalogazione/documenti/Singer%2C%20Thorpe%20-%20Lecture%20notes%20on%20elementary%20topology%20and%20geometry.pdf)。
- EBF04，[18]。1984英文版共同署名 Arhangel’skii、Ponomarev；D. Reidel 在 Dordrecht、Boston 出版，Kluwer Boston 为美加销售发行人。在展平印记时将 Kluwer 当成该版唯一出版者会丢失两家的角色。[1984版馆藏著录](https://ci.nii.ac.jp/ncid/BA00345119)。

**说明性增补**　EBB09 所引的 16(1)，61–71（1964）为俄文原文。刊名的英文译法可用 Ukrainian Mathematical Journal。另一篇 1995 年译本在 *International Journal of Bifurcation and Chaos* 5，1263–1273；此前修改的英文刊名不应暗示1964年卷页就是英译的出处。[原刊的历史回顾，参考文献分列两版](https://umj.imath.kiev.ua/index.php/umj/article/view/7641)。

| ID | 原书书目号 | 判定 | 独立核查及证据 |
|---|---|---|---|
|EBB01|[1]|确认|卷首页年款与 DOI 中的卷年相符，Abel 文在第4卷131–156页。 [核查来源](https://doi.org/10.1515/crll.1829.4.131)|
|EBF01|[5]|确认|1969年原书与1982年芝加哥重印本是同一作品的不同出版记录；原条的出版者配错了年款。 [核查来源](https://www.math.uchicago.edu/~may/PAPERS/70.pdf)|
|EBF02|[11]|确认|波兰数学研究所原刊同时列 Fredric D. Ancel 和 Tadeusz Dobrowolski。 [核查来源](https://www.impan.pl/en/publishing-house/journals-and-series/studia-mathematica/all/109/3/108416/closed-subgroups-in-banach-spaces)|
|EBF04|[18]|确认、补充字段|1984英文版题名页有两位作者；该版出版商 D. Reidel，Kluwer Boston 仅负责美加销售发行。应同时区分两种责任。 [核查来源](https://ci.nii.ac.jp/ncid/BA00345119)|
|EBF05|[33]|确认|出版社与 MAA 的同一对作者题名为 An Introduction to Differential Manifolds；原题名属于另一条论文。 [核查来源](https://doi.org/10.1142/p285)|
|EBF06|[36]|确认|Kluwer/Springer 原书完整主标题区分闭集与闭凸集，Closed 出现两次。 [核查来源](https://link.springer.com/book/10.1007/978-94-015-8149-3)|
|EBF07|[37]|确认|1995年著作的书名还列有 Shape 和 Material，三者都是并列名词。 [核查来源](https://link.springer.com/book/10.1007/978-3-662-03115-5)|
|EBF08|[38]|确认|Springer 的2003年出版页清楚列出 Bendsøe 与 Sigmund；主标题为 Topology Optimization。 [核查来源](https://link.springer.com/book/10.1007/978-3-662-05086-6)|
|EBF09|[40]|确认|以卷101页161锁定1929原文，题名用 fractional，和后来常用术语 fractal 有别。 [核查来源](https://link.springer.com/article/10.1007/BF01454831)|
|EBF10|[42]|确认|AMS 的英文图书与 MAA 书评均列2006；其他语种出版年不能移给这一本。 [核查来源](https://www.ams.org/books/stml/035/stml035-endmatter.pdf)|
|EBF11|[48]|确认|1999年明确题为 Chemical Topology 的目录列 Introduction and Fundamentals，与其中收录章节的作者自引一致。另有相似题名 Complexity in Chemistry，不作证据。 [核查来源](https://ci.nii.ac.jp/ncid/BA43155465)|
|EBF12|[49]|确认|1960 年 Princeton Annals 系列第46卷题名用单数 Seminar。 [核查来源](https://www.jstor.org/stable/j.ctt1bd6jxd)|
|EBF13|[54]|确认|按 Braun、Griebel 和 DOI 交叉定位，该期刊当时用单数 Constructive Approximation。 [核查来源](https://doi.org/10.1007/s00365-009-9054-2)|
|EBB02|[57]|确认|直接核 AMS 原文页眉，列 Bruno Brosowski 与 Frank Deutsch，标 1981 年一月。 [核查来源](https://doi.org/10.1090/S0002-9939-1981-0589143-8)|
|EBF14|[63]|确认|同一1988年第二版分英国 Ellis Horwood 与美国 Halsted Press；Halstead 拼写有误。 [核查来源](https://ci.nii.ac.jp/ncid/BA05088432)|
|EBF15|[65]|确认|UCF 的学生学位论文库保存论文和完整题名，Implementation 与 Applications 中间有 in。 [核查来源](https://stars.library.ucf.edu/etd/3689/)|
|EBF16|[67]|确认|分别核 Cardano 的1545年初版、后来版本的增补、Witmer 译本及1993年 Dover 重印；原条 1565 对不上译者所据版本。 [核查来源](https://obnb.uk/p8742387-ars-magna-or-the-rules-of-algebra)|
|EBF17|[71]|确认|以 Numdam 原文卷首核法语重读符号，文中两处 ˊ 不应当作撇号使用。 [核查来源](https://www.numdam.org/item/10.24033/asens.943.pdf)|
|EBF18|[73]|确认|Springer 对 LNM 1667 同时列书名、作者、1997版权/卷年。 [核查来源](https://link.springer.com/book/10.1007/BFb0112511)|
|EBF19|[92]|确认|馆藏两套印记 Ellis Horwood、Halsted 的同书1989版均列 Cordier 与 Porter。 [核查来源](https://ci.nii.ac.jp/author/DA03354611)|
|EBF20|[93]|确认|核作者自己的文章稿与对应期目录，Eisenstein Criterion 前无所有格，Schönemann 的 -ne- 不可删除。 [核查来源](https://dacox.people.amherst.edu/normat.pdf)|
|EBF21|[107]|确认|Springer 的责任者栏列 Dikranjan 和 Tholen，所著为书而非论文集。 [核查来源](https://link.springer.com/book/10.1007/978-94-015-8400-5)|
|EBF22|[109]|确认|农业与国际科技目录收录该书的三位作者，Ivan Gutman 在第二位。 [核查来源](https://agris.fao.org/search/en/providers/122535/records/65ddfe9563b8185d9ca66dc5)|
|EBF23|[110]|确认|Springer 书名以 Categories, Bundles 开头，二者不是单一词组。 [核查来源](https://link.springer.com/book/10.1007/978-94-015-7776-2)|
|EBF24|[111]|确认|书页署名 C. T. J. Dodson、P. E. Parker；和前一条 Dodson 所著书区分。 [核查来源](https://link.springer.com/book/9780792342922)|
|EBF25|[114]|确认|Smithsonian 馆藏的原书题名为 Their History and Solution。 [核查来源](https://americanhistory.si.edu/collections/object/nmah_1347179)|
|EBF26|[115]|确认|作者保藏的原刊首页已印第57卷、第195期、1991年7月、387–401页。 [核查来源](https://site.uvm.edu/ddummit/files/2021/04/Solving_Solvable_Quintics__Math_Comp_57_no195_1991__pp_387_401.pdf)|
|EBF27|[122]|确认|1967年本的同时期评论列 James Eells, Jr.，证明姓氏有两个 l；保留原条简署名也可。 [核查来源](https://ci.nii.ac.jp/author/DA0123470X?l=en)|
|EBF28|[132]|确认|在 MathWorld 本条推荐引文取作者自署 Eric W. Weisstein；并非相近姓名 Weinstein。 [核查来源](https://mathworld.wolfram.com/AxiomofChoice.html)|
|EBF29|[133]|确认|同版题名和原出版广告均为 Ionescu Tulcea；排除形近的 Tulceac。 [核查来源](https://ci.nii.ac.jp/ncid/BA06866952)|
|EBF30|[139]|确认|Cambridge 的正题只指一个 Martin’s Axiom；保留单数。 [核查来源](https://www.cambridge.org/core/books/consequences-of-martins-axiom/95D39CA5BC839C5E93EB202C5D32ADEF)|
|EBF31|[140]|确认|核1964年纽约初版，以 Harper & Row 为出版者。 [核查来源](https://stacks.math.columbia.edu/bibliography/Freyd)|
|EBF32|[163]|确认|1987年 Wiley 版列 Gross 与 Tucker，同题后出的其他印本未影响首版共同署名。 [核查来源](https://www.iri.upc.edu/people/thomas/Collection/details/42828.html)|
|EBF33|[169]|确认|会议是1836年8月，所引报告的封面/资料说明给出1837年出版。标题的 recently 与末词 degrees 都能在原始题头找到。 [核查来源](https://www.maths.tcd.ie/pub/HistMath/People/Hamilton/Jerrard/Jerrard.pdf)|
|EBF34|[172]|确认|Hausdorff Edition 的作品目录给出 ä、ß、大写 Maß 及末页179。 [核查来源](https://www.hausdorff-edition.de/wp/?page_id=4)|
|EBF35|[184]|确认|英国书目与1990年2月 LMS 当期的 Oxford/Clarendon 广告一致，均为1989。 [核查来源](https://www.lms.ac.uk/sites/default/files/inline-files/169%20-%20Feb%201990.pdf)|
|EBF36|[186]|确认|Cambridge 提供1967平装版权页，明确列 P. J. Hilton 与 S. Wylie；勿拿精装早年款推翻1967年。 [核查来源](https://assets.cambridge.org/97805210/94221/frontmatter/9780521094221_frontmatter.pdf)|
|EBF37|[193]|确认|以唯一 DOI 定位 Hofmann 合著文章，合著者 Jimmie Don Lawson 原用 ie。在线先发在2019年，不能仅拿2020卷年去否定2019。 [核查来源](https://doi.org/10.1007/s00233-019-10068-3)|
|EBF38|[196]|确认|核 Hornik 的实际原刊页面，论文从251页续至257页。 [核查来源](https://web.njit.edu/~usman/courses/cs677/hornik-nn-1991.pdf)|
|EBF39|[199]|确认|AMS 图书详情与系列号59对应1998年，不与后来电子化日期混同。 [核查来源](https://doi.org/10.1090/surv/059)|
|EBF40|[207]|确认|Princeton 的责任者为 Witold Hurewicz 与 Henry Wallman，Witold 仅属首位作者。 [核查来源](https://press.princeton.edu/books/hardcover/9780691653686/dimension-theory)|
|EBF41|[213]|确认、补充字段|书目[213]与附录三第465页均涉及 David Assaf IV、Steve Gadbois 的同一期通讯，Assaf 的 ss 有权威索引旁证，保留同一稳定编号。 [核查来源](https://doi.org/10.1080/00029890.1992.11995945)|
|EBF42|[223]|确认|以 Kahane 的书辨认德国出版地 Heidelberg；原书在城市拼写中插入分号。 [核查来源](https://link.springer.com/book/10.1007/978-3-662-59158-1)|
|EBF43|[226]|确认|按著者、书名、年份确定 Birkhäuser 的标准出版社拼写。 [核查来源](https://link.springer.com/book/10.1007/978-0-8176-4932-6)|
|EBF44|[227]|确认|核 Kaplan 的第一篇 Infinite products 属 Duke 卷15（1948），页649–658；和后续篇成对核定。 [核查来源](https://doi.org/10.1215/S0012-7094-48-01557-9)|
|EBF45|[228]|确认|核 Kaplan 的第二篇 Direct and inverse sequences 属 Duke 卷17（1950），页419–435；旧记录对换了两篇页码。 [核查来源](https://doi.org/10.1215/S0012-7094-50-01737-6)|
|EBF46|[229]|确认|大学馆藏的1974年修订本载 University of Chicago Press, Chicago，和以前的出版机构区分。 [核查来源](https://iucat.iu.edu/iusb/3916558)|
|EBF47|[230]|确认|Chicago 出版的第二版版权1972，1995年2月发行同版平装。原年可留，出版地 Chicago。 [核查来源](https://press.uchicago.edu/ucp/books/book/chicago/F/bo27002624.html)|
|EBF48|[234]|确认|直接检印原条地址的 scheme 出现两次，句法错误可独立核定；删一处不保证短链接永久可用。 [核查来源](https://zapatopi.net/kelvin/papers/the_tides.html)|
|EBF49|[238]|确认|法国国家图书馆和美国大学馆藏的题名责任者均为 R. Bruce King。 [核查来源](https://catalogue.bnf.fr/ark:/12148/cb37399240p)|
|EBF50|[245]|确认|Springer 原刊德文正题使用 Weierstraßschen Approximationssatzes，校正原书多处拼写。 [核查来源](https://link.springer.com/article/10.1007/BF01589203)|
|EBF51|[246]|确认|Springer 原会议录的章节题名与 LNCS 系列名分属不同著录层次，二者均可查验。 [核查来源](https://link.springer.com/chapter/10.1007/3-540-46084-5_77)|
|EBF52|[249]|确认|1961年英文版题名责任页出版社为 Pergamon，末字母 n 只一个。 [核查来源](https://books.google.com/books?id=RDJPAQAAIAAJ)|
|EBB03|[258]|确认|汉堡大学第19卷目录列出该文；应保留德文变音符、projektiver 与 Gruppen。 [核查来源](https://abhandlungen.math.uni-hamburg.de/archiv.php?vol=19)|
|EBF53|[260]|确认|以1963年70卷36–41页找原文，可直接确认标准刊名，原条误重复 Math.。 [核查来源](https://doi.org/10.1080/00029890.1963.11990039)|
|EBB04|[273]|确认|文摘索引同时给出 Science 卷156、期3775和起页636。 [核查来源](https://doi.org/10.1126/science.156.3775.636)|
|EBF54|[287]|确认|按1993年专著定位数学家/物理学家 Mikhail I. Monastyrsky，避免将此前拼写当成常见转写。 [核查来源](https://link.springer.com/book/10.1007/978-1-4899-2403-2)|
|EBF55|[298]|确认|DOI 对应 Morris 的 Bulletin 第58卷文章，正式卷年2021年，页107–118；早期在线日期在2020年，原条的2000不合两者。 [核查来源](https://doi.org/10.1090/bull/1698)|
|EBF57|[311]|确认|国会图书馆记录的 Academic Press 1983年英文版同时署 Nash 和 Sen。 [核查来源](https://ndlsearch.ndl.go.jp/books/R100000002-I000006283131)|
|EBF58|[313]|确认|EMS 明列纸本 ISBN 和2011-10-20出版日，修正早一年著录。 [核查来源](https://ems.press/books/hem/102/contents)|
|EBB06|[326]|确认|所收入论文的主编在自己的出版清单中标明 Ed.，卷的出版者写 Academic Press。 [核查来源](https://cse.usf.edu/~lespiegl/gm.htm)|
|EBB07|[329]|确认、补充字段|核 Dover 重印本记录，作者之姓 Poincaré 末音节用尖音符。正文第462页书目号[329]前也印错。 [核查来源](https://openlibrary.org/books/OL7639196M/Science_and_Method)|
|EBB29|[351]|确认、补充字段|核短报及[著者完整著作目录](https://celebratio.org/Rudin_Mary/article/236/)，题名中的 X 与 I 都是数学变量；作者为 Mary Ellen Rudin，两个名字间无连字符。不要误引同名的长文。 [核查来源](https://doi.org/10.1090/S0002-9904-1971-12702-7)|
|EBB08|[353]|确认|馆藏明确把 1976、third edition 和 ISBN 007054235X 相联；另外的 1964 年版本是第二版。 [核查来源](https://openlibrary.org/isbn/007054235X)|
|EBB09|[357]|确认、补充字段|作者及原刊把卷16第1期61–71页归入1964年俄文论文；Ukrainian 的拼写正确。建议补明俄文，以区别1995年另刊的英译。 [核查来源](https://umj.imath.kiev.ua/index.php/umj/article/view/8026)|
|EBB10|[358]|确认|在同卷两篇同名开头的论文间按93–105页定位，第二篇自题 Fortsetzung。 [核查来源](https://doi.org/10.1515/crll.1846.32.93)|
|EBB11|[359]|确认|作者出版清单分别列出 Doklady 的俄文页1332–1336和英文页290–294。 [核查来源](https://www.math.sci.ehime-u.ac.jp/~dima/en/publications.html)|
|EBB12|[360]|确认|Shelah 所属大学的出版档案将该章列入 Studies in Logic 第95卷、373–394页。 [核查来源](https://doi.org/10.1016/S0049-237X(08)71346-6)|
|EBB13|[364]|确认|1963年版书与馆藏责任者均写 George F. Simmons；F 是 Finlay。 [核查来源](https://obnb.uk/p6999903-introduction-to-topology-and-modern-analysis)|
|EBB14|[366]|确认、补充字段|补列 J. A. Thorpe；同一原条还混用旧版版权年与重印出版社。首版 Scott, Foresman（1967），Springer-Verlag 美国重印版（1976）。 [核查来源](https://old.maa.org/press/maa-reviews/lecture-notes-on-elementary-topology-and-geometry)|
|EBB15|[378]|确认|原六位年款确错，Steenrod 为编辑。1968见两卷实物及后来的引用，1969见出版社目录；可保留有归属说明的两年，不把其中一年描述为唯一可信。 [核查来源](https://www.ams.org/journals/notices/197508/197508FullIssue.pdf)|
|EBB16|[382]|确认|Springer 卷目与目录正文支持 Hilbert’s 13th problem 与书系 Lecture Notes in Mathematics。 [核查来源](https://doi.org/10.1007/BFb0090046)|
|EBB17|[384]|确认|Profile Books 的原版目录把完整主标题印为 Significant Figures。 [核查来源](https://profilebooks.com/work/significant-figures/)|
|EBB18|[385]|确认|1995年第二版与同一版的书评都以 Combinatorial Group Theory 收尾。 [核查来源](https://old.maa.org/press/maa-reviews/classical-topology-and-combinatorial-group-theory)|
|EBB19|[387]|确认|第21卷第4期是1948年3–4月号，书目指第一篇167–184页。 [核查来源](https://www.jstor.org/stable/i351873)|
|EBB20|[389]|确认|作者主站的论文首末页及 Springer 期次相符，卷16期4页341–355。 [核查来源](https://doi.org/10.1007/s12045-011-0040-1)|
|EBB21|[391]|确认|AMS 题名页以作者惯用署名 Terence Tao 出版此书。 [核查来源](https://doi.org/10.1090/gsm/153)|
|EBB22|[398]|确认|波兰数学研究所的本刊目录及平行版署名均为 Toruńczyk。 [核查来源](https://doi.org/10.4064/fm-111-3-247-262)|
|EBB23|[400]|确认|Elsevier 卷43首页给出正题、复题，无原书加在卷名开头的冠词。 [核查来源](https://shop.elsevier.com/books/infinite-dimensional-topology/van-mill/978-0-444-87133-6)|
|EBB24|[411]|确认|Szeged 的原刊档案给出卷1和页199–208，两处信息同时匹配。 [核查来源](https://acta.bibl.u-szeged.hu/13294/)|
|EBB25|[419]|确认|按书名锁定 W. A. Benjamin 1968 年的微分拓扑入门书，作者 Andrew H. Wallace。 [核查来源](https://ci.nii.ac.jp/ncid/BA07615277)|
|EBB26|[420]|确认|1938年 Annals 卷39的作者及德累斯顿人名规范档都是 Henry Wallman。 [核查来源](https://katalog.slub-dresden.de/?tx_find_find%5Bq%5D%5Bauthor%5D=Wallman%2C+Henry)|
|EBB27|[424]|确认|查合著论文的独立著录，F. Peter 居首；不要因定理通常随口称 Peter–Weyl 而直接决定。 [核查来源](https://doi.org/10.1007/s00031-025-09919-x)|
|EBB28|[427]|确认|牛津出版社该书页列发布日期 1998-10-01，作者、书名均和原条吻合。 [核查来源](https://academic.oup.com/book/53384)|
|EBB05|[429]|确认|刊载该文的 Monthly 第82卷第10期按 Li、Yorke 顺序署名。 [核查来源](https://doi.org/10.1080/00029890.1975.11994008)|

**未计入的撤号**　[16] 的 1995 年12月实际发行与 ©1996 可以并存，EBF03 继续排除。[301] 的209页是书中那段轶事的具体页，全文范围不否定该页，EBF56 继续排除。
