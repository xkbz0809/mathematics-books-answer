"""Match formal answers, in reading order, to every inventory identifier and page."""
from collections import Counter, defaultdict
import csv
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
input_pat = re.compile(r"\\input\{([^{}]+)\}")
def expand(path):
    s = path.read_text(encoding="utf-8-sig")
    def child(m):
        p = root / m[1]
        if not p.suffix:
            p = p.with_suffix(".tex")
        return "\n" + expand(p) + "\n"
    return input_pat.sub(child, s)

rows = list(csv.reader((root/"inventory/exercises.csv").open(encoding="utf-8-sig")))
wanted = defaultdict(list)
for row in rows[1:]:
    wanted[row[2]].append(row)

def items(section):
    result = []
    depth = 0
    for m in re.finditer(r"\\(begin|end)\{(enumerate|itemize|description)\}|\\item(?![a-zA-Z])(?:\[([^\]\n]*)\])?",section):
        if m[1] == "begin":
            depth += 1
        elif m[1] == "end":
            depth -= 1
        elif depth == 1:
            result.append(m.start())
    if not result:
        result = [m.start() for m in re.finditer(r"(?m)^\\(?:paragraph|noindent\\textbf)\{(?:\*?\s*)?(?:第\s*)?\d+",section)]
    return result

answer = {}
for chapter in [f"ch{i:02}" for i in range(1,13)]+[f"app{i:02}" for i in range(3,7)]:
    path = root / chapter / "solutions.tex"
    if not path.exists(): continue
    s = expand(path)
    if chapter == "ch01":
        s = expand(root/"ch01/solutions11.tex")+"\n"+s
        s = s.replace(r"\section{开集、闭集与既开又闭集}",r"\section{习题 1.2}")
        s = s.replace(r"\section{余有限拓扑}",r"\section{习题 1.3}")
    heads = list(re.finditer(r"\\(?:sub)?section\*?\{习题\s*(A?\d+\.\d+)(?=[^.\d])",s))
    for i,h in enumerate(heads):
        group=h[1]
        sub=s[h.end():heads[i+1].start() if i+1<len(heads) else len(s)]
        starts=items(sub)
        if group in ("1.2","1.3"):
            starts=[m.start() for m in re.finditer(r"\\paragraph\{\d+\.\d+\.\d+",sub)]
        if not starts:
            starts=[m.start() for m in re.finditer(r"(?m)^\s*\\(?:noindent\s*)?\\?textbf\{\s*(?:第\s*)?(?:\*?\d+)[.、）题}]",sub)]
        answer[group]=(chapter,sub,starts)

out=root/"review/answer-coverage.csv"
errors=[]
with out.open("w",encoding="utf-8-sig",newline="") as f:
    writer=csv.writer(f)
    writer.writerow(["唯一定位","原书起页","原书止页","解答源码包","题组定位","正文起始语"])
    for g,group in wanted.items():
        chap,s,starts=answer.get(g,("","",[]))
        if len(starts)!=len(group):
            errors.append((g,len(group),len(starts)));continue
        for row,pos in zip(group,starts):
            writer.writerow([row[4],row[5],row[6],chap+"/solutions.tex",g,s[pos:pos+136].split("\n")[0]])
print(f"Groups {len(wanted)}; expected {sum(len(v) for v in wanted.values())}; mismatches: {errors}")
if errors: raise SystemExit(1)
