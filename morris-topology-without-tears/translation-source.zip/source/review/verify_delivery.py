"""Inspect the released PDFs, verify exercise/errata accounting and render sample pages."""
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re
import sys
import pymupdf
from PIL import Image, ImageDraw

source = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(source/"errata"))
from pdf_entries import read_entries
from physical_locations import check_theorem_positions, check_exercise_pages, check_printed_contents, check_bibliography_positions

dest = source.parent / "交付" / "Morris-2024-08-06"
report = {}
errata = json.loads((source/"errata/records.json").read_text(encoding="utf-8-sig"))
ids = [entry["id"] for entry in sorted(errata["entries"], key=lambda entry: int(re.match(r"\d+", entry["pages"])[0]))]
book_pdf = source.parent / "topology with tears.pdf"
if book_pdf.is_file():
    with book_pdf.open("rb") as fp:
        digest = hashlib.sha256(fp.read()).hexdigest()
    assert digest.lower() == errata["source_sha256"].lower()
with (source/"inventory/pages.csv").open(encoding="utf-8-sig") as fp:
    page_rows = list(csv.reader(fp))[1:]
assert [int(row[2]) for row in page_rows] == list(range(1, 730))
index_rows = (source/"backmatter/index.tex").read_text(encoding="utf-8").splitlines()
assert sum(row.startswith(r"\TWTIndexRow{") for row in index_rows) == 1517
bibliography = (source/"backmatter/bibliography.tex").read_text(encoding="utf-8")
assert re.findall(r"\\label\{bib:(\d+)\}", bibliography) == [str(i) for i in range(1, 430)]
stage = source / "build" / "release-review"
stage.mkdir(parents=True, exist_ok=True)
for filename in ("Morris-Translation-ZH.pdf", "Morris-Solutions-ZH.pdf", "Morris-Errata-ZH.pdf", "Morris-Errata-EN.pdf"):
    path = dest / filename
    with pymupdf.open(path) as doc:
        pages = len(doc)
        toc = doc.get_toc()
        names = doc.resolve_names()
        metadata = {}
        all_text = []
        kinds = Counter()
        for p in doc:
            all_text.append(p.get_text())
            for link in p.get_links():
                kinds[link["kind"]] += 1
                if link["kind"] == pymupdf.LINK_LAUNCH:
                    raise ValueError((filename, p.number + 1, "File action", link))
                if link["kind"] in (pymupdf.LINK_GOTO, pymupdf.LINK_NAMED):
                    if not 0 <= link["page"] < pages:
                        raise ValueError((filename,p.number,link))
        text = "\n".join(all_text)
        if not all(t.strip() for t in all_text):
            empty = [n+1 for n,t in enumerate(all_text) if not t.strip()]
            print("Pages without extractable text:",filename,empty)
        selection = [0]
        if "Translation" in filename or "Solutions" in filename:
            metadata["printed_contents_page_numbers_checked"] = check_printed_contents(doc)
        if "Translation" in filename:
            metadata["bibliography_destinations_checked"] = check_bibliography_positions(doc, names)
            theorem_targets = {k: v for k, v in names.items() if k.startswith("morris-thm-")}
            assert len(theorem_targets) == 964
            assert all(0 <= v["page"] < pages for v in theorem_targets.values())
            check_theorem_positions(doc, theorem_targets)
            metadata["numbered_math_destinations"] = len(theorem_targets)
            metadata["numbered_titles_physically_checked"] = len(theorem_targets)
            compact = re.sub(r"\s+", "", text)
            absent = [entry for entry in ids if not re.search(re.escape(entry) + r"(?![0-9])", compact)]
            assert not absent, ("Errata identifiers missing from the translated book", absent)
            withdrawn = list(errata.get("withdrawn", {}))
            assert not any(re.search(re.escape(entry) + r"(?![0-9])", compact) for entry in withdrawn)
            metadata["errata_annotations_checked"] = len(ids)
            assert "索引" in toc[-1][1]
            assert len([x for x in toc if x[0]==1])>=22
            selected = [e[2]-1 for e in toc if any(k in e[1] for k in ("度量空间","拓扑群","参考文献","索引"))]
            selection += [selected[0],selected[-3],selected[-2],pages-1] if len(selected)>=3 else [pages//2,pages-1]
        elif "Solutions" in filename:
            groups=[x for x in toc if x[0]==2]
            assert len(groups)==67, (filename,len(groups))
            with (source/"inventory/exercises.csv").open(encoding="utf-8-sig") as fp:
                exercises = defaultdict(list)
                for row in list(csv.reader(fp))[1:]:
                    exercises[row[2]].append(row)
                counts = {group: len(items) for group, items in exercises.items()}
            expected = {f"morris-sol-{group}-{ordinal}" for group, n in counts.items() for ordinal in range(1, n + 1)}
            actual = {k for k in names if k.startswith("morris-sol-")}
            assert actual == expected and len(actual) == 602
            assert all(0 <= names[k]["page"] < pages for k in actual)
            total, misplaced = check_exercise_pages(doc, names, exercises)
            if misplaced:
                raise ValueError(("Exercise destinations or printed page ranges", misplaced[:10]))
            metadata["original_exercise_page_ranges_checked"] = total
            metadata["exercise_destinations"] = len(actual)
            assert "602" in all_text[0]
            selection += [groups[0][2]-1,groups[25][2]-1,groups[-2][2]-1,pages-1]
        else:
            assert toc and all(1 <= entry[2] <= pages for entry in toc), (filename, "invalid section bookmarks")
            found = [entry_id for entry_id, _ in read_entries(doc)]
            assert found==ids,(filename,len(found),len(ids))
            selection += [1,pages//3,(2*pages)//3,pages-1]
        sheet=Image.new("RGB",(1100,685),"white")
        for i,n in enumerate(selection):
            pix=doc[n].get_pixmap(matrix=pymupdf.Matrix(.78,.78),alpha=False)
            img=Image.frombytes("RGB",(pix.width,pix.height),pix.samples)
            img.thumbnail((212,635))
            sheet.paste(img,(220*i,35))
            ImageDraw.Draw(sheet).text((220*i+10,10),f"PDF {n+1}",fill="black")
        sheet.crop((0,0,1100,352)).save(stage/(path.stem+".jpg"), quality=92)
        report[filename]={**metadata,"pages":pages,"bookmarks":len(toc),"links":sum(kinds.values()),"sampled_pages":[n+1 for n in selection],"bytes":path.stat().st_size,"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
rows=list(csv.reader((source/"review/answer-coverage.csv").open(encoding="utf-8-sig")))[1:]
assert len(rows)==len({r[0] for r in rows})==602
report["formal_exercises"]=602
report["groups"]=67
report["errata"]=len(ids)
(source/"review/release-check.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf8")
for name,r in report.items():
    print(name,r["pages"] if isinstance(r,dict) else r)
