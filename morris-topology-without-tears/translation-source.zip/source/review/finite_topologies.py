"""Independent exhaustive checks for the two finite classification exercises."""
from itertools import combinations

def topologies(n):
    size = 1 << n
    full = size - 1
    for mask in range(1 << (size - 2)):
        family = {0, full}
        family.update(a for a in range(1, full) if mask & (1 << (a-1)))
        if all((a | b) in family and (a & b) in family for a,b in combinations(family, 2)):
            yield family

three = list(topologies(3))
four = list(topologies(4))
assert len(three) == 29
assert sum(len(f) == 4 for f in four) == 43
assert sum(all(a in f or (15 ^ a) in f for a in range(16)) for f in four) == 45
print("29 labelled three-point topologies; 43 four-open-set and 45 door topologies on four points.")
