"""Check where PDF destinations land relative to their printed titles and source-page labels."""
import re
from collections import defaultdict

def check_printed_contents(doc):
    """Compare the page number typeset on each contents line to its PDF target."""
    outline = doc.get_toc(simple=False)
    found = []
    for index in range(1, outline[0][2] - 1):
        page = doc[index]
        numbers = [w for w in page.get_text("words") if w[0] > page.rect.width * .80 and w[4].isdigit()]
        for link in page.get_links():
            rect = link["from"]
            midpoint = (rect.y0 + rect.y1) / 2
            on_line = [int(w[4]) for w in numbers if abs((w[1] + w[3]) / 2 - midpoint) < 5]
            target = link["page"] + 1
            if on_line != [target]:
                raise ValueError(("Printed contents page", index + 1, link.get("nameddest"), on_line, target))
            found.append(link["nameddest"])
    if found != [row[3]["nameddest"] for row in outline]:
        raise ValueError("The printed contents and PDF outline reference different entries")
    return len(found)

def check_bibliography_positions(doc, names):
    outline = doc.get_toc()
    start = next(row[2] - 1 for row in outline if row[1] == "参考文献")
    stop = next(row[2] - 1 for row in outline if row[1] == "索引")
    found = set()
    for index in range(start, stop):
        page = doc[index]
        for x0, y0, x1, y1, word, *_ in page.get_text("words"):
            if not 96 < x1 < 103 or not re.fullmatch(r"\[\d+\]", word):
                continue
            number = int(word[1:-1])
            target = names[f"morris-bib-{number}"]
            y = page.rect.height - target["to"][1]
            if target["page"] != index or not y0 - 12 <= y <= y1 + 6:
                raise ValueError(("Bibliography destination", number, index + 1, target, y0, y1))
            found.add(number)
    if found != set(range(1, 430)):
        raise ValueError(("Missing bibliography labels", sorted(set(range(1, 430)) - found)))
    return len(found)

def heading_positions(doc):
    positions = defaultdict(list)
    for page in doc:
        for block in page.get_text("dict", flags=0)["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    if "Bold" not in span["font"]:
                        continue
                    match = re.match(r"\s*(A?\d+\.\d+\.\d+)(?![\d.])", span["text"])
                    if match:
                        positions[match[1]].append((page.number, span["bbox"][1], span["bbox"][3]))
    return positions

def check_theorem_positions(doc, targets):
    positions = heading_positions(doc)
    for name, target in targets.items():
        number = name.removeprefix("morris-thm-")
        page = target["page"]
        y = doc[page].rect.height - target["to"][1]
        if not any(p == page and top - 12 <= y <= bottom + 6
                   for p, top, bottom in positions[number]):
            raise ValueError(f"The destination for {number} misses its printed title on page {page + 1}")

def text_rows(page):
    spans = [span for block in page.get_text("dict", flags=0)["blocks"]
             for line in block.get("lines", []) for span in line["spans"] if span["text"].strip()]
    rows = []
    for span in sorted(spans, key=lambda value: value["origin"][1]):
        baseline = span["origin"][1]
        if not rows or baseline - rows[-1][0] > 2.5:
            rows.append((baseline, []))
        rows[-1][1].append(span)
    return [(baseline, "".join("".join(span["text"].split())
                              for span in sorted(items, key=lambda value: value["bbox"][0])))
            for baseline, items in rows]

def check_exercise_pages(doc, names, groups):
    page_rows = [text_rows(page) for page in doc]
    bad = []
    count = 0
    for group, items in groups.items():
        for order, record in enumerate(items, 1):
            key = f"morris-sol-{group}-{order}"
            target = names[key]
            page = target["page"]
            y = doc[page].rect.height - target["to"][1]
            pages = record[5] if record[5] == record[6] else record[5] + "–" + record[6]
            nearby = [text for baseline, text in page_rows[page] if -12 <= baseline-y <= 16]
            if not any("第"+pages+"页" in text for text in nearby):
                bad.append((key, page+1, pages, [(round(b-y,1),t[:50]) for b,t in page_rows[page] if abs(b-y)<35]))
            count += 1
    return count, bad
