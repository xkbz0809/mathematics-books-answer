"""Add links from unambiguous theorem and bibliography references to printed entries."""
import re
from pathlib import Path

INCLUDE = re.compile(r"\\input\{([^{}]+)\}")
NUMBER = r"A?\d+\.\d+\.\d+"
HEADING = re.compile(r"(?m)^((?:[ \t]*\\(?:noindent|smallskip|medskip)[ \t]*)?[ \t]*\\(?:paragraph|subparagraph|subsubsection|textbf)\*?\{\s*)("+NUMBER+r")(?![.\d])")
REFERENCE = re.compile(r"((?:定理|命题|推论|定义|引理|注记|说明|例子|例|第)\s*)("+NUMBER+r")(?![.\d])")
BIBREF = re.compile(r"((?:[A-Za-zÀ-ž][A-Za-zÀ-ž.'’\-]+|参见|文献|见|等|一书|著作|论文)\s*)\[([1-9]\d*(?:\s*[,，]\s*[1-9]\d*)*)\]")
PROTECTED = re.compile(r"(\\(?:url|nolinkurl|label|ref|pageref|includegraphics|hyperlink)\{[^{}]*\}|\$[^$\n]*\$|\\\([^\n]*?\\\))")

def linked_body(root, body, bibliography):
    def expand(match):
        key = match[1]
        if key == "shared":
            return match[0]
        path = root / key
        if path.suffix == "":
            path = path.with_suffix(".tex")
        contents = path.read_text(encoding="utf-8-sig")
        return "\n% source: "+key+"\n"+INCLUDE.sub(expand, contents)+"\n"
    expanded = INCLUDE.sub(expand, "\n".join(body))
    def web_link(match):
        printed = match[1]
        address = "https://" + printed
        if printed == "www.genealogy.math.ndsu.nodak.edu":
            address = "https://genealogy.ams.org/"
        return r"\href{" + address + r"}{\nolinkurl{" + printed + "}}"
    expanded = re.sub(r"\\url\{(www\.[^{} ]+)\}", web_link, expanded)
    expanded = re.sub(r"\\phantomsection\\label\{bib:(\d+)\}", r"\\MorrisBibAnchor{\1}", expanded)
    targets = {m[2] for m in HEADING.finditer(expanded)}
    counts = {"anchors":0,"theorem-links":0,"bibliography-links":0}
    seen = set()
    def heading(m):
        num=m[2]
        if num in seen: return m[0]
        seen.add(num)
        counts["anchors"]+=1
        return m[1]+r"\MorrisNumber{"+num+"}"
    def refer(m):
        num=m[2]
        if num not in targets: return m[0]
        counts["theorem-links"]+=1
        return m[1]+r"\hyperlink{morris-thm-"+num+"}{"+num+"}"
    def cite(m):
        nums=re.split(r"[,，]\s*",m[2])
        if not all(1<=int(v)<=429 for v in nums): return m[0]
        counts["bibliography-links"]+=len(nums)
        return m[1]+"["+ ", ".join(r"\hyperref[bib:"+n.strip()+"]{"+n.strip()+"}" for n in nums)+"]"
    expanded=HEADING.sub(heading,expanded)
    result=[]
    for line in expanded.splitlines():
        if line.lstrip().startswith(("%", r"\TWTIndexRow",r"\item[{\normalfont[")):
            result.append(line)
            continue
        parts=PROTECTED.split(line)
        for i in range(0,len(parts),2):
            parts[i]=REFERENCE.sub(refer,parts[i])
            if bibliography:
                parts[i]=BIBREF.sub(cite,parts[i])
        result.append("".join(parts))
    return "\n".join(result),counts
