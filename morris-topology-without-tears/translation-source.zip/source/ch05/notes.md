# 第 5 章复核及双语勘误

Sidney A. Morris，Topology Without Tears，2024 年 8 月 6 日版。印刷页及 PDF 顺序页 110–124。5.1 为 13 道，5.2 为 15 道。5.1 第 1–2 题在 115 页、3–10 题在 116 页、11–13 题在 117 页；5.2 第 1–3 题在 120 页、4–10 题在 121 页、11–14 题在 122 页、15 题在 123 页。核查了各小问及星号，复核了闭包方向、图像分段、子空间开集、粘合论证和对所有区间的不动点讨论。5.1.6 的图直接裁自原 PDF 第 113 页。联合 15 页校样 XeLaTeX 编译成功，第 1–8 页为译文，第 9–13 页为本章解答，未报告缺字、公式错误或行溢出。使用源稿在书籍 source 主目录下编译。

| 编号 | 原书定位及原文 | 修正与理由 | English |
|---|---|---|---|
| E501 | 2024-08-06，第 123 页（PDF 123），习题 5.2 第 15 题，提示开头 “Let a,b ∈ C, with a ≠ b.” | 取 a,b ∈ C∖S，且 a≠b。若 a∈S，则所有经过 a 的直线都与 S 相交，提示中选择避开 S 的直线不可能。道路连通的命题本身成立。 | Page 123 (PDF 123), Exercises 5.2, no. 15, opening line of the hint. Take distinct endpoints in C∖S. If a belongs to S, every line through it meets S. The path-connectedness assertion remains valid. |