"""Add per-exercise original-page locators and make every exercise group navigable."""
import csv
import re
from collections import defaultdict
from pathlib import Path
from link_book import INCLUDE

GROUP = re.compile(r"(?m)^\\(?:sub)?section\*?\{习题\s*(A?\d+\.\d+)(?=[^.\d])")
TOKEN = re.compile(r"\\(begin|end)\{(enumerate|itemize|description)\}|\\item(?![a-zA-Z])(?:\[([^\]\n]*)\])?")
PARAGRAPH = re.compile(r"\\paragraph\{\d+\.\d+\.\d+[^}]*\}")
PAGE_NUMBER = re.compile(r"(第\s*)(\d+(?:\s*(?:–|—|--?|至|、)\s*\d+)?)(\s*页)")
LEADING_LOCATOR = re.compile(
    r"\s*(?:\\(?:textbf|textit|emph)\{)?\s*[（(]?\s*(?:原书(?:及\s*PDF)?\s*)?"
    r"第\s*\d+(?:\s*(?:–|—|--?|至|、)\s*\d+)?\s*页"
    r"(?:\s*[（(]\s*PDF\s*第\s*\d+(?:\s*(?:–|—|--?|至|、)\s*\d+)?\s*页\s*[）)])?"
    r"(?=\s*[。．:：;；，,）)}])"
)

def set_locator(text, pages):
    return PAGE_NUMBER.sub(lambda m: m[1] + pages + m[3], text)

def enrich(root,body):
    def include(m):
        if m[1] == "shared": return m[0]
        target = root/m[1]
        if target.suffix=="": target=target.with_suffix(".tex")
        return "\n% source: "+m[1]+"\n"+INCLUDE.sub(include,target.read_text(encoding="utf-8-sig"))+"\n"
    s=INCLUDE.sub(include,"\n".join(body))
    s=s.replace(r"\section{开集、闭集与既开又闭集}",r"\section{习题 1.2　开集与闭集}")
    s=s.replace(r"\section{余有限拓扑}",r"\section{习题 1.3　余有限拓扑}")
    with (root/"inventory/exercises.csv").open(encoding="utf-8-sig") as src:
        files=defaultdict(list)
        for r in list(csv.reader(src))[1:]:
            files[r[2]].append(r)
    heads=list(GROUP.finditer(s))
    count=0
    for i in reversed(range(len(heads))):
        h=heads[i]
        k=h[1]
        end=heads[i+1].start() if i+1<len(heads) else len(s)
        section=s[h.start():end]
        if k in ("1.2","1.3"):
            headings = list(PARAGRAPH.finditer(section))
        else:
            headings = []
            depth = 0
            for token in TOKEN.finditer(section):
                if token[1] == "begin":
                    depth += 1
                elif token[1] == "end":
                    depth -= 1
                elif depth == 1:
                    headings.append(token)
        if len(headings) != len(files[k]):
            raise ValueError(f"Exercise count mismatch in {k}: {len(headings)} vs {len(files[k])}")
        count += len(headings)
        for j in reversed(range(len(headings))):
            row = files[k][j]
            pages = row[5] if row[5] == row[6] else row[5] + "–" + row[6]
            heading = headings[j]
            tag = heading[0]
            tail = section[heading.end():]
            mark = r"\leavevmode\hypertarget{morris-sol-" + k + "-" + str(j+1) + "}{}"
            if PAGE_NUMBER.search(tag):
                tag = set_locator(tag, pages)
            else:
                locator = LEADING_LOCATOR.match(tail)
                if locator:
                    tail = set_locator(locator[0], pages) + tail[locator.end():]
                else:
                    mark += r"{\footnotesize（原书第 " + pages + " 页）}"
            section = section[:heading.start()] + tag + mark + tail
        firstline=section.split("\n",1)[0]
        if r"\section*{" in firstline and r"\addcontentsline{toc}{section}" not in section[:len(firstline)+170]:
            section=section.replace(firstline,firstline+"\n"+r"\addcontentsline{toc}{section}{习题 "+k+"}",1)
        s=s[:h.start()]+section+s[end:]
    return s,count
