# 第11章核对记录

Morris《Topology Without Tears》2024-08-06 版，PDF及印刷页339–354。有 12＋6＋1＝19 道正式习题及所有小问。原书图片分别位于345、346、347、349、350、351、352、353页。

|编号|原页及条目|原书短摘及中文修正、依据|English|
|---|---|---|---|
|E1101|342，例11.1.11|定义式 f(x) − (cos 2πx,sin 2πx) 的减号应为等号。|In the defining formula replace the minus sign after f(x) by an equals sign.|
|E1102|346，命题11.2.10证明末行|原文把 E^{n−1} 写为 CS^n 的同胚像；极坐标商给出的实际结论是 E^n≅CS^{n−1}，与命题一致。|The final line swaps the indices. The stated map identifies CS^{n−1} with E^n.|
|E1103|347，命题11.2.12证明后半|将 SX≅C⁻X 修作 CX≅C⁻X；同胚链中重复的 C⁺S^{n−1} 改为 CS^{n−1}；赤道应为 {(x,0):x∈S^{n−1}}。例如自由的 x=0 不在赤道。|The lower half is a cone, not the entire suspension. Replace the repeated upper cone in the comparison by the full cone, and restrict x on the equator to the unit sphere.|
|E1104|348，习题11.2 #6|原式仅称“n∼m iff n,m∈Z”，遗漏非整数与自身等价，违反自反性。完整关系为 x=y 或 x,y 均为整数。|The displayed iff clause omits reflexivity at nonintegers. The intended relation identifies two real numbers exactly when they are equal or both integral.|
|E1105|348，注11.3.1|原文以克莱因瓶为四维对象实例。其内在维数为2，四维是它能无自交嵌入的一种欧氏空间维数（见11.3.5）。|The Klein bottle is a two-dimensional surface. Four refers to the dimension of an ambient Euclidean space admitting an embedding.|
|E1106|351，例11.3.4 限制映射证明|“by the compactness of Sⁿ, is a quotient map”仅据紧定义域不足以推出商映射。令 r(x)=x/‖x‖，用 φ=q∘r 及 φ 的商性质补证；不必先证明射影空间是豪斯多夫。|Compactness of the source alone does not turn a continuous surjection into a quotient map. Radial normalization r gives φ=q∘r, which supplies the missing implication.|
|E1107|351，例11.3.4末个双向公式|φ(a)=φ(b) iff b=−a 遗漏 b=a。每个非零射影方向与单位球交于相反的两点；同一球面点当然也有同一像。|For arbitrary a,b on the sphere the relation is b=a or b=−a. The original iff omits equality.|

