"""Build the page and formal exercise indexes from the supplied 2024-08-06 PDF."""
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import pymupdf

here = Path(__file__).resolve().parent
book = next(here.parents[1].glob("*.pdf"))
pdf = pymupdf.open(book)
edition = "2024-08-06"
bookmarks = {p:t for level,t,p in pdf.get_toc() if level == 1}
section_pattern = re.compile(r'(?:A?\d+)\.\d+')
group_pattern = re.compile(r'Exercises\s+(A?\d+\.\d+)')
number_pattern = re.compile(r'(\d{1,3})(\**)(?:\.(?!\d)|(?=\s))\s*(\**)\s*(.*)')
part_pattern = re.compile(r'^\s*\(([a-z]|[ivxlcdm]+|[A-Z]|\d+)\)(\**)')
theorem_pattern = re.compile(r'(?:A?\d+)\.\d+\.\d+')
pages = []
groups = []
entries = []
special = []
chapter = "封面"
section = ""
active_group = None
entry = None
notes = []

def get_lines(pg):
    for block in pg.get_text("dict", flags=pymupdf.TEXTFLAGS_DICT & ~pymupdf.TEXT_PRESERVE_IMAGES)["blocks"]:
        for line in block.get("lines", []):
            spans = line["spans"]
            yield dict(t="".join(s["text"] for s in spans).strip(), x=round(line["bbox"][0],1), y=round(line["bbox"][1],1),
                       size=round(spans[0]["size"],1), font=spans[0]["font"], spans=spans)

def write_csv(name, records):
    with (here / name).open("w", encoding="utf-8-sig", newline="") as file:
        out=csv.DictWriter(file,fieldnames=list(records[0]))
        out.writeheader()
        out.writerows(records)

for pg in pdf:
    n = pg.number + 1
    lines = list(get_lines(pg))
    if n == 2:
        chapter = "目录"
    if n in bookmarks:
        chapter = bookmarks[n]
        section = ""
        active_group = None
        entry = None
    page_sections = [section] if section else []
    page_objects = []
    page_groups = []
    printed = "未标页码"
    for i, line in enumerate(lines):
        t,x,y,size,font = (line[k] for k in ("t","x","y","size","font"))
        if n != 1 and t == str(n) and (y < 68 or y > 735):
            printed = str(n)
        if not t or y < 66 or (t == str(n) and y>720):
            continue
        sect = re.match(r'^(A?\d+\.\d+)(?:$|\s+)',t)
        if sect and size >= 14 and "Bold" in font and 51 <= x < 70:
            section = sect[1]
            if i==0 or not any(ln["y"]>66 and ln["font"].endswith("Regular") and ln["size"]>=11 for ln in lines[:i]):
                page_sections=[]
            page_sections.append(section)
            active_group = None
            entry = None
        if theorem_pattern.fullmatch(t) and "Bold" in font:
            page_objects.append(t)
        if (m:=group_pattern.fullmatch(t)) and "Bold" in font:
            active_group = m[1]
            entry = None
            groups.append({"group":active_group,"start":n})
            continue
        if not active_group:
            continue
        if ("SansQuot" in font and size==12.0 and x<71 and (m:=number_pattern.fullmatch(t))
                and (re.match(r"^\d+\**\.",t) or (active_group=="6.2" and n in (147,148) and m[1] in ("11","12")))):
            num, before_stars, after_stars, after = m.groups()
            stars = before_stars + after_stars
            entry = {"group":active_group,"number":num,"stars":stars,"start":n,"end":n,"labels":[],"lines":[]}
            entries.append(entry)
            t=after
        if entry is None:
            continue
        if entry["group"] not in page_groups:page_groups.append(entry["group"])
        if size<11 and x<68 and y>590:
            continue
        if y>65 and t:
            entry["end"]=n
            entry["lines"].append((n, x, y, t))
            key=(active_group,entry["number"])
            greek=re.match(r"^\(([αβγ])\)",t)
            if greek:
                entry["labels"].append((greek[1],n,x))
            if key==("1.2","6") and re.match(r"^\([abc]\) [AB] ",t):
                entry["labels"].append((t[1],n,x))
            if key==("3.2","3") and "if and only if (i)" in t:
                entry["labels"].extend((q,n,x) for q in ("i","ii"))
            if (key in (("A3.6","2"),("A3.6","3")) and t.startswith("[Hints. (i)")) or (key==("10.2","6") and t.startswith("[Hints: (i)")):
                entry["labels"].append(("i",n,x))
            if "SansQuot" in font or "Roman" in font:
                rest=t
                while (part:=part_pattern.match(rest)):
                    entry["labels"].append((part[1]+part[2],n,x))
                    rest=rest[part.end():]
                # Inline enumerations verified in the identified exercises.
                extra=[]
                key=(active_group,entry["number"])
                if key==("1.2","1") and "whether it is" in t: extra=["i","ii","iii"]
                if key==("3.1","6") and "the four sets" in t: extra=["i","ii","iii","iv"]
                if key==("5.2","13") and "(a) set of all" in t: extra=["a","b"]
                if key==("5.2","13") and "(c) set of all" in t: extra=["c"]
                if key==("10.3","33") and "Verify (a)" in t: extra=["a"]
                if key==("10.3","33") and "Banach space;" in t and "(b)" in t: extra=["b","c","d"]
                if key in (("A6.1","1"), ("A6.1","10")) and "(i)" in t and "{1, 2}" in t:
                    extra=["i","ii"]+(["iii"] if "(iii)" in t else [])
                if key==("9.2","4") and "If each" in t: extra=["i"]
                if key==("9.2","4") and t.startswith("space, (ii)"): extra=["ii","iii"]
                if key==("10.3","7") and "(i) Lindel" in t: extra=["i","ii"]
                if key==("10.3","7") and "(iii) second" in t: extra=["iii"]
                entry["labels"].extend((q,n,x) for q in extra)
    pages.append({"版次":edition,"卷":"全一册","PDF页":n,"印刷页":printed,"章或书末材料":chapter,"节":"/".join(dict.fromkeys(page_sections)),"正文条目":"; ".join(dict.fromkeys(page_objects)),"题组":"; ".join(page_groups)})

for g in groups:
    q=[e for e in entries if e["group"]==g["group"]]
    if not q:
        notes.append(f"ERROR empty group {g}")
        continue
    nums=[int(e["number"]) for e in q]
    expected=[1,2,3,4,5,5,6,7,8,9,10,11] if g["group"]=="A5.5" else list(range(1,len(q)+1))
    if nums!=expected:
        notes.append(f"NONSEQUENTIAL {g} {nums}")
    g["end"]=q[-1]["end"]
    g["count"]=len(q)

write_csv("pages.csv",pages)
write_csv("exercise-groups.csv",groups)
label_notes={
    ("1.2","6"): "(i) 内 (a)–(c) 是互斥的备选条件。",
    ("3.2","3"): "(i)、(ii) 是充要判据的两个条件。",
    ("8.3","3"): "(xii) 内 (α)–(γ) 是半范数定义的三个条件。",
    ("10.2","6"): "(i)–(v) 是提示中列出的证明步骤。",
    ("10.3","5"): "(xi) 内 (α)、(β)、(γ) 是应证明的三个子问，均在第 300 页。",
    ("A3.6","2"): "(i)–(iii) 属于提示。",
    ("A3.6","3"): "各编号属于提示，原书连续两项均作 (ii)，见 E3A10。",
    ("A5.1","3"): "原书从 (ii) 起标，继以 (iii)。"
}
compact = []
seen=Counter()
for e in entries:
    first=e["lines"][:3]
    k=(e["group"],e["number"])
    seen[k]+=1
    loc=e["group"]+"#"+e["number"]
    if k==("A5.5","5"): loc+=("a" if seen[k]==1 else "b")
    compact.append({"版次":edition,"卷":"全一册","题组":e["group"],"原题号":e["number"]+e["stars"],"唯一定位":loc,"印刷起页":e["start"],"印刷止页":e["end"],"PDF起页":e["start"],"PDF止页":e["end"],"原文分项标记及所在页":" ".join(f"({p})@{n}" for p,n,x in e["labels"]),"起始语（定位）":" ".join(k[3] for k in first)[:85],"分项说明":label_notes.get(k,"")})
write_csv("exercises.csv",compact)
with (here / "qa-extracted.json").open("w",encoding="utf-8") as file:
    json.dump(entries,file,ensure_ascii=False)
print("groups",len(groups),"entries",len(entries),"per chapter",dict(Counter(e["group"].split(".")[0] for e in entries)))
print("pages without printed labels", [p["PDF页"] for p in pages if p["印刷页"]=="未标页码"])
print("nonsequential:",*notes, sep="\n")
print("raw groups",[(g["group"],g.get("start"),g.get("end"),g.get("count")) for g in groups])
print("sha256",hashlib.sha256(book.read_bytes()).hexdigest())

