# Appendix 1 errata / 附录1勘误

Sidney A. Morris, Topology Without Tears, 6 August 2024, one volume; printed and one-based PDF page numbers coincide.

| ID | Page | Locator | Original | 修正与依据 | Correction and evidence |
|---|---|---|---|---|---|
| EA101 | 407 | A1.2.2 | “A collection … if” omitted nonemptiness. | 基数的等势类应非空，空类满足印出的两个全称条件，却不代表任何集合。 | Require a nonempty class. Otherwise the empty class vacuously meets both conditions although no set represents it. |
| EA102 | 408, 410 | before A1.2.7; A1.2.13 proof | “1.2.1”, “A.2.1”. | 两处均指附录中的康托尔–施罗德–伯恩斯坦定理 A1.2.1。 | Both references should be A1.2.1, the Cantor–Schröder–Bernstein theorem. |
| EA103 | 410 | A1.2.12 proof | card (a,b) ≤ card [a,b] ≤ card ℝ only. | 原证明只覆盖特别情形，应把任意 S 夹在 (a,b) 和 ℝ 之间。 | Use card (a,b) ≤ card S ≤ card ℝ for the arbitrary S in the statement. The printed argument handles only S=[a,b]. |
| EA104 | 412 | A1.3.7(iv) | “any finite cardinal n”. | 须限定正有限基数 n；n=0 时两乘积均为零。 | Require n>0, since multiplication by zero gives zero. |
| EA105 | 413 | A1.3.9(v) | α≤β ⇒ γ^α≤γ^β. | 加 γ>0。按本节函数集定义，0⁰=1 而 0¹=0。 | Exclude base zero. With α=γ=0 and β=1, the unique empty function gives 0⁰=1, while 0¹=0. |
| EA106 | 413 | after A1.3.9 | “three questions … second”. | 第409页只列两问，下文回答第一问，即连续统基数是否在该列表中。 | There are two numbered questions and A1.3.11 answers the first one. |
| EA107 | 414 | proof of A1.3.10 | f(0.a₁a₂…)=(a₁,a₂,…). | 十进位中允许零，但 ℕ 从1起。固定不以无穷个9结尾的展开，把每一位加1。 | Digits may vanish whereas ℕ here starts at 1. Use the canonical decimal expansion and send each digit aᵢ to aᵢ+1. |
| EA108 | 416 | A1.4.1–2 | “strict” iff a≤b and b≤a imply a=b. | 这只是反对称性。严格全序 < 不自反、传递、异点可比，对应 a<b 当且仅当 a≤b 且 a≠b。 | Antisymmetry already holds in every partial order. A strict linear order is irreflexive, transitive, and compares distinct elements. |
| EA109 | 417 | A1.4.3 | “Well-Ordering Theorem A1.2.4”. | 改 A1.4.4。A1.2.4 是基数序的定义。 | The well-ordering theorem is A1.4.4, whereas A1.2.4 defines cardinal comparison. |
| EA110 | 419 | A1.4.10 | ℕ as defined is the ordinal ω. | 按本书 ℕ={1,2,…} 不含0；1∈ℕ、0∈1 却有0∉ℕ。应为 ω={0}∪ℕ。 | Positive integers are order isomorphic to ω but do not form that transitive ordinal. Add zero. |
| EA111 | 420 | A1.4.13, ordinal sum | (i,δ)≤(j,γ) iff i<j or δ≤γ. | 第二种情况须 i=j。取 α=β=1 会使 (0,0) 和 (1,0) 双向可比。 | Require i=j in the second branch. Otherwise the two distinct tagged copies of zero violate antisymmetry. |
| EA112 | 421 | table after A1.4.14 | blocks 0,…,n for nω; ω+n>ω+1. | n 项块从0计应止于 n−1；严格不等式另须 n>1。 | Use blocks of length n, ending at n−1 when counted from zero. The displayed strict inequality requires n>1. |
| EA113 | 422 | A1.4.20 | every finite n makes ω+n a nonlimit. | 须 n>0，因为 ω+0=ω 是极限序数。 | Exclude n=0 since ω+0=ω is a limit ordinal. |
| EA114 | 423 | A1.4.25–26 | “smallest member” where f and g differ. | 应按最大不同坐标比较不同函数。取 α=2,β=ω，单点支撑函数 eₙ 在原序下成无穷下降链。 | Compare distinct functions at their greatest differing coordinate. With the least differing coordinate the unit functions e₀>e₁>… form a descending chain. |
| EA115 | 424 | A1.4.30 | “All the ε-numbers … a countable ordinal.” | 原全称命题错误。可数指标所得 ε 数可数，但 ω^ω₁=ω₁；因一切可数 ξ 的 ω^ξ 可数且共尾。 | Only epsilon numbers indexed by countable ordinals are necessarily countable. Continuity gives ω^ω₁=ω₁, an uncountable fixed point. |
| EA116 | 424 | A1.4.31 | Z(α)⊆P(α); each cardinal is a limit ordinal. | 取 β≤α 且与 α 等势，所得非空集合是 α+1 的子集，便可取最小元。原集合含与 ω 等势的 ω+2，但它不在 P(ω) 内。只有无限初始序数都是极限序数。 | Restrict to ordinals β≤α equipotent to α to obtain a set with the same minimum. The ordinal ω+2 has cardinality ω but is not a subset of ω. Positive finite cardinals are successor ordinals. |
| EA117 | 425 | A1.4.32 | “Every ordinal” with n positive and all cᵢ positive. | 非空标准形只能表示正序数。零使用空和。 | Every term in a nonempty Cantor normal form is positive. Represent zero by the empty sum. |
