from pathlib import Path
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

out = Path(__file__).resolve().parent / "images"
out.mkdir(exist_ok=True)
colors = ["#006b73", "#a13d11", "#5f449a"]
plt.rcParams.update({"font.size": 9, "pdf.fonttype": 42, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.titlesize": 10})
fig, axes = plt.subplots(5, 1, figsize=(7, 6.5), constrained_layout=True)
examples = [
    (r"(i)  $-x^3$", lambda x: -x**3, (-1.9,1.9), [-1.19,-1,-.67,.43,1,1.14], [0], [-1,0,1]),
    (r"(ii)  $4x$", lambda x: 4*x, (-2,2), [-.45,-.18,.20,.45], [0], [-1,0,1]),
    (r"(iii)  $x-x^2$", lambda x: x-x*x, (-1.7,1.5), [-.75,-.34,.25,.72,1,1.36], [0], [-1,0,1]),
    (r"(iv)  $\sin x$", math.sin, (-4.2,4.2), [-3.9,-2.2,-1.1,1.1,2.2,3.9], [0], [-3,0,3]),
    (r"A3.3.4  $2x(1-x)$", lambda x: 2*x*(1-x), (-1.1,1.4), [-.36,.16,.78,1,1.25], [0,.5], [0,.5,1])]
for ax, (title, func, limits, starts, fixed, ticks) in zip(axes, examples):
    ax.set(xlim=limits, ylim=(-.7,.87), yticks=[], xticks=[])
    ax.spines[["bottom","left"]].set_visible(False)
    ax.axhline(0,color=".3",lw=.8)
    for tick in ticks:
        ax.plot([tick,tick],[-.04,.04],color=".2",lw=.8)
        ax.text(tick,-.13,f"{tick:g}",ha="center",va="top",fontsize=8,
                bbox={"facecolor":"white","alpha":.85,"edgecolor":"none","pad":.1})
    for i, x in enumerate(starts):
        y = func(x)
        arc = .36 if i%2 == 0 else -.43
        # Use a quadratic Bezier curve in data coordinates so the arc is readable on short moves.
        from matplotlib.path import Path as MplPath
        path = MplPath([(x,0), ((x+y)/2,2*arc), (y,0)], [MplPath.MOVETO,MplPath.CURVE3,MplPath.CURVE3])
        ax.add_patch(FancyArrowPatch(path=path,arrowstyle="-|>",mutation_scale=8,
                                     color=colors[i%3],lw=1.0))
    ax.scatter(fixed,[0]*len(fixed),s=15,color="black",zorder=4)
    ax.set_title(title,loc="left",pad=0)
fig.savefig(out / "phase-sol.pdf", bbox_inches="tight")
plt.close(fig)

examples = [(r"$x^4$", lambda x:x**4, (-1.2,1.55), [-.85,1.08]),
            (r"$2x$", lambda x:2*x, (-2,2), [-.18,.26]),
            (r"$\sqrt{x}$", np.sqrt, (0,2.5), [.07,2.15]),
            (r"$x-x^2$", lambda x:x-x*x, (-1.3,1.3), [-.22,.78,1.16]),
            (r"$e^x$", np.exp, (-1.7,4), [-1.55,.45]),
            (r"$|x-2|$", lambda x:abs(x-2), (-.3,5.3), [.4,4.4,5])]
fig, axes = plt.subplots(2,3,figsize=(8.1,5.5), constrained_layout=True)
for ax, (title, func, (lo,hi), seeds) in zip(axes.flat, examples):
    xs = np.linspace(lo,hi,500)
    ax.plot(xs,func(xs),color=".1",lw=1.6)
    ax.plot(xs,xs,"--",color=".4",lw=.8)
    for i, seed in enumerate(seeds):
        x = seed
        for _ in range(13):
            y = float(func(x))
            ax.plot([x,x,y],[x,y,y],color=colors[i],lw=.86,alpha=.83)
            if not lo <= y <= hi or abs(y-x)<.0005: break
            x = y
        ax.scatter([seed],[seed],color=colors[i],s=14,zorder=4)
    ax.set(xlim=(lo,hi),ylim=(lo,hi),aspect="equal",title=title)
    ax.tick_params(labelsize=7)
fig.savefig(out / "cobweb-sol.pdf",bbox_inches="tight")
plt.close(fig)
fig, axes = plt.subplots(1,3,figsize=(7.5,2.4),constrained_layout=True)
for n, ax in enumerate(axes,1):
    count=2**n
    xx=np.arange(count+1)/count
    yy=np.arange(count+1)%2
    ax.plot(xx,yy,"o-",markersize=3,color=colors[0],lw=1.25)
    ax.set(xticks=[0,.5,1],yticks=[0,1],xlim=(-.03,1.03),ylim=(-.06,1.06),
           title=rf"$T^{n}(x)$",aspect="equal")
fig.savefig(out / "tent-sol.pdf",bbox_inches="tight")
plt.close(fig)
