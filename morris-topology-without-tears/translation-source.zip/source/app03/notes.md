﻿# 附录三　原页与数学复核
版本为 Sidney A. Morris《Topology Without Tears》，2024-08-06。单卷。以下 p. 同为印刷页及从 1 起算的 PDF 顺序页。附录三占 437–469 页。A3.1–A3.8 的正式题数依次为 5、6、4、7、4、6、4、4，合计 40。原书图收于 images/p439、p440、p443、p444、p446、p447、p448.pdf，解答另绘相图、蛛网图和帐篷映射迭代图。下列同一编号中英文使用同一公式、原页和依据。

| 编号 | 原书印刷页/PDF页、位置 | 原书与修正、依据 | English erratum |
|---|---|---|---|
| E3A01 | 438，A3.1.1 | 定义二次迭代时左端印作 f¹。应为 f²=f∘f，与前一行 f¹=f 及递推一致。 | In the definition of the second iterate, change the left side from f¹ to f². By definition f²=f∘f. |
| E3A02 | 441，A3.2.4 后 | 原书无条件断言多数点的轨道会含有无穷多个点。改写为可能出现无限轨道。恒等映射每条轨道都只有一个点；原文也未给出“多数”的含义。 | The assertion about “most” points is unsupported as a general statement. Infinite orbits are possible, but the identity has only one-point orbits. |
| E3A03 | 445，A3.3 题3(ii) | 倍增映射的定义域为 [0,1)。断言 1/n 是周期点或最终周期点时应限 n≥2；n=1 给出的 1 不在定义域。 | State the periodic or eventually periodic conclusion for integers n≥2, since 1 lies outside the domain [0,1). |
| E3A04 | 452，A3.5.4 | 原书示例在有理点取 x²、在无理点取 −x²。零点差商的绝对值为 abs(x)，故趋零。若需在吸引不动点不可导，可用 f(x)=abs(x)/2。 | The signed quadratic shown is differentiable at zero, with derivative zero. The map f(x)=abs(x)/2 instead has a nondifferentiable attracting fixed point at zero. |
| E3A05 | 452，A3.5.4 | A3.1.17、A3.1.18 改为 A3.5.2、A3.5.3，即前述吸引、排斥判据。 | The two derivative criteria are Theorems A3.5.2 and A3.5.3, not A3.1.17 and A3.1.18. |
| E3A06 | 453，A3.5.9 | 定义排斥周期点时把最小周期为 m 的点写成 f^(nm) 的排斥不动点。其中 n 没有定义；应为 f^m，同前面吸引情形。 | Remove the unbound n from the exponent in the repelling case. A point of prime period m is classified using the fixed point of f^m, as in the attracting case. |
| E3A07 | 454，A3.5 题2(ii) | 原题要求仅靠导数判据判定。f(x)=1/(4x) 在 ±1/2 有乘子 −1，严格不等式均不适用。平方迭代为恒等，故两点中性。 | The strict derivative tests cannot classify the fixed points of 1/(4x). Both have multiplier −1 and are neutral because the second iterate is the identity. |
| E3A08 | 455，A3.5 题4(vi) | A3.1.17 改为 A3.5.2，即导数绝对值小于1的吸引性判据。 | The attracting fixed-point criterion cited here is A3.5.2. |
| E3A09 | 458，A3.6.5(ii) | 必须是周期的数值、而非周期点的数值，是 2 的幂。拓扑共轭可任意改变点的坐标而保持周期。 | It is the periods, not the periodic points themselves, that can only be powers of two in this case. |
| E3A10 | 459，A3.6 题3提示 | 两个不同提示均标 (ii)，按出现顺序保留为 (ii-a)、(ii-b)。 | Two hints share label (ii). Distinguish them in order as (ii-a) and (ii-b). |
| E3A11 | 461，A3.6 题5(i) | “3.6.2”应为 A3.6.2，即本附录周期三定理。 | The intended reference is A3.6.2 in this appendix. |
| E3A12 | 463，A3.7 洛伦兹讲演段 | 年份 1973 改为 1972。原始 AAAS 讲演资料注明 1972 年12月29日。 | The butterfly-effect talk was given on 29 December 1972, not in 1973. See the original AAAS programme reproduced in the lecture scan. |
| E3A13 | 463，A3.7 历史引言 | George David Birkoff 应为 George David Birkhoff，即乔治·戴维·伯克霍夫。 | Correct George David Birkoff to George David Birkhoff. |
| E3A14 | 464，A3.7 周期点稠密段 | 周期三定理推出各个正整数周期均出现，但无法由此推出周期点在全空间稠密。例如将 [0,1] 上端点同映为 0 的、含三周期的满帐篷映射在区间外常值延拓为 0。 | Period three gives all periods, but it does not imply dense periodic points in the ambient space. Extending the full tent map constantly by zero outside [0,1] gives a counterexample on the line. |
| E3A15 | 465，A3.7.8、A3.7.11 | Banks 等的敏感性推论需要无限度量空间与连续自映射。任意有限离散空间上的单循环置换均传递、周期点稠密，却不敏感。 | State the Banks et al. implication for a continuous map on an infinite metric space. A cyclic permutation of a finite discrete space is transitive with dense periodic points and has no sensitive dependence. |
| E3A16 | 465，A3.7.12 | 稠密周期点是定义 A3.7.7 的条件 (i)，原印 (ii)。区间传递性推出周期点稠密应加连续性，见 Vellekoop 与 Berglund。 | Dense periodic points is condition (i) of Definition A3.7.7, not condition (ii). The cited interval result assumes a continuous map. |
| E3A17 | 466，A3.7 题1–2 | 第 n 次迭代有 2^n 个单调分支。下标 k 上界应为 2^n，非 n；各分支长度为 2^(−n)。 | Replace the upper bound n on the branch index by 2^n. The n-th iterate has precisely 2^n monotone branches. |
| E3A18 | 466，A3.7 题3 | 所有正整数 m 的原命题错误。m=1 给出圆周恒等映射，不传递。修订为整数 m≥2。 | For m=1 the circle map is the identity and is not transitive. The intended statement holds for integers m≥2. |
| E3A19 | 467，A3.7 题4 | 已量化正整数 n，结论中的未定义迭代指数 k 应统一为 n。 | Replace the unbound iteration index k by the quantified n. |
| E3A20 | 467，A3.8.1 | 共轭 h 的陪域原印 X，应为第二系统所在的 X₂，h:X₁→X₂。 | The conjugacy h has codomain X₂, the phase space of the second system. |
| E3A21 | 467，A3.8.2 | 注的编号“3A.8.2”应为 A3.8.2。 | Correct the remark number 3A.8.2 to A3.8.2. |
| E3A22 | 468，A3.8.4 及式(12.3)、(12.5) | 分别在 X₁、X₂ 量化各自开集。(12.3) 中两个命题间应作合取，原印蕴涵会造成真空成立；(12.5) 更正函数复合的右括号位置。结尾两项对应 (12.2)、(12.3)。 | Quantify over open sets in X₁ or X₂ as appropriate. Use conjunction instead of implication in (12.3), put the closing parenthesis in its correct position in (12.5), and cite (12.2) and (12.3) at the end. |
| E3A23 | 469，A3.8 题1(iv)–(vii) | 等分区间须包含 k=2^n 才能覆盖 1。并更正附录内引文漏 A 及颠倒的映射空间次序。 | Include the last branch k=2^n so that 1 is covered; restore the A in the appendix reference and the correct order of the space and map in the dynamical-system tuple. |

核验资料：[洛伦兹讲演原始资料](https://home.cs.colorado.edu/~lizb/chaos/lorenz_1972.pdf)；[Banks 等，On Devaney’s Definition of Chaos](https://web.math.pmf.unizg.hr/~sonja/T%2BPP%3DChaos.pdf)；[Vellekoop 与 Berglund，On Intervals, Transitivity = Chaos](https://web.abo.fi/fak/mnf/mate/kurser/dynsyst/VellekoopBerglund.pdf)。
