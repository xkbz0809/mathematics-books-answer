"""Extract the six figures in §6.1 from the exact supplied edition."""
from pathlib import Path
import pymupdf
from PIL import Image,ImageChops

folder=Path(__file__).resolve().parent
book=folder.parent.parent/"topology with tears.pdf"
figures={3:(126,412,575),5:(127,307,546),6:(128,209,446),12:(130,426,688),13:(131,152,368),14:(131,478,705)}
with pymupdf.open(book) as doc:
    for num,(page,top,bottom) in figures.items():
        clip=pymupdf.Rect(45,top,552,bottom)
        pix=doc[page-1].get_pixmap(clip=clip,dpi=400,alpha=False)
        img=Image.frombytes("RGB",(pix.width,pix.height),pix.samples)
        mask=ImageChops.difference(img,Image.new("RGB",img.size,"white")).convert("L").point(lambda n:255 if n>23 else 0)
        box=mask.getbbox()
        if not box: raise ValueError((page,"empty figure"))
        img.crop(box).save(folder/f"fig-6-1-{num}.png",dpi=(400,400))
