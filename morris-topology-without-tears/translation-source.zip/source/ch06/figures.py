from pathlib import Path
import pymupdf

here = Path(__file__).resolve().parent
src = here/"section1.tex"
contents = src.read_text(encoding="utf-8")
for label,next_text in [(3,r"\paragraph{6.1.4"),(5,r"\paragraph{6.1.6"),(6,r"\paragraph{6.1.7"),(12,r"\paragraph{6.1.13"),(13,r"\paragraph{6.1.14"),(14,"下面的引理")]:
    pic=r"\begin{center}\includegraphics[width=.52\linewidth,height=42mm,keepaspectratio]{ch06/fig-6-1-"+str(label)+r".png}\end{center}"
    if pic not in contents:contents=contents.replace(next_text,pic+"\n"+next_text,1)
src.write_text(contents,encoding="utf-8")
with pymupdf.open(here.parent.parent/"topology with tears.pdf") as doc:
    pymupdf.Pixmap(doc,465).save(here/"fig-6-2-13.png")
