# 第12章原书勘误 / Chapter 12 errata

Sidney A. Morris, Topology Without Tears, 6 August 2024, one volume. Numbers below are both printed and one-based PDF pages. Each row gives the original reading, the correction, and the reason. Corrections of broken cross-references are distinguished from conjectural identification of the intended target.

| ID | 页 / page, locator | 原文与修正、依据 / Reading, correction and evidence |
|---|---|---|
| E1201 | 357, footnote 2 | 原文称定义 Taylor 多项式须任意阶导数均存在。有限阶只需中心处到该阶的导数，如 x\|x\| 在 0 有一阶 Taylor 多项式却没有二阶导数。 A Taylor polynomial of finite degree requires derivatives only through that degree at the centre. |
| E1202 | 360–361, Lemma 12.1.4 | 原文在 [a,c] 和 [d,b] 分别要求逼近 1 和 0，而 a<d<c<b，两区间重叠。改为 [a,d] 和 [c,b]。因函数在 x 上单调递减，只需在 d、c 两点取共同的指标，再重排尾列可使所有 n 满足估计。 The printed intervals overlap. Use the two disjoint intervals and monotonicity in x to get the bounds uniformly. |
| E1203 | 362, (13) | 左中括号误作绝对值竖线，改为 [Pε(x)−f(s)]pₙ(x)。 Replace the unmatched vertical bar by an opening square bracket, as the surrounding algebra requires. |
| E1204 | 363, (17) and (18) | (17)所引(2),(16)改为(3),(12)，两式分别给出小乘子与一致界。(18)左端区间 [a,s+δ]∩[c,b] 应为 [a,s+δ]∩[a,b]，否则未覆盖整个延拓区间。 Cite (3),(12) and intersect with the whole domain [a,b] to cover the full claimed extension. |
| E1205 | 364, Remark 12.1.6 | 三处二项式系数的上下标颠倒，均须取 n choose m。Bernstein 近似次数至多 n；采样值 f(m/n) 和基多项式随 n 改变，公式没有给出一列固定通项按 m 截断。取 f=1 可检验权重。 In all three displays use n choose m. Each approximant has degree at most n. Both the sampled coefficients and the basis polynomials change with n, so this formula does not truncate one fixed list of summands indexed by m. |
| E1206 | 365, before Corollary 12.1.8 | 复系数 aⱼ=rⱼ+isⱼ 的有理性要求应为 rⱼ,sⱼ∈ℚ，且须含常数项 j=0；原写 aⱼ,bⱼ。Weierstrass 定理号 12.1.6 应为 12.1.5。 If only real rational coefficients were admitted, the imaginary constant i could not be uniformly approximated. Use rational real and imaginary parts of every coefficient and cite 12.1.5. |
| E1207 | 370, before Proposition 12.1.21 | 一元函数 g 的导数须取 g′(rᵢ)，原作 g′(r)，其中 r 是向量。 Evaluate the one-variable derivative at the scalar coordinate rᵢ. |
| E1208 | 371, Exercises 12.1 #9 | “Theorem 12.1.5 (i)” 没有分项。建议目标是定理 12.1.16(i)；紧邻的题10–12处理该定理其他部分。 The cited theorem has no part (i). The proposed target is 12.1.16(i) on the zeros of polynomials. |
| E1209 | 372, Exercises 12.1 #11(ii),(iii) | 无界分支上，一个紧支撑鼓包不能处处为正；又 fᵢ 未定义。取非负光滑 bᵢ，正值集恰为 Uᵢ，各阶导数有界，在无界端最终取常数；级数写 Σcᵢbᵢ 及 Σcᵢbᵢ⁽ʲ⁾。 A compactly supported bump cannot be positive on an entire unbounded component. Specify smooth functions with these positivity and bounded derivative properties, and use consistent subscripts in both series. |
| E1210 | 373, Exercises 12.1 #12, stem and (iv) | 原文同时使用 aₖ=0 和 g(x₀)=aₖ≠0。令 k 为首个非零系数的指标，aⱼ=0 (j<k)。实直线连通且 f 非常值，故全零 Taylor 展开不可能。末引 12.1.15(ii) 改为 12.1.16(ii)。 Define k as the order of the zero and cite Theorem 12.1.16(ii). |
| E1211 | 373, Exercises 12.1 #15 | “Df(x)=f(x)” 左边是线性映射，右边是向量。对线性 f 有 Df(x)=f。 The derivative at x is the linear map f itself, with zero remainder. |
| E1212 | 374, Exercises 12.1 #16 | 乘、商公式左边的括号分别改为 D(fg)(x₀)、D(f/g)(x₀)。 The derivative acts on the product or quotient of the functions before evaluation. |
| E1213 | 374, opening §12.2 | 原称所有 Bernstein 多项式构成“smaller set”。按 12.1.6，它们的全体就是所有多项式。 The Bernstein basis spans each finite-degree polynomial space, so the full set is equal. |
| E1214 | 375–376, Definition 12.2.1, Example 12.2.2(a), proof 12.2.3 | 所分离的 a,b 是 X 的点，不是函数族 S 或 C(X,F) 的点。例中 pₐ(a) 改为 p(a)。 The arguments belong to X, and the polynomial used in (a) is called p. |
| E1215 | 377, Definition 12.2.4(i) | (x+y)z=xy+xz 改为 (x+y)z=xz+yz。取实数 x=0,y=z=1 即可否定原式。 The printed right distributive law already fails for real numbers. |
| E1216 | 377, Example 12.2.5 and 388, Exercises 12.2 #2 | M₁(ℝ) 可交换；不可交换性只对 n≥2 成立。题2引例 12.2.3 应为 12.2.5。 A one-by-one matrix is a scalar. Distinct matrix units show noncommutativity for all n≥2. |
| E1217 | 377, Example 12.2.6 | 三个运算和单位函数自变量必须在 X 中，标量域是 ℝ，标量乘法应为 αf(x)。 Use x∈X in the pointwise definitions, ℝ as the scalar field, and close the parenthesis correctly. |
| E1218 | 378, Example 12.2.11 | x∈F 应为 x∈Fⁿ，范数作用在向量上。 The norm is evaluated on vectors, not on scalars. |
| E1219 | 380, Definition 12.2.14 | 子格须对母格的交、并封闭。仅要求限制偏序本身成格不足：幂集格中 ∅,{1},{2},{1,2,3} 限制后成格，但其内部并 {1,2,3} 与母格并 {1,2} 不同。 A sublattice must preserve the ambient lattice operations, as required by Proposition 12.2.17. |
| E1220 | 381, proof of Proposition 12.2.17 | Φₓ(x)=x 改为 Φₓ(x)=f(x)；Oᵧ 的指标是 y∈X\\{x}，每个 Oᵧ 已含 x。 Each constituent equals f(x) at x. The open cover uses the actually defined indices. |
| E1221 | 382, proof of Proposition 12.2.19 | “Lemma 7.2.18(iv)” 应为 12.2.18(iv)。必须从 f∈A 起步来证明 \|f\|∈A，所用近似多项式常数项为零。 Start with f in A and cite the lemma of this chapter. Zero constant term makes polynomial substitution available in a possibly nonunital algebra. |
| E1222 | 384, proof of Theorem 12.2.22 | 对每对异点选分离它的一个 f，其实部或虚部分离该对；复共轭封闭保证两者都在 A。证明常函数条件时须取 A 中非零常函数 c，得 \|c\|²，而非取非常函数并断言其模平方非常。 A nonconstant function can have constant modulus. Use a nonzero constant and apply self-adjointness when extracting real and imaginary parts. |
| E1223 | 384, Remarks 12.2.23–24 | 12.2.23 印作 7.2.23。Weierstrass 逼近的推导须对多项式代数的闭包应用定理，因原多项式代数未必闭。 Correct the remark number and apply the closed-algebra theorem to the closure of the polynomials. |
| E1224 | 386, Remark 12.2.27 | “any periodic function” 应限连续周期函数；间断周期函数不是连续三角多项式的一致极限。 Uniform trigonometric approximation requires continuity, as uniform limits of continuous functions are continuous. |
| E1225 | 387, second Remark 12.2.31 | 与上一条同号，建议第二条编号 12.2.32。C[(0,1),R) 应为 C([0,1],ℝ)。 The duplicated number is ambiguous and the interval notation is malformed. |
| E1226 | 388, Exercises 12.2 #4–7 | #4 的 Example 12.2.6(iii) 无分项，建议 12.2.8(iii)。#5 的 Example 7.2.9 不是本节例，建议 12.2.11。#6 写 Proposition 12.2.10，而同号为注，建议命题12.2.12。#7 的 Lemma 7.2.16 在本版不存在（第185页止于7.2.15，第186页起为习题），建议 12.2.18。 The indicated kinds and numbers disagree with the text. Proposed targets are supported by the surrounding exercises and the explicit proof requests, but are editorial identifications. |
| E1227 | 387 footnote 4, 390 image credit 7 | William Thompson 应为 William Thomson；Camridge 应为 Cambridge，格拉斯哥教席是自然哲学。 William Thomson held the chair of natural philosophy at Glasgow. Source: University of Glasgow, Lord Kelvin 200, https://www.gla.ac.uk/explore/lordkelvin200/about/ . |
| E1228 | 387, final theorem in second Remark 12.2.31 | 原书未限制密度指标 α。须取无限基数，与 Kleiber–Pervin 1969 年原定理一致；α=1 时函数空间含不同常函数，密度不为 1。 Require α to be infinite. For α=1 the continuous function space contains distinct constants and has no dense singleton. Source: Kleiber and Pervin, A generalized Banach–Mazur theorem (1969), https://doi.org/10.1017/S0004972700041411 . |
