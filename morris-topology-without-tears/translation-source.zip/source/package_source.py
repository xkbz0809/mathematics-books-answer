"""Package editable materials and source-page audit records without build caches."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
import argparse

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument("--release", action="store_true")
release=parser.parse_args().release
dest=root.parent/"交付"/"Morris-2024-08-06"
if not release:
    dest=dest/"阶段校样"
dest.mkdir(parents=True,exist_ok=True)
target=dest/("Morris-Source.zip" if release else "Morris-Source-Working.zip")
stage=target.with_suffix(".partial")
extensions={".tex",".py",".md",".csv",".json",".png",".jpg",".jpeg",".bib",".sty",".cls",".txt",".pdf"}
with ZipFile(stage,"w",compression=ZIP_DEFLATED,compresslevel=5) as archive:
    for p in sorted(root.rglob("*")):
        rel=p.relative_to(root)
        if not p.is_file() or p.suffix.lower() not in extensions:continue
        if any(s.casefold() in {"build","preview","renders","__pycache__","_build","work","qa-screens","qa","proof","previews","qa-build"} or s.startswith(".") for s in rel.parts):continue
        if p.name.startswith(("pass1","pass2","probe","proof-sheet")):continue
        if release and ("-Working" in p.name or p.name.lower() in {"chap-proof.tex","standalone.tex"}):continue
        if p.suffix.lower()==".pdf" and any(x in p.stem.lower() for x in ("review","proof","working","trial","check","morris-errata")):continue
        archive.write(p,Path("source")/rel)
with ZipFile(stage) as archive:
    bad=archive.testzip()
    if bad:sys.exit(f"Invalid archive entry: {bad}")
stage.replace(target)
print(f"{target.name}: {target.stat().st_size} bytes")
