"""Build and verify bilingual errata, with --release for the delivery copies."""
import argparse
from datetime import date
import json
import re
import shutil
import subprocess
import unicodedata
from pathlib import Path
import pymupdf
from pdf_entries import read_entries

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--release", action="store_true", help="publish the reviewed bilingual pair")
release=parser.parse_args().release

here = Path(__file__).resolve().parent
book = here.parents[1]
output = book / "交付" / "Morris-2024-08-06"
if not release:
    output /= "阶段校样"
build = here / "build"
output.mkdir(parents=True, exist_ok=True)
build.mkdir(exist_ok=True)
data = json.loads((here / "records.json").read_text(encoding="utf-8-sig"))
def source_order(entry):
    first=int(re.match(r"\d+",entry["pages"]).group())
    reference=re.search(r"\[(\d+)\]",entry["locator"]) if entry["id"].startswith(("EBB","EBF")) else None
    return first, int(reference.group(1)) if reference else 0

items = sorted(data["entries"], key=source_order)
ids = [e["id"] for e in items]
assert len(set(ids)) == len(ids)

# Chapter starts are the printed pages listed in this edition's contents (pp. 2–4).
SECTION_STARTS = [['0', 1], ['1', 24], ['2', 50], ['3', 72], ['4', 89], ['5', 110], ['6', 125], ['7', 176], ['8', 194], ['9', 222], ['10', 260], ['11', 339], ['12', 355], ['A1', 391], ['A2', 426], ['A3', 437], ['A4', 470], ['A5', 483], ['A6', 619], ['References', 672], ['Index', 705]]

def section_group(entry):
    first_page = int(re.match(r"\d+", entry["pages"])[0])
    return next(name for name, start in reversed(SECTION_STARTS) if first_page >= start)

def prose(value):
    """Keep authored TeX math. Display formula characters that came as plain Unicode."""
    if "$_$" in value:
        return r"\$\_\$".join(prose(piece) for piece in value.split("$_$"))
    links = list(re.finditer(r"\\url\{(https?://[^{}\s]+)\}|(https?://[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]+)", value))
    if links:
        chunks = []
        start = 0
        for link in links:
            chunks.append(prose(value[start:link.start()]))
            target = link[1] or link[2].rstrip(".,;:。，；、）”")
            if link[2]:
                while target.endswith(")") and target.count(")") > target.count("("):
                    target = target[:-1]
            chunks.append(r"\url{" + target + "}")
            if link[2]:
                chunks.append(prose(link[2][len(target):]))
            start = link.end()
        return "".join(chunks) + prose(value[start:])
    escaped = {"#": r"\#", "%": r"\%", "&": r"\&", "_": r"\_", "{": r"\{", "}": r"\}",
               "^": r"\textasciicircum{}", "~": r"\textasciitilde{}", "\\": r"\textbackslash{}"}
    segments = value.split("$")
    for i in range(0,len(segments),2):
        parts = []
        for ch in segments[i]:
            n=ord(ch)
            if (0x370<=n<=0x3ff or 0x2070<=n<=0x22ff or 0x1d00<=n<=0x1dff or n in (0xb1,0xb2,0xb3,0xb9)):
                parts.append(r"{\mathtextfont "+ch+"}")
            else:
                parts.append(escaped.get(ch,ch))
        segments[i]="".join(parts)
    return "$".join(segments)

chinese_locators = json.loads((here / "locator-zh.json").read_text(encoding="utf-8"))

def localized_locator(e,zh):
    locators={"A5.0.4 后 / after A5.0.4":("A5.0.4 后","after A5.0.4"),
                  "A5.0.7 后，例 (i) / following example (i)":("A5.0.7 后，例 (i)","A5.0.7, following example (i)"),
                  "A5.0.11 后 / after A5.0.11; A5.0.28(iii)":("A5.0.11 后；A5.0.28(iii)","after A5.0.11; A5.0.28(iii)"),
                  "Hilbert 段 / Hilbert paragraph":("希尔伯特生平段落","Hilbert paragraph")}
    raw=e["locator"]
    if not zh:
        return locators.get(raw,(raw,raw))[1]
    if e["id"] in chinese_locators:
        return chinese_locators[e["id"]]
    raw=locators.get(raw,(raw,raw))[0]
    raw=re.sub(r"^Bibliography\s*\[", "参考文献 [",raw)
    raw=re.sub(r"^Exercises? (A?\d+\.\d+),\s*", r"习题 \1，第 ",raw)
    raw=re.sub(r"^Ex\.\s+", "习题 ",raw)
    raw=raw.replace(", hints", "，提示").replace(", hint", "，提示")
    raw=raw.replace(" and ", "、")
    return raw

def generate(language):
    zh = language == "ZH"
    chapters=sorted({section_group(e) for e in items}, key=lambda x:(2,0) if x in ("Index","References") else (x.startswith("A"),int(x.lstrip("A"))))
    scope=', '.join(x for x in chapters if x[0].isdigit() and x!="0")
    appendices=', '.join(x[1:] for x in chapters if x.startswith("A"))
    zh_front="书前材料、" if "0" in chapters else ""
    en_front="the front matter, " if "0" in chapters else ""
    zh_backmatter="、参考文献及书末索引" if "References" in chapters else "及书末索引"
    en_backmatter=", the bibliography, and the index" if "References" in chapters else ", and the index"
    reviewed=date.fromisoformat(data["review_date"])
    if zh:
        header="中文勘误" if release else "中文勘误校样"
        subtitle="原书勘误" if release else "阶段校样"
        record_date=f"核查日期（北京时间）为 {reviewed.year} 年 {reviewed.month} 月 {reviewed.day} 日。"
        coverage=f"本册列出 {len(items)} 条已确认的原书勘误，分布于{zh_front}第 {scope} 章、附录 {appendices}{zh_backmatter}。印刷页与从 1 开始的 PDF 顺序页在所列位置相同。每条附有原书表述、修订与依据。"
    else:
        header="Errata" if release else "Errata working edition"
        subtitle="Corrections to the source edition" if release else "Working edition"
        record_date=f"Review date (Beijing time): {reviewed.day} {reviewed.strftime('%B %Y')}."
        coverage=f"This edition lists {len(items)} confirmed corrections in {en_front}Chapters {scope}, Appendices {appendices}{en_backmatter}. The printed page and the one-based PDF page coincide at every cited location. Each entry gives the source wording, the correction, and its basis."
    text = [r"\documentclass[UTF8,11pt,fontset=fandol]{ctexart}" if zh else r"\documentclass[11pt]{article}",
        r"\usepackage[a4paper,margin=24mm,top=22mm,bottom=22mm]{geometry}",
        r"\usepackage{amsmath,amssymb,mathtools,enumitem,fancyhdr,fontspec,xcolor}",
        r"\usepackage[hidelinks,unicode,bookmarksnumbered]{hyperref}",
        r"\makeatletter\g@addto@macro\UrlBreaks{\do\a\do\b\do\c\do\d\do\e\do\f\do\g\do\h\do\i\do\j\do\k\do\l\do\m\do\n\do\o\do\p\do\q\do\r\do\s\do\t\do\u\do\v\do\w\do\x\do\y\do\z\do\A\do\B\do\C\do\D\do\E\do\F\do\G\do\H\do\I\do\J\do\K\do\L\do\M\do\N\do\O\do\P\do\Q\do\R\do\S\do\T\do\U\do\V\do\W\do\X\do\Y\do\Z\do\0\do\1\do\2\do\3\do\4\do\5\do\6\do\7\do\8\do\9}\makeatother",
        r"\newcommand{\Needspace}[1]{\par\begingroup\dimen0=\pagegoal\advance\dimen0 by -\pagetotal\ifdim\dimen0<#1\newpage\fi\endgroup}",
        r"\setmainfont{TeX Gyre Pagella}", r"\IfFontExistsTF{Cambria Math}{\newfontfamily\mathtextfont{Cambria Math}}{\newfontfamily\mathtextfont{TeX Gyre Pagella Math}}",
        r"\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Topology Without Tears}\fancyfoot[C]{\thepage}",
        r"\fancyhead[R]{\small " + header+r"}",
        r"\setlength{\headheight}{14pt}\setlength{\parindent}{0pt}\setlength{\parskip}{3pt}\setlength{\emergencystretch}{2em}\raggedbottom",
        r"\definecolor{ink}{HTML}{254B52}",
        r"\begin{document}",
        r"{\LARGE\bfseries " + ("《无泪拓扑学》中文勘误" if zh else "Topology Without Tears: Errata") + r"\par}",
        r"\vspace{3mm}{\large " + subtitle+r"\par}",
        "Sidney A. Morris · " + ("原书版本 2024 年 8 月 6 日" if zh else "Source version of 6 August 2024") + r"\par",
        record_date, coverage,
        (data["author_errata_check"]["zh" if zh else "en"] + r" \url{"+data["author_site"]+"}"+r"\par") if release else r"\relax",
        r"\medskip\hrule\medskip"]
    outline=[]
    previous = None
    for e in items:
        group = section_group(e)
        if group != previous:
            isapp=group.startswith("A")
            name=(("附录 "+group[1:] if isapp else "第 "+group+" 章") if zh else ("Appendix "+group[1:] if isapp else "Chapter "+group))
            if group=="0": name="书前材料" if zh else "Front matter"
            if group=="Index": name="索引" if zh else "Index"
            if group=="References": name="参考文献" if zh else "Bibliography"
            text += [r"\Needspace{9\baselineskip}",r"\section*{"+name+r"}\addcontentsline{toc}{section}{"+name+"}"]
            outline.append(name)
            previous = group
        locator=localized_locator(e, zh)
        cite=prose(locator).replace("–","--")
        page=e["pages"].replace("–","--")
        loc=e["zh_type"] if zh else e["en_type"]
        suffix=("印刷页及 PDF 页 " if zh else "Printed/PDF p. ")+page
        text += [r"\Needspace{6\baselineskip}",
                 r"{\large\bfseries\color{ink} "+e["id"]+r"}\quad\textbf{"+cite+r"}\quad "+loc+r"\par",
                 r"{\small "+suffix+r"}\par",
                 r"\textbf{"+("原书表述" if zh else "As printed")+r"}\quad "+prose(e["zh_original" if zh else "en_original"])+r"\par",
                 r"\textbf{"+("修订与理由" if zh else "Correction and reason")+r"}\quad "+prose(e["zh_correct" if zh else "en_correct"])+r"\par",
                 r"\smallskip"]
    if release:
        pending=data["items_to_verify"]
        name="待核事项" if zh else "Items to verify"
        text += [r"\Needspace{5\baselineskip}",r"\section*{"+name+r"}\addcontentsline{toc}{section}{"+name+"}"]
        outline.append(name)
        if pending:
            for item in pending:
                text.append(prose(item["zh" if zh else "en"])+r"\par")
        else:
            text.append("本次勘误记录中待核事项为 0 条。" if zh else "The errata register contains no unresolved items.")
    text.append(r"\end{document}")
    return "\n".join(text)+"\n",outline

candidates=[]
for language in ("ZH","EN"):
    name=f"Morris-Errata-{language}"+("" if release else "-Working")
    tex=here/(name+".tex")
    body,outline = generate(language)
    tex.write_text(body, encoding="utf-8")
    for _ in range(2):
        cmd=["xelatex","-interaction=nonstopmode","-halt-on-error","-file-line-error",
             "-output-directory="+str(build),tex.name]
        result=subprocess.run(cmd,cwd=here,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(result.stdout.decode("utf-8", "replace")[-4500:])
    candidate=build/(name+".pdf")
    with pymupdf.open(candidate) as pdf:
        printed = read_entries(pdf)
        matches = [entry_id for entry_id, _ in printed]
        if matches != ids:
            raise ValueError(f"{language}: printed headings differ: {matches}")
        blocks = [body for _, body in printed]
        def normalized(value):
            return re.sub(r"[^\w\u3400-\u9fff]","",unicodedata.normalize("NFKC",value)).casefold()
        for record,block in zip(items,blocks):
            marker=r"印刷页及\s*PDF\s*页\s*" if language=="ZH" else r"Printed/PDF p\.\s*"
            expected=re.sub(r"\s","",record["pages"]).replace("–","-")
            locator=localized_locator(record,language=="ZH")
            match=re.search(marker+r"([0-9][0-9, \-–]*)",block)
            if not match or re.sub(r"\s","",match.group(1)).replace("–","-")!=expected:
                raise ValueError(f"{language} {record['id']}: incorrect printed/PDF pages {block[:190]}")
            if normalized(locator) not in normalized(block[:match.start()]):
                raise ValueError(f"{language} {record['id']}: cannot find locator {locator} in {block[:match.start()]}")
        bookmarks=pdf.get_toc(simple=False)
        if [item[1] for item in bookmarks]!=outline:
            raise ValueError(f"{language}: PDF outline does not match the group headings: {bookmarks}")
        for level, label, page_number, link in bookmarks:
            if level!=1 or link.get("page")!=page_number-1 or not 1<=page_number<=len(pdf):
                raise ValueError(f"{language}: invalid bookmark target for {label}: {link}")
            page=pdf[page_number-1]
            lines=(line for block in page.get_text("dict")["blocks"] for line in block.get("lines",[]))
            ys=[line["bbox"][1] for line in lines if normalized("".join(span["text"] for span in line["spans"]))==normalized(label)]
            target=link["to"]
            if link["kind"]==pymupdf.LINK_NAMED:
                target=target*page.transformation_matrix
            if not ys or not any(abs(target.y-y)<45 for y in ys):
                raise ValueError(f"{language}: bookmark {label} misses heading on page {page_number}: {link}, {ys}")
        print(name,len(pdf),"pages",len(matches),"entries",len(bookmarks),"bookmarks",flush=True)
    candidates.append((name,candidate))

for name,candidate in candidates:
    staging=output/(name+".new.pdf")
    shutil.copyfile(candidate,staging)
    staging.replace(output/(name+".pdf"))

