# 双语勘误维护

本目录适用 Sidney A. Morris 的 *Topology Without Tears*，2024 年 8 月 6 日版。原件共 729 个 PDF 页面，封面不印页码，其余印刷页与 PDF 顺序页相同。

`records.json` 是正式版与阶段校样共同的条目来源。记录各有稳定编号、对应印刷页和 PDF 页、节或题号定位、类型、分别用中英文写出的原文短摘和修订依据。书目中的拼写、年份和索引按原书出现处定位。编号一经分配予以保留，复核撤销的编号停用。例如 E5A54 已依据原页上的闭包上划线撤销。已确认错误的建议修法可在记录中注明。仍须辨读或证明错误本身的事项另存于 `items_to_verify`。

在本目录运行以下命令，须安装 Python、PyMuPDF、XeLaTeX、Fandol 字体及 TeX Gyre 系列字体。

```powershell
python build.py --release
```

该命令对两种语言各编译两遍，再逐条从两份输出 PDF 中核对编号、定位、页码及条目顺序，并验证每个分组书签的名称和跳转坐标。全部通过后写入本书交付目录。省略 `--release` 可生成阶段校样。`import_records.py` 可从分章记录导入九个条目字段，使用 `--refresh` 时以指定来源重置重复编号的字段；合并后应对照各章勘误及译注核查已撤销条目。

```powershell
python import_records.py --refresh ..\ch10\errata.json
```
