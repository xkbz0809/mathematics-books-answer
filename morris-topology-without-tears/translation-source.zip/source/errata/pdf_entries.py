"""Locate printed erratum headings without mistaking references in prose for entries."""
import re

IDENTIFIER = re.compile(r"E(?:A?\d{3,4}|\d+[A-Z]\d+|[A-Z]{2,}\d+)")


def read_entries(pdf):
    entries = []
    for page in pdf:
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line["spans"]:
                    text = span["text"]
                    label = text.strip()
                    if IDENTIFIER.fullmatch(label) and span["color"] == 0x254B52 and "Bold" in span["font"]:
                        entries.append((label, []))
                    elif entries:
                        entries[-1][1].append(text)
                if entries:
                    entries[-1][1].append("\n")
    return [(label, "".join(parts)) for label, parts in entries]
