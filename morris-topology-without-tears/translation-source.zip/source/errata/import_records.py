"""Merge reviewed section records into the working edition's canonical record set."""
import argparse
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("sources", nargs="+", type=Path)
parser.add_argument("--refresh", action="store_true", help="replace existing entries with the same ID")
args = parser.parse_args()
path = Path(__file__).resolve().with_name("records.json")
data = json.loads(path.read_text(encoding="utf-8-sig"))
entries = {e["id"]: e for e in data["entries"]}
keys = tuple(data["entries"][0])
for source in args.sources:
    payload = json.loads(source.read_text(encoding="utf-8-sig"))
    incoming = payload["entries"] if isinstance(payload, dict) else payload
    for entry in incoming:
        if entry.get("id") in data.get("withdrawn",{}):
            continue
        if not all(isinstance(entry.get(key),str) and entry[key].strip() for key in keys):
            raise ValueError(f"{source}: invalid or missing field in {entry.get('id')}")
        if args.refresh or entry["id"] not in entries:
            entries[entry["id"]] = {key: entry[key] for key in keys}
def source_order(entry):
    first=int(re.match(r"\d+",entry["pages"]).group())
    reference=re.search(r"\[(\d+)\]",entry["locator"]) if entry["id"].startswith(("EBB","EBF")) else None
    return first, int(reference.group(1)) if reference else 0

data["entries"] = sorted(entries.values(),key=source_order)
tmp = path.with_suffix(".new.json")
tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tmp.replace(path)
print(len(entries), "records in", path)
