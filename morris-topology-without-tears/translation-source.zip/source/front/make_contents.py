"""Rebuild the original edition's contents with Chinese headings and original locators."""
from pathlib import Path
import pymupdf

root=Path(__file__).resolve().parent
d=pymupdf.open(root.parent.parent/"topology with tears.pdf")
chap=-1
sections=[
["引言","致谢","读者的地区和职业","读者来信","使用超链接的小技巧","作者","图片来源"],
["拓扑空间","拓扑","开集","余有限拓扑","后记"],
["欧氏拓扑","欧氏拓扑","拓扑的基","给定拓扑的基","后记"],
["极限点","极限点与闭包","邻域","连通性","后记"],
["同胚","子空间","同胚","不同胚的空间","后记"],
["连续映射","连续映射","介值定理","后记"],
["度量空间","度量空间","序列的收敛","完备性","压缩映射","贝尔空间","后记"],
["紧性","紧空间","海涅–博雷尔定理","后记"],
["有限积","积拓扑","积到因子的投影","有限积的吉洪诺夫定理","积与连通性","代数基本定理","后记"],
["可数积","康托尔集","积拓扑","康托尔空间与希尔伯特立方体","乌雷松定理","皮亚诺定理","后记","图片来源"],
["吉洪诺夫定理","任意积的积拓扑","佐恩引理","吉洪诺夫定理","斯通–切赫紧化","后记","图片来源"],
["商空间","商空间","粘合空间","莫比乌斯带、克莱因瓶与实射影空间","后记","图片来源"],
["斯通–魏尔斯特拉斯定理","魏尔斯特拉斯逼近定理","斯通–魏尔斯特拉斯定理","图片来源"]]
back=["附录 1　无穷集合","附录 2　拓扑学人物","附录 3　混沌理论与动力系统","附录 4　豪斯多夫维数","附录 5　拓扑群研究生课程","附录 6　滤子与网","参考文献","索引"]
out=[r"\chapter*{原书目录}",r"\addcontentsline{toc}{chapter}{原书目录}",
     "本目录所列为 2024 年 8 月 6 日原书的印刷页码。译稿本身的页码见前面的目录。",
     r"\begin{longtable}{@{}p{.81\linewidth}r@{}}"]
for level,name,page in d.get_toc():
    if level==1:
        chap+=1
        part=0
        title=(str(chap)+"　"+sections[chap][0]) if chap<len(sections) else back[chap-len(sections)]
        out.append(r"\textbf{"+title+r"} & \textbf{"+str(page)+r"}\\*")
    elif level==2:
        part+=1
        out.append(r"\quad "+f"{chap}.{part}　"+sections[chap][part]+" & "+str(page)+r"\\")
    else:raise ValueError(name)
out.append(r"\end{longtable}")
(root/"original-contents.tex").write_text("\n".join(out)+"\n",encoding="utf-8")
