# 第三章原页及复核

版本为2024年8月6日。第72–88页，原书页与PDF顺序页一致；页面无照片或示意图。

**E301　原书及 PDF 第 85 页，注 3.3.1，最小上界公理后段末句。** 原文从 “Any set S of real numbers which is bounded below” 起，断言任意有下界的实数集有最大下界。应将 “Any set” 改为 “Any non-empty set”。每个实数都是空集的下界，实数全体却没有最大元。正文已加译注，习题 3.3 第 1(b) 题自身写明非空。

**E301　English erratum.** August 6, 2024 version, printed/PDF page 85, Remark 3.3.1, last sentence of the paragraph following the Least Upper Bound Axiom. Change “Any set” to “Any non-empty set”. Every real number is a lower bound for the empty set, so its lower bounds have no greatest element. Exercise 3.3, 1(b) includes the required hypothesis.

题号已核对。第 80 页第 6 题的四种闭包运算、第 82–84 页各闭包横线和第 87 页第 2(iv) 题的分母已对照同版页图。第 3.3 第 6 题分别处理可数无穷和不可数的底集。

**E302　原书及 PDF 第 75、76 页，例 3.1.4 和例 3.1.7(i)–(iii)。** 补条件 $a<b$。当 $a=b$ 时，$[a,b)$ 与 $(a,b)$ 都是空闭集，$[a,a]$ 为没有极限点的单点集。原书第 54 页例 2.1.2(viii) 明确允许闭区间退化。后例 (iv) 无需此限制。

**E302　English erratum.** Printed/PDF pages 75–76, Examples 3.1.4 and 3.1.7(i)–(iii). Assume $a<b$. For $a=b$, the half-open and open intervals are empty and closed, and the singleton $[a,a]$ has no limit points. Compare Example 2.1.2(viii) on page 54.
