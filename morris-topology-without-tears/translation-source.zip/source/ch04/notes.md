# 第四章审读记录

Sidney A. Morris, Topology Without Tears, 2024-08-06。本章对应原书印刷页与 PDF 顺序页 89–109。三组正式习题分别为 17、8、10 题，共 35 题，全部小问均有中文解答。4.3 第 7 题另核对 31–32 页的五个拓扑。

## E401
印刷/PDF 第 99 页，例 4.2.5，证明提纲。原文 “a diagrammatic argument like that in Example 4.2.2”。例 4.2.2（第 97 页）证明同胚的复合，未使用图形；图示开区间的像和原像见第 98 页例 4.2.4，应把例号改为 4.2.4。
English: Page 99 (PDF 99), Example 4.2.5, outline proof. Change the reference to Example 4.2.4. Example 4.2.2 establishes transitivity without a diagram, whereas Example 4.2.4 uses the graph to describe the images and inverse images of open intervals.

## E402
印刷/PDF 第 104 页定义 4.3.3 及注 4.3.4(iii)、第 106 页习题 4.3 第 1 题、第 109 页后记。定义写 “A subset S ... is said to be an interval if ...”，未写非空。空集真空地满足定义，却不能同胚于所列四种非空模型的任何一个。可选修法一：定义中要求非空，与本书定义 4.1.1 的非空子空间惯例及四类结论相合；修法二：保留空区间，分类增列空集。译文采用第一种，并附注说明。
English: Pages 104, 106 and 109 (same PDF pages), Definition 4.3.3, Remark 4.3.4(iii), Exercise 4.3 no. 1 and Postscript. The order-convexity condition also holds for the empty set, which is not homeomorphic to any of the four listed models. Require a nonempty subset in the definition, consistently with the nonempty subspace convention in Definition 4.1.1; alternatively include the empty set as a fifth type.

4.3 第 8 题的递降闭集构造不需额外分离公理；第（iv）问采用该空间特殊化偏序，并给出无穷拉姆齐二元着色法的直接论证。

## E403
印刷/PDF 第 105 页注 4.3.6。原注说删去一点后得到子空间；若 X 为单点，两边都是空集，违反本书第 25 页及第 91 页对空间与子空间所作的非空约定。为符合本书约定应补 X 至少有两点；若允许空拓扑空间，原结论仍然成立。
English: Page 105 (PDF 105), Remark 4.3.6. In the singleton case the punctured sets are empty. They are not subspaces under the book's nonempty convention in Definitions 1.1.1 and 4.1.1. Assume the space has at least two points; this qualification is unnecessary under the alternative convention allowing empty spaces.

## 2026-11-27 独立复查

新增 E404（第 91、97 页，三处已定义拓扑的符号）与 E405（第 109 页后记的两个前指），详见本章 round2-errata.json。按原页补全解答星号，复算第 4.3 组第 1 题的开射线与第 5 题四条连通分支。原页 91–92 的截基与删去空集的基已明确区分。
