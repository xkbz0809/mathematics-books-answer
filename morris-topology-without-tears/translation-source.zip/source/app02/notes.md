# 附录二　原页与复核

Sidney A. Morris, Topology Without Tears, 2024-08-06。单卷，印刷页及 PDF 顺序页 426–436 相同。第426页为本附录目录。427–435页为六人传记、图注与引文；435–436页为六幅肖像的图片来源。图像均从本版嵌入对象裁出。此附录未设正式习题。完整双语勘误见 errata.json。

|编号|页|核查定位与论据|资料|
|---|---|---|---|
|E2A01|428|Stefan Banach, opening paragraph。原书称巴拿赫生于奥斯特罗夫斯科。1892 年出生地为克拉科夫圣拉撒路医院。家族史料将奥斯特罗夫斯科记为其父亲出生地。|https://kielich.amu.edu.pl/Stefan_Banach/e-biography.html|
|E2A02|428|Stefan Banach, Banach–Tarski paper。所引论文署 1926，法文题名中印作 partiens、congruent。期刊原卷为 Fundamenta Mathematicae 6 (1924), 244–277，题名 Sur la décomposition des ensembles de points en parties respectivement congruentes。|https://doi.org/10.4064/fm-6-1-244-277|
|E2A03|430|Brouwer, fixed-point theorem, paragraph after van der Waerden quotation。原书先称保定向球面连续单射有不动点，接着称从二维推广到 n 维，未说明奇偶性。偶维球面的保定向自同胚有不动点。奇维球面的对径映射度为 (−1)^(n+1)=1，保定向且无不动点；S¹ 上的非平凡旋转已构成反例。|https://www.ams.org/bookstore/pspdf/gsm-108-prev.pdf|
|E2A04|432|Felix Hausdorff, Leipzig to Bonn。原书称豪斯多夫 1910 年得波恩大学讲席。波恩大学记载他在 1910 年任副教授，1913 年在格赖夫斯瓦尔德始获正教授职，1921 年重返波恩。|https://www.mathematics.uni-bonn.de/hcm/felix-hausdorff/about-felix-hausdorff|
|E2A05|432|Felix Hausdorff, final sentence。原书作“his wife and sister”。第三人伊迪特·帕彭海姆是妻子的妹妹，即豪斯多夫的姻亲。|https://www.sammlungen.ulb.uni-bonn.de/de/historische-sammlungen/nachlaesse/hausdorff-felix|
|E2A06|434|Wacław Sierpiński, Egorov after the Viatka passage。原书把叶戈罗夫的父称写作 Feddrovich。按标准转写应为 Fedorovich。|https://mathshistory.st-andrews.ac.uk/Biographies/Egorov/|
|E2A07|434–435|Wacław Sierpiński, foundation of the journal and later mentions。原书称期刊 Fundamenta Mathematica。正式刊名为 Fundamenta Mathematicae。谢尔宾斯基、马祖尔凯维奇和亚尼谢夫斯基共同筹办，创刊号于 1920 年在亚尼谢夫斯基去世后出版。|https://archiwum.pan.pl/images/wydawnictwa/biuletynnr%2049-internet.pdf|
|E2A08|434|Wacław Sierpiński, paragraph on the space-filling curve。把正方形面积的 5/12 说成填充空间的极限曲线所围的面积。5/12 指闭多边形逼近序列所围面积的极限。曲线像充满正方形，像的二维测度等于整个正方形的面积；其像不是简单闭曲线。|https://mathworld.wolfram.com/SierpinskiCurve.html|
|E2A11|434|Wacław Sierpiński, scientific societies paragraph。写作 1928 年出任华沙科学学会副主席，并以笼统的 Polish Academy 指 1921 年的学术院。华沙科学学会副主席任期为 1925–1931 年。1928 年对应波兰数学会主席任职。1921 年当选的是波兰学术院 PAU 正式院士；另一个机构波兰科学院 PAN 成立于 1952 年。|https://gigancinauki.pl/gn/biogramy/84184%2CSierpnski-Waclaw-Franciszek.html；https://rcin.org.pl/Content/14907/WA488_5873_P1765_R1945-1946-RPAU.pdf|
|E2A09|435|Wacław Sierpiński, quoted 1945 lecture。引文记萨克斯在 1943 年遇害，林登鲍姆在 1942 年遇害。为忠实于讲词，保留原引文，加注萨克斯的遇害日为 1942-11-23；波兹南大学数学年表将林登鲍姆遇害年记为 1941，确切日期尚有分歧。|https://www.ipsb.nina.gov.pl/a/biografia/stanislaw-saks；https://wmi.amu.edu.pl/__data/assets/pdf_file/0025/219085/2004-maj.pdf|
|E2A10|435|Wacław Sierpiński, editorial boards。期刊名印成 Rendiconti dei Circolo Matimatico di Palermo。核正式刊名，应为 Rendiconti del Circolo Matematico di Palermo。|https://portal.issn.org/resource/issn/1973-4409|
