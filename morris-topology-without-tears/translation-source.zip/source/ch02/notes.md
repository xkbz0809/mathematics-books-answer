# 第 2 章核查记录

Sidney A. Morris, Topology Without Tears, 2024-08-06，全书单卷。第 2 章印刷页及 PDF 顺序页 50–71。语言与学科术语依本章定义核对；四图自 PDF 60、66、67、67 以 400 dpi 裁取。习题 2.1 第 1–8 题在 55 页，2.2 第 1–3 题在 61 页（第 3 题提示续 62 页）、第 4–5 题在 62 页、第 6–7 题在 63 页；2.3 第 1–4 题在 68 页、第 5–12 题在 69 页。共 27 题。第 2.3 组第 4 题带星。附录或同书其他章节另计。

|编号|本版原页定位及短摘|修正及理由|English|
|---|---|---|---|
|E201|60，例 2.2.9，“the intersection of any two rectangles is a rectangle”|两轴平行开矩形的交为空或仍为此种矩形。例如 (0,1)² 与 (2,3)² 的交为空。空集为基元素的空并。|The intersection of two axis-parallel open rectangles is either empty or another such rectangle. Disjoint rectangles give the missing case and the empty union suffices.|
|E202|63，例 2.3.1，“the intersection of any two half-open intervals is a half-open interval”|如 (0,1] 与 (1,2] 不交。非空时交为 (max(a,c),min(b,d)]，否则为空并。|Two left-open right-closed intervals may be disjoint. If their intersection is nonempty it is of the same form.|
|E203|65，命题 2.3.4 证明最后一段，“By Proposition 2.3.2”|已知某集合每一点都有包含于它的基邻域，推出该集合开，应直接引命题 2.3.3。2.3.2 的结论是对给定开集族判别它是否为基。|Cite Proposition 2.3.3, the pointwise criterion that recognizes an arbitrary subset as open, in the converse implication.|
|E204|66，例 2.3.5，“the intersection of two such triangles is another such triangle”|可能不相交；即使非空，取以原点为重心、底边水平、指向相反的两个全等开等边三角形，可得开正六边形。交中每点距两者各边界均为正，可在其内放入以该点为重心的同类小三角形，所以交是基元素的并。|Their intersection can be empty, or an open regular hexagon for two congruent co-centred triangles with opposite orientations. Every point of the intersection lies in a sufficiently small triangle of the stated family contained in the intersection.|

以上四条由另一位审读者独立复核。原题第 2.3 组第 12 题中，圆心限于横轴，解答给出全部关于横轴对称的子集，上下两点对可由两个不同圆心的圆周相交得到；横轴上的点在同一构造下成为单点。没有待解的习题。

## 2026-11-27 独立复查

上一轮另记 E205（第 55 页习题 2.1 第 8(iii) 题，详见 review-errata.json）。本轮新增 E206（第 63 页第 2.3 节引言，详见 round2-errata.json）；必须核实候选基元在给定拓扑中开。习题 2.1 第 8(i) 题补退化区间，第 2.2 组第 2(i) 题补真包含见证。
