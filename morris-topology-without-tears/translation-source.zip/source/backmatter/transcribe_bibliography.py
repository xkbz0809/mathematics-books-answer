"""Reconcile all 429 numbered bibliography entries against the supplied PDF."""
from pathlib import Path
import re
import json
import pymupdf

folder=Path(__file__).resolve().parent
doc=pymupdf.open(folder.parent.parent/"topology with tears.pdf")
items=[]
for i in range(671,704):
    page=doc[i]
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines",[]):
            if line["bbox"][1]<70 or line["bbox"][1]>748: continue
            value="".join(span["text"] for span in line["spans"]).strip()
            if not value or value.lower()=="bibliography" or value==str(i+1): continue
            m=re.match(r"^\[(\d+)\]\s*(.*)$",value)
            if m:
                number=int(m[1])
                if len(items)+1!=number: raise ValueError((i+1,number,len(items)))
                items.append(dict(number=number,pages=[i+1],lines=[m[2]]))
            elif items:
                if i+1!=items[-1]["pages"][-1]:items[-1]["pages"].append(i+1)
                items[-1]["lines"].append(value)
if len(items)!=429:raise ValueError(len(items))
def escape(txt):
    table={"&":r"\&","%":r"\%","_":r"\_","#":r"\#","{":r"\{","}":r"\}","$":r"\$","~":r"\textasciitilde{}","^":r"\textasciicircum{}","\\":r"\textbackslash{}"}
    table.update({"σ": r"\(\sigma\)", "ω": r"\(\omega\)", "∗": r"\({}^\ast\)"})
    return "".join(table.get(c,c) for c in txt)

def typeset_reference(raw):
    pieces = []
    start = 0
    for match in re.finditer(r"(?:https?://|www\.)[^\s]+", raw):
        pieces.append(escape(raw[start:match.start()]))
        token = match[0]
        link = token.rstrip(".,;")
        if link.endswith(")") and link.count("(") < link.count(")"):
            link = link[:-1]
        pieces.append(r"\url{" + link + "}" + escape(token[len(link):]))
        start = match.end()
    pieces.append(escape(raw[start:]))
    return "".join(pieces).replace(r"\(\omega\)\(\omega\)", r"\(\omega^\omega\)")
tex=[r"\chapter*{参考文献}",r"\addcontentsline{toc}{chapter}{参考文献}",r"\begin{list}{}{\setlength{\leftmargin}{3.6em}\setlength{\labelwidth}{3em}\setlength{\itemsep}{.4em}}"]
def review_records():
    by_number = {}
    for file in sorted(folder.glob("bibliography-*-edits.json")):
        for entry in json.loads(file.read_text(encoding="utf-8")):
            by_number.setdefault(entry["number"], []).append(entry)
    return by_number


def normalize_layout(raw):
    for broken, joined in [
        ("Arkhangel’skiˇi", "Arkhangel’skiǐ"), ("K¸akol", "Kąkol"),
        ("Springer- Verlag", "Springer-Verlag"), ("ωω- bases", "ωω-bases"),
        ("infinite- dimensional", "infinite-dimensional"), ("Holden- Day", "Holden-Day"),
        ("North- Holland", "North-Holland"), ("self- similarity", "self-similarity"),
        ("18-091Spring--2005/ A335FB2E", "18-091Spring--2005/A335FB2E"),
    ]:
        raw = raw.replace(broken, joined)
    return raw


changes = review_records()
errata = []
for item in items:
    raw=" ".join(item["lines"])
    raw=re.sub(r"((?:https?://|www\.)\S+[-/.])\s+([A-Za-z0-9_]+(?:\.html?|\.pdf)?(?=[\s.,]|$))",r"\1\2",raw)
    item["text"]=raw
    display = raw
    notes = []
    for correction in changes.get(item["number"], []):
        for printed, corrected in correction["edits"]:
            if display.count(printed) != 1:
                raise ValueError((item["number"], printed, display))
            display = display.replace(printed, corrected)
        before = correction.get("original") or " | ".join(edit[0] for edit in correction["edits"])
        after = correction.get("corrected") or " | ".join(edit[1] for edit in correction["edits"])
        before = before.rstrip(". ")
        after = after.rstrip(". ")
        sources = [correction["url"]]
        if correction.get("source2"):
            sources.append(correction["source2"])
        source_list = " ".join(dict.fromkeys(sources))
        errata.append(dict(id=correction["id"], pages=correction.get("all_pages") or ", ".join(map(str,item["pages"])),
            locator=correction.get("locator") or "Bibliography ["+str(item["number"])+"]", zh_type="书目数据",
            en_type="Bibliographic data", zh_original=before, en_original=before,
            zh_correct=after+"。"+correction["zh"]+" 核据 "+source_list,
            en_correct=after+". "+correction["en"]+" Source "+source_list))
        notes.append(r"\footnote{译注·"+correction["id"]+"。原书作 "+
                     escape(before)+"。"+escape(correction["zh"])+"}")
    item["display_text"] = normalize_layout(display)
    entry = typeset_reference(item["display_text"])
    if item["number"] == 351:
        entry = entry.replace("space X for which X×I",r"space \(X\) for which \(X\times I\)")
    if item["number"] == 371:
        entry = entry.replace("x5 + ax + b",r"\(x^5+ax+b\)")
    tex.append(r"\item[{\normalfont["+str(item["number"])+r"]}]\phantomsection\label{bib:"+str(item["number"])+"} "+entry+"".join(notes))
(folder/"bibliography-errata.json").write_text(json.dumps(errata,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
tex.append(r"\end{list}")
(folder/"bibliography.tex").write_text("\n".join(tex)+"\n",encoding="utf-8")
(folder/"bibliography-source.json").write_text(json.dumps(items,ensure_ascii=False,indent=1),encoding="utf-8")
print("Bibliography",len(items))
