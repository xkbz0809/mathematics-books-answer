"""Build a specified run of reviewed chapters; keep draft scope visible on the title page."""
from pathlib import Path
import argparse
import shutil
import subprocess
import pymupdf
from link_book import linked_body
from solution_navigation import enrich

root = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument("kind", choices=("Translation", "Solutions"))
p.add_argument("--through", type=int, required=True)
p.add_argument("--extra-chapters", type=int, nargs="*", default=[])
p.add_argument("--appendices", type=int, nargs="*", default=[])
p.add_argument("--bibliography", action="store_true")
p.add_argument("--index", action="store_true")
p.add_argument("--release", action="store_true", help="build the entire volume and publish after verification")
args = p.parse_args()
end = args.through
kind = args.kind
if not 1 <= end <= 12:
    p.error("--through must be a chapter number from 1 to 12")
chapters = sorted(set(range(1, end + 1)).union(args.extra_chapters))
appendices = sorted(set(args.appendices))
if args.release:
    if end != 12:
        p.error("the full volume needs --through 12")
    appendices = list(range(1,7))
    args.bibliography = kind == "Translation"
    args.index = kind == "Translation"
if any(n < 1 or n > 12 for n in chapters) or any(n < 1 or n > 6 for n in appendices):
    p.error("chapter or appendix number outside this edition")
if kind == "Solutions":
    appendices = [n for n in appendices if n >= 3]
scope = f"第 1 至 {end} 章" + "".join(f"、第 {i} 章" for i in chapters if i > end)
if appendices:
    scope += "，附录 " + "、".join(map(str, appendices))
if kind == "Translation":
    scope = "扉页、引言，" + scope
    if args.bibliography:
        scope += "，参考文献"
    if args.index:
        scope += "，索引"

book = root.parent / "topology with tears.pdf"
for asset in (21,23,25,27,32,37,39,41,11281):
    target = root / "front" / f"img-{asset}.png"
    if not target.exists():
        with pymupdf.open(book) as doc:
            pymupdf.Pixmap(doc,asset).save(target)

body = [r"\documentclass[UTF8,11pt,openany,fontset=fandol]{ctexbook}",
        r"\input{shared}",r"\begin{document}"]
if args.release:
    body.insert(2, r"\renewcommand{\morriseditionstamp}{中文编译本 · 2026 年 11 月 27 日}")
if kind == "Translation":
    title = "中文译本" if args.release else "中文译稿校样"
    if args.release:
        scope = "全十二章、六篇附录、参考文献及索引"
    body.extend([rf"\proofcover{{{title}}}{{{scope}}}",r"\tableofcontents",
                 r"\input{front/opening}",r"\input{front/front-extra}",r"\input{front/readers}",r"\input{front/author}"])
else:
    title = "习题解答" if args.release else "习题解答校样"
    if args.release:
        scope = "正文与附录的 67 组习题 · 602 道"
    body.extend([rf"\proofcover{{{title}}}{{{scope}}}",r"\tableofcontents"])
for chap in chapters:
    path = f"ch{chap:02}"
    body.append(rf"\setcounter{{chapter}}{{{chap-1}}}")
    if kind == "Solutions" and chap == 1:
        body.extend([r"\chapter{拓扑空间}",r"\input{ch01/solutions11}",r"\setcounter{section}{1}"])
    if kind == "Solutions" and chap == 12:
        if r"\chapter" not in (root/path/"solutions.tex").read_text(encoding="utf-8-sig"):
            body.append(r"\chapter{斯通--魏尔斯特拉斯定理}")
    name = "text" if kind == "Translation" else "solutions"
    body.append(rf"\input{{{path}/{name}}}")
    if chap == 1 and kind == "Translation":
        primary = (root/path/"text.tex").read_text(encoding="utf-8-sig")
        for leaf in ("sec12","sec13"):
            if (root/path/(leaf+".tex")).exists() and leaf not in primary and not (leaf=="sec12" and "label{sec:open-sets}" in primary):
                body.append(rf"\input{{{path}/{leaf}}}")
for n in appendices:
    name = "text" if kind == "Translation" else "solutions"
    body.append(rf"\input{{app{n:02}/{name}}}")
if kind == "Translation":
    for use, item in ((args.bibliography, "bibliography"), (args.index, "index")):
        if use:
            body.append(rf"\input{{backmatter/{item}}}")
body.append(r"\end{document}")
name = "Morris-"+kind+"-ZH"
main = root / (name+".tex")
if kind == "Translation":
    expanded, links = linked_body(root, body, args.bibliography)
    print("Internal navigation", links)
    main.write_text(expanded, encoding="utf-8")
else:
    expanded, count = enrich(root, body)
    if args.release and count != 602:
        raise ValueError(f"Expected 602 exercises; found {count}")
    print("Linked original exercise locations", count)
    main.write_text(expanded, encoding="utf-8")
out = root/"build"/kind
out.mkdir(parents=True,exist_ok=True)
previous_state = None
for run in range(1, 9):
    with (out/f"pass{run}.txt").open("wb") as log:
        cmd = ["xelatex","-interaction=nonstopmode","-halt-on-error","-file-line-error",f"-output-directory={out}",main.name]
        proc = subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        if proc.returncode:
            raise SystemExit(f"Build failed in {out}, pass {run}")
    state = tuple((out / (name + suffix)).read_bytes() for suffix in (".aux", ".out", ".toc"))
    if state == previous_state:
        break
    previous_state = state
else:
    raise SystemExit(f"References or contents did not stabilize after {run} passes in {out}")
print(f"Contents and references stabilized on pass {run}")
pdf = out/(name+".pdf")
with pymupdf.open(pdf) as doc:
    assert len(doc)>2 and bool(doc.get_toc())
    print(name,len(doc),len(doc.get_toc()))
delivery = root.parent/"交付"/"Morris-2024-08-06"
if not args.release:
    delivery = delivery / "阶段校样"
delivery.mkdir(parents=True,exist_ok=True)
dest = delivery/(name+(".pdf" if args.release else "-Working.pdf"))
stage = dest.with_suffix(".new.pdf")
shutil.copy2(pdf,stage)
stage.replace(dest)
