# 第 7 章核查记录

Sidney A. Morris, Topology Without Tears，2024-08-06，单卷，印刷页与 PDF 页 176–193。两题组 7+22=29 道。习题 7.1 在 180 页；7.2 第 1–4 题在 186 页，第 5–8 题在 187 页，第 9–14 题在 188 页，第 15、16 题在 189 页，第 17 题在 190 页，第 18–20 题在 191 页，第 21、22 题在 192 页。星号题 7.1.7、7.2.11、7.2.16、7.2.21。第 186、188 页公式已渲染核对。

|编号|原页及原书短摘|判定与修订|English|
|---|---|---|---|
|E701|179，命题 7.1.9，So for each x ...|此前只说明 x∈S ⇒ Ux⊆S。若任取 s∈Ux∩S，则覆盖 [0,s] 的有限族连同 Ux 能覆盖到 Ux 中任一点。由此才有 Ux∩S 非空便推出 Ux⊆S。|In the proof of 7.1.9 show that any interval Ux meeting S in a point s is contained in S. Add Ux to a finite cover of [0,s]. This gives the stated conclusion even when x was not assumed to lie in S.|
|E702|180，习题 7.1.7 提示，an open subbasis cover ... maximal|应先对给定的无有限子覆盖的开覆盖在全体开集中取极大扩张，再证明其中的子基成员仍覆盖空间。|Start from an arbitrary open cover with no finite subcover, extend among families of open sets, and only then prove that the subbasic members cover X. The suggested subbasic cover is the object still to be found.|
|E703|187，习题 7.2.7，a family of closed compact subsets|补 J 非空；空族在非紧空间 R 的交为整个 R。|Require a nonempty indexing set J. The empty intersection in a noncompact space equals the whole space.|
|E704|190，习题 7.2.17(ix)，every countably infinite subset ... has a limit point|逆向需 T₁，或须改为每个邻域含无穷多个点的聚点。可数个二点平凡空间的拓扑和不满足可数紧，但任一非空集合都有普通极限点。|The converse fails without a separation hypothesis. The sum of countably many two-point indiscrete spaces has the indicated limit-point property and is not countably compact. Assume T1 or require an omega-accumulation point.|
|E705|191，习题 7.2.18 的定义，y ∈ Y|改为 y∈X，序列定义只给定空间 X。|Replace y in Y by y in X; X is the ambient space throughout the definition.|

7.2.21 中的非可数紧若干处宜读作“不具可数紧性”。全部子问已给出解答。
