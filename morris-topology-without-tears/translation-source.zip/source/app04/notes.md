# 附录 4 勘误与复核

原书 2024 年 8 月 6 日版，PDF 与印刷页均为 470–482。正式习题 A4.1 第 1–15 题。原书第 480 页 1–6 题，第 481 页 7–13 题，第 482 页 14–15 题。所有小问、星号题、原提示及其数学性质均有对应解答。书中将 Hausdorff 外测度定义在正指数上；直径的严格上界是本附录若干证明的关键。

| 编号 | 原页及定位 | 原文节录、修正与理由 | English |
|---|---|---|---|
|E4A01|472，A4.1.3 逆向证明末句|“radius ε/2 is an ε-covering”。实直线的开球直径可等于 ε。以 ε/3 代 ε/2，直径便至多 2ε/3，满足严格界。|The ball of radius ε/2 may have diameter ε, whereas A4.1.2 requires diameter strictly below ε. Use balls of radius ε/3.|
|E4A02|473，A4.1.6 第一段|“or (Y,d₂)”的环境空间应为 (Z,d₂)，与前一句所定义的记号一致。|In the comparison of ambient spaces, replace (Y,d₂) by (Z,d₂), as introduced immediately before.|
|E4A03|474，A4.1.7 证明|“(diam Uᵢ)ᵗ < (diam Uᵢ)ˢ”，以及其后的第二个严格式对零直径都失效。两处用 ≤。|Both strict termwise comparisons in the proof fail for a singleton of diameter zero. Replace each strict inequality by ≤.|
|E4A04|474，A4.1.8 证明|“Definition A4.1.3”应为定义 A4.1.4。A4.1.3 是可分性命题。|The outer measure is defined in A4.1.4, not A4.1.3.|
|E4A05|474–475，A4.1.10–11 两个临界指数公式|“s∈[0,∞)”包含本节尚未定义 H⁰ 的指数。改取 s>0；维数仍可取零。|Use s>0 when taking critical exponents in A4.1.10–11, in keeping with the domain of A4.1.4. Zero remains a possible dimension.|
|E4A06|475，A4.1.12 证明|半径 ε/2 的开球不一定构成严格 ε-覆盖，且“∑(diam Oᵢ)ˢ=εˢNˢ⁺¹/2ˢ”即使在实线 N=1 时也失效。有限个单点即是总代价零的覆盖。|The balls need not have diameter strictly below ε, and the displayed sum is incorrect already for one ball in the real line. Cover the finite set by its singletons; each term is zero.|
|E4A07|478，A4.1.20 末句|“Exercises 6.6 #7 and #8”应为习题 A4.1 第 7、8 题，见第 481 页多项式图像两题。|The intended parabola and polynomial graph problems are Exercises A4.1 nos. 7 and 8 (p. 481).|
|EA401|480，A4.1 第 5 题的两个 (ii)|原来连续标了两个 (ii)，分别在开球维数、开立方体维数两问。译稿、解答标 (ii-a)、(ii-b)，保持后面原号。前者最后的 dim 应按该题统一为 dim_H。|Two consecutive parts are numbered (ii). The translation distinguishes the ball question from the open-cube question as (ii-a) and (ii-b); the omitted Hausdorff subscript in the first is restored.|
|E4A08|481，A4.1 第 10 题提示 (iii)|“diam Oᵢ ≤ z diam Uᵢ”在非孤立单点（如实线中的 {0}）不可能满足。开集扩张改用可求和的小正数控制各项直径 s 次幂的加法误差。|The multiplicative diameter bound fails for a nonisolated singleton. Thicken each covering set with an arbitrarily small, summable additive error in its s-cost; the proposition still holds.|
|E4A09|482，A4.1 第 14 题首句，影响第 15 题 (iii)–(vi)|“there exists an N”从任意开覆盖取有限子覆盖错误。一维 (0,1) 可用 (1/(k+2),1/2) 及 (1/3,1) 严格 3/4-覆盖，无有限子覆盖。下确界公式仍成立：在有限代价近优覆盖中，直径一致小于 ε；略作中心放大，覆盖闭立方体后用紧致性取有限子覆盖。|An open cube is not compact and an arbitrary open ε-cover need not have a finite subcover. For the stated infimum, a finite-cost cover has supremum of diameters strictly below ε. Dilate it slightly about the centre to cover the closed cube, and extract a finite subcover there.|
