## E1009
第 273 页引理 10.3.3 证明。空链之并为空族，若原族非空则并不包含它。空链可取原族 F 作为上界；一般上界位于偏序集 Z，而非原文的底集 X。
Page 273, proof of Lemma 10.3.3. The union of an empty chain need not contain the given family. Use the given family itself as an upper bound for the empty chain. For a nonempty chain its union is an upper bound in the poset Z, not in X.

## E1010
第 274 页定理 10.3.4 证明最后两段。受限坐标 i 的圆柱条件应为 pᵢ⁻¹(Uᵢ)，非原式 U₁；末行积的游标 I∈I 应为 i∈I。
Page 274, proof of Theorem 10.3.4, final two paragraphs. Read pᵢ⁻¹(Uᵢ), not pᵢ⁻¹(U₁), for the i-th cylinder, and i∈I rather than I∈I in the final product.

## E1011
第 279 页定理 10.3.22 证明第一段结尾。应为 U∩V=∅，原文 A∩B=∅ 已是假设。两者作为不交区间的原像确实不交。
Page 279, Theorem 10.3.22, first paragraph of proof. The last condition should be U∩V=∅. A∩B=∅ is a hypothesis; disjointness of the inverse images U and V proves normality.

## E1012
第 279 页定理 10.3.22 证明的二进有理数构造。构造所列 k/2ⁿ 实际为 1≤k<2ⁿ，没有给出 U₁ 或 V₁。取开区间 (0,1) 中的二进数足以保留证明。原页的两个非严格单调式均没有闭包线。
Page 279, proof of Theorem 10.3.22. The induction constructs sets at the interior dyadics, not at 1. Use 1≤k<2ⁿ. The two non-strict monotonicity assertions do not contain closure bars in the supplied original.

## E1013
第 280 页定理 10.3.22 证明末段。y₀+ε 和 Y+ε 均应为 y+ε，f(u)⊆W 应为 f(U)⊆W，分别由取定的函数值 y 和开邻域 U 确定。
Page 280, final paragraph of the proof of Theorem 10.3.22. Replace y₀+ε and Y+ε by y+ε, and replace f(u)⊆W by f(U)⊆W.

## E1014
第 285 页引理 10.3.30 证明，定义带撇开集后。V′ₙ∩A=Aₙ∩A 应为 V′ₙ∩A=Vₙ∩A；Aₙ 未定义，且删去的各闭集均与 A 不交。
Page 285, proof of Lemma 10.3.30. Replace the undefined Aₙ by Vₙ in V′ₙ∩A=Aₙ∩A. The closed sets removed from Vₙ miss A.

## E1015
第 288 页命题 10.3.36 证明第二个旁注框。原文把 φ(T) 中 T 说成 S 的子集；φ 的定义域为 S，所以 T 应是 S 的元素。
Page 288, Proposition 10.3.36, second aside. The argument T of φ is an element of its domain S; the wording “subset of S” is incorrect.

## E1016
第 293 页命题 10.3.44 证明中，Φ(x)=φ(x) 应限定为所有 x∈S，而非原书中的 x∈X。φ 仅在 S 上定义。
Page 293, Proposition 10.3.44, proof. Restrict the extension identity to x∈S. The function φ is defined only on S.

## E1017
第 293 页引理 10.3.45。γ 的定义域 (S,τ₂) 应为 (S,τ₁)。τ₂ 是 Y 上的拓扑。
Page 293, Lemma 10.3.45. The domain of γ is (S,τ₁), not (S,τ₂); τ₂ is the topology of Y.

## E1018
第 297 页命题 10.3.53(ii)。应要求 C₁ 和 C₂ 是 K 中一对不交闭集。否则令 S=X=K 为单点空间、φ 为恒等、C₁=C₂=K，则连续延拓存在，但两个闭包相同且非空。第 298 页反向证明也采用不交的闭邻域。
Page 297, Proposition 10.3.53(ii). Insert “disjoint” before “closed subsets”. For the identity map of a singleton, take C₁=C₂=K: the extension exists, but the two nonempty inverse images are identical. The converse proof uses disjoint closed neighborhoods.
## E1019
第302页习题10.3第14题(iii)。原文用“不可数”来推出连续实值函数至少有 2^c 个。由 Urysohn 引理只能直接构造至少 2^|D| 个连续实值函数；应把“不可数闭离散子集”加强为“势至少为 c 的闭离散子集”。若 2^ℵ₁=c<2^c，取离散空间 ℵ₁，其连续实值函数只有 c 个。索尔根弗雷平面的反对角线确有势 c。
Page 302, Exercise 10.3 no. 14(iii). For an uncountable closed discrete D the construction gives 2^|D| continuous real functions. The stated 2^c conclusion does not follow in general: in a model with 2^ℵ₁=c<2^c the discrete space of size ℵ₁ is a counterexample. Require |D|≥c. The anti-diagonal used in the Sorgenfrey plane has size c.
## E1020
第304页习题10.3第21题的 k 空间定义。一个 A 闭当且仅当“对每个紧子集 K，A∩K 在 K 中闭”。原书将 K 的量词放在等价式外；反例为 X=ℝ，A=(0,1)，K={0}。
Page 304, Exercise 10.3 no. 21. The universal quantifier over compact K belongs to the right-hand side of the equivalence. A=(0,1) in ℝ and K={0} refute the pointwise equivalence.

