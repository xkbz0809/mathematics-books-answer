# 第十章审校记录
版本 2024-08-06，印刷页与 PDF 顺序页一致。

## E1001
第 262 页命题 10.1.3，原作 (X, τᵢ)，积的第 i 个因子是 Xᵢ，应为 (Xᵢ, τᵢ)。
Page 262, Proposition 10.1.3. The space in which Cᵢ is closed is (Xᵢ, τᵢ), rather than (X, τᵢ), as the product in the conclusion has Xᵢ as its i-th factor.

## E1002
第 262 页命题 10.1.4，原式对全部 i 要求 Oᵢ∈Bᵢ，同时除有限多个 i 外 Oᵢ=Xᵢ。应只对有限的受限坐标要求 Oᵢ∈Bᵢ，其他坐标取 Xᵢ。取可数无穷个离散二点空间，其基只含两个单点，原式即给出空族，不能覆盖非空积空间。
Page 262, Proposition 10.1.4. Require membership in the specified bases only on the finitely many restricted coordinates. On the remaining coordinates use the whole factor, whether or not it is in its chosen base. For countably many discrete two-point factors with singleton bases, the displayed family in the original is empty.

## E1003
第 263 页引理 10.1.9（ii），原式 fᵢ(x₁) ≠ f₁(x₂) 右侧下标 1 应为 i。指标集未必含 1，点分离必须比较同一映射在两点的值。（iii）的闭包横线已核对原页，保留。 
Page 263, Lemma 10.1.9(ii). Replace f₁(x₂) with fᵢ(x₂): separation compares the values of one coordinate map. The index set need not even contain 1.

## E1004
第 268 页例 10.2.6。原图的覆盖边为 d–a、a–b、a–j、c–b、b–g、e–g、g–f、g–h、g–i（下端在前）。原表误列 f<g、f<h 并漏列 g<f，末句还误称 e、f 不可比。原图有 e<g<f，且 f 极大。可用 h 与 f 举不可比例。
Page 268, Example 10.2.6. In the supplied diagram there is an upward path e<g<f. Delete f<g and f<h from the table, insert g<f, and correct the final assertion that e and f are incomparable. The maximal elements h and f are incomparable.

## E1005
第 269 页注 10.2.8 第一段。图中不存在标为 1 的顶点。可将“1 与 e”改为图上确实不可比的“j 与 e”。
Page 269, Remark 10.2.8. The diagram has no vertex labeled 1. One possible replacement is j, since j and e are incomparable in the supplied diagram.

## E1006
第 269 页注 10.2.8 末句，例号 10.2.4 应为 10.2.3。3 与 5 在例 10.2.3 的整除序中不可比；例 10.2.4 是幂集的包含序。
Page 269, Remark 10.2.8, last line. Replace Example 10.2.4 with Example 10.2.3, which orders the natural numbers by divisibility. Example 10.2.4 concerns inclusion in a power set.

## E1007
第 269 页定义 10.2.9。原文把“a≤b 且 b≤a 蕴含 a=b”作为严格全序的额外定义，但这是 10.2.1(ii) 的反对称性。标准严格全序 < 不可自反、传递，任意异点可比；可从非严格全序以 a<b 当且仅当 a≤b 且 a≠b 导出。
Page 269, Definition 10.2.9. The displayed criterion repeats antisymmetry from 10.2.1(ii) and does not define a strict linear order. Use the associated strict relation a<b iff a≤b and a≠b. It is irreflexive and transitive, and any distinct pair is comparable.

## E1008
第 271 页习题 10.2 第 1 题。b<c、c<d、b>d 形成矛盾的严格环。原命题不可能成立。可将 b>d 改为 b<d，取所列关系的传递闭包，并令 e、f 不可比。此修法给出 b<v<a<c<d，其上并列 e 和 f，再上为 u。正文和解答保留了原题的环及修法的建议性质。
Page 271, Exercise 10.2 no. 1. The conditions b<c, c<d and b>d are incompatible with a strict partial order. One possible repair is to reverse b>d, take the transitive closure, and keep e and f incomparable. A realization has b<v<a<c<d, then e and f immediately above d, and u above both.
