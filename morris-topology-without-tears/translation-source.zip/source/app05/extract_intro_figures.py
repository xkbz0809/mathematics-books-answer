"""Retain the plates and portraits in the 2024-08-06 appendix introduction."""
from pathlib import Path
import pymupdf

here = Path(__file__).resolve().parent
book = here.parents[1] / "topology with tears.pdf"
out = here / "intro-fig"
out.mkdir(exist_ok=True)
with pymupdf.open(book) as doc:
    for number in range(483, 513):
        page = doc[number - 1]
        for img in page.get_image_info(xrefs=True):
            xref = img["xref"]
            if not xref or img["width"] < 30:
                continue
            dest = out / f"p{number}-{xref}.png"
            pix = pymupdf.Pixmap(doc, xref)
            if pix.colorspace and pix.colorspace.n > 3:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)
            pix.save(dest)
    page = doc[486]
    page.get_pixmap(matrix=pymupdf.Matrix(2.5,2.5), clip=pymupdf.Rect(75,172,520,415), alpha=False).save(out / "genealogy.png")
