# 第9章核对记录

版本：Sidney A. Morris, Topology Without Tears, 2024-08-06。原书印刷页与 PDF 顺序页同为 222–259。解答覆盖 §9.1 的 2 题、§9.2 的 6 题、§9.3 的 10 题、§9.4 的 16 题、§9.5 的 3 题，共 37 题。第 246 页第 13 题的 (a)–(o) 逐项作答，第 255 页第 2(iii) 题同时证明连续性、满射性与纤维至多五点。第 223、254 页插图采用保留原书文字及几何位置的矢量剪取，第 253 页两幅照片提取自所给 PDF。各条已在译稿相应位置回写，原题有误时在解答处也给出反例。下列定位均兼指纸本页及 PDF 页。

| ID | 位置 | 原写法、改法及理由 | English |
|---|---|---|---|
| E901 | p225，9.2.1 后 Warning | 仅假设每个开因子均为真子集便断言乘积不开。补“非空”。任一空因子使乘积成为开集 ∅。 | Require the proper open factors to be nonempty. A single empty factor makes the product empty and hence open. |
| E902 | p226，例9.2.3 | 有限离散因子的可数无穷箱积未必无穷；全取单点即反例。宜加无穷多个因子至少有两个点。 | An infinite box product of finite discrete spaces need not be infinite. Require infinitely many factors to have more than one point; otherwise the product can be a singleton. |
| E903 | p231，命题9.3.5连续性证明 | 只要求给定数字序列的尾和小于 ε，未控制同一柱集内其他序列。取 2^{-N}<ε，它是固定前 N 位时的统一尾差上界。 | Bound the tail uniformly by 2^{-N}, not just the tail of the given sequence, which can vanish identically. |
| E904 | p240，推论9.4.10证明末句 | 将 f_i(x_i) 改为 f_i(x_1)。被比较的是固定的 x_1 与 x_2；i 是函数指标。 | In the last inequality replace the argument x_i on the left by x_1. |
| E905 | p243，命题9.4.17逆向证明 | 从 V∈τ 推出 V 与所选点集相交前，须要求 V 非空；对空开集不成立。 | Require V to be nonempty before asserting that it meets Z. |
| E906 | p244，习题9.4 #10(i) | 连续满射未必有非空真闭集 A 满足 f(A)=A。在圆周上作无理旋转，各轨取代表 t；增添所有 R^n t（n<0）的开单点，使空间不可分、R 仍为连续满射。一个非空闭不变集含整条通常稠密轨道，故含所有未增补为孤立点的点，包括所有代表，再由不变性含全空间。可加入“闭映射”作为一种充分修法。 | For an irrational circle rotation choose one representative on each orbit and isolate all its strictly negative iterates. This yields a nonseparable Hausdorff space; the rotation is still a continuous bijection. A nonempty closed invariant set contains one entire orbit, hence every representative, and therefore the entire space. An additional closed-map assumption validates the orbit-closure argument. |
| E907 | p246，习题9.4 #13(ii)(o) | 原断言极端不连通且满足本题逐对分离条件必离散。两点平凡空间满足前者且所有离散子空间至多有一点，故满足后者，却不离散。 | The two-point indiscrete space is extremally disconnected and satisfies the exercise's stated pairwise condition on discrete subspaces, vacuously, but is not discrete. |
| E908 | p249，命题9.5.2证明 | 起首把 G 到 I∞ 的映射记作 φ，随后原像与复合式却用未定义的 ψ；统一为 φ 并在 Z 上取限制。 | The map introduced as φ is later called ψ without definition. Keep φ throughout and restrict it to Z in the composite. |
| E909 | p249，命题9.5.3证明 | “if g1∈G′ and g2∈G′” 应加 g1≠g2，中点不在 G′ 才成立。 | Require the two points of G′ to be distinct in the assertion about their midpoint. |
| E910 | p250，命题9.5.3证明末段 | 单取 δ=(b−a)/2 不能保证只剩两个候选点。例取 Y={0,5/36,1}、g=5/36+5/216，均有只含0、5的六进制展开；ψ(g)=5/36，x=0 符合原距离界，却有 ψ(x)=0。取 min(a/2,(b−a)/2) 即可。 | The proposed δ does not keep x to the right of ψ(g). With Y={0,5/36,1} and g=5/36+5/216 the proposed neighborhood contains 0. Taking the minimum with a/2 fixes the proof. |
| E911 | p251，命题9.5.6证明；p255，9.5 #3 | 链条件 b_i=a_{i+1} 使 d1 恰为两个纤维间的距离。X={0,1,3,4} 中三个纤维 {0},{1,3},{4} 给出 4>1+1，三角不等式失败。命题仍真，可用紧度量空间可数基的有限并、闭满射与正则第二可数空间的度量化定理证明。 | The literal chain condition gives the infimum of distances between two fibers. Fibers {0}, {1,3}, {4} in the four-point metric subspace violate the triangle inequality, 4>1+1. The proposition itself holds by second countability and metrization. |
| E912 | p257，9.6.5；p258，9.6.7 | 闭球表达式 “‖X‖≤r‖” 应为 “‖x‖≤r”。定义内使用的是点 x，右端是正实数半径。 | Replace the malformed closed-ball condition by ‖x‖≤r in both occurrences. |
| E913 | p258，推论9.6.8中 E 的假设与(n) | 内部非空的 Gδ 子空间 E 不必同胚于全空间。在 ℓ₂ 中取闭单位球与 3e₁ 的并，它是闭集，因而是 Gδ，且有内部，却有孤立点并且不连通。原书前文支持的一种充分条件是 E 闭、凸且内部非空。 | A Gδ subset with nonempty interior need not be homeomorphic to the whole space. The closed unit ball of ℓ₂ together with 3e₁ is closed, hence Gδ, with interior, yet disconnected. Closed convexity together with nonempty interior is a sufficient replacement supported by the preceding result. |

| E914 | 第249页，命题9.5.3最近点的存在性 | 应引紧空间极值定理7.2.14。7.2.15要求实闭区间为定义域。 | Cite 7.2.14 for attainment on a compact space. Proposition 7.2.15 applies only to a closed real interval. |
