# 《无泪拓扑学》工作源稿

底本为 Sidney A. Morris 的 *Topology Without Tears*，2024 年 8 月 6 日版，单卷 729 页。原件在本目录的上一级，文件名为 `topology with tears.pdf`。正文第 1 至 12 章、附录 3 至 6 共编有 67 组、602 道正式习题。原书扉页没有印刷页码，第 2–729 页的印刷页码与 PDF 顺序页相同。

`front`、`chNN` 和 `appNN` 保存译文、图及各章习题解答。`inventory/pages.csv`、`inventory/exercises.csv`、`inventory/exercise-groups.csv` 提供原页、单题和题组索引。`backmatter` 保存书后材料。`errata/records.json` 为双语勘误的共同来源，章目录下的说明保存数学推导与复核依据。

使用 XeLaTeX、Python 与 PyMuPDF 生成四份 PDF。排版使用 TeX Live 的 Fandol 中文字体；勘误的少量 Unicode 数学字符使用 Cambria Math。把整个 `source` 目录放在原书所在目录中，再在 `source` 内运行：

```powershell
python review/audit_answers.py
python review/finite_topologies.py
python publish.py Translation --through 12 --release
python publish.py Solutions --through 12 --release
python errata/build.py --release
python review/verify_delivery.py
python package_source.py --release
```

译本总入口为 `Morris-Translation-ZH.tex`，解答册总入口为 `Morris-Solutions-ZH.tex`。二者由模块化源稿生成；改动请写回相应的章、节或附录文件，再运行构建。译本和解答册重复运行 XeLaTeX，直至目录和交叉引用文件稳定。成品核查逐行比较两册目录印出的页码与 PDF 目标页。中英文勘误各编译两遍。图片按原书或译图随包附上。恢复原页索引或重新提取图表时，再使用上级的原书 PDF。

`review/answer-coverage.csv` 保存编号题与解答的逐条对应；附录 5.5 原书两个“5”按原页顺序区分。译本保留原书页码目录与双语索引，同时提供本译本的导航目录。书目保留原作者和出版资料的原文写法。经核实的题干错误在译文中有对应的译注，并在中英文勘误里使用同一编号。独立复核的逐章记录位于 `review` 或所属章目录的 `independent-…` 文件。

原文件 SHA-256 为 `59f33c9ffc8199210ffff837ca3d18589de69ace6518cf537c8f040e1bf1fbaa`。
