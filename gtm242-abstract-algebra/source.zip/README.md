# 《抽象代数》习题解答：可编译 LaTeX 源码

Pierre Antoine Grillet 原著（Springer GTM 242，第二版）的独立中文解答，不是出版社的官方解答，亦不是原书译稿。全部 1521 个原书题号均有条目；其中附录 A 52 项，原书的 27 道星号题已原样标注。2026 年 11 月 22 日修订仅更换 IX.7.1 的解答及相应说明，补齐任意维的结构参数化；它未求出无挠同构轨道的 Jordan 式规范代表。其余题目内容未改。

main.tex 控制全册，answers/ 中每题一个独立片段。题号页码对应.tsv 采用 UTF-8 制表符格式；原书、已交付译稿以及本册三种页码分别标注，PDF 的物理页都从 1 起。题号星号是原书难题标记，不是校对状态。

XVI.10.7 的三生成元自由模格补充数据与可运行证明见 supplements/。其中有 28 个元素、两张运算表及 48 条 Hasse 覆盖边，也可以直接逐边核验排进 PDF 的图。

## 复编

在装有 XeLaTeX 与 Biber 的 TeX Live 系统中运行 bash tools/build.sh。生成物为 build/main.pdf。需要 CTeX、xeCJK、AMS、fontspec、biblatex、hyperref、xurl、TikZ、tikz-cd、enumitem、needspace 等常用宏包，以及 Fandol 与 Computer Modern Unicode 字体。推荐 TeX Live 2025 或兼容版；不需要原书 PDF、翻译工程、网络或 shell-escape。也可以在编辑器中依次跑两遍 XeLaTeX、一遍 Biber、两遍 XeLaTeX；这些程序须指向同一输出目录。
