# XVI.10.7：三生成元自由模格的复核附件

- `XVI.10.7-elements.tsv` 以解答中的符号列出 28 个元素。`bits` 为六个布尔试验点的十进制位掩码，依题 XVI.10.6 的试验点顺序给权重 1、2、4、8、16、32。`M3` 列的 0、4 表示底和顶，1、2、3 分别表示三个原子 z₁、z₂、z₃。
- `XVI.10.7-meet.tsv`、`XVI.10.7-join.tsv` 为两张操作表（行、列为输入，单元格为输出），`XVI.10.7-covers.tsv` 为 48 条由下至上的 Hasse 覆盖边。这些表补充正文的 Hasse 图。
- 使用 Python 3.10+（标准库）从坐标重建全部数据，并与已排进解答的图比较。从源码目录运行：

  ```sh
  python3 supplements/XVI.10.7-finite-model.py --output /tmp/gtm242-lattice --check-tex answers/GTM242-16.10.7.tex
  for f in supplements/*.tsv; do cmp "$f" "/tmp/gtm242-lattice/${f##*/}"; done
  ```

- `XVI.10.7-modular-identities.py` 是另一路上界验证。在模型上给项编号，并从这组项的定义开始，用格的界性质、传递性及单调性、结合律和模律反复推出项等式。脚本不只是把有限模型的操作结果当成普遍等式：候选下界/上界需经已知不等式和已证操作的闭包推出。最后要求所有 812 个考虑交换律后不同的二元操作式确实均已推出，因而任意三元组生成的模格至多有 28 个元素。此脚本的布尔位仍保留全零和全一两个额外试验点；编号及与正文项符号的对应见 `XVI.10.7-identity-names.tsv`。运行：

  ```sh
  python3 supplements/XVI.10.7-modular-identities.py
  ```

  预期最后一行：`Missing 0 {}`。这与正文引用闭包引理的上界证明相互独立；Python 不是复编 PDF 的必需依赖。
