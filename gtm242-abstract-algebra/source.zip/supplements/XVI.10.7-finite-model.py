"""Python 3.10+; finite model, both operations and the Hasse covers of XVI.10.7."""
import argparse
from itertools import combinations, product
from pathlib import Path
import csv
import re

def dm(a, b):
    return a if a == b else b if a == 4 else a if b == 4 else 0

def dj(a, b):
    return a if a == b else b if a == 0 else a if b == 0 else 4

def m(a, b):
    return a[0] & b[0], dm(a[1], b[1])

def j(a, b):
    return a[0] | b[0], dj(a[1], b[1])

points = ({1}, {2}, {3}, {1, 2}, {1, 3}, {2, 3})
x = {i:(sum(1 << k for k, s in enumerate(points) if i in s), i) for i in range(1, 4)}
v, d, u, c = {}, {}, {}, {}
for i in x:
    p, q = sorted(x.keys() - {i})
    v[i], u[i] = m(x[p], x[q]), j(x[p], x[q])
for i in x:
    p, q = sorted(x.keys() - {i})
    d[i], c[i] = j(v[p], v[q]), m(u[p], u[q])
a = {i:m(x[i], u[i]) for i in x}
b = {i:j(x[i], v[i]) for i in x}
e = {i:j(a[i], v[i]) for i in x}

def fold(f, z):
    return f(f(z[1], z[2]), z[3])

nodes = {"O":fold(m,x), "I":fold(j,x), "s":fold(j,v), "t":fold(m,u)}
for name, group in zip("vdaxebcu", (v,d,a,x,e,b,c,u)):
    nodes.update({f"{name}{i}": z for i,z in group.items()})

assert len(nodes) == len(set(nodes.values())) == 28
assert [nodes[k] for k in "v1 d1 a1 x1 e1 b1 c1 u1 O s t I".split()] == [(32,0),(24,0),(24,1),(25,1),(56,1),(57,1),(57,4),(62,4),(0,0),(56,0),(56,4),(63,4)]
rev = {value:key for key,value in nodes.items()}

def lt(a, b):
    return a != b and m(nodes[a], nodes[b]) == nodes[a]

covers = {(a,b) for a,b in product(nodes, repeat=2) if lt(a,b) and not any(lt(a,c) and lt(c,b) for c in nodes)}
assert len(covers) == 48, len(covers)

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output", type=Path, help="write freshly computed TSV tables here")
parser.add_argument("--check-tex", type=Path, help="compare the embedded Hasse diagram of the exercise against the computed cover relation")
args = parser.parse_args()
if args.check_tex:
    src = args.check_tex.read_text(encoding="utf-8")
    label_pat = r"\\put\(([\d.]+),([\d.]+)\).*?\$\s*([a-zA-Z](?:_\d+)?)\s*\$"
    pos = {tag.replace("_",""):(float(px),float(py)) for px,py,tag in re.findall(label_pat,src)}
    assert set(pos) == set(nodes)
    pattern = r"\\qbezier\(([\d.]+),([\d.]+)\)\([\d.]+,[\d.]+\)\(([\d.]+),([\d.]+)\)"
    def nearest(px,py):
        p = float(px),float(py)
        distance = lambda n:sum((a-b)**2 for a,b in zip(p,pos[n]))
        n = min(pos,key=distance)
        assert distance(n) < 125
        return n
    edges = [(nearest(px,py),nearest(qx,qy)) for px,py,qx,qy in re.findall(pattern,src)]
    assert len(edges) == len(covers) and set(edges) == covers
    print("embedded Hasse diagram verified")
if args.output:
    args.output.mkdir(exist_ok=True,parents=True)
    def write(name, rows):
        with (args.output/name).open("w", encoding="utf-8",newline="") as f:
            csv.writer(f,delimiter="\t",lineterminator="\n").writerows(rows)
    write("XVI.10.7-elements.tsv", [("name","bits","M3"),*((a,*z) for a,z in nodes.items())])
    write("XVI.10.7-covers.tsv", [("lower","upper"),*sorted(covers)])
    for name,f in (("meet",m),("join",j)):
        write(f"XVI.10.7-{name}.tsv", [[name,*nodes],*[[a,*[rev[f(nodes[a],nodes[b])] for b in nodes]] for a in nodes]])
else:
    # Confirm both operations are closed even when not writing out the two tables.
    assert all(f(a,b) in rev for a,b in product(rev,repeat=2) for f in (m,j))
print(f"{len(nodes)} elements; {len(covers)} covers; {2*len(nodes)**2} ordered operation entries")
