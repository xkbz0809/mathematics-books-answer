from itertools import product
# Terms from closure inside FD(3)×M3 in sibling script. IDs use its order.
definition={0:('m',11,3),1:('m',11,13),2:('m',11,16),3:('m',13,16),
4:('j',1,2),5:('j',1,3),6:('j',2,3),7:('m',11,26),8:('m',13,25),9:('m',16,24),10:('j',1,6),
12:('m',26,18),14:('m',25,19),15:('m',24,20),17:('m',24,23),18:('j',11,3),19:('j',13,2),20:('j',16,1),
21:('m',24,25),22:('m',24,26),23:('m',25,26),24:('j',11,13),25:('j',11,16),26:('j',13,16),27:('j',11,26)}
rangel=range(28)
boolean=[0x80,0x88,0xa0,0xc0,0xa8,0xc8,0xe0,0xa8,0xc8,0xe0,0xe8,0xaa,0xe8,0xcc,0xe8,0xe8,0xf0,0xe8,0xea,0xec,0xf8,0xea,0xec,0xf8,0xee,0xfa,0xfc,0xfe]
diamond=[0,0,0,0,0,0,0,1,2,3,0,1,1,2,2,3,3,4,1,2,3,4,4,4,4,4,4,4]
pairs=list(zip(boolean,diamond))
def dm(a,b):return a if a==b else (b if a==4 else a if b==4 else 0)
def dj(a,b):return a if a==b else (b if a==0 else a if b==0 else 4)
def m(a,b):return pairs.index((boolean[a]&boolean[b],dm(diamond[a],diamond[b])))
def j(a,b):return pairs.index((boolean[a]|boolean[b],dj(diamond[a],diamond[b])))
table={(op,a,b):f(a,b) for op,f in [('m',m),('j',j)] for a,b in product(rangel,repeat=2)}
def key(op,x,y):return (op,min(x,y),max(x,y))
known={}
reasons={}
le={(x,x) for x in rangel}
def add(op,a,b,c,reason):
 k=key(op,a,b)
 assert k in table and table[k]==c,(k,c,table.get(k),reason)
 assert known.get(k,c)==c
 if k not in known:
  known[k]=c; reasons[k]=reason
  if op=='j':le.update(((a,c),(b,c)))
  else:le.update(((c,a),(c,b)))
for z,(op,x,y) in definition.items():add(op,x,y,z,'definition')

def get(op,a,b):
 return known.get(key(op,a,b))
def assoc_rules():
 for op in ['j','m']:
  for a,b,c in product(rangel,repeat=3):
   ab,bc=get(op,a,b),get(op,b,c)
   if ab is None or bc is None: continue
   x,y=get(op,ab,c),get(op,a,bc)
   if x is not None: add(op,a,bc,x,('ass-left',a,b,c))
   if y is not None: add(op,ab,c,y,('ass-right',a,b,c))
def modular_rules():
 for a,c in list(le):
  for b in rangel:
   ab,bc=get('j',a,b),get('m',b,c)
   if ab is None or bc is None: continue
   x,y=get('m',ab,c),get('j',a,bc)
   if x is not None: add('j',a,bc,x,('mod-left',a,b,c))
   if y is not None: add('m',ab,c,y,('mod-right',a,b,c))

def bound_rules():
 # Prove transitive inequalities from all previous identities (and monotonicity).
 for x,y in list(le):
  for z in rangel:
   if (y,z) in le: le.add((x,z))
   if (z,x) in le: le.add((z,y))
   for op in ['j','m']:
    l,r=get(op,x,z),get(op,y,z)
    if l is not None and r is not None:le.add((l,r))
 for a,b in le.copy():
  add('j',a,b,b,'order');add('m',a,b,a,'order')
 # Use proofs of other operations as lower/upper bounds.
 for a,b in product(rangel,repeat=2):
  for op in ['j','m']:
   k=key(op,a,b)
   if k in known:continue
   c=table[k]
   if op=='j' and (a,c) in le and (b,c) in le:
    pool={z for z in rangel if (z,a) in le or (z,b) in le}
    while c not in pool:
     expanded=pool|{out for p,q in product(pool,repeat=2) if (out:=get(op,p,q)) is not None}
     if expanded==pool:break
     pool=expanded
    if c in pool:add(op,a,b,c,'lower closure plus upper bound')
   if op=='m' and (c,a) in le and (c,b) in le:
    pool={z for z in rangel if (a,z) in le or (b,z) in le}
    while c not in pool:
     expanded=pool|{out for p,q in product(pool,repeat=2) if (out:=get(op,p,q)) is not None}
     if expanded==pool:break
     pool=expanded
    if c in pool:add(op,a,b,c,'upper closure plus lower bound')
while True:
 size=(len(known),len(le))
 bound_rules();assoc_rules();modular_rules()
 print(size,'→',len(known),len(le))
 if size==(len(known),len(le)):break
missing={key(op,a,b):out for (op,a,b),out in table.items() if key(op,a,b) not in known}
print('Missing', len(missing),missing)
assert len(known)==812 and not missing
