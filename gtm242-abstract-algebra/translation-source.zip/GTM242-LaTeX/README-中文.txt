《抽象代数》中文译稿：可编译 LaTeX 源码
Pierre Antoine Grillet, Abstract Algebra, second edition, GTM 242, Springer, 2007。

入口为 main.tex。十六章及附录共 143 节，原书习题保留题面、星标及原有提示，不含另编解答。正文所订正的原书误植、证明缺口与附加条件用译注标出；部分原书略证、引文或历史归属并不因翻译而获独立认证。原版参考文献、延伸阅读及含 1613 个实际词条的英中对照索引齐备；索引页码是原书印刷页码，不是中文 PDF 页码。译本另有可跳转的术语索引；原书前后所载丛书书目合列，保留著作原题名与版次。
构建：先安装兼容的 XeLaTeX、Biber 和相应字体，详见 BUILD-DEPENDENCIES.txt。在解压的 GTM242-LaTeX 目录执行 bash tools/build.sh full，得到 build/main.pdf。云端 Linux 已从此包洁净复编。也附 tools/build.ps1，未在 Windows 上实测。常规 TeX 环境只需使 xelatex 和 biber 位于 PATH。
清单：226份实际参与编译的 TeX 输入、文类与项目图件、参考文献、构建脚本及依赖说明。backmatter/index-entries.tsv 是可检索的原书索引完整对照底表。各文件大小与 SHA-256 见 sources-manifest.json。不内嵌原书扫描、字体/TeX 发行版、临时编译产物或工程历史。
