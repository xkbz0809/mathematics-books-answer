#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -z "${GTM_TEX_ENV:-}" ]] || source "$GTM_TEX_ENV"
mkdir -p build/chapters build/backmatter
for n in 1 2; do xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > "build/pass$n.log" 2>&1; done
biber --input-directory=build --output-directory=build main > build/biber.log 2>&1
for n in 3 4; do xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex > "build/pass$n.log" 2>&1; done
