# Run in PowerShell with TeX Live XeLaTeX and matching Biber available on PATH.
$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '..')
try {
  New-Item -ItemType Directory -Force build,build/chapters,build/backmatter | Out-Null
  foreach ($n in 1,2) {
    & xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex *> "build/pass$n.log"
    if ($LASTEXITCODE -ne 0) { throw "XeLaTeX pass $n failed; inspect build/pass$n.log" }
  }
  & biber --input-directory=build --output-directory=build main *> build/biber.log
  if ($LASTEXITCODE -ne 0) { throw 'Biber failed; inspect build/biber.log' }
  foreach ($n in 3,4) {
    & xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex *> "build/pass$n.log"
    if ($LASTEXITCODE -ne 0) { throw "XeLaTeX pass $n failed; inspect build/pass$n.log" }
  }
} finally { Pop-Location }
