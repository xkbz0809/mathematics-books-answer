"""Build with XeLaTeX twice, Biber, XeLaTeX twice; retain all outputs in this project."""
from pathlib import Path
import subprocess, sys, json, time
ROOT=Path(__file__).resolve().parents[1]
name=sys.argv[1] if len(sys.argv)>1 else 'main'
out=ROOT/'build'; out.mkdir(exist_ok=True)
steps=[['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error','-output-directory=build',name+'.tex']]*2
steps += [['biber','--input-directory=build','--output-directory=build',name]]
steps += [steps[0]]*2
results=[]
for i,cmd in enumerate(steps,1):
    t=time.time()
    p=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (out/f'{name}-pass{i}.txt').write_bytes(p.stdout)
    row={'step':i,'command':cmd,'returncode':p.returncode,'seconds':round(time.time()-t,2)}
    results.append(row); print(json.dumps(row),flush=True)
    if p.returncode:
        print(p.stdout.decode('utf-8',errors='replace')[-4000:]); break
(ROOT/'qa'/f'{name}-build.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
sys.exit(results[-1]['returncode'])
