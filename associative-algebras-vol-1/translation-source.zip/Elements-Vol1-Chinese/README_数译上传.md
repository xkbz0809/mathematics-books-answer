# 《结合代数表示论基础》第1卷：数译上传源码包

原书：Ibrahim Assem、Daniel Simson、Andrzej Skowroński，Elements of the Representation Theory of Associative Algebras, Volume 1: Techniques of Representation Theory，Cambridge University Press，2006。

这是当前中文译本的独立源码交付包，按 GTM110_中文译本_完整包.zip 的信息范围筛选。包含现有422页成品PDF、完整LaTeX源码、文献、术语表、模板类、必要图片、构建脚本和关键文字校对/修订记录。不包含原书PDF、逐页截图、编译缓存、历次PDF副本或配套习题解答工程。

## 编译

在本README所在目录运行：

    python -X utf8 tools/build.py main

或：

    bash tools/build.sh full

需要Python 3（使用Python入口时）、完整TeX Live、XeLaTeX、Biber。流程为XeLaTeX两次、Biber、XeLaTeX两次；输出为build/main.pdf。qa目录已随包提供。字体使用TeX Live中的Fandol和Computer Modern Unicode；术语表由类文件管理，无须另行运行texindy。章节箭图由TeX绘制，logo.pdf是所需外部图片。

## 文件

main.tex为主文件；chapters、frontmatter、backmatter保存全书正文；mathtranslation.cls与preamble.tex保存排版和宏；references.bib保存文献；glossary.tsv保存术语约定。source/manifest.json保留原文件身份和页码记录，原书PDF不包含在上传包内。

qa与review_round2保留文字核对和修订证据，build/main.log为既有最终编译日志。习题修订记录.md及solutions/qa/translation_edit_ledger.json保留解题过程中对译本所作修订的依据；并不表示本包包含独立解答书。历史报告中提及的图片、旧稿、原书、解答工程及大归档包仍存于原完整工程，并未随本包分发。历史报告的页数与状态以最终译本及最新复核记录为准。

## 已知限制与来源忠实性

原PDF第414页（印刷第403页）缺失，影响IX.12题图，译本保留缺失说明。IX.6.3已按既有数学审查改为遗传A_n情形，并保留一般情形反例；IX.6.8(d)、IX.6.11涉及一般温柔树矩形判据的独立证明仍有缺口，正文和修订记录保留此限制。当前译本包含数学修订，并非未加修订的逐字转录。

本次仅筛选和归档现存文件，未修改翻译内容，未重新编译或重新开展数学审查。已检查TeX显式文件依赖、包内文件与原件的逐项SHA-256一致性；既有编译、编号及版面审查结果见随包记录。包内MANIFEST.json列出归档文件及散列。
