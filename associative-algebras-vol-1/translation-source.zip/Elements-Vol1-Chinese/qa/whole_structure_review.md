# 全书目录结构独立复核

复核日期：2026-11-12.

## 范围与依据

- 原书目录：原 PDF 第 7–8 页，印刷页 v–vi；读取 `source/pages/p007.txt`、`source/pages/p008.txt`，并逐页查看原 PDF 渲染 `source/renders/structure_source007.png`、`source/renders/structure_source008.png`，以页面图像为准.
- 译本结构：从 `main.tex` 按 `\input` 的实际顺序递归检查正文文件，包括 `chapters/ch08.tex` 引入的两部分和第 VI 章的独立习题文件. 统计的对象是正文中的实际 `\chapter` 和 `\section`，不是未更新的目录缓存.
- 此次为只读正文复核. 除本报告及用于查看的原书页面渲染外，不改写正文或主文件.
- 此次确认章、节、标题含义、次序及习题节设置；不据此推断正文逐句忠实性、习题逐题完整性、数学正确性或最终 PDF 目录链接质量.

## 结果

原书与译本均为 9 章加 1 篇附录，合计 60 节. 译本各章的节数依次为 7、4、4、7、6、7、6、6、7、6，与原书完全一致. 所有节次序一致，未发现漏节、多节、重复输入、标题含义不符或习题节位置错误. 每章及附录各有且仅有一个末节“习题”，共 10 个.

章标签为 `ch:I` 至 `ch:IX` 及 `ch:A`；节标签分别为各章的 `I:sec1` 等至末节，合计 60 个，未发现缺号或重复. 第 VI 章习题在 `chapters/ch06_exercises.tex` 中，由该章正文末尾输入；第 VIII 章由 `ch08_part1.tex`、`ch08_part2.tex` 依次组成，均纳入本次统计.

| 章 | 原书章名 | 译本章名 | 原书起页 | 节数 | 末节 |
|---|---|---|---:|---:|---|
| I | Algebras and modules | 代数与模 | 1 | 7 | I.7 习题 |
| II | Quivers and algebras | 箭图与代数 | 41 | 4 | II.4 习题 |
| III | Representations and modules | 表示与模 | 69 | 4 | III.4 习题 |
| IV | Auslander–Reiten theory | Auslander–Reiten 理论 | 97 | 7 | IV.7 习题 |
| V | Nakayama algebras and representation-finite group algebras | Nakayama 代数与表示有限型群代数 | 160 | 6 | V.6 习题 |
| VI | Tilting theory | 倾斜理论 | 184 | 7 | VI.7 习题 |
| VII | Representation-finite hereditary algebras | 表示有限的遗传代数 | 243 | 6 | VII.6 习题 |
| VIII | Tilted algebras | 倾斜代数 | 301 | 6 | VIII.6 习题 |
| IX | Directing modules and postprojective components | 定向模与后投射分支 | 357 | 7 | IX.7 习题 |
| A | Appendix. Categories, functors, and homology | 范畴、函子与同调 | 404 | 6 | A.6 习题 |

附录的“附录 A”由主文件的附录模式及类文件生成，正文标题只写“范畴、函子与同调”，不存在遗漏“Appendix”的结构问题.

## 60 节逐项对照

下表页码均为原书印刷页码，不是译本页码. 各行已经核对原书目录页面图像及实际译本标题；结论均为一致. 英文连字符与中文标题中的 LaTeX 长连字符在表中按可读形式显示.

| 节 | 原书标题 | 译本标题 | 原书起页 | 译本标签 |
|---|---|---|---:|---|
| I.1 | Algebras | 代数 | 1 | `I:sec1` |
| I.2 | Modules | 模 | 6 | `I:sec2` |
| I.3 | Semisimple modules and the radical of a module | 半单模与模的根基 | 13 | `I:sec3` |
| I.4 | Direct sum decompositions | 直和分解 | 18 | `I:sec4` |
| I.5 | Projective and injective modules | 投射模与内射模 | 25 | `I:sec5` |
| I.6 | Basic algebras and embeddings of module categories | 基本代数与模范畴的嵌入 | 32 | `I:sec6` |
| I.7 | Exercises | 习题 | 38 | `I:sec7` |
| II.1 | Quivers and path algebras | 箭图与路代数 | 41 | `II:sec1` |
| II.2 | Admissible ideals and quotients of the path algebra | 容许理想与路代数的商代数 | 53 | `II:sec2` |
| II.3 | The quiver of a finite dimensional algebra | 有限维代数的箭图 | 59 | `II:sec3` |
| II.4 | Exercises | 习题 | 65 | `II:sec4` |
| III.1 | Representations of bound quivers | 束缚箭图的表示 | 69 | `III:sec1` |
| III.2 | The simple, projective, and injective modules | 单模、投射模与内射模 | 76 | `III:sec2` |
| III.3 | The dimension vector of a module and the Euler characteristic | 模的维数向量与 Euler 特征 | 86 | `III:sec3` |
| III.4 | Exercises | 习题 | 93 | `III:sec4` |
| IV.1 | Irreducible morphisms and almost split sequences | 不可约态射与几乎可裂列 | 98 | `IV:sec1` |
| IV.2 | The Auslander–Reiten translations | Auslander–Reiten 平移 | 107 | `IV:sec2` |
| IV.3 | The existence of almost split sequences | 几乎可裂列的存在性 | 120 | `IV:sec3` |
| IV.4 | The Auslander–Reiten quiver of an algebra | 代数的 Auslander–Reiten 箭图 | 125 | `IV:sec4` |
| IV.5 | The first Brauer–Thrall conjecture | 第一 Brauer–Thrall 猜想 | 138 | `IV:sec5` |
| IV.6 | Functorial approach to almost split sequences | 几乎可裂列的函子方法 | 143 | `IV:sec6` |
| IV.7 | Exercises | 习题 | 154 | `IV:sec7` |
| V.1 | The Loewy series and the Loewy length of a module | 模的 Loewy 列与 Loewy 长度 | 160 | `V:sec1` |
| V.2 | Uniserial modules and right serial algebras | 单列模与右列代数 | 163 | `V:sec2` |
| V.3 | Nakayama algebras | Nakayama 代数 | 168 | `V:sec3` |
| V.4 | Almost split sequences for Nakayama algebras | Nakayama 代数的几乎可裂列 | 173 | `V:sec4` |
| V.5 | Representation-finite group algebras | 表示有限型群代数 | 175 | `V:sec5` |
| V.6 | Exercises | 习题 | 180 | `V:sec6` |
| VI.1 | Torsion pairs | 挠偶 | 184 | `VI:sec1` |
| VI.2 | Partial tilting modules and tilting modules | 部分倾斜模与倾斜模 | 192 | `VI:sec2` |
| VI.3 | The tilting theorem of Brenner and Butler | Brenner 与 Butler 的倾斜定理 | 202 | `VI:sec3` |
| VI.4 | Consequences of the tilting theorem | 倾斜定理的推论 | 215 | `VI:sec4` |
| VI.5 | Separating and splitting tilting modules | 分离倾斜模与可裂倾斜模 | 225 | `VI:sec5` |
| VI.6 | Torsion pairs induced by tilting modules | 倾斜模诱导的挠偶 | 232 | `VI:sec6` |
| VI.7 | Exercises | 习题 | 238 | `VI:sec7` |
| VII.1 | Hereditary algebras | 遗传代数 | 243 | `VII:sec1` |
| VII.2 | The Dynkin and Euclidean graphs | Dynkin 图与 Euclidean 图 | 252 | `VII:sec2` |
| VII.3 | Integral quadratic forms | 整二次型 | 259 | `VII:sec3` |
| VII.4 | The quadratic form of a quiver | 箭图的二次型 | 265 | `VII:sec4` |
| VII.5 | Reflection functors and Gabriel’s theorem | 反射函子与 Gabriel 定理 | 278 | `VII:sec5` |
| VII.6 | Exercises | 习题 | 298 | `VII:sec6` |
| VIII.1 | Sections in translation quivers | 平移箭图中的截面 | 301 | `VIII:sec1` |
| VIII.2 | Representation-infinite hereditary algebras | 表示无限遗传代数 | 306 | `VIII:sec2` |
| VIII.3 | Tilted algebras | 倾斜代数 | 317 | `VIII:sec3` |
| VIII.4 | Projectives and injectives in the connecting component | 连接分支中的投射模与内射模 | 326 | `VIII:sec4` |
| VIII.5 | The criterion of Liu and Skowroński | Liu 与 Skowroński 判据 | 338 | `VIII:sec5` |
| VIII.6 | Exercises | 习题 | 350 | `VIII:sec6` |
| IX.1 | Directing modules | 定向模 | 357 | `IX:sec1` |
| IX.2 | Sincere directing modules | 忠诚定向模 | 361 | `IX:sec2` |
| IX.3 | Representation-directed algebras | 表示定向代数 | 366 | `IX:sec3` |
| IX.4 | The separation condition | 分离条件 | 372 | `IX:sec4` |
| IX.5 | Algebras such that all projectives are postprojective | 所有投射模均为后投射模的代数 | 379 | `IX:sec5` |
| IX.6 | Gentle algebras and tilted algebras of type A_n | 温柔代数与 A_n 型倾斜代数 | 389 | `IX:sec6` |
| IX.7 | Exercises | 习题 | 400 | `IX:sec7` |
| A.1 | Categories | 范畴 | 404 | `A:sec1` |
| A.2 | Functors | 函子 | 409 | `A:sec2` |
| A.3 | The radical of a category | 范畴的根基 | 420 | `A:sec3` |
| A.4 | Homological algebra | 同调代数 | 424 | `A:sec4` |
| A.5 | The group of extensions | 扩张群 | 431 | `A:sec5` |
| A.6 | Exercises | 习题 | 435 | `A:sec6` |

## 目录中的其他项目

- 原书的 Introduction（印刷页 vii）对应 `frontmatter/introduction.tex` 的“引言”，已由主文件输入. 译本按前置篇章排版，不计入上述 10 个正文章命令与 60 个节命令.
- 原书 Bibliography（437）对应主文件的 `\makebibliography`；Index（451）对应 `backmatter/index.tex`；List of symbols（457）对应 `backmatter/symbols.tex`. 输入次序与原书一致.
- 译本另含翻译出版说明、丛书页及术语索引；这些项目位于前后置部分，不改变原书正文的章、节编号或上述统计.
- `IX.6` 的数学标题在正文用 `\mathbb A_n` 排版，书签备用文字为 `An`，数学含义与原书一致.

## 待后续验证的边界

本报告不以尚在更新中的整书 PDF 缓存为验证对象. 最终构建后仍需检查实际目录页显示、书签/目录目标坐标以及各章分页；这与本次已完成的源文件结构核对分开记录.
