from vi_end import *

def bmodels(key):
    a,ars=vi_case(key);ad=ar_data(a,ars);ts=selected(key,ars,ad);b=EndAlgebra(ts)
    zs=b.zeros;eq=[(p,q) for p,q,c in b.equalities if c==1]
    assert all(c==1 for p,q,c in b.equalities)
    alg=Algebra(b.vertices,b.arrows,zs,eq)
    if key in ['14i','14iv','16']:
        reps=string_modules(b.vertices,b.arrows,zs)
    elif key=='14iii':
        # Dual of A in VI.17, with vertex permutation. Equivalently a
        # projective-injective commutative square and its zero quotient.
        reps=string_modules(b.vertices,b.arrows,zs+[p for pair in eq for p in pair])
        reps.append(alg.projectives[5])
    elif key=='14ii':
        _,old=vi_case('24');perm={1:1,2:3,3:2,4:4,5:5};amap={'a':'u3','b':'u1','c':'u5','d':'u2','e':'u4'}
        reps=[Rep(m.name,{perm[v]:m.dims[v] for v in range(1,6)},b.arrows,{amap[a]:x for a,x in m.maps.items()}) for m in old]
        # Keep a uniform ordered vertex convention.
        reps=[Rep(m.name,{v:m.dims[v] for v in b.vertices},b.arrows,m.maps) for m in reps]
    elif key=='17':
        reps=thin_modules(b.vertices,b.arrows,zs,eq)
        reps.append(Rep('R',{1:2,2:1,3:1,4:1,5:0},b.arrows,{'u1':[[1],[1]],'u2':[[1,0]],'u3':[[0,1]]}))
    elif key=='21':
        reps=thin_modules(b.vertices,b.arrows,zs,eq)
        reps.append(Rep('R',{1:2,2:1,3:1,4:1,5:1},b.arrows,{'u1':[[1],[0]],'u2':[[1,1]],'u3':[[1,0]],'u4':[[1]],'u5':[[1]]}))
    else:raise ValueError(key)
    for i,m in enumerate(reps,1):m.original_name=m.name;m.name='N'+str(i)
    return a,ars,ts,b,alg,reps

def run_b(key):
    a,ars,ts,b,alg,reps=bmodels(key);ad=ar_data(alg,reps)
    for row,m in zip(ad['vertices'],reps):
        row['maps']=m.maps;row['model']=m.original_name;row['pd']=alg.projective_dimension(m)
    tor=[m for m in ars if all(a.ext1(t,m)==0 for t in ts)];free=[m for m in ars if all(not hom_basis(t,m) for t in ts)]
    fm={m.name:match(b.functor_hom(m),reps).name for m in tor}
    gm={m.name:match(functor_ext(b,a,m),reps).name for m in free}
    return {'B':ad,'F':fm,'G':gm,'mixed':sorted(set(m.name for m in reps)-set(fm.values())-set(gm.values())), 'algebra':b.plain()}

if __name__=='__main__':
    import sys
    for key in sys.argv[1:] or ['14i','14ii','14iii','14iv','16','17','21']:
        out=run_b(key);Path(__file__).with_name('vi_b_'+key+'.json').write_text(json.dumps(out,default=encode,indent=2),encoding='utf-8')
        print(key,'count',len(out['B']['vertices']),'mixed',out['mixed'],'pd',[x['pd'] for x in out['B']['vertices']],flush=True)
