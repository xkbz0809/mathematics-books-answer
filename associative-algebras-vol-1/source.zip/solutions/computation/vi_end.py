"""Exact, finite linear-algebra calculations for VI's specified examples."""
from ar_linear import *
from vi_models import *
from itertools import product,combinations
import json
from pathlib import Path
def contains(word,sub):return any(word[i:i+len(sub)]==sub for i in range(len(word)-len(sub)+1))

def transpose(a):return matrix([[a.rows[i][j] for i in range(a.nrows)] for j in range(a.ncols)],a.nrows)
def identity(m):return {v:eye(m.dims[v]) for v in m.vertices}
def coords(basis,f,m,n):
    vs=[flatten(h,m.vertices) for h in basis]
    return solve(columns(vs,sum(m.dims[v]*n.dims[v] for v in m.vertices)),columns([flatten(f,m.vertices)],sum(m.dims[v]*n.dims[v] for v in m.vertices)))
def isomorphic(m,n):
    if m.dimension()!=n.dimension():return False
    hs=hom_basis(m,n)
    if not hs:return False
    trials=list(product(range(3),repeat=len(hs)))
    for cs in trials:
        f=linear_combination(hs,cs,m,n)
        if all(len(rref(f[v])[1])==m.dims[v] for v in m.vertices):return True
    # No conclusion from a failed small grid: the determinant polynomial has
    # degree <= total dimension; a larger grid certifies non-isomorphism.
    for cs in product(range(sum(m.dimension())+1),repeat=len(hs)):
        f=linear_combination(hs,cs,m,n)
        if all(len(rref(f[v])[1])==m.dims[v] for v in m.vertices):return True
    return False
def match(m,reps):
    found=[r for r in reps if isomorphic(m,r)]
    assert len(found)==1,(m.name,m.dimension(),[x.name for x in found])
    return found[0]
def ar_data(alg,reps):
    data=ar_quiver(reps,True);by={r.name:r for r in reps};tau={};seq={}
    projs={match(p,reps).name for p in alg.projectives.values()}
    injs={match(alg.injective(v),reps).name for v in alg.vertices}
    for m in reps:
        if m.name in projs:continue
        es=[];fs=[]
        for a in data['arrows']:
            if a['target']==m.name:
                for f in a['maps']:es.append(by[a['source']]);fs.append(f)
        e=direct_sum(es,'E('+m.name+')')
        f={v:matrix([sum((list(h[v].rows[i]) for h in fs),[]) for i in range(m.dims[v])],e.dims[v]) for v in m.vertices}
        assert all(len(rref(f[v])[1])==m.dims[v] for v in m.vertices),(m.name,'not epic')
        k,_=kernel_rep(e,m,f);t=match(k,reps)
        tau[m.name]=t.name;seq[m.name]={'left':t.name,'middle':[x.name for x in es]}
    return {'vertices':data['vertices'],'arrows':[{k:v for k,v in x.items() if k!='maps'} for x in data['arrows']], 'tau':tau,'sequences':seq,'projectives':sorted(projs),'injectives':sorted(injs)}

class EndAlgebra:
    def __init__(self,ts):
        self.ts=ts;self.n=len(ts);self.vertices=tuple(range(1,self.n+1));self.arrows={};self.maps={}
        for row in ar_quiver(ts,True)['arrows']:
            i=next(k for k,t in enumerate(ts,1) if t.name==row['source'])
            j=next(k for k,t in enumerate(ts,1) if t.name==row['target'])
            for f in row['maps']:
                a='u'+str(len(self.arrows)+1);self.arrows[a]=(j,i);self.maps[a]=f
        self.normal={};self.images={};self.relations=[];self.zeros=[];self.equalities=[]
        pending=[(i,i,(),identity(t)) for i,t in enumerate(ts,1)]
        for length in range(30):
            nxt=[]
            for s,t,p,f in pending:
                key=(s,t);span=self.normal.setdefault(key,[])
                vec=flatten(f,ts[0].vertices);basis=[flatten(self.images[s,t,q],ts[0].vertices) for q in span]
                sp=Span()
                for x in basis:sp.add(x)
                if sp.add(vec):
                    span.append(p);self.images[s,t,p]=f
                    for a,(a_s,a_t) in self.arrows.items():
                        if a_s==t:
                            word=p+(a,)
                            if not any(contains(word,r['leading']) for r in self.relations):
                                nxt.append((s,a_t,word,compose(f,self.maps[a])))
                else:
                    coeff=solve(columns(basis,len(vec)),columns([vec],len(vec)))
                    terms=[(q,coeff.rows[i][0]) for i,q in enumerate(span) if coeff.rows[i][0]]
                    self.relations.append({'leading':p,'terms':terms})
                    if not terms:self.zeros.append(p)
                    elif len(terms)==1 and terms[0][1] in (1,-1):
                        # The sign is retained in relation records. All current
                        # examples have positive commutativity after basis choice.
                        self.equalities.append((p,terms[0][0],terms[0][1]))
            pending=nxt
            if not pending:break
        else:raise RuntimeError('End normal forms did not terminate')
        assert sum(len(v) for v in self.normal.values())==sum(len(hom_basis(x,y)) for x in ts for y in ts)
        self.cartan=matrix([[len(hom_basis(ts[i],ts[j])) for j in range(self.n)] for i in range(self.n)])
    def functor_hom(self,m):
        hs={i:hom_basis(t,m) for i,t in enumerate(self.ts,1)};maps={}
        for a,(s,t) in self.arrows.items():
            vs=[]
            for h in hs[s]:vs.append(tuple(x[0] for x in coords(hs[t],compose(h,self.maps[a]),self.ts[t-1],m).rows))
            maps[a]=columns(vs,len(hs[t]))
        return Rep('F'+m.name,{i:len(hs[i]) for i in self.vertices},self.arrows,maps)
    def plain(self):
        return {'summands':[t.name for t in self.ts],'arrows':self.arrows,'relations':self.relations,'cartan':self.cartan.tolist(),'dimension':sum(len(v) for v in self.normal.values())}

def ext_basis(alg,t,m):
    p,f,(k,inc)=alg.cover(t);space=Span();restr=[]
    for h in hom_basis(p,m):
        g=compose(h,inc)
        if space.add(flatten(g,t.vertices)):restr.append(g)
    chosen=[]
    for h in hom_basis(k,m):
        if space.add(flatten(h,t.vertices)):chosen.append(h)
    return p,f,k,inc,restr,chosen

def functor_ext(end,alg,m):
    dat={i:ext_basis(alg,t,m) for i,t in enumerate(end.ts,1)};maps={}
    for a,(s,t) in end.arrows.items():
        # a:s->t corresponds to T_t -> T_s.
        ps,eps,ks,incs,rs,es=dat[s];pt,ept,kt,inct,rt,et=dat[t]
        hs=hom_basis(pt,ps);target=compose(end.maps[a],ept)
        comps=[compose(eps,h) for h in hs]
        cs=coords(comps,target,pt,end.ts[s-1]);lift=linear_combination(hs,[x[0] for x in cs.rows],pt,ps)
        restricted=compose(lift,inct)
        f1={v:solve(incs[v],restricted[v]) for v in kt.vertices}
        vs=[]
        for h in es:
            q=coords(rt+et,compose(h,f1),kt,m)
            vs.append(tuple(x[0] for x in q.rows[len(rt):]))
        maps[a]=columns(vs,len(et))
    return Rep('G'+m.name,{i:len(dat[i][5]) for i in end.vertices},end.arrows,maps)

def selected(key,reps,ad):
    dims={
      '14i':[(1,0,0,0,0),(1,0,1,0,1),(0,0,1,1,1),(0,0,1,1,0),(0,1,1,1,0)],
      '14ii':[(1,0,1,1,0),(1,1,1,1,1),(0,0,1,0,0),(0,0,1,1,0),(0,0,1,1,1)],
      '14iii':[(0,0,0,0,1),(0,0,0,1,1),(1,0,1,1,0),(0,1,1,1,0),(1,1,1,1,0)],
      '14iv':[(2,1),(1,0)]}
    if key in dims:
        return [next(m for m in reps if m.dimension()==d) for d in dims[key]]
    if key in ['16','17','21']:
        s1=next(m for m in reps if m.dimension()==(1,0,0,0,0));ut=next(k for k,v in ad['tau'].items() if v==s1.name)
        alg,_=vi_case(key)
        return [next(m for m in reps if m.name==ut)]+[match(alg.projectives[i],reps) for i in range(2,6)]

def encode(x):
    if isinstance(x,F):return int(x) if x.denominator==1 else str(x)
    if isinstance(x,Mat):return x.tolist()
    if isinstance(x,Rep):return {'name':x.name,'dimension':x.dimension(),'maps':{a:m.tolist() for a,m in x.maps.items()}}
    raise TypeError(type(x))

def run(key):
    alg,reps=vi_case(key);ad=ar_data(alg,reps);ts=selected(key,reps,ad)
    if key=='15':
        valid=[m for m in reps if alg.projective_dimension(m)<=1];out=[]
        for comb in combinations(valid,len(alg.vertices)):
            if all(alg.ext1(m,n)==0 for m in comb for n in comb):out.append(EndAlgebra(list(comb)).plain())
        return {'A':ad,'tiltings':out}
    if key=='24':return {'A':ad}
    assert all(alg.projective_dimension(t)<=1 for t in ts)
    assert all(alg.ext1(t,u)==0 for t in ts for u in ts)
    end=EndAlgebra(ts);tor=[m for m in reps if all(alg.ext1(t,m)==0 for t in ts)];free=[m for m in reps if all(not hom_basis(t,m) for t in ts)]
    fm=[end.functor_hom(m) for m in tor];gm=[functor_ext(end,alg,m) for m in free]
    ca=matrix([[alg.projectives[j].dims[i] for j in alg.vertices] for i in alg.vertices]);cb=end.cartan
    dt=columns([t.dimension() for t in ts],len(alg.vertices));ff=cb@solve(dt,eye(dt.nrows));ea=transpose(solve(ca,eye(ca.nrows)));eb=transpose(solve(cb,eye(cb.nrows)))
    assert transpose(ff)@eb@ff==ea
    return {'A':ad,'B':end.plain(),'T':[t.name for t in ts],'torsion':[m.name for m in tor],'free':[m.name for m in free], 'F':fm,'G':gm,'F_matrix':ff,'Euler_A':ea,'Euler_B':eb}

if __name__=='__main__':
    import sys
    for key in sys.argv[1:] or ['14i','14ii','14iii','14iv','15','16','17','21','24']:
        data=run(key);Path(__file__).with_name('vi_end_'+key+'.json').write_text(json.dumps(data,default=encode,indent=2),encoding='utf-8')
        print(key, 'T=',data.get('T'), 'B=',data.get('B'), 'torsion=',data.get('torsion'), 'free=',data.get('free'),flush=True)
