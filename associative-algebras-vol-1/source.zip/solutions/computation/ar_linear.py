"""Exact rational representation/Hom/radical calculations (standard library only).

Rep(name, dims, arrows, maps): dims is {vertex: dimension}; arrows is
{arrow: (source,target)}; maps uses target-by-source matrices (lists of rows).
Omitted maps are zero. Vertex and arrow names may be strings or integers.

ar_quiver(reps) assumes the supplied list consists of pairwise nonisomorphic
absolutely indecomposable representations AND is complete for the category
being examined. It computes rad/rad^2 relative to that list, not a completeness
certificate. A mathematical classification is required separately. At a
diagonal End ring its radical is the trace-zero subspace, justified for an
absolutely indecomposable representation over a characteristic-zero field.
"""
from dataclasses import dataclass
from fractions import Fraction as F


@dataclass(frozen=True)
class Mat:
    rows: tuple
    ncols: int

    @property
    def nrows(self):
        return len(self.rows)

    def __matmul__(self, other):
        assert self.ncols == other.nrows
        return Mat(tuple(tuple(sum((self.rows[i][k]*other.rows[k][j]
                    for k in range(self.ncols)), F(0))
                    for j in range(other.ncols)) for i in range(self.nrows)), other.ncols)

    def flat(self):
        return tuple(x for row in self.rows for x in row)

    def tolist(self):
        return [[int(x) if x.denominator == 1 else str(x) for x in row] for row in self.rows]


def matrix(rows, ncols=None):
    if isinstance(rows, Mat):
        return rows
    rows=tuple(tuple(F(x) for x in row) for row in rows)
    ncols=len(rows[0]) if rows and ncols is None else (ncols or 0)
    assert all(len(row)==ncols for row in rows)
    return Mat(rows,ncols)


def zero(n,m):
    return Mat(tuple((F(0),)*m for _ in range(n)),m)


def eye(n):
    return matrix([[int(i==j) for j in range(n)] for i in range(n)],n)


def rref(a):
    a=matrix(a)
    rows=[list(row) for row in a.rows]; piv=[]; k=0
    for j in range(a.ncols):
        pos=next((i for i in range(k,len(rows)) if rows[i][j]),None)
        if pos is None: continue
        rows[k],rows[pos]=rows[pos],rows[k]
        q=rows[k][j]; rows[k]=[x/q for x in rows[k]]
        for i in range(len(rows)):
            if i!=k and rows[i][j]:
                q=rows[i][j]; rows[i]=[x-q*y for x,y in zip(rows[i],rows[k])]
        piv.append(j);k+=1
        if k==len(rows):break
    return matrix(rows,a.ncols),piv


def nullspace(a):
    a=matrix(a); b,piv=rref(a); free=[j for j in range(a.ncols) if j not in piv]
    out=[]
    for j in free:
        v=[F(0)]*a.ncols;v[j]=F(1)
        for i,p in enumerate(piv):v[p]=-b.rows[i][j]
        out.append(tuple(v))
    return out


def columns(vectors,nrows):
    return matrix([[v[i] for v in vectors] for i in range(nrows)],len(vectors))


class Span:
    """Incremental exact row space; add(v) says whether v increases its rank."""
    def __init__(self):
        self.rows={}

    def add(self,vector):
        v=list(map(F,vector))
        for p,w in sorted(self.rows.items()):
            if v[p]:
                q=v[p];v=[x-q*y for x,y in zip(v,w)]
        p=next((i for i,x in enumerate(v) if x),None)
        if p is None:return False
        q=v[p]; self.rows[p]=tuple(x/q for x in v);return True

    def __len__(self):return len(self.rows)


def solve(a,b):
    """Solve A X=B; free coordinates are zero. Reject inconsistent systems."""
    a=matrix(a);b=matrix(b);assert a.nrows==b.nrows
    aug=matrix([list(x)+list(y) for x,y in zip(a.rows,b.rows)],a.ncols+b.ncols)
    rr,piv=rref(aug)
    assert not any(p>=a.ncols for p in piv),'inconsistent linear system'
    x=[[F(0)]*b.ncols for _ in range(a.ncols)]
    for i,p in enumerate(piv):x[p]=list(rr.rows[i][a.ncols:])
    return matrix(x,b.ncols)


class Rep:
    def __init__(self,name,dims,arrows,maps=None):
        self.name=name; self.dims=dict(dims);self.vertices=tuple(dims);self.arrows=dict(arrows)
        maps=maps or {};self.maps={}
        for a,(s,t) in arrows.items():
            x=matrix(maps[a],self.dims[s]) if a in maps else zero(self.dims[t],self.dims[s])
            assert x.nrows==self.dims[t] and x.ncols==self.dims[s],(name,a,x,self.dims)
            self.maps[a]=x

    def dimension(self):return tuple(self.dims[v] for v in self.vertices)

    def path(self,word):
        if not word:raise ValueError('specify a nonempty path')
        x=self.maps[word[0]];end=self.arrows[word[0]][1]
        for a in word[1:]:
            assert self.arrows[a][0]==end
            x=self.maps[a]@x;end=self.arrows[a][1]
        return x


def hom_basis(m,n):
    assert m.vertices==n.vertices and m.arrows==n.arrows
    offset={};total=0
    for v in m.vertices:
        offset[v]=total;total+=m.dims[v]*n.dims[v]
    equations=[]
    for a,(s,t) in m.arrows.items():
        ma=m.maps[a];na=n.maps[a]
        for i in range(n.dims[t]):
            for j in range(m.dims[s]):
                row=[F(0)]*total
                for k in range(n.dims[s]):row[offset[s]+k*m.dims[s]+j]+=na.rows[i][k]
                for k in range(m.dims[t]):row[offset[t]+i*m.dims[t]+k]-=ma.rows[k][j]
                equations.append(row)
    vectors=nullspace(matrix(equations,total))
    return [unflatten(m,n,x) for x in vectors]


def unflatten(m,n,vector):
    out={};k=0
    for v in m.vertices:
        rows=[]
        for i in range(n.dims[v]):
            rows.append(vector[k:k+m.dims[v]]);k+=m.dims[v]
        out[v]=matrix(rows,m.dims[v])
    assert k==len(vector)
    return out


def flatten(morphism,vertices):
    return tuple(x for v in vertices for x in morphism[v].flat())


def compose(g,f):
    return {v:g[v]@f[v] for v in f}


def linear_combination(basis,coefficients,m,n):
    vecs=[flatten(f,m.vertices) for f in basis]
    total=sum(m.dims[v]*n.dims[v] for v in m.vertices)
    return unflatten(m,n,[sum((c*x[k] for c,x in zip(coefficients,vecs)),F(0)) for k in range(total)])


def trace(morphism):
    return sum((a.rows[i][i] for a in morphism.values() for i in range(a.nrows)),F(0))


def radical_basis(m,n,basis=None,same=False):
    basis=hom_basis(m,n) if basis is None else basis
    if not same:return basis
    coeffs=nullspace(matrix([[trace(f) for f in basis]],len(basis)))
    return [linear_combination(basis,c,m,n) for c in coeffs]


def ar_quiver(reps,include_maps=False):
    size=len(reps);hom={};rad={}
    for i,m in enumerate(reps):
        for j,n in enumerate(reps):
            hom[i,j]=hom_basis(m,n)
            rad[i,j]=radical_basis(m,n,hom[i,j],i==j)
    edges=[]
    for i,m in enumerate(reps):
        for j,n in enumerate(reps):
            if not rad[i,j]:continue
            span=Span()
            for k in range(size):
                for f in rad[i,k]:
                    for g in rad[k,j]:span.add(flatten(compose(g,f),m.vertices))
            dim2=len(span);selected=[]
            for f in rad[i,j]:
                if span.add(flatten(f,m.vertices)):selected.append(f)
            if selected:
                row={'source':m.name,'target':n.name,'multiplicity':len(selected),
                     'hom_dimension':len(hom[i,j]),'rad_dimension':len(rad[i,j]),'rad2_dimension':dim2}
                if include_maps:row['maps']=selected
                edges.append(row)
    return {'vertices':[{'name':m.name,'dimension':m.dimension(),'end_dimension':len(hom[i,i])} for i,m in enumerate(reps)],'arrows':edges}


def kernel_rep(m,n,f,name='kernel'):
    bases={v:columns(nullspace(f[v]),m.dims[v]) for v in m.vertices}
    dims={v:bases[v].ncols for v in m.vertices};maps={}
    for a,(s,t) in m.arrows.items():maps[a]=solve(bases[t],m.maps[a]@bases[s])
    return Rep(name,dims,m.arrows,maps),bases


def cokernel_rep(m,n,f,name='cokernel'):
    projections={};sections={};dims={}
    for v in m.vertices:
        cols=[tuple(f[v].rows[i][j] for i in range(n.dims[v])) for j in range(m.dims[v])]
        span=Span();ind=[x for x in cols if span.add(x)];rank=len(ind)
        rest=[]
        for j in range(n.dims[v]):
            x=tuple(F(i==j) for i in range(n.dims[v]))
            if span.add(x):rest.append(x)
        change=columns(ind+rest,n.dims[v]);inv=solve(change,eye(n.dims[v]))
        projections[v]=matrix(inv.rows[rank:],n.dims[v]);sections[v]=columns(rest,n.dims[v]);dims[v]=len(rest)
    maps={a:projections[t]@n.maps[a]@sections[s] for a,(s,t) in n.arrows.items()}
    return Rep(name,dims,n.arrows,maps),projections


def direct_sum(reps,name='sum'):
    first=reps[0];dims={v:sum(m.dims[v] for m in reps) for v in first.vertices};maps={}
    for a,(s,t) in first.arrows.items():
        rows=[[F(0)]*dims[s] for _ in range(dims[t])];ro=co=0
        for m in reps:
            for i,row in enumerate(m.maps[a].rows):
                for j,x in enumerate(row):rows[ro+i][co+j]=x
            ro+=m.dims[t];co+=m.dims[s]
        maps[a]=matrix(rows,dims[s])
    return Rep(name,dims,first.arrows,maps)


def self_test():
    q={'a':(2,1)};dims=lambda a,b:{1:a,2:b}
    s1=Rep('S1',dims(1,0),q);p2=Rep('P2',dims(1,1),q,{'a':[[1]]});s2=Rep('S2',dims(0,1),q)
    data=ar_quiver([s1,p2,s2],True)
    assert [(x['source'],x['target'],x['multiplicity']) for x in data['arrows']]==[('S1','P2',1),('P2','S2',1)]
    f=hom_basis(p2,s2)[0];k,_=kernel_rep(p2,s2,f);assert k.dimension()==(1,0)
    c,_=cokernel_rep(s1,p2,hom_basis(s1,p2)[0]);assert c.dimension()==(0,1)
    q={'t':(0,0)};s=Rep('S',{0:1},q);p=Rep('B',{0:2},q,{'t':[[0,0],[1,0]]})
    d=ar_quiver([s,p]);assert [(x['source'],x['target']) for x in d['arrows']]==[('S','B'),('B','S')]
    assert len(hom_basis(p,p))==2 and len(radical_basis(p,p,same=True))==1
    return {'exact_backend':'fractions.Fraction','checks':['A2 AR quiver','kernel and cokernel','dual-numbers radical and AR quiver'],'passed':True}


if __name__=='__main__':
    import json
    print(json.dumps(self_test()))
