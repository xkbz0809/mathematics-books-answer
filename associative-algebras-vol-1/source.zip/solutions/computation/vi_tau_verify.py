from vi_bmodels import *

def left_path_map(alg,a):
    i,j=alg.arrows[a];pi=alg.projectives[i];pj=alg.projectives[j];f={}
    for v in alg.vertices:
        cols=[]
        for start,w in pj.path_bases[v]:
            target=alg.reduce.get((i,(a,)+w));cols.append(tuple(F(p==target) for p in pi.path_bases[v]))
        f[v]=columns(cols,pi.dims[v])
    return f

def nu(alg,p):
    hs={i:hom_basis(p,alg.projectives[i]) for i in alg.vertices};maps={}
    for a,(i,j) in alg.arrows.items():
        f=left_path_map(alg,a);cols=[]
        for h in hs[j]:cols.append(tuple(x[0] for x in coords(hs[i],compose(f,h),p,alg.projectives[i]).rows))
        maps[a]=transpose(columns(cols,len(hs[i])))
    return Rep('nu('+p.name+')',{i:len(hs[i]) for i in alg.vertices},alg.arrows,maps),hs

def actual_tau(alg,m):
    p0,ep,(om,inc)=alg.cover(m)
    if not any(om.dims.values()):return None
    p1,ep1,_=alg.cover(om);f=compose(inc,ep1)
    n0,h0=nu(alg,p0);n1,h1=nu(alg,p1);nf={}
    for i in alg.vertices:
        cols=[tuple(x[0] for x in coords(h1[i],compose(h,f),p1,alg.projectives[i]).rows) for h in h0[i]]
        nf[i]=transpose(columns(cols,len(h1[i])))
    return kernel_rep(n1,n0,nf,'DTr('+m.name+')')[0]

def check(alg,reps):
    data=ar_data(alg,reps);by={m.name:m for m in reps};out=[]
    for m in reps:
        actual=actual_tau(alg,m)
        if actual is None:assert m.name in data['projectives'];continue
        t=match(actual,reps);assert t.name==data['tau'][m.name]
        dim=alg.ext1(m,t)
        # In these cases Ext^1(M,tau M) is one-dimensional, so the
        # non-split exact sequence calculated from the candidate middle term
        # is the genuine almost split sequence, independent of enumeration.
        assert dim==1,(m.name,dim,len(hom_basis(m,m)))
        assert m.name not in data['sequences'][m.name]['middle']
        out.append({'module':m.name,'tau':t.name,'ext1_dimension':dim,'DTr_matches':True})
    # The AR sequences cover all candidates on both ends; injectives are the
    # only possible left endpoints without a translate.
    assert set(data['tau'].values())==set(by)-set(data['injectives'])
    return {'checked_nonprojectives':out,'projectives':data['projectives'],'injectives':data['injectives']}

if __name__=='__main__':
    allout={}
    for key in ['14i','14ii','14iii','14iv','15','16','17','24']:
        a,rs=vi_case(key);allout['A'+key]=check(a,rs);print('A',key,'passed',flush=True)
    for key in ['14i','14ii','14iii','14iv','16','17','21']:
        _,_,_,_,a,rs=bmodels(key);allout['B'+key]=check(a,rs);print('B',key,'passed',flush=True)
    Path(__file__).with_name('vi_tau_certificates.json').write_text(json.dumps(allout,default=encode,indent=2),encoding='utf-8')
