"""Small bound-quiver models for VI; exact rational maps, no numerical guesses."""
from itertools import product
from collections import defaultdict
from ar_linear import *


def thin_modules(vertices,arrows,zeros=(),equalities=()):
    """All connected thin 0/1 representations; completeness is NOT assumed."""
    out=[]
    for dims_tuple in product([0,1],repeat=len(vertices)):
        if not any(dims_tuple):continue
        dims=dict(zip(vertices,dims_tuple));active=[a for a,(s,t) in arrows.items() if dims[s] and dims[t]]
        for bits in product([0,1],repeat=len(active)):
            on={a for a,b in zip(active,bits) if b};support={v for v in vertices if dims[v]}
            seen={next(iter(support))}
            while True:
                enlarged=seen|{t for a,(s,t) in arrows.items() if a in on and s in seen}|{s for a,(s,t) in arrows.items() if a in on and t in seen}
                if enlarged==seen:break
                seen=enlarged
            if seen!=support:continue
            rep=Rep('',dims,arrows,{a:[[1]] for a in on})
            if any(any(rep.path(z).flat()) for z in zeros):continue
            if any(rep.path(a).rows!=rep.path(b).rows for a,b in equalities):continue
            rep.name=''.join(map(str,dims_tuple))+('['+','.join(sorted(on))+']' if len(on)<len(active) else '')
            out.append(rep)
    return out


def string_modules(vertices,arrows,zeros,max_length=20):
    """Enumerate strings modulo inversion; fail if chosen bound is reached."""
    letters=[(a,d) for a in arrows for d in [1,-1]]
    endpoints={(a,1):pair for a,pair in arrows.items()}
    endpoints.update({(a,-1):(t,s) for a,(s,t) in arrows.items()})
    forbidden=[tuple((a,1) for a in z) for z in zeros]+[tuple((a,-1) for a in reversed(z)) for z in zeros]
    def valid(word):
        if len(word)>1 and word[-1]==(word[-2][0],-word[-2][1]):return False
        return not any(len(word)>=len(z) and word[-len(z):]==z for z in forbidden)
    def reverse(word):return tuple((a,-d) for a,d in reversed(word))
    words=[];frontier=[(a,) for a in letters]
    while frontier:
        assert len(frontier[0])<max_length,'potential infinite strings/band: mathematical analysis required'
        words.extend(w for w in frontier if w<=reverse(w))
        frontier=[w+(a,) for w in frontier for a in letters if endpoints[w[-1]][1]==endpoints[a][0] and valid(w+(a,))]
    out=[Rep('S'+str(v),{x:int(x==v) for x in vertices},arrows) for v in vertices]
    for word in words:
        vs=[endpoints[word[0]][0]]+[endpoints[a][1] for a in word]
        dims={v:vs.count(v) for v in vertices};indices=[];counts=defaultdict(int)
        for v in vs:indices.append(counts[v]);counts[v]+=1
        rows={a:[[0]*dims[s] for _ in range(dims[t])] for a,(s,t) in arrows.items()}
        for j,(a,d) in enumerate(word):
            src,dst=(j,j+1) if d==1 else (j+1,j)
            rows[a][indices[dst]][indices[src]]+=1
        name=''.join(a+('^-' if d<0 else '') for a,d in word)
        out.append(Rep(name,dims,arrows,rows))
    return out


class Algebra:
    def __init__(self,vertices,arrows,zeros=(),equalities=()):
        self.vertices=tuple(vertices);self.arrows=arrows;self.zeros=tuple(map(tuple,zeros));self.equalities=equalities
        paths=[(v,()) for v in vertices];front=paths[:]
        def endpoint(p):return arrows[p[1][-1]][1] if p[1] else p[0]
        def killed(w):return any(tuple(w[i:i+len(z)])==z for z in self.zeros for i in range(len(w)-len(z)+1))
        for length in range(1,21):
            new=[(s,w+(a,)) for s,w in front for a,(u,v) in arrows.items() if endpoint((s,w))==u and not killed(w+(a,))]
            if not new:break
            paths+=new;front=new
        else:raise ValueError('path bound reached')
        parent={p:p for p in paths};parent[None]=None
        def find(x):
            while parent[x]!=x:x=parent[x]
            return x
        def union(a,b):
            a,b=find(a),find(b)
            if a!=b:parent[a]=b
        for p in paths:
            s,w=p
            for left,right in equalities:
                for a,b in [(tuple(left),tuple(right)),(tuple(right),tuple(left))]:
                    for j in range(len(w)-len(a)+1):
                        if w[j:j+len(a)]==a:
                            q=(s,w[:j]+b+w[j+len(a):]);union(p,None if killed(q[1]) else q)
        groups=defaultdict(list)
        for p in paths:groups[find(p)].append(p)
        killed_root=find(None)
        canonical={key:min(vals,key=lambda x:(len(x[1]),x[0],x[1])) for key,vals in groups.items() if key!=killed_root}
        self.reduce={p:canonical.get(find(p)) for p in paths};self.paths=sorted(set(canonical.values()),key=lambda x:(x[0],len(x[1]),x[1]));self.endpoint=endpoint
        self.projectives={v:self.projective(v) for v in vertices};self.injectives={v:self.injective(v) for v in vertices}

    def projective(self,i):
        bases={v:[p for p in self.paths if p[0]==i and self.endpoint(p)==v] for v in self.vertices}
        dims={v:len(bases[v]) for v in self.vertices};maps={}
        for a,(s,t) in self.arrows.items():
            rows=[[0]*dims[s] for _ in range(dims[t])]
            for j,p in enumerate(bases[s]):
                q=self.reduce.get((i,p[1]+(a,)))
                if q is not None:rows[bases[t].index(q)][j]=1
            maps[a]=matrix(rows,dims[s])
        rep=Rep('P'+str(i),dims,self.arrows,maps);rep.path_bases=bases;return rep

    def injective(self,i):
        bases={v:[p for p in self.paths if p[0]==v and self.endpoint(p)==i] for v in self.vertices}
        dims={v:len(bases[v]) for v in self.vertices};maps={}
        for a,(s,t) in self.arrows.items():
            rows=[[0]*dims[s] for _ in range(dims[t])]
            for k,p in enumerate(bases[t]):
                q=self.reduce.get((s,(a,)+p[1]))
                if q is not None:rows[k][bases[s].index(q)]=1
            maps[a]=matrix(rows,dims[s])
        return Rep('I'+str(i),dims,self.arrows,maps)

    def cover(self,m):
        summands=[];generator_data=[]
        for v in self.vertices:
            span=Span()
            for a,(s,t) in self.arrows.items():
                if t==v:
                    for j in range(m.dims[s]):span.add([m.maps[a].rows[i][j] for i in range(m.dims[v])])
            for j in range(m.dims[v]):
                x=tuple(F(i==j) for i in range(m.dims[v]))
                if span.add(x):summands.append(self.projectives[v]);generator_data.append((v,x))
        if not summands:return None,None,None
        p=direct_sum(summands,'cover('+m.name+')');morph={}
        for v in self.vertices:
            cols=[]
            for proj,(start,x) in zip(summands,generator_data):
                for _,word in proj.path_bases[v]:
                    image=(m.path(word)@columns([x],m.dims[start])) if word else columns([x],m.dims[start])
                    cols.append(tuple(row[0] for row in image.rows))
            morph[v]=columns(cols,m.dims[v])
        kernel,inclusion=kernel_rep(p,m,morph,'Omega('+m.name+')')
        return p,morph,(kernel,inclusion)

    def ext1(self,m,n):
        p,f,(k,inc)=self.cover(m)
        basis=hom_basis(k,n);span=Span()
        for h in hom_basis(p,n):span.add(flatten(compose(h,inc),m.vertices))
        return len(basis)-len(span)

    def projective_dimension(self,m,limit=12):
        seen=set()
        for d in range(limit+1):
            if not any(m.dims.values()):return max(0,d-1)
            signature=(m.dimension(),tuple(tuple(x.flat()) for x in m.maps.values()))
            if signature in seen:return 'infinite-periodic'
            seen.add(signature)
            p,f,(k,inc)=self.cover(m)
            if not any(k.dims.values()):return d
            m=k
        return 'beyond-bound'


def vi_case(key):
    n=5;equalities=[];zeros=[];extra=[]
    if key=='14i':
        arrows={'a':(4,3),'b':(3,1),'c':(5,3),'d':(3,2)};zeros=[('a','b'),('c','d')]
    elif key in ['14ii','21']:
        arrows={'a':(5,2),'b':(2,1),'c':(5,4),'d':(4,3),'e':(3,1)};equalities=[(('a','b'),('c','d','e'))]
    elif key=='14iii':
        arrows={'a':(1,3),'b':(2,3),'c':(3,4),'d':(4,5)};zeros=[('c','d')]
    elif key=='14iv':
        n=2;arrows={'a':(1,2),'b':(2,1)};zeros=[('b','a')]
    elif key=='15':
        n=3;arrows={'a':(3,2),'b':(2,1),'c':(3,1)};zeros=[('a','b')]
    elif key=='16':
        arrows={'a':(5,2),'b':(2,1),'c':(5,4),'d':(4,3),'e':(3,1)};zeros=[('a','b'),('c','d'),('d','e')]
    elif key=='17':
        arrows={'a':(4,2),'b':(2,1),'c':(4,3),'d':(3,1),'e':(5,4)};zeros=[('e','a'),('e','c')];equalities=[(('a','b'),('c','d'))]
    elif key=='24':
        arrows={'a':(5,3),'b':(3,1),'c':(5,4),'d':(4,1),'e':(4,2)};equalities=[(('a','b'),('c','d'))]
    else:raise ValueError(key)
    vs=tuple(range(1,n+1));alg=Algebra(vs,arrows,zeros,equalities)
    if key in ['14i','14iv','15','16']:
        reps=string_modules(vs,arrows,zeros)
    elif key in ['14ii','21','17']:
        reps=string_modules(vs,arrows,zeros+[p for eq in equalities for p in eq]);reps.append(alg.projectives[5 if key!='17' else 4])
    else:
        reps=thin_modules(vs,arrows,zeros,equalities)
        if key=='14iii':reps.append(Rep('R',{1:1,2:1,3:2,4:1,5:0},arrows,{'a':[[1],[0]],'b':[[0],[1]],'c':[[1,1]]}))
        if key=='24':reps.append(Rep('R',{1:1,2:1,3:1,4:2,5:1},arrows,{'a':[[1]],'b':[[1]],'c':[[1],[0]],'d':[[1,0]],'e':[[1,1]]}))
    for i,m in enumerate(reps,1):m.original_name=m.name;m.name='M'+str(i)
    return alg,reps


if __name__=='__main__':
    import json
    from pathlib import Path
    folder=Path(__file__).resolve().parent
    for key in ['14i','14ii','14iii','14iv','15','16','17','24']:
        alg,reps=vi_case(key)
        data=ar_quiver(reps,False)
        for row,m in zip(data['vertices'],reps):
            row['string_or_model']=m.original_name
            row['maps']={a:x.tolist() for a,x in m.maps.items()}
            row['pd']=alg.projective_dimension(m)
        data['arrows_of_algebra']=alg.arrows;data['zero_relations']=alg.zeros;data['commutativity_relations']=alg.equalities
        data['hom']=[[len(hom_basis(m,n)) for n in reps] for m in reps]
        data['ext1']=[[alg.ext1(m,n) for n in reps] for m in reps]
        data['projectives']={v:p.dimension() for v,p in alg.projectives.items()}
        data['injectives']={v:p.dimension() for v,p in alg.injectives.items()}
        data['completeness']='Needs the separate mathematical classification in solution text; this is an exact check on listed models.'
        (folder/f'vi_{key}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        print(json.dumps({'case':key,'modules':len(reps),'arrows':len(data['arrows']),'pd':[v['pd'] for v in data['vertices']]}),flush=True)
