# 结合代数表示论基础 · 第 1 卷习题解答源码

使用带 Fandol 与 CM Unicode 字体的 TeX Live。在源码目录依次运行两遍 xelatex main、biber main，再运行两遍 xelatex main。book-labels.aux 提供外部编号映射，配套译本 PDF 用于阅读时的跨册跳转。收录 165 个题号，IX.12 因编写所据版本缺页暂缺解答。
