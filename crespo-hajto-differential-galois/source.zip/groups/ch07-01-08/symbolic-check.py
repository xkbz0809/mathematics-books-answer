import sympy as s

z, x, a, n = s.symbols('z x a n')
U = s.Function('U')(x)
assert s.expand(-x*x*s.diff(-x*x*s.diff(U,x),x))==x**4*s.diff(U,x,2)+2*x**3*s.diff(U,x)
for y in (1+z,2*(s.exp(z)-1-z)):
    assert s.simplify(s.diff(y,z,2)-(1+z)/z*s.diff(y,z)+y/z)==0
for co in (1,2):
    pp=co*z/(z**2-1)
    qq=-(a**2 if co==1 else n*(n+1))/(z**2-1)
    assert s.simplify(2/x-pp.subs(z,1/x)/x**2-((1-2*x**2)/x if co==1 else -2*x)/(1-x**2))==0
    assert s.simplify(qq.subs(z,1/x)/x**4+(a**2 if co==1 else n*(n+1))/(x**2*(1-x**2)))==0
    for eps in (0,1):
        c=s.Rational(1,s.factorial(eps))
        y=0
        for k in range(eps,13,2):
            y+=c*z**k
            c*=((k*(k+co-1))-(a**2 if co==1 else n*(n+1)))/((k+2)*(k+1))
        residual=s.Poly(s.expand((1-z*z)*s.diff(y,z,2)-co*z*s.diff(y,z)+(a**2 if co==1 else n*(n+1))*y),z)
        assert all(s.simplify(residual.nth(k))==0 for k in range(11))
A,Ap,B,Bp,G,Gp=s.symbols('A Ap B Bp G Gp')
Gp=1-A-Ap-B-Bp-G
p=(1-A-Ap)/z+(1-B-Bp)/(z-1)
q=A*Ap/z**2+B*Bp/(z-1)**2+(G*Gp-A*Ap-B*Bp)/(z*(z-1))
h=A/z+B/(z-1)
aa,bb,cc=G+A+B,Gp+A+B,1+A-Ap
assert s.cancel(p+2*h-((aa+bb+1)*z-cc)/(z*(z-1)))==0
assert s.cancel(q+p*h+s.diff(h,z)+h*h-aa*bb/(z*(z-1)))==0
print("OK: chain rule, explicit solutions, inversion, series recurrences, and hypergeometric gauge")
