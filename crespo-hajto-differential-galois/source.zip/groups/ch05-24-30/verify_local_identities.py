#!/usr/bin/env python3
"""Independent coefficient checks for Exercises 5.25 and 5.29."""
from math import comb, factorial
from sympy import diff, expand, eye, Matrix, simplify, symbols, zeros

u,v,y,h,c,x,T=symbols("u v y h c x T")
d = lambda f: expand(v*diff(f,u)-4*u*diff(f,v)+h*diff(f,y)-y*diff(f,h))
assert d(y*y+h*h)==0 and d(u*y*y+v*y*h-u*h*h)==0
assert expand((v*v-4*(c+u)*(c-u)).subs(v*v,-1-4*u*u))==-1-4*c*c

def assert_vector_eq(a,b):
    assert all(expand(t)==0 for t in a-b), (a,b)

for n in range(1,5):
    # An arbitrary-looking connection over Q(x), to test formulas, not replace the proof.
    A=Matrix(n,n,lambda i,j: (i-j)*x+(i+1)*(j+2))
    D=lambda w:w.diff(x)-A*w
    z=zeros(n,1)
    E=[eye(n)[:,i] for i in range(n)]
    powers=[E]
    for j in range(n):
        powers.append([D(w) for w in powers[-1]])
    C=[sum(((-1)**p*comb(j,p)*powers[p][j-p] for p in range(j+1)),z) for j in range(n)]
    V=sum((x**j/factorial(j)*C[j] for j in range(n)),z)
    rows=[]
    for i in range(n):
        assert_vector_eq(V,sum((x**j/factorial(j)*C[j] for j in range(n)),z))
        for j in range(n-i):
            assert_vector_eq(C[j],sum(((-1)**p*comb(j,p)*powers[p][i+j-p] for p in range(j+1)),z))
        rows.append(sum((T**j/factorial(j)*C[j] for j in range(n)),z).T)
        C=[D(C[j])+C[j+1] for j in range(n-1)]+[D(C[-1])]
        V=D(V)
    assert_vector_eq(Matrix.vstack(*rows).subs(T,0),eye(n))
print("PASS: both conserved quantities, the discriminant, and cyclic-vector coefficient checks at ranks 1–4.")
