# Crespo–Hajto 第 5 章习题 (1)–(8) 审校

直接核对影印本印刷第 133 页 / 扫描 PDF 第 147 页的 8 道题。第 (8) 题两小问齐全；第 (6) 题对应原书第 125 页 / PDF139 的引理 5.4.1，两个方向和唯一性均证明。前八题不跨页。

- 5.1 按原书定义证明高阶 Leibniz 公式，并始终保留乘积顺序；5.2 用内导子在 Q 上矩阵环明确核对 a²=a、Ba=0、aB=B。
- 5.3 用同一个纯不可分扩张给出不延拓及多延拓两例；第 5.5 节才开始设特征零。5.4 先在超越基上指定导数为零，再延拓到可分代数部分；纯超越扩张保持不可约性，故中间代数子域确实可分且所有延拓限制相同。
- 5.5 取求值同态核的首一生成元，而非假定微分环扩张是域；导数只施于系数使次数下降，实际不需可分性。这是加强结论，不是题干错误。
- 5.6 商放在左/右的约定与 Maple 按除式位置命名恰相反；数学公式明确保留。两种消首项用同一最高项系数，因为系数域交换且 Ore 求导只产生低阶项。
- 5.7 核对 Maplesoft 官方帮助：[rightdivision / leftdivision](https://www.maplesoft.com/support/help/maple/view.aspx?path=DEtools/rightdivision), [GCRD](https://www.maplesoft.com/support/help/maple/view.aspx?path=DEtools/GCRD), [LCLM](https://www.maplesoft.com/support/help/maple/view.aspx?path=DEtools/LCLM), [DFactor](https://www.maplesoft.com/support/help/maple/view.aspx?path=DEtools/DFactor), [mult](https://www.maplesoft.com/support/help/maple/view.aspx?path=DEtools/mult). 两个非对称反例、公共因子、最小左倍式及有序分解均用手算并由 verify_operator_examples.py 独立核对。Maple 环境不可用，未声称执行过 Maple；maple-examples.mpl 可复核。算法可能返回另一有序不可约分解，不写死输出表。
- 5.8 用乘积求导、平方和根性证明 a)，再对每个 s 使用 a) 及根条件证明 T；不使用除以任何整数，因此任意特征都成立。
- 这些题未发现新题干错误。第 5.7 题引用已交付勘误 DG-G-087 的正文术语区分，不当作新增条目。
