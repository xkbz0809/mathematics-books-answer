restart:
with(DEtools):
dom := [Dx,x]:
P := mult(Dx-x,Dx,dom):
rightdivision(P,Dx,dom);
leftdivision(P,Dx,dom);
rightdivision(P,Dx-x,dom);
leftdivision(P,Dx-x,dom);
L := mult(Dx+x,Dx-x,dom):
rightdivision(L,Dx-x,dom);
leftdivision(L,Dx-x,dom);
GCRD(P,Dx^2,dom);
LCLM(Dx,Dx-x,dom);
F := DFactor(P,dom):
F;
normal(mult(op(F),dom)-P);
