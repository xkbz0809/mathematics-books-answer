#!/usr/bin/env python3
"""Independent symbolic verification, not a claim of actually executing Maple."""
from math import comb
from sympy import diff, expand, simplify, symbols
x = symbols("x")
D = {1: 1}
one = {0: 1}

def mult(P, Q):
    out = {}
    for i, a in P.items():
        for j, b in Q.items():
            for k in range(i + 1):
                v = i + j - k
                out[v] = out.get(v, 0) + a * comb(i, k) * diff(b, x, k)
    return out

def assert_equal(P, Q):
    assert all(simplify(P.get(i, 0) - Q.get(i, 0)) == 0 for i in set(P) | set(Q)), (P, Q)

Da = {1: 1, 0: -x}
Db = {1: 1, 0: x}
P = {2: 1, 1: -x}
L = {2: 1, 0: -x**2 - 1}
M = {2: 1, 1: -x - 1/x}

assert_equal(mult(Da, D), P)
assert_equal(mult(D, Da), {**P, 0: -1})
assert_equal(mult(Db, Da), L)
assert_equal(mult(Da, Db), {**L, 0: -x**2 + 1})
assert_equal(mult({1: 1, 0: -x - 1/x}, D), M)
assert_equal(mult({1: 1, 0: -1/x}, Da), M)
assert_equal(mult({0: 1/x}, {1: x}), D)
print("PASS: 7 differential-operator identities, including both sides of the LCLM identity.")
