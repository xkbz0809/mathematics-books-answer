#!/usr/bin/env python3
"""Symbolic verification of Riccati/polynomial tests, not a replacement for case screening."""
import sympy as s
z,T,a,b,d,e=s.symbols("z T a b d e")
R=s.Rational

def ok(expr):
    assert s.cancel(expr)==0, expr

p=2*z/(z*z-1)
q=-d*(d+1)/(z*z-1)
ok(s.diff(p,z)/2+p**2/4-q-(d*(d+1)/(z*z-1)-1/(z*z-1)**2))

r11=z*z-2*z+3+1/z+R(7,4)/z**2-5/z**3+1/z**4
test=lambda P,th,r: s.cancel(s.diff(P,z,2)+2*th*s.diff(P,z)+(s.diff(th,z)+th**2-r)*P)
thp=z-1+1/z**2-R(3,2)/z
thm=-(z-1)+1/z**2-R(3,2)/z
ok(test(1,thm,r11)+2*(3*z-2)/z**2)
ok(test(z*z-1,thp,r11))
J=s.Poly(s.cancel(z*z*test(z*z+a*z+b,thp,r11)),z)
assert s.solve(J.all_coeffs(),[a,b],dict=True)==[{a:0,b:-1}]

for d0 in range(7):
    for eps in (-s.I,s.I):
        c={d0:1}
        for k in range(d0-1,-1,-1):
            c[k]=-(k+1)*(k-2*d0)*c[k+1]/(2*eps*(k-d0))
        P=sum(c[k]*z**k for k in c)
        ok(test(P,eps-d0/z,-1+d0*(d0+1)/z**2))

r14=1/z-R(3,16)/z**2
th=1/(2*z)
ok(s.diff(th,z,2)+3*th*s.diff(th,z)+th**3-4*r14*th-2*s.diff(r14,z))
for eps in (-1,1):
    w=1/(4*z)+eps/s.sqrt(z)
    ok(s.diff(w,z)+w**2-r14)

r15=-R(3,16)/z**2-R(2,9)/(z-1)**2+R(3,16)/(z*(z-1))
S=z*(z-1)
for e1 in [4,5]:
    n=4
    th=1/z+R(e1,3)/(z-1)
    P={n:s.Integer(-1),n+1:s.Integer(0)}
    for i in range(n,-1,-1):
        P[i-1]=s.cancel(-S*s.diff(P[i],z)+((n-i)*s.diff(S,z)-S*th)*P[i]-(n-i)*(i+1)*S**2*r15*P[i+1])
    assert P[-1]==0
    if e1==4:
        expected={3:(7*z-3)/3, 2:-(48*z**2-41*z+9)/12, 1:(320*z**3-409*z**2+180*z-27)/72, 0:-(2048*z**4-3484*z**3+2313*z**2-702*z+81)/864}
        for i,pi in expected.items():
            ok(P[i]-pi)
    F=sum(S**i*P[i]*T**i/s.factorial(n-i) for i in range(n+1))
    assert s.discriminant(F.subs(z,2),T)!=0
    ok(s.diff(F,z)+s.diff(F,T)*(r15-T**2)-(n*s.diff(S,z)/S-th-n*T)*F)
print("PASS: Legendre reduction; both 7.11 tests; Bessel recurrences (degrees 0–6); 7.14 Riccati; both 7.15 quartics squarefree and Riccati-compatible.")
