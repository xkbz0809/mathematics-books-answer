#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode groups-solutions-release.tex; done
