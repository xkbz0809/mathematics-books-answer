"""Independent symbolic checks for §7.1; numeric verification only for connection identity."""
from sympy import symbols, diff, simplify, limit, factor, Rational
import mpmath as mp

z, X = symbols('z X')
a, b, c = symbols('a b c')
A = ((a+b+1)*z-c)/(z*(z-1))
B = a*b/(z*(z-1))
indicial0 = factor(X*(X-1)+limit(z*A,z,0)*X+limit(z**2*B,z,0))
indicial1 = factor(X*(X-1)+limit((z-1)*A,z,1)*X+limit((z-1)**2*B,z,1))
from sympy import oo
indicialinf = factor(X*(X+1)-limit(z*A,z,oo)*X+limit(z**2*B,z,oo))
assert simplify(indicial0-X*(X+c-1))==0
assert simplify(indicial1-X*(X+a+b-c))==0
assert simplify(indicialinf-(X-a)*(X-b))==0
print('Indicial polynomials at 0, 1, infinity:',indicial0,indicial1,indicialinf)

def check_gauge_variable(f,eta,aa,bb,cc):
    """y(z)=p(z)u(f(z)), eta=p'/p; verify u is the stated hypergeometric equation."""
    g=diff(f,z)
    new_A=(2*eta*g+diff(g,z)+A*g)/g**2
    new_B=(diff(eta,z)+eta**2+A*eta+B)/g**2
    target_A=((aa+bb+1)*f-cc)/(f*(f-1))
    target_B=aa*bb/(f*(f-1))
    assert simplify(new_A-target_A)==0
    assert simplify(new_B-target_B)==0

check_gauge_variable(z,0,a,b,c)
check_gauge_variable(z,(1-c)/z,a-c+1,b-c+1,2-c)
check_gauge_variable(1-z,0,a,b,a+b-c+1)
check_gauge_variable(1-z,-(c-a-b)/(1-z),c-a,c-b,c-a-b+1)
check_gauge_variable(1/z,-a/z,a,a-c+1,a-b+1)
check_gauge_variable(1/z,-b/z,b,b-c+1,b-a+1)
print('Exact symbolic substitution verifies all six local formulas in their applicable parameter ranges.')

# A nonterminating, nonresonant numerical test of the Gamma connection formula.
mp.mp.dps=75
r=mp.mpf
a,b,c=r('0.2'),r('0.4'),r('1.3')
delta=c-a-b
for z in [r('0.41'),mp.mpc('0.48','0.15')]:
    lhs=mp.hyp2f1(a,b,c,z)
    rhs=(mp.gamma(c)*mp.gamma(delta)/(mp.gamma(c-a)*mp.gamma(c-b))*mp.hyp2f1(a,b,1-delta,1-z)
         +mp.gamma(c)*mp.gamma(-delta)/(mp.gamma(a)*mp.gamma(b))*(1-z)**delta*mp.hyp2f1(c-a,c-b,1+delta,1-z))
    residual=abs(lhs-rhs)
    assert residual<r('1e-70')
    print('Gamma-connection residual:',mp.nstr(residual,4))
