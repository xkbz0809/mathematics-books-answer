#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
(cd "ch01-projective"
  export TEXINPUTS=".:../ch03-sec34:../ch03-sec34/figures:${TEXINPUTS:-}"
  for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode "groups-translation.tex"; done)
if [[ -d errata ]]; then (
  cd errata
  for lang in zh en; do for i in 1 2 3; do xelatex -halt-on-error -interaction=nonstopmode "errata-g-$lang.tex"; done; done
); fi
