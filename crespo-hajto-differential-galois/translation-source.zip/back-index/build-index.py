from pathlib import Path
import re
from collections import Counter
base=Path(__file__).resolve().parent
data=base/'index.tsv'
headers=['\\chapter*{索引（原书页码）}\\markboth{索引}{索引}\\label{groups:original-print-index}','','\\noindent 条目按原书的英文顺序排列；页码均指原书印刷页码，并非本译稿页码。','','\\begin{multicols}{2}','\\begingroup','\\small','\\setlength{\\parindent}{0pt}','\\setlength{\\parskip}{0.36ex}','\\raggedright']
out=headers[:]
blocks=[[]]
level0=0
for line in data.read_text().splitlines():
    if not line or line.startswith('#'):
        if line.startswith('# Print'): blocks.append([])
        continue
    depth,cn,en,ref=line.split('|')
    assert depth in ('0','1') and cn and en
    assert not ref or re.fullmatch(r'\d+(?:,\d+)*',ref)
    if depth=='1': assert level0
    else: level0+=1
    if ref: blocks[-1].extend(map(int,ref.split(',')))
    lead = r'\noindent\hangindent=0.6em\relax ' if depth=='0' else r'\noindent\hangindent=1.6em\relax\hspace*{1em}'
    title=f'\\textbf{{{cn}}}' if depth=='0' else cn
    page=f'\\nobreak\\hfill\\mbox{{{ref.replace(",",", ")}}}' if ref else r'\nopagebreak[3]'
    out.append(lead+title+r' {\footnotesize ('+en+r')}'+page+r'\par')
out.extend(['\\endgroup','\\end{multicols}'])
indexfiles=[base/'../navigational-ocr'/f'physical-{i}.txt' for i in range(237,240)]
for i,(refs,ocr) in enumerate(zip(blocks,indexfiles),223):
    matches=[int(x) for x in re.findall(r'\b\d+\b',ocr.read_text()) if int(x)!=i]
    assert Counter(matches)==Counter(refs),(i,Counter(matches)-Counter(refs),Counter(refs)-Counter(matches))
    print(i,len(refs),'original page numbers matched')
print(len(out)-len(headers)-2, 'index rows;',level0,'top-level headings')
(base/'original-index.tex').write_text('\n'.join(out)+'\n')
