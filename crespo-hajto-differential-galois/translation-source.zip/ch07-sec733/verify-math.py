import sympy as s
from fractions import Fraction
z = s.symbols('z', nonzero=True)
a = s.symbols('a', real=True)
r = ((a*a-s.Rational(1,4))*z*z-a*a-s.Rational(1,2))/(z*z-1)**2
t = z/(z*z-1)
w = t/2+a/s.sqrt(z*z-1)
assert s.simplify(s.diff(w,z)+w*w-r)==0
assert s.simplify(w*w-t*w+s.diff(t,z)/2+t*t/2-r)==0
assert s.simplify(s.diff(t,z,2)+3*t*s.diff(t,z)+t**3-4*r*t-2*s.diff(r,z))==0
assert s.limit(z*z*r,z,s.oo)==a*a-s.Rational(1,4)
T,P,R=s.Function('T')(z),s.Function('P')(z),s.Function('R')(z)
V=s.exp(T)*P
rhs=s.diff(V,z,3)-4*R*s.diff(V,z)-2*s.diff(R,z)*V
th=s.diff(T,z)
coeff=s.diff(P,z,3)+3*th*s.diff(P,z,2)+(3*th**2+3*s.diff(th,z)-4*R)*s.diff(P,z)+(s.diff(th,z,2)+3*th*s.diff(th,z)+th**3-4*R*th-2*s.diff(R,z))*P
assert s.simplify(rhs/s.exp(T)-coeff)==0
e,f,b=s.symbols('e f b')
g=e/(2*z)+f
lhs=s.expand(s.diff(g,z,2)+3*g*s.diff(g,z)+g**3)
assert lhs.coeff(z,-3) == e**3/8-3*e**2/4+e
assert lhs.coeff(z,-2) == 3*e**2*f/4-3*e*f/2
assert s.expand(4*b*g/z+2*s.diff(b/z,z)).coeff(z,-2)==2*e*b-2*b
b=s.symbols('b')
assert s.expand((lhs.coeff(z,-3)-2*e*b+4*b)*8-(e-2)*(-16*b+e**2-4*e))==0
rs=[(101-81*z*z)/(48*(1+3*z*z)**2),(-128*z*z+155*z-135)/(576*z*z*(z-1)**2),-3*(25*z*z-8*z/s.sqrt(5)+19)/(16*(5*z*z-1)**2)]
centres=[(s.I/s.sqrt(3),-s.I/s.sqrt(3)),(s.Integer(0),s.Integer(1)),(1/s.sqrt(5),-1/s.sqrt(5))]
expected=[(-s.Rational(2,9),-s.Rational(2,9),-s.Rational(3,16)),(-s.Rational(15,64),-s.Rational(3,16),-s.Rational(2,9)),(-s.Rational(21,100),-s.Rational(6,25),-s.Rational(3,16))]
for r,cs,bb in zip(rs,centres,expected):
    b1,b2,binf=bb
    assert s.simplify(s.limit((z-cs[0])**2*r,z,cs[0])-b1)==0
    assert s.simplify(s.limit((z-cs[1])**2*r,z,cs[1])-b2)==0
    assert s.simplify(s.limit(z*z*r,z,s.oo)-binf)==0
def E(b):
    q=s.sqrt(1+4*b)
    return {int(x) for x in [s.Integer(2),2-2*q,2+2*q] if x.is_Integer}
assert [[E(x) for x in row] for row in expected]==[[{2},{2},{1,2,3}],[{2},{1,2,3},{2}],[{2},{2},{1,2,3}]]
for (a,b,c) in expected:
    assert all(Fraction(ei-e1-e2,2)<0 for e1 in E(a) for e2 in E(b) for ei in E(c))
print('Validated polynomial gauge, Chebyshev quadratic/Riccati/P=1, first local coefficients, finite and infinite pole sets, and d<0 tests.')
