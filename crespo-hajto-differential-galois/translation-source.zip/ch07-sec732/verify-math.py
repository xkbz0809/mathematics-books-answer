"""Independent symbolic and exact-arithmetic checks, no exercise solutions."""
import itertools
import sympy as S
from fractions import Fraction as F

z, A = S.symbols('z A')
R=S.Rational
sqrt=S.sqrt
s=S.simplify
p=z/(z**2-1)
r=((A**2-R(1,4))*z**2-A**2-R(1,2))/(z**2-1)**2
assert s(r-(S.diff(p,z)/2+p**2/4+A**2/(z**2-1)))==0
for sign in (1,-1):
    w=z/(2*(z**2-1))+sign*A/sqrt(z**2-1)
    assert s(S.diff(w,z)+w*w-r)==0
w=z/(2*(z**2-1))
assert s(S.diff(w,z)+w*w-r.subs(A,0))==0
for b in (R(1,4),R(3,4)):
    w=b/(z-1)+(1-b)/(z+1)
    assert s(S.diff(w,z)+w*w-r.subs(A,R(1,2)))==0
assert S.limit(z**2*r,z,S.oo)==A**2-R(1,4)
assert all(S.limit((z-c)**2*r,z,c)==-R(3,16) for c in (1,-1))

def check_examples():
    for r,poles,ep in [
        ((101-81*z**2)/(48*(1+3*z*z)**2),(S.I/sqrt(3),-S.I/sqrt(3)),((F(1,3),F(2,3)),(F(1,3),F(2,3)),(F(1,4),F(3,4)))),
        ((-128*z**2+155*z-135)/(576*z**2*(z-1)**2),(0,1),((F(3,8),F(5,8)),(F(1,4),F(3,4)),(F(1,3),F(2,3)))),
        (-3*(25*z**2-8*z/sqrt(5)+19)/(16*(5*z**2-1)**2),(1/sqrt(5),-1/sqrt(5)),((F(3,10),F(7,10)),(F(2,5),F(3,5)),(F(1,4),F(3,4)))),
    ]:
        bs=[S.limit((z-c)**2*r,z,c) for c in poles]+[S.limit(z*z*r,z,S.oo)]
        for b,ab in zip(bs,ep):
            a,aa=map(S.Rational,ab)
            assert s(a*(a-1)-b)==0 and s(aa*(aa-1)-b)==0,(b,ab)
        assert all((c-a-b).denominator!=1 for a,b,c in itertools.product(*ep))
    print('Examples 7.3.5(2)–(4): all local coefficients and noninteger degrees verified.')

def check_branch_pairing():
    # One high-pole example, construct r from a known rational Riccati solution.
    w=2/z**2+3/z+z
    r=S.expand(S.diff(w,z)+w*w)
    a0,b0=2,S.expand(r-4/z**4).coeff(z,-3)
    assert (b0/a0+2)/2==3
    aI,bI=1,S.expand(r-z*z).coeff(z,0)
    assert (bI/aI-1)/2==3
    print('Finite-pole and infinity sign pairings verified in a fourth-order/polynomial test.')

check_examples()
check_branch_pairing()
print('Chebyshev normalization, both radical Riccati branches, alpha=0 and ±1/2 counterchecks verified.')
