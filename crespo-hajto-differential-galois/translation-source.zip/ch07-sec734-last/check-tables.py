#!/usr/bin/env python3
from itertools import product
import sympy as a
z,T=a.symbols('z T')
sqrt, I = a.sqrt,a.I
q=I*sqrt(3)
h=sqrt(5)
QQ=a.Rational
cases = {
    4: ( (101-81*z*z)/(48*(1+3*z*z)**2), [q/3,-q/3], [5,4], 9, q ),
    6: ( (-128*z*z+155*z-135)/(576*z*z*(z-1)**2), [0,1], [5,3], 8, None ),
    12: ( -3*(25*z*z-8*z/h+19)/(16*(5*z*z-1)**2), [1/h,-1/h], [4,5], 9, h ),
}
scans = {
 4: [
  [-1], [3,q/9], [QQ(27,4),-4*q/9,-QQ(1,36)],
  [QQ(81,8),7*sqrt(3)/8,QQ(25,216),-q/216],
  [-QQ(243,32),-3*q/4,-QQ(71,432),13*q/972,-QQ(1,864)]
 ],
 6: [
  [-1], [4,-QQ(5,2)], [-QQ(40,3),QQ(1595,96),-QQ(165,32)],
  [QQ(320,9),-QQ(19085,288),QQ(11815,288),-QQ(135,16)],
  [-QQ(640,9),QQ(705,4),-QQ(250795,1536),QQ(154405,2304),-QQ(5265,512)],
  [QQ(2560,27),-QQ(5275,18),QQ(1664435,4608),-QQ(6136255,27648),QQ(4895,72),-QQ(8505,1024)],
  [-QQ(5120,81),QQ(18950,81),-QQ(4973285,13824),QQ(390462455,1327104),-QQ(179120705,1327104),QQ(539485,16384),-QQ(54675,16384)]
 ],
 12: [
  [-1], [45,-h], [-3375,152*h,-5],
  [28125,-1925*h,135,h], [-759375,70200*h,-7826,-88*h,17],
  [56953125,-6665625*h,1044750,12794*h,-5923,79*h],
  [-5980078125,850500000*h,-174943125,-1917760*h,1725505,-47200*h,2113],
  [64072265625,-10764140625*h,2778890625,21714375*h,-39685405,1675317*h,-151485,1045*h],
  [-4805419921875,934031250000*h,-293245312500,-917550000*h,5443088750,-316466320*h,43387980,-601616*h,17165],
  [24027099609375,-5317998046875*h,1983107812500,-5621062500*h,-44473713750,3354864430*h,-620549260,12975420*h,-742865,3733*h],
  [-1081219482421875,269103515625000*h,-117017314453125,1154857500000*h,3002510531250,-283800362000*h,66473149190,-1863698592*h,160581937,-1619672*h,38415],
  [16218292236328125,-4493067626953125*h,2244771826171875,-39972835546875*h,-63055095468750,7315325778750*h,-2085651170250,73532772890*h,-8475909695,128675127*h,-6136777,29201*h],
  [-405457305908203125,123979833984375000*h,-70303293457031250,1863791015625000*h,2080083701953125,-292962854250000*h,98995669922500,-4215079100720*h,609351970405,-12374529096*h,889866670,-8527480*h,205195],
 ]
}
scales12=[
 (1,1),(5,1),(5*10**2,11),(5*10**3,3**2*11),(2*10**4,3**2*11),
 (5**2*10**4,3**2*11),(5*10**6,3**2*11),(5**2*10**7,3**3*7*11),
 (5*10**9,3**3*7*11),(5**2*10**9,3**4*7*11),(5*10**11,3**4*7*11),
 (5*10**12,3**4*7*11),(5*10**14,3**5*7*11)
]
expected_diffs={4:{(2,2):(QQ(27,4),-QQ(27,4)),(1,2):(7*sqrt(3)/8,7*q/8)},6:{},12:{}}
actual_diffs={4:{},6:{},12:{}}
def algebraic_poly(f,ext):
    return a.Poly(f,z,extension=ext) if ext else a.Poly(f,z,domain='QQ')
def recurrence(n,r,S,theta,ext):
    A=lambda f: algebraic_poly(a.cancel(f,extension=ext) if ext else a.cancel(f),ext)
    S=A(S); R=A(S.as_expr()**2*r); H=A(S.as_expr()*theta)
    P={n+1:A(0),n:A(-1)}
    for j in range(n,-1,-1):
        P[j-1]=-S*P[j].diff()+((n-j)*S.diff()-H)*P[j]-(n-j)*(j+1)*R*P[j+1]
    assert P[-1].is_zero
    return P
def indicial_data(r,C):
    return [a.simplify(a.limit((z-c)**2*r,z,c)) for c in C] + [a.limit(z*z*r,z,a.oo)]
def check_all():
    all_results={}
    for n,(r,C,e,ei,ext) in cases.items():
        S=a.prod(z-c for c in C)
        th=QQ(n,12)*sum(k/(z-c) for k,c in zip(e,C))
        B=indicial_data(r,C)
        print('n=',n,'B=',B)
        ds=[a.sqrt(1+4*b) for b in B]
        assert all(a.is_Rational for a in ds)
        assert all((i-sum(f)).is_Integer is False for *f,i in product(*(tuple((1+x*d)/2 for x in [-1,1]) for d in ds)))
        E2=[sorted(t for t in (2-2*d,QQ(2),2+2*d) if t.is_Integer) for d in ds]
        assert max(E2[-1]) < sum(min(r) for r in E2[:-1])
        for k in [x for x in (4,6,12) if x<=n]:
            E=[sorted(t for t in (6+QQ(12,k)*j*d for j in range(-k//2,k//2+1)) if t.is_Integer) for d in ds]
            valid=[(x,y,w,QQ(k,12)*(w-x-y)) for x,y,w in product(*E) if QQ(k,12)*(w-x-y)>=0 and (QQ(k,12)*(w-x-y)).is_Integer]
            print('  case 3 step 2',k,E,valid)
            if k<n:
                assert not valid
            else:
                assert (e[0],e[1],ei,0) in valid
        P=recurrence(n,r,S,th,ext)
        # Test each coefficient of the cleared Riccati divisibility identity
        # D(f)=(n S'/S-nT-theta) f, where D=d/dz+(r-T^2)d/dT.
        APoly=lambda f: algebraic_poly(a.cancel(f,extension=ext) if ext else a.cancel(f),ext)
        SP=APoly(S); R=APoly(S*S*r); H=APoly(S*th)
        C={j:SP**j*P[j]*QQ(1,a.factorial(n-j)) for j in range(n+1)}
        for j in range(n+2):
            Cj=C.get(j,APoly(0))
            resid=(SP**2*Cj.diff()+(j+1)*R*C.get(j+1,APoly(0))
                   +(n-j+1)*SP**2*C.get(j-1,APoly(0))
                   +SP*(H-n*SP.diff())*Cj)
            assert resid.is_zero, (n,j,resid)
        print('  verified P[-1]=0 and exact cleared Riccati divisibility')
        for j in range(n,-1,-1):
            A=QQ(*scales12[n-j]) if n==12 else 1
            expected=(A*P[j]).all_coeffs()
            printed=scans[n][n-j]
            assert len(expected)==len(printed)
            for k,(x,y) in enumerate(zip(expected,printed)):
                if a.expand(x-y) !=0:
                    print('  discrepancy: P',j,'coeff degree',len(printed)-1-k,'printed',y,'expected',x)
                    actual_diffs[n][j,len(printed)-1-k]=(y,x)
        all_results[n]=P
    assert actual_diffs==expected_diffs
    return all_results
if __name__=='__main__': check_all()
