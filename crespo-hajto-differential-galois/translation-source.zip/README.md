# 《代数群和微分 Galois 理论》中文译稿源码
主文件：`ch01-projective/groups-translation.tex`。运行 `bash build.sh`（Linux/macOS）或 `.\build.ps1`（Windows PowerShell）。
需要 XeLaTeX、ctex 和 Fandol 字体，以及 AMS、enumitem、TikZ/PGF、graphicx、pdfpages、multicol、url 等常用 TeX Live/MiKTeX 宏包。
编译勘误源码另需 Noto Serif CJK SC、DejaVu Sans 和 DejaVu Math TeX Gyre 字体。程序会按原样保留所有 PDF 内的索引编号。
`verified-errata.tsv` 保存中英文条目及核验说明；原书页码和扫描 PDF 页序不等同于本译稿页码。
本包不含原书全集扫描或习题解答。书末原版出版社附页为保留其条形码而原样嵌入。

本译本卷首新增可点击的「译本目录」，以译本页码为准；原书目录仍保留，所列为原书印刷页码。
