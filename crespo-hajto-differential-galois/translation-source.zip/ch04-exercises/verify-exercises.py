"""Verify source/reference coverage of the isolated exercise chapter against the joined book."""
from pathlib import Path
import hashlib
import re
import subprocess
from collections import Counter
root = Path(__file__).resolve().parent
source = (root / 'exercises.tex').read_text()
part_counts, count = {}, 0
for line in source.splitlines():
    tag = re.search(r'^\\item\\label\{ex:ch-4-final-(\d+)\}', line)
    if tag:
        count += 1
        assert int(tag[1]) == count
    elif re.match(r'^\\item ', line):
        part_counts[count] = part_counts.get(count, 0) + 1
assert (count, part_counts) == (17, {4:3,8:3,9:2,10:2,13:4,15:2,16:3})
assert source.count('\\emph{提示：}') == 2
# Source-file-only linter cannot follow xr imports; verify each against the real book AUX.
aux = (root.parent / 'ch01-projective/front-before-groups61-representation.aux').read_text()
expected = {'chap:ch-basic-notions':'3','cor:ch-3-2-5':'3.2.5','ex:ch-4-1-3':'4.1.3',
            'prop:ch-4-1-7':'4.1.7','rem:ch-4-2-3':'4.2.3'}
refs = set(re.findall(r'\\ref\{([^}]+)\}', source))
assert refs == expected.keys()
imported = dict(re.findall(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}', aux))
assert all(expected[k] == imported[k] for k in refs)
extracted = subprocess.check_output(['pdftotext','-layout',str(root/'preview.pdf'),'-'], text=True)
assert [int(m) for m in re.findall(r'(?m)^\s*\((\d+)\)', extracted)] == list(range(1,18))
assert '??' not in extracted
log = (root/'preview.log').read_text()
for hazard in ['Missing character','Warning:','Overfull','Underfull','Undefined control sequence','Emergency stop']:
    assert hazard not in log, hazard
print('17 ordered top-level; 19 subparts; two hints. All five external references linked to existing book labels with the correct print numbering.')
print('Three clean preview pages; rendered numbering (1) through (17) verified.')
