"""Check every printed partial fraction, pole/exp. coefficient, and Chebyshev Liouvillian witness."""
import sympy as s
z,a=s.symbols('z a')
R=s.Rational
i=s.I
q3=s.sqrt(3)
q5=s.sqrt(5)
p=z/(z*z-1)
q=-a*a/(z*z-1)
A=(8*a*a+1)/16
data=[
    ('Chebyshev',((a*a-R(1,4))*z*z-a*a-R(1,2))/(z*z-1)**2,
        ((1,A,-R(3,16)),(-1,-A,-R(3,16))),
        (R(1,2),R(1,2)),a*a-R(1,4),2*a),
    ('Example 3',(101-81*z*z)/(48*(1+3*z*z)**2),
        ((i/q3,-37*q3*i/288,-R(2,9)),(-i/q3,37*q3*i/288,-R(2,9))),
        (R(1,3),R(1,3)),-R(3,16),R(1,2)),
    ('Example 4',(-128*z*z+155*z-135)/(576*z*z*(z-1)**2),
        ((0,-R(115,576),-R(15,64)),(1,R(115,576),-R(3,16))),
        (R(1,4),R(1,2)),-R(2,9),R(1,3)),
    ('Example 5',-3*(25*z*z-8*z/q5+19)/(16*(5*z*z-1)**2),
        ((1/q5,21*q5/160,-R(21,100)),(-1/q5,-21*q5/160,-R(6,25))),
        (R(2,5),R(1,5)),-R(3,16),R(1,2)),
]
for name,r,terms,roots,gam,root in data:
    pf=sum(b/(z-c)+d/(z-c)**2 for c,b,d in terms)
    assert s.simplify(s.together(r-pf))==0,name
    assert s.simplify(sum(b for _,b,_ in terms))==0,name
    assert s.simplify(sum(d+b*c for c,b,d in terms)-gam)==0,name
    assert all(s.simplify(rt**2-(1+4*d))==0 and d for (_,_,d),rt in zip(terms,roots)),name
    assert s.simplify(root**2-(1+4*gam))==0,name
    print(f'{name}: exact partial fractions, residue sum and case-3 radicands verified')
rc=data[0][1]
assert s.simplify(s.diff(p,z)/2+p*p/4-q-rc)==0
assert s.simplify(rc.subs(a,R(1,2))+3/(4*(z*z-1)**2))==0
for sign in (-1,1):
    om=z/(2*(z*z-1))+sign*a/s.sqrt(z*z-1)
    assert s.simplify(s.diff(om,z)+om**2-rc)==0
print('Chebyshev: reduced coefficient and explicit Liouvillian witnesses verified')
assert s.degree(s.denom(z),z)-s.degree(s.numer(z),z)==-1
print('Airy: no finite poles, order −1 at infinity')
