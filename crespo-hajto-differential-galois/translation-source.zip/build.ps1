﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Build-Tex($name) {
  for ($i=0; $i -lt 3; $i++) {
    & xelatex -halt-on-error -interaction=nonstopmode $name
    if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed for $name" }
  }
}
Push-Location 'ch01-projective'
$env:TEXINPUTS = ".;../ch03-sec34;../ch03-sec34/figures;$($env:TEXINPUTS);"
Build-Tex 'groups-translation.tex'
Pop-Location
if (Test-Path errata) {
  Push-Location errata
  Build-Tex 'errata-g-zh.tex'
  Build-Tex 'errata-g-en.tex'
  Pop-Location
}
