"""Exact algebra checks for the necessary conditions in Theorem 7.3.2."""
import sympy as s
z,t,e,nu,b,a,mu,alpha,beta,c,d=s.symbols('z t e nu b a mu alpha beta c d', nonzero=True)
r=s.Function('r')(z)
f=s.Function('f')(z)
g=s.Function('g')(z)
rules={f.diff(z,3):r.diff(z)*f+r*f.diff(z),g.diff(z,3):r.diff(z)*g+r*g.diff(z),
       f.diff(z,2):r*f,g.diff(z,2):r*g}
w=f*g
assert s.expand(w.diff(z,3).subs(rules, simultaneous=True)-4*r*w.diff(z)-2*r.diff(z)*w)==0
theta=e/(2*z)
symmetric=theta.diff(z,2)+3*theta*theta.diff(z)+theta**3
assert s.factor(symmetric*z**3)==e*(e-2)*(e-4)/8
assert s.simplify((4*b*z**nu*theta+2*s.diff(b*z**nu,z))/z**(nu-1))==2*b*(e+nu)
assert s.simplify((b*z**nu)*(a*z**mu)/z**(nu+mu))==b*a
f=s.series(alpha/(1/t-c)**2+beta/(1/t-d),t,0,3).removeO().expand()
assert f.coeff(t,1)==beta and f.coeff(t,2)==alpha+beta*d
print("Product equation, leading obstruction, and infinity expansion verified.")
