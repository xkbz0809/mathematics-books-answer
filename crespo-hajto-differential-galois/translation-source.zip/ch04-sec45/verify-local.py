"""Independent finite matrix checks of the signs/order in 4.5.8, 4.5.13."""
import sympy as S
I=S.eye(2)
x=[S.Matrix([[1,2],[0,1]]),S.Matrix([[2,1],[1,1]])]
y=[S.Matrix([[2,1],[1,1]]),S.Matrix([[1,0],[3,1]])]
T=[S.Matrix([[0,2],[-1,0]]),S.Matrix([[3,-2],[1,-3]])]
def inv(a): return a.inv()
def c(a,b): return a*b*inv(a)*inv(b)
def ad(a,b): return a*b*inv(a)
def mul(L):
 s=I
 for v in L:s=s*v
 return s
s=S.symbols('s')
A=S.Matrix([[1,2],[3,-1]])
B=S.Matrix([[2,0],[-3,5]])
# Differentiate conjugation at identity, Lemma 4.5.8.
assert (ad(I+s*A,B).diff(s).subs(s,0)-A*B+B*A).equals(S.zeros(2))
# Group word identities and telescoping differential at n=2.
for a,b in zip(x,y):
 assert inv(c(a,b))==c(inv(a),ad(a,b))
u=[I,c(x[0],y[0]),mul([c(a,b) for a,b in zip(x,y)])]
D=S.zeros(2)
C=[]
for k,(a,b,t) in enumerate(zip(x,y,T)):
 z=I+s*t
 ck=u[k]*c(a,b*z)*inv(u[k+1])
 assert (ck-ad(u[k+1],ad(b*a,z)*ad(b,inv(z)))).equals(S.zeros(2))
 D+=ad(u[k+1],ad(b,ad(a,t)-t))
 C.append(ck)
phi=mul(c(a,b*(I+s*t)) for a,b,t in zip(x,y,T))*inv(u[-1])
assert (mul(C)-phi).equals(S.zeros(2))
assert (phi.diff(s).subs(s,0)-D).equals(S.zeros(2))
print('Passed: dAd bracket sign; inverse word, C_k order, telescoping and derivative at n=2.')
