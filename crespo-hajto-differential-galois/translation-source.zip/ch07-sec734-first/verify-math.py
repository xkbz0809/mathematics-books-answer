"""Exact bookkeeping checks for equations and matrices in 7.3.8–7.3.12."""
import math
import sympy as s

T, r, v = s.symbols("T r v")
for n in range(1, 13):
    a = {-1: 0, n: -1, n+1: 0}
    a.update({i: s.Symbol(f"a_{n}_{i}") for i in range(n)})
    adot = {i: s.Symbol(f"adot_{n}_{i}") for i in range(n)} | {n: 0}
    A = sum(a[i]*T**i/math.factorial(n-i) for i in range(n+1))
    Az = sum(adot[i]*T**i/math.factorial(n-i) for i in range(n+1))
    s0 = a[n-1]
    B = s.Poly(s.diff(A,T)*(r-T*T) + Az + (n*T+s0)*A, T)
    assert B.degree() < n
    for i in range(n):
        recurrence = (n-i)*(i+1)*r*a[i+1] + a[i-1] + adot[i] + s0*a[i]
        assert s.expand(B.nth(i) - recurrence/math.factorial(n-i)) == 0
    for k in range(n+1):
        left = s.diff((n*T+v)*A, T, k)
        right = (n*T+v)*s.diff(A,T,k)
        if k:
            right += k*n*s.diff(A,T,k-1)
        assert s.expand(left-right) == 0
print("7.3.8: coefficient recurrence verified for n=1..12")

for n in range(1, 7):
    w=s.symbols(f"w0:{n}")
    elementary=[s.expand(sum(math.prod(c) for c in __import__('itertools').combinations(w,k))) for k in range(n+1)]
    def E(k):
        return elementary[k] if 0<=k<=n else s.Integer(0)
    for k in range(n+1):
        derivative = sum(s.diff(E(k),wi)*(r-wi**2) for wi in w)
        assert s.expand(derivative-((n+1-k)*r*E(k-1)-E(1)*E(k)+(k+1)*E(k+1))) == 0
print("7.3.12: elementary symmetric derivative identity verified")

I=s.I
B=s.diag(I,-I)
D=s.Matrix([[-1+I,-1+I],[1+I,-1-I]])/2
E=s.diag(1+I,1-I)/s.sqrt(2)
bet,gam=1-s.sqrt(5),1+s.sqrt(5)
F=s.Matrix([[2*I,bet-I*gam],[-bet-I*gam,-2*I]])/4
def powers(M,n):
    out=s.eye(2)
    for k in range(1,n+1):
        out=(out*M).applyfunc(lambda v:s.simplify(s.expand_complex(v)))
        if out==s.eye(2):
            return k
    return None
for name,M,n in [("-D",-D,6),("E",E,8),("DBF",D*B*F,10)]:
    found=powers(M,n)
    print(f"7.3.10: order({name})={found}")
    assert found==n
z=s.symbols("z", positive=True)
for n in (4,6):
    A=-(T-z)**n
    R=z*z+1
    S=n*z
    assert s.expand(s.diff(A,z)+(R-T*T)*s.diff(A,T)+(n*T+S)*A)==0
print("7.3.11: explicit case-1 recurrence solutions n=4,6 with reducible polynomials verified")
w=1/(4*z)+1/(2*s.sqrt(z))
assert s.simplify(s.diff(w,z)+w*w-1/(4*z)+3/(16*z*z))==0
print("7.3.12: nonrational logarithmic derivative example verified")
