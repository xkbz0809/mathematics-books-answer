import sympy as s

q,b,e=s.symbols('q b e')
for n in (4,6,12):
    A={n+1:0,n:-1}
    B={n:0}
    C={n:0}
    for i in range(n,-1,-1):
        A[i-1]=s.expand((n-i-q)*A[i])
        B[i-1]=s.expand((n-i-1-q)*B[i]-(n-i)*(i+1)*b*A[i+1])
        C[i-1]=s.expand((n-i-1-q)*C[i]-A[i])
    for i in range(-1,n+1):
        a=-s.prod(j-q for j in range(n-i))
        bclosed=b*sum((j+1)*(n-j)*s.prod(k-q for k in range(n-i-1) if k!=j) for j in range(n-i-1))
        c=(n-i)*s.prod(j-q for j in range(n-i-1))
        assert s.expand(A[i]-a)==0, ("A",n,i)
        assert s.expand(B[i]-bclosed)==0, ("B",n,i)
        assert s.expand(C[i]-c)==0, ("C",n,i)
    for ell in range(n):
        assert B[-1].subs(q,ell)!=0
        assert C[-1].subs(q,ell)==0
    A={n+1:0,n:-1}
    for i in range(n,-1,-1):
        A[i-1]=s.expand((n-i-q)*A[i]+s.Rational(1,4)*(n-i)*(i+1)*A[i+1])
    assert s.expand(A[-1].subs(q,s.Rational(n,12)*e)-(s.Rational(n,12)*(e-6))**(n+1))==0
    print(f"n={n}: local coefficient formulas, simple-pole deduction, and double-root A_-1 all verified")
