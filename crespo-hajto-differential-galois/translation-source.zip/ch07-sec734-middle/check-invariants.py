import sympy as s
x,y=s.symbols("x y")
I=s.I
a = -5*(1+I)+s.sqrt(5)*(-1+I)
b = (30*s.sqrt(3)+22*s.sqrt(5))*(1+I)+(22-6*s.sqrt(15))*(1-I)
U=x**4+2*I*s.sqrt(3)*x*x*y*y+y**4
V=x*y*(x**4-y**4)
B=s.diag(I,-I)
D=s.Matrix([[-1+I,-1+I],[1+I,-1-I]])/2
E=s.diag(1+I,1-I)/s.sqrt(2)
bet,gam=1-s.sqrt(5),1+s.sqrt(5)
F=s.Matrix([[2*I,bet-I*gam],[-bet-I*gam,-2*I]])/4
def action(p,M):
    row=s.Matrix([[x,y]])*M
    return s.Poly(p.subs({x:row[0,0],y:row[0,1]}, simultaneous=True),x,y)
def norm(p):
    return {m:s.simplify(s.expand(v)) for m,v in s.Poly(p,x,y).terms()}
def same(p,q):
    keys=set(norm(p))|set(norm(q))
    P,Q=norm(p),norm(q)
    nz={k:s.simplify(P.get(k,0)-Q.get(k,0)) for k in keys}
    nz={k:v for k,v in nz.items() if v!=0}
    if nz:
       print("mismatch", len(nz), list(nz.items())[:4])
    return not nz
D_scale=s.simplify(action(U,D).coeff_monomial(x**4))
print("D weight",D_scale)
assert s.simplify(D_scale**3-1)==0
assert same(action(U,B),U)
assert same(action(U,D),D_scale*U)
assert same(action(V,B),V)
assert same(action(V,D),V)
assert same(action(V,E),-V)
assert not same(action(a*U**3+b*V**2,F),a*U**3+b*V**2)
a11=s.simplify(action(U**3,F).coeff_monomial(x**11*y))
b11=s.simplify(action(V**2,F).coeff_monomial(x**11*y))
ratio=s.simplify(s.radsimp(-a11/b11))
print('a11:',a11)
print('b11:',b11)
print('correct ratio b/a:',ratio, 'approx.', complex(ratio.evalf()))
print('printed ratio b/a approx.', complex((b/a).evalf()))
assert same(action(U**3+ratio*V**2,F),U**3+ratio*V**2)
print('Corrected invariant verified in every coefficient.')
print('β retaining printed α:',s.expand(a*ratio))
print('β_print−β_correct:',s.simplify(s.expand(b-a*ratio)))
