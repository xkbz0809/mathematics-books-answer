"""Exact closure in Hamilton quaternions with coordinates (a+b*sqrt(d))/4.
A unit quaternion is written (scalar, i, j, k) in Lemma 4.6.3's basis.
No external packages. Membership of the integral 1/4-lattice is checked on each product."""
from collections import deque, Counter
from itertools import product
ZERO=((0,0),)*4
ONE=((4,0),(0,0),(0,0),(0,0))
B=((0,0),(4,0),(0,0),(0,0))
C=((0,0),(0,0),(4,0),(0,0))
K=((0,0),(0,0),(0,0),(4,0))
D=((-2,0),(2,0),(-2,0),(2,0))
E=((0,2),(0,2),(0,0),(0,0))
F=((0,0),(2,0),(1,-1),(-1,-1))
inds=(((0,0,1),(1,1,-1),(2,2,-1),(3,3,-1)),((0,1,1),(1,0,1),(2,3,1),(3,2,-1)),((0,2,1),(2,0,1),(3,1,1),(1,3,-1)),((0,3,1),(3,0,1),(1,2,1),(2,1,-1)))
def mult(q,r,d):
 z=[]
 for eq in inds:
  a=b=0
  for j,k,sign in eq:
   u,v=q[j];s,t=r[k]; a+=sign*(u*s+d*v*t); b+=sign*(u*t+v*s)
  assert a%4==b%4==0
  z.append((a//4,b//4))
 return tuple(z)
def neg(q): return tuple((-x,-y) for x,y in q)
def conj(q): return (q[0],*neg(q)[1:])
def closure(gens,d):
 seen={ONE}; todo=deque([ONE])
 while todo:
  q=todo.popleft()
  for r in gens:
   p=mult(q,r,d)
   if p not in seen:
    seen.add(p);todo.append(p)
    assert len(seen)<=120
 return seen
for d,gens,expected in [(2,[B,C],8),(2,[B,D],24),(2,[D,E],48),(5,[B,D,F],120)]:
 H=closure(gens,d)
 assert len(H)==expected and neg(ONE) in H
 print('order upstairs:',len(H),'rotation quotient:',len(H)//2)
def m(q,r): return mult(q,r,5)
def pw(q,k):
 p=ONE
 for i in range(k): p=m(p,q)
 return p
assert [m(m(D,q),conj(D)) for q in [B,C,K]]==[neg(C),neg(K),B]
assert m(F,F)==pw(m(D,F),2)==neg(ONE) and pw(m(B,F),3)==ONE
assert mult(E,E,2)==B
print('D conjugates (i,j,k) to (-j,-k,i); E^2=B; F^2=(DF)^2=-1 and (BF)^3=1.')
S={ONE}; counts=[1]
for _ in range(8):
 S=S|{mult(q,r,5) for q in S for r in [B,D,F]}; counts.append(len(S))
assert counts==[1,4,12,28,54,89,111,120,120]
print('2A5 cumulative ball counts:',counts)
