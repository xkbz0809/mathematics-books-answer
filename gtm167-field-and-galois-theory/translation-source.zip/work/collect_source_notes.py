from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[1]
def group(s,pos):
 while pos<len(s) and s[pos].isspace():pos+=1
 assert s[pos]=='{'
 start=pos+1;level=1;pos+=1
 while level:
  if s[pos]=='\\':pos+=2;continue
  if s[pos]=='{':level+=1
  if s[pos]=='}':level-=1
  pos+=1
 return s[start:pos-1],pos
notes=[]
for p in sorted((root/'translations').rglob('*.tex')):
 s=p.read_text(encoding='utf8')
 for m in re.finditer(r'\\sourceissue\s*\{',s):
  key,pos=group(s,m.end()-1);body,pos=group(s,pos)
  notes.append({'id':key,'file':p.relative_to(root).as_posix(),'text_tex':body})
lines=['# 原书疑误与译文核对记录','',
 '这里汇集翻译过程中依据原页图像记录的问题，以及译者为区分原文与校正意见而加入的注释。它不是已穷尽的原书勘误表，也不是把每一条都归为确定数学错误的计数清单。明确排印错误、记号不一致、证明省略、假设不足、术语约定和待核实问题须分别阅读。',
 '', '原书作为翻译内容的依据。本轮依用户授权，在完成习题解答后，经过原图核对、数学推导或反例、写后回读三次确认的事项已直接修订译稿；原印字句或公式与理由保留于显式核对注。未确认的疑点仍保留。下列历史初审记录描述当时状态，本轮应用情况以 solutions/qa/consolidated_revisions.md 及《习题解答与修订报告.md》为准。部分注释含 LaTeX 记号，排版形式可在中文 PDF 对应位置查看。','', '## 分章记录','']
record_paths=[root/'translations'/f'ch{i:02}'/'issues.md' for i in range(1,6)]+[root/'translations/appendices'/f'{a}_issues.md' for a in 'ABCDE']
for p in record_paths:
 if p.exists():
  lines+=['### '+p.relative_to(root).as_posix(),'']
  content=p.read_text(encoding='utf8')
  content=re.sub(r'(?m)^#.*\n','',content,count=1)
  lines += [content.strip(),'']
lines += ['## PDF 中带编号的译者核对注','']
for note in notes:lines += [f"### {note['id']}（{note['file']}）",'',note['text_tex'],'']
lines += ['## 独立复核记录','',
 '独立复核的实际范围、发现、撤销的低分辨率误判及修复情况见 work/qa/review_*.md。编译和版面检查另见《翻译与核对报告》，不与数学核对合并计为同一种完成状态。','']
(root/'原书疑误与译文核对记录.md').write_text('\n'.join(lines),encoding='utf8')
(root/'work/qa/numbered_source_notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf8')
print(f'{len(notes)} numbered notes; collected available per-unit records')
