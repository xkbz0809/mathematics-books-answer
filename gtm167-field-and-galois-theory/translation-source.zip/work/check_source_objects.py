from pathlib import Path
import re,json
root=Path(__file__).resolve().parents[1]
groups=[('',18,238),('A-',239,253),('B-',254,257),('C-',258,266),('D-',267,278),('E-',279,285)]
labels=set()
for p in (root/'translations').rglob('*.tex'):
 labels.update(re.findall(r'\\label\{([^{}]+)\}',p.read_text(encoding='utf8')))
found={};missing=[]
for prefix,a,b in groups:
 for page in range(a,b+1):
  s=(root/'work/source/pages'/f'page_{page:04}.txt').read_text(encoding='utf8')
  for m in re.finditer(r'(?m)^\s*(Theorem|Lemma|Proposition|Corollary|Definition|Example|Remark)\s+(\d+)\.(\d+)\b',s):
   k=prefix+'thm:'+m[2]+'.'+m[3]
   found.setdefault(k,[]).append({'source_physical_page':page,'type':m[1]})
for k,v in found.items():
 if k not in labels:missing.append({'label':k,'source_locations':v})
result={'ocr_recognized_objects':len(found),'recognized_but_unmatched':missing,'warning':'OCR-based lower-bound candidate check only; original scans remain authoritative, and many labels are not recognized by OCR.'}
(root/'work/qa/source_object_candidates.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(result,ensure_ascii=False,indent=2))
