from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
rows=[line.split('\t') for line in (root/'work/index_rows.tsv').read_text(encoding='utf8').splitlines() if line.strip()]
assert all(len(row)==4 for row in rows)
lines=[r'\MTunnumberedchapter{原书索引（中英对照）}',r'\label{original-index}',
       r'本索引完整保留原书词条、排列顺序及原列页码，并附中文译名. 原书部分索引页码与这份扫描本正文的印刷页码不一致，例如“拓扑空间”列作第 271 页，而定义实际在印刷第 267 页. 因此下表数字仅表示原索引所列页码，不是本译稿页码，也未设置未经核实的跳转链接. 后面的术语表另提供译稿中的定位链接. 英文词条中的原拼写（如 Accending）仍予保留.',
       r'\begingroup\small',r'\setlength{\tabcolsep}{4pt}',
       r'\begin{longtable}{@{}>{\raggedright\arraybackslash}p{.35\textwidth}>{\raggedright\arraybackslash}p{.43\textwidth}>{\raggedright\arraybackslash}p{.15\textwidth}@{}}',
       r'\toprule 中文词条 & 原文词条 & 原列页码 \\ \midrule\endfirsthead',
       r'\toprule 中文词条 & 原文词条 & 原列页码 \\ \midrule\endhead',r'\bottomrule\endfoot']
last=None
for page,en,zh,refs in rows:
    if page!=last:lines.append(r'\noalign{\sourcepage{'+page+'}}');last=page
    lines.append(f'{zh} & {en} & {refs} '+r'\\')
lines += [r'\end{longtable}',r'\endgroup']
dest=root/'translations/back/index.tex';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text('\n'.join(lines)+'\n',encoding='utf8')
(root/'work/index_manifest.json').write_text(json.dumps({'rows':len(rows),'source_physical_pages':[288,289,290,291,292],'source_printed_pages':[277,278,279,280,281],'source_images_viewed':True,'reference_page_numbers':'preserved as printed, not normalized or linked'},ensure_ascii=False,indent=2),encoding='utf8')
print(f'{len(rows)} index rows written')
