# MathTranslations 静态检查的解释

本次实际运行技能提供的audit_latex.py。先对project全目录运行，模板样例也被纳入，产生1个额外的术语重复和模板统计噪音；随后solutions/tools/audit_static.py仅复制实际编译入口、章节、公共宏、文献、类文件和图形到work/qa/static-input-*重新检查。未扫描答案原稿与组装快照两套同样内容，亦未把上游示例算入本书。

两册通用检查均为0 error。解答册的审计副本将question宏实际生成的label显式补出，并按book-labels.aux登记book-外部标签；未删除引用，实际外部目标另由PDF QA核验。输入原文件hash全部保存。

译稿的mathtranslations profile仍有7个重复术语key提示：directed-set、group-exponent、inverse-limit、pro-p-group、profinite-group、purely-inseparable-closure、solvable-group。这些是正文/附录重述同一术语；本工程newterm用MT@seen@key只登记首次出现的label与索引，后续只排术语文字，最终PDF日志无重复目标/标签。故保留重复调用，未误删附录定义，也未把profile退出码称为通过。

profile的其他提示包括中文引号、缺少不用的longproof/answers兼容宏、没有build.sh（本工程由Python执行完整五步构建）、printterminology在宏定义和主入口被同时计数。本工程实际只执行一个术语索引。中文引号均实际排出字形，无缺字；没有为消除风格提示而改动已审文字。

通用检查中的硬编码候选：D附录定理3.4.16与22节命题3.11、定理1均属于所引外部参考文献；reader中的定理2.3及附录第2节是编号规则示例；第2节“引理第5条”是紧邻引理的分项引用。没有将这些误当作缺失书内标签。PDF层另检查363道解答题号及全部内部/外部链接目标。

最终原始输出为static-project-generic.txt、static-project-mathtranslations.txt、static-solutions-generic.txt、static-solutions-mathtranslations.txt，结构化结果为static_audit_summary.json。编译后的日志由两册PDF QA独立读取；静态检查默认排除build目录，不能代替编译检查。
