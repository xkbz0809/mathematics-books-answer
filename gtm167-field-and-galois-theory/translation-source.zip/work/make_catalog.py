from pathlib import Path
root=Path(__file__).resolve().parents[1]
rows=[line.split('\t') for line in (root/'work/catalog_rows.tsv').read_text(encoding='utf8').splitlines()]
assert [int(row[0]) for row in rows]==list(range(1,168))
lines=[r'\MTunnumberedchapter{出版商附页：数学研究生教材丛书}',
 r'以下为原 PDF 物理第 3、293、294 页所附 Graduate Texts in Mathematics 目录的中文翻译. 序号、作者、分卷及版次均按原书附页保留，表示该书出版时的目录资料；书名中文译法用于辨识原列书目. 原附页在第 60 卷后注明“续见索引之后”，后半部分注明“接第 ii 页”；这里合并列出.',
 r'\begingroup\small',r'\setlength{\tabcolsep}{4pt}',
 r'\begin{longtable}{@{}r>{\raggedright\arraybackslash}p{.35\textwidth}>{\raggedright\arraybackslash}p{.53\textwidth}@{}}',
 r'\toprule 卷号 & 作者 & 书名与原列版次 \\ \midrule\endfirsthead',
 r'\toprule 卷号 & 作者 & 书名与原列版次 \\ \midrule\endhead',r'\bottomrule\endfoot']
for n,author,title in rows:lines.append(f'{n} & {author} & {title} '+r'\\')
lines += [r'\end{longtable}',r'\endgroup']
(root/'translations/back/series_catalog.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('167 source series entries translated')
