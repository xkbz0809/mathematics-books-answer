"""Freeze the reviewed translation and create a self-contained local delivery."""
from pathlib import Path
import collections, hashlib, json, re, shutil, zipfile
from datetime import datetime, timezone, timedelta

root = Path(__file__).resolve().parents[1]
client_timezone = timezone(timedelta(hours=8))
qa = root / 'work/qa'
project = root / 'project'
build = project / 'build'

def readjson(path):
    return json.loads(path.read_text(encoding='utf8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assembly = readjson(build / 'assembly.json')
structure = readjson(qa / 'structure_audit.json')
pdfqa = readjson(qa / 'pdf_qa.json')
visual = readjson(qa / 'visual_review.json')
bookmark_qa = readjson(qa / 'bookmark_heading_audit.json')
assert bookmark_qa['passed'] == bookmark_qa['bookmarks'] and not bookmark_qa['failures']
assert assembly['final_requested'] and len(assembly['included']) == 40
assert not assembly['missing'] and not assembly['unfinished']
for key in ['numbering_gaps', 'duplicate_labels', 'undefined_references', 'environment_errors', 'missing_source_printed_pages']:
    assert not structure[key], (key, structure[key])
for key in ['bad_internal_links', 'bad_bookmarks', 'near_edge_text', 'empty_pages', 'number_label_mismatches']:
    assert not pdfqa[key], (key, pdfqa[key])
for key in ['undefined_references', 'undefined_citations', 'multiply_defined', 'missing_glyphs', 'overfull_boxes']:
    assert not pdfqa['log'][key], (key, pdfqa['log'][key])
assert visual['final_pdf_sha256'] == sha(build / 'main.pdf')
assert visual['all_final_pages_layout_reviewed']
assert all(x['exit_code'] == 0 for x in readjson(build / 'main-build-report.json'))
assert (build/'main.pdf').stat().st_mtime >= max((build/'assembly.json').stat().st_mtime, (project/'mathtranslation.cls').stat().st_mtime, (project/'preamble.tex').stat().st_mtime)
assert (build/'main-build-report.json').stat().st_mtime >= (build/'main.pdf').stat().st_mtime
for rel, expected in assembly['hashes'].items():
    text = (root / rel).read_text(encoding='utf8')
    assert hashlib.sha256(text.encode('utf8')).hexdigest() == expected, rel
    snap = project / 'chapters' / Path(rel).relative_to('translations')
    assert snap.read_text(encoding='utf8') == text, rel

source = root / 'GTM167-Field and Galois Theory.pdf'
source_sha = sha(source)
assert source_sha == readjson(root / 'source_inventory.json')['sha256']
out_pdf = root / 'GTM167-域与伽罗瓦理论-中文译稿.pdf'
shutil.copy2(build / 'main.pdf', out_pdf)

groups = collections.OrderedDict()
for unit in structure['units']:
    rel = Path(unit['file'])
    key = rel.parts[1] if rel.parts[1] != 'appendices' else '附录 ' + rel.stem
    counts = groups.setdefault(key, [0, 0])
    counts[0] += unit['numbered_objects']
    counts[1] += unit['exercises']
names = {'ch01': '第 I 章（第1–5节）', 'ch02': '第 II 章（第6–11节）',
         'ch03': '第 III 章（第12–16节）', 'ch04': '第 IV 章（第17–18节）',
         'ch05': '第 V 章（第19–23节）'}
order = [f'ch{i:02}' for i in range(1,6)] + ['附录 '+a for a in 'ABCDE']
table = '\n'.join(f'| {names.get(k,k)} | {groups[k][0]} | {groups[k][1]} |' for k in order)
notes = readjson(qa / 'numbered_source_notes.json')
independent = readjson(qa / 'independent_review_summary.json')
review_lines = '\n'.join(f"- {x['scope']}：{x['coverage']}。记录：`{x['report']}`。" for x in independent['reviews'])
report = f'''# GTM167《域与伽罗瓦理论》翻译与核对报告

交付日期：{datetime.now(client_timezone).isoformat(timespec='seconds')}（Asia/Shanghai）。

## 原书与工作范围

Patrick Morandi，*Field and Galois Theory*，Graduate Texts in Mathematics 167，Springer，1996 年第一版的平装重印本。用户提供的源 PDF 共294个物理页面，26,856,886字节。原文件保持不变，交付前再次核对 SHA-256：

`{source_sha}`

所有项目文件、构建产物和检查图像均保存在 `D:\\translation\\GTM167`。印刷页64、154、172、240、254、274按用户明确确认的空白页处理；此项来源是用户确认，并未声称与另一版本独立比对。暂停记录保留为历史记录，后续工作依据用户的继续指令完成。

## 翻译覆盖

五章23节、五个附录的正文、证明、例子、全部编号习题及子问已译写；另含出版资料、前言、致读者、符号表、重新生成的目录、30条参考文献、338条原索引的中英对照，以及出版商附页的167条丛书书目。参考文献的书名、论文题名和出版字段按学术引用习惯保留原文，未把参考文献全文视为待翻译内容。按用户后续要求，363道编号习题及全部子问的解答已另编为《GTM167-域与伽罗瓦理论-习题解答.pdf》，详见《习题解答与修订报告.md》。

| 单元 | 编号陈述（定理、引理、定义、例等） | 习题主编号 |
|---|---:|---:|
{table}
| **合计** | **{structure['total_numbered_objects']}** | **{structure['total_exercises']}** |

上述习题数只计主编号，子问包含在对应题中。原书阿拉伯页码1–281扣除6个用户确认空白页后的275个内容页均有定位标记，另有10个罗马页码标记，共285个。标记计数是结构检查，不能独立证明段落或公式译写正确。

## 原图与独立内容复核

翻译依据原PDF的页面图像。隐藏OCR文字层仅用于定位与候选项检查；其漏识别的显示公式按扫描图像译写。五章和五个附录在译写时均实际查看对应原图，图形重绘保留原图节点、连接、方向和标注。

另由非该单元译写者进行逐页对照，实际范围如下：

{review_lines}

{independent['boundary']}

复核发现的译文差异按报告处理并回读，保留了撤销的低分辨率误判及其撤销理由。统一术语时将“Abel 群/扩张”改为“阿贝尔群/扩张”，记录在 `work/qa/terminology_normalization.json`；各审查时点的hash仅代表当时文件，交付文件以最终manifest为准。

## 原书疑误与译者注

原书疑点与译文错误分开记录。本轮按用户授权，对原图、数学推导或反例、写后回读三次确认的事项直接修订译稿，原印字句或公式及理由保留在显式核对注中；未确认的疑点继续保留。明确排印错误、记号不一致、假设不足、证明省略和约定问题不能合并称为确定数学错误。本次共有{len(notes)}条带编号的 `sourceissue` 脚注，此外还有各章/附录的独立记录，这一数字不是原书全部错误数。

汇总文件为《原书疑误与译文核对记录.md》。原索引的部分页码与本扫描本正文不符，译稿保留其“原列页码”，没有生成误导性跳转；另设可点击的术语索引。书中一些已记录原书疑点仍保留原文，读者应结合注释理解。

## 编译、结构与PDF检查

- 40个完整源单元均已纳入正式组装；无缺失或未闭合单元。
- 按 XeLaTeX两遍、Biber一遍、XeLaTeX两遍构建，五步退出码均为0。
- 最终中文PDF共 **{pdfqa['pdf_pages']}页**；{pdfqa['bookmarks']}个书签、{pdfqa['links']}个链接、{pdfqa['source_page_destinations']}个原页内容定位目标。
- 无重复标签、断档编号、未定义引用或文献引用；编译后的定理/习题/公式标签显示编号与源标签一致。
- PDF链接及书签目标都在有效页范围内，书签标题位置另作语义核对。
- 编译日志无缺失字形、无行宽/页高溢出；有{len(pdfqa['log']['underfull_boxes'])}条Underfull提示，属于行间填充不足，已结合所在页面检查，不存在内容裁切。
- 对最终PDF全部页面进行文字边界和链接扫描，并查看全页版面缩略图；对公式密集页、域格图、尺规图、表格、索引和链接落点另放大检查。具体页码与修复见 `work/qa/visual_review.json`。
- OCR候选编号检查识别444项，全部能映射到译稿；这只是下限候选检查，不作为逐页数学审校的替代。
- MathTranslations 通用静态检查通过；模板专用检查的重复术语等适配提示已逐项解释，见 `work/qa/static_audit_review.md`，未将该 profile 的非零退出码表述为零警告通过。

这些检查提高了可用性和忠实性，但不构成“整书数学绝对无误”的证明。独立复核仍是AI辅助审阅；原书自身已记录的问题不会因成功编译而消失。

## 文件与复用

- `GTM167-域与伽罗瓦理论-中文译稿.pdf`：阅读文件。
- `GTM167-域与伽罗瓦理论-习题解答.pdf`：363道编号习题及全部子问的独立解答册，含修订后题面和原印页码。
- `GTM167-域与伽罗瓦理论-LaTeX源码.zip`：完整可编译工程、逐节源文件、官方模板来源记录、术语表与核对证据。
- `原书疑误与译文核对记录.md`：原书疑点、译文修订及注释汇总。
- `delivery_manifest.json`：原PDF及交付文件SHA-256、冻结的逐节源文件hash。

源包保留 `project/chapters` 编译快照和 `translations` 工作源文件。编辑流程及构建命令见 `project/README.md`。本项目的 `mathtranslation.cls` 为基于官方数译模板的ctexbook适配，不冒称上游提供该适配版。无需原始PDF即可编译译稿；需要复查原文时请使用本目录内的用户提供PDF。
'''
(root / '翻译与核对报告.md').write_text(report, encoding='utf8')
status={'translation':'complete','assembly':'40/40 complete','build':'passed five steps',
 'pdf_pages':pdfqa['pdf_pages'],'numbered_objects':structure['total_numbered_objects'],
 'exercises':structure['total_exercises'],'visual_review':'completed all final pages',
 'solutions':{'status':'complete','numbered_exercises':363,'report':'习题解答与修订报告.md'},
 'independent_review':{'completed_pages':independent['independent_pages_completed'],
                     'remaining_pages':independent['independent_pages_remaining'],
                     'details':'work/qa/independent_review_summary.json'},
 'authoritative_report':'翻译与核对报告.md','historical_status_note':'Earlier pause and per-unit handoff records are retained as history.'}
(root/'交付状态.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf8')

paths = set()
def add(path):
    if path.is_file(): paths.add(path)

for name in ['main.tex','preamble.tex','mathtranslation.cls','references.bib','README.md']:
    add(project/name)
for sub in ['chapters','graphics','tools']:
    for path in (project/sub).rglob('*'):
        if path.suffix in {'.tex','.pdf','.py','.md','.json'}: add(path)
for name in ['provenance.json','mathtranslations-translation-template.zip']:
    add(project/'upstream'/name)
for name in ['assembly.json','main-build-report.json','main.log','main.blg','main.aux','main.toc','main.bbl']:
    add(build/name)
for path in (root/'translations').rglob('*'):
    if path.suffix in {'.tex','.md','.json'} and path.name != 'STOPPED.md': add(path)
for path in qa.iterdir():
    if path.suffix in {'.json','.md'}: add(path)
for path in (root/'solutions/qa').iterdir():
    if path.suffix in {'.json','.md'}: add(path)
for name in ['TRANSLATION_CONTRACT.md','check_source_objects.py','collect_source_notes.py','make_index.py','make_catalog.py','index_rows.tsv','catalog_rows.tsv','deliver.py']:
    add(root/'work'/name)
for name in ['source_pages.json','structure.json']:
    add(root/'work/source'/name)
for name in ['glossary.tsv','source_inventory.json','交付状态.json','翻译与核对报告.md','原书疑误与译文核对记录.md','习题解答与修订报告.md','GTM167-习题解答索引.csv',out_pdf.name]:
    add(root/name)
out_zip = root/'GTM167-域与伽罗瓦理论-LaTeX源码.zip'
with zipfile.ZipFile(out_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(paths): z.write(path,path.relative_to(root).as_posix())
with zipfile.ZipFile(out_zip) as z:
    assert z.testzip() is None
    assert 'project/main.tex' in z.namelist()
    zip_count = len(z.infolist())
manifest={'created':datetime.now(client_timezone).isoformat(timespec='seconds'),
 'source_pdf':{'name':source.name,'sha256':source_sha,'unchanged':True},
 'pdf_pages':pdfqa['pdf_pages'],'zip_files':zip_count,'zip_integrity':'passed',
 'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in [out_pdf,out_zip,root/'翻译与核对报告.md',root/'原书疑误与译文核对记录.md']},
 'translation_files':{p.relative_to(root).as_posix():sha(p) for p in sorted((root/'translations').rglob('*.tex'))}}
(root/'delivery_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in manifest.items() if k!='translation_files'},ensure_ascii=False,indent=2))
