"""Audit saved translation structure, labels and visible build diagnostics."""
from pathlib import Path
import re,json,collections
root=Path(__file__).resolve().parents[2]
files=sorted((root/'translations').rglob('*.tex'))
labels=collections.defaultdict(list);sources=collections.defaultdict(list);refs=[];units=[];env_errors=[]
for p in files:
    s=p.read_text(encoding='utf8');rel=p.relative_to(root).as_posix()
    for k in re.findall(r'\\label\{([^{}]+)\}',s):labels[k].append(rel)
    for k in re.findall(r'\\sourcepage\{([^{}]+)\}',s):sources[k].append(rel)
    for k in re.findall(r'\\(?:eqref|ref|pageref|autoref)\*?\{([^{}]+)\}',s):refs.append((k,rel))
    for k in re.findall(r'\\hyperref\[([^\]]+)\]',s):refs.append((k,rel))
    stack=[]
    for a,e in re.findall(r'\\(begin|end)\{([^{}]+)\}',s):
        if a=='begin':stack.append(e)
        elif not stack or stack.pop()!=e:env_errors.append([rel,'mismatch',e])
    if stack:env_errors.append([rel,'unclosed',stack])
    objects=re.findall(r'\\label\{((?:[A-E]-)?thm:[^{}]+)\}',s)
    exercises=re.findall(r'\\label\{((?:[A-E]-)?ex:[^{}]+)\}',s)
    if objects or exercises:units.append({'file':rel,'numbered_objects':len(objects),'objects':objects,'exercises':len(exercises),'exercise_labels':exercises})
for k in sources:labels['source-page-'+k].extend(sources[k])
labels['source-page-275']=['bibliography ref1 hook'];labels['source-page-276']=['bibliography ref11 hook']
blanks={64,154,172,240,254,274}
expected=set(map(str,set(range(1,282))-blanks));observed=set(sources)|{'275','276'}
undefined=[{'label':k,'file':f} for k,f in refs if k not in labels]
families=collections.defaultdict(list)
for key in labels:
    match=re.fullmatch(r'((?:[A-E]-)?(?:thm|ex):\d+)\.(\d+)',key)
    if match:families[match[1]].append(int(match[2]))
gaps={family:sorted(set(range(1,max(nums)+1))-set(nums)) for family,nums in families.items() if set(range(1,max(nums)+1))-set(nums)}
report={'units':units,'total_numbered_objects':sum(x['numbered_objects'] for x in units),'total_exercises':sum(x['exercises'] for x in units),'numbering_gaps':gaps,'duplicate_labels':{k:v for k,v in labels.items() if len(v)>1},'undefined_references':undefined,'environment_errors':env_errors,'missing_source_printed_pages':sorted(expected-observed,key=int),'user_confirmed_blank_pages':sorted(blanks),'source_page_anchor_count':len(observed),'arabic_source_page_anchor_count':len(expected&observed),'note':'Coverage markers are a structural check, not proof of complete or correct translation.'}
out=root/'work/qa';out.mkdir(parents=True,exist_ok=True)
(out/'structure_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='units'},ensure_ascii=False,indent=2))
