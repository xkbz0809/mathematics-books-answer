"""Inspect every rendered page and link; emit evidence for manual visual review."""
from pathlib import Path
import json,re,collections,argparse
import pymupdf as fitz
parser=argparse.ArgumentParser();parser.add_argument('--render',action='store_true');args=parser.parse_args()
root=Path(__file__).resolve().parents[2];build=root/'project/build';out=root/'work/qa';out.mkdir(exist_ok=True,parents=True)
doc=fitz.open(build/'main.pdf');names=doc.resolve_names();toc=doc.get_toc(simple=False)
bad_links=[];wide=[];empty=[];links=0;bad_bookmarks=[]
for i,p in enumerate(doc):
    if len(p.get_text().strip())<5:empty.append(i+1)
    for b in p.get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            for span in line['spans']:
                x0,y0,x1,y1=span['bbox']
                # Allow CJK hanging punctuation and full-em glyph metric boxes;
                # exact line overflows are separately read from the TeX log.
                if x0<54 or x1>p.rect.width-54 or y0<25 or y1>p.rect.height-25:
                    wide.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
    for link in p.get_links():
        links+=1
        if link['kind']==fitz.LINK_GOTO or (link['kind']==fitz.LINK_NAMED and ('page' in link or 'nameddest' in link)):
            target=link.get('page',names.get(link.get('nameddest',''),{}).get('page',-1))
            if not 0<=target<len(doc):bad_links.append({'page':i+1,'link':str(link)})
for level,title,page,dest in toc:
    if not 1<=page<=len(doc):bad_bookmarks.append({'title':title,'page':page})
aux=(build/'main.aux').read_text(encoding='utf8',errors='replace')
labels={k:(number,page) for k,number,page in re.findall(r'\\newlabel\{([^{}]+)\}\{\{([^{}]*)\}\{([^{}]*)\}',aux)}
number_mismatches=[]
for key,(number,page) in labels.items():
    if re.fullmatch(r'(?:[A-E]-)?(?:thm|ex|eq):\d+\.\d+',key):
        expected=key.split(':')[1]
        if expected!=number:number_mismatches.append({'key':key,'expected':expected,'printed':number,'page':page})
log=(build/'main.log').read_text(encoding='utf8',errors='replace')
issues={
 'undefined_references':re.findall(r"LaTeX Warning: Reference `([^']+)'",log),
 'undefined_citations':re.findall(r"LaTeX Warning: Citation `([^']+)'",log),
 'multiply_defined':re.findall(r"LaTeX Warning: Label `([^']+)' multiply defined",log),
 'missing_glyphs':re.findall(r'Missing character:.*',log),
 'overfull_boxes':re.findall(r'Overfull \\[hv]box[^\n]*',log),
 'underfull_boxes':re.findall(r'Underfull \\[hv]box[^\n]*',log),
}
source_destinations={k:v for k,v in names.items() if k.startswith('source-page-')}
report={'pdf_pages':len(doc),'bookmarks':len(toc),'links':links,'named_destinations':len(names),'source_page_destinations':len(source_destinations),'bad_internal_links':bad_links,'bad_bookmarks':bad_bookmarks,'near_edge_text':wide,'empty_pages':empty,'number_label_mismatches':number_mismatches,'log':issues,'manual_review_note':'All-page geometry checks do not replace visual review or mathematical fidelity checks.'}
(out/'pdf_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str),encoding='utf8')
(out/'source_destinations.json').write_text(json.dumps(source_destinations,ensure_ascii=False,indent=2,default=str),encoding='utf8')
(out/'bookmark_destinations.json').write_text(json.dumps(toc,ensure_ascii=False,indent=2,default=str),encoding='utf8')
if args.render:
    from PIL import Image,ImageDraw
    directory=out/'contact';directory.mkdir(exist_ok=True)
    cols,rows,w,h=4,3,300,450
    for start in range(0,len(doc),cols*rows):
        sheet=Image.new('RGB',(cols*w,rows*h),'#cccccc');draw=ImageDraw.Draw(sheet)
        for slot,i in enumerate(range(start,min(start+cols*rows,len(doc)))):
            pix=doc[i].get_pixmap(matrix=fitz.Matrix(.46,.46),alpha=False)
            im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);im.thumbnail((w-12,h-32))
            x=(slot%cols)*w+(w-im.width)//2;y=(slot//cols)*h+24
            sheet.paste(im,(x,y));draw.text(((slot%cols)*w+8,(slot//cols)*h+6),f'PDF {i+1}',fill='black')
        sheet.save(directory/f'pages-{start+1:03}-{min(start+cols*rows,len(doc)):03}.jpg',quality=90)
print(json.dumps({**{k:v for k,v in report.items() if k not in ['near_edge_text','manual_review_note']},'near_edge_text_count':len(wide)},ensure_ascii=False,indent=2))
