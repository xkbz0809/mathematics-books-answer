"""Repeatable XeLaTeX x2 -> Biber -> XeLaTeX x2 build, all output in project/build."""
from pathlib import Path
import argparse, json, os, subprocess, sys, shutil

parser=argparse.ArgumentParser()
parser.add_argument('document',nargs='?',default='main')
parser.add_argument('--clean',action='store_true')
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
build=root/'build'
build.mkdir(exist_ok=True)
doc=args.document.removesuffix('.tex')
if not (root/(doc+'.tex')).is_file():
    raise SystemExit('Missing input: '+str(root/(doc+'.tex')))
if args.clean:
    for ext in ['aux','toc','out','bbl','bcf','run.xml','log','blg']:
        p=build/(doc+'.'+ext)
        if p.exists():p.unlink()
env=os.environ.copy()
env['TEXINPUTS']=str(root).replace('\\','/')+'//;'+env.get('TEXINPUTS','')
env['BIBINPUTS']=str(root).replace('\\','/')+'//;'+env.get('BIBINPUTS','')
env['TMP']=str(root/'build')
env['TEMP']=str(root/'build')
binary=Path(r'D:\texlive\2026\bin\windows')
def executable(name):
    local=binary/(name+'.exe')
    found=str(local) if local.exists() else shutil.which(name)
    if not found:raise SystemExit('Required executable not found: '+name)
    return found
tex=[executable('xelatex'),'-interaction=nonstopmode','-file-line-error','-halt-on-error',str(root/(doc+'.tex'))]
report=[]
for i,cmd in enumerate([tex,tex,[executable('biber'),doc],tex,tex],1):
    p=subprocess.run(cmd,cwd=build,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (build/f'{doc}-pass-{i}.log').write_bytes(p.stdout)
    report.append({'pass':i,'tool':Path(cmd[0]).name,'exit_code':p.returncode})
    print(f'Pass {i}: {Path(cmd[0]).name}, exit={p.returncode}',flush=True)
    if p.returncode:
        print(p.stdout.decode('utf-8',errors='replace')[-9000:])
        break
(build/(doc+'-build-report.json')).write_text(json.dumps(report,indent=2),encoding='utf-8')
sys.exit(report[-1]['exit_code'])
