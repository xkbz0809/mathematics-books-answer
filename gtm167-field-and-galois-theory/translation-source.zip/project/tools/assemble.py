"""Assemble available translated units; only final mode accepts full source coverage."""
from pathlib import Path
import json, argparse, re, shutil, hashlib
p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parents[2];project=root/'project';tr=root/'translations'
lines=[r'\documentclass{mathtranslation}',r'\input{preamble}',r'\addbibresource{references.bib}',r'\begin{document}',
 r'\nocite{'+','.join(f'ref{i}' for i in range(1,31))+'}',r'\makecover',r'\frontmatter']
included=[];missing=[];unfinished=[];hashes={}
def inc(p):
    if p.exists():
        text=p.read_text(encoding='utf8');stack=[]
        for action,env in re.findall(r'\\(begin|end)\{([^{}]+)\}',text):
            if action=='begin':stack.append(env)
            elif not stack or stack.pop()!=env:stack.append('MISMATCH');break
        if stack:
            unfinished.append(p.relative_to(root).as_posix());return
        dest=project/'chapters'/p.relative_to(tr);dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(text,encoding='utf8')
        lines.append(r'\input{'+dest.relative_to(project).as_posix()+'}');included.append(p.relative_to(root).as_posix())
        hashes[p.relative_to(root).as_posix()]=hashlib.sha256(text.encode('utf8')).hexdigest()
    else:missing.append(p.relative_to(root).as_posix())
for name in ['imprint','translation_note','preface','reader']:inc(tr/'front'/f'{name}.tex')
lines.append(r'\makecontents');inc(tr/'front'/'symbols.tex');lines.append(r'\mainmatter')
for ch,a,b in [(1,1,5),(2,6,11),(3,12,16),(4,17,18),(5,19,23)]:
    lines.append(r'\setcounter{chapter}{'+str(ch-1)+'}')
    inc(tr/f'ch{ch:02}'/'intro.tex')
    for s in range(a,b+1):
        lines.append(r'\setcounter{section}{'+str(s-1)+'}');inc(tr/f'ch{ch:02}'/f's{s:02}.tex')
lines.append(r'\appendix')
for i,ch in enumerate('ABCDE'):
    lines.append(r'\setcounter{chapter}{'+str(i)+'}');inc(tr/'appendices'/f'{ch}.tex')
lines.extend([r'\backmatter',r'\makebibliography'])
inc(tr/'back'/'index.tex')
inc(tr/'back'/'series_catalog.tex')
lines.extend([r'\printterminology',r'\end{document}'])
(project/'build'/'assembly.json').write_text(json.dumps({'included':included,'missing':missing,'unfinished':unfinished,'hashes':hashes,'final_requested':args.final},ensure_ascii=False,indent=2),encoding='utf8')
if args.final and (missing or unfinished):raise SystemExit('Missing/unfinished units: '+str(missing+unfinished))
(project/'main.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')
print(json.dumps({'included':len(included),'missing':missing,'unfinished':unfinished},ensure_ascii=False))
