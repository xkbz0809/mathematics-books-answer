from pathlib import Path
import shutil, hashlib, json

root = Path(__file__).resolve().parents[1]
up = root/'upstream/template/mathtranslations-translation-template'
source = (up/'mathtranslations-translation-template.cls').read_text(encoding='utf-8')
font_start = source.index('% ---------- 页面')
font_end = source.index('% ---------- 译本元信息')
fonts = source[font_start:font_end].replace(',titlesec','').replace('style=alphabetic','style=numeric').replace('sorting=nyt','sorting=none')
metadata_start = source.index('% ---------- 译本元信息')
metadata_end = source.index('% ================================================================\n%                       定理类环境')
metadata = source[metadata_start:metadata_end]
metadata = metadata.replace('\\renewcommand{\\maketitle}', '\\newcommand{\\makecover}')
metadata = metadata.replace('\\makeatletter','').replace('\\makeatother','')
metadata = metadata.replace('\\section{术语索引}', '\\MTunnumberedchapter{术语索引}')
metadata = metadata.replace('  % 此处仍处于 \\appendix 状态，因此术语索引按普通附录章节排版并自动编号。','')
# The long English title and neutral translation credit need a wider cover block.
metadata = metadata.replace('\\hspace{2cm} {\\fontsize{45pt}{60pt}', '{\\fontsize{36pt}{46pt}')
metadata = metadata.replace('\\hspace{2cm} {\\fontsize{25pt}{30pt}', '{\\fontsize{23pt}{29pt}')
metadata = metadata.replace('\\hspace{2cm} {\\Huge', '{\\Huge')
metadata = metadata.replace('0.46\\textwidth','0.35\\textwidth').replace('0.50\\textwidth','0.61\\textwidth').replace('width=5.7cm','width=4.8cm')
theorem_start = source.index('\\newtheoremstyle{mtfang}')
theorem_end = source.index('\\theoremstyle{mtfang}',theorem_start)
styles = source[theorem_start:theorem_end]
proof_start = source.index('% ---------- proof 样式')
proof_end = source.index('% ================================================================\n%                     长证明',proof_start)
proof = source[proof_start:proof_end].replace('\\makeatletter','').replace('\\makeatother','')
extra = r'''
% Native book structure; main sections remain continuous across chapters.
\counterwithout{section}{chapter}
\renewcommand{\thesection}{\arabic{section}}
\renewcommand{\thechapter}{\Roman{chapter}}
\renewcommand{\theHsection}{\theHchapter.\arabic{section}}
\counterwithout{equation}{chapter}
\counterwithin{equation}{section}
\renewcommand{\theequation}{\thesection.\arabic{equation}}
\renewcommand{\theHequation}{\theHsection.\arabic{equation}}
\ctexset{chapter={name={第,章},number=\Roman{chapter}},section={format=\Large\bfseries}}
\setcounter{tocdepth}{1}
\newcommand{\MTunnumberedchapter}[1]{\chapter*{#1}\phantomsection\addcontentsline{toc}{chapter}{#1}}
\newcommand{\makecontents}{\tableofcontents\clearpage}
\newcommand{\makebibliography}{\MTunnumberedchapter{参考文献}\printbibliography[heading=none]}
\setlength{\bibitemsep}{0.5\baselineskip}
\let\MToriginalappendix\appendix
\renewcommand{\appendix}{\MToriginalappendix\counterwithin*{section}{chapter}}
\theoremstyle{mtfang}
\newtheorem{theorem}{定理}[section]
\newtheorem{definition}[theorem]{定义}
\newtheorem{lemma}[theorem]{引理}
\newtheorem{proposition}[theorem]{命题}
\newtheorem{corollary}[theorem]{推论}
\newtheorem{remark}[theorem]{注}
\theoremstyle{mtsong}
\newtheorem{example}[theorem]{例}
\newtheorem{problem}[theorem]{问题}
\newtheorem*{remark*}{注}
\newtheorem*{example*}{例}
\renewcommand{\theHtheorem}{\theHsection.\arabic{theorem}}
\RequirePackage{enumitem}
\newlist{exerciselist}{enumerate}{1}
\setlist[exerciselist]{label=\textbf{\arabic*.},ref=\thesection.\arabic*,leftmargin=2.3em,itemsep=.5\baselineskip}
\newenvironment{exercises}{\par\medskip\noindent\large\bfseries 习题\par\normalfont\normalsize\begin{exerciselist}}{\end{exerciselist}}
\newcommand{\sourcepage}[1]{\hypertarget{source-page-#1}{}\label{source-page-#1}}
\newcommand{\srcpageref}[1]{\hyperlink{source-page-#1}{#1}}
\newcommand{\translatedpageref}[1]{\pageref{source-page-#1}}
\renewcommand{\sectionautorefname}{节}
\renewcommand{\chapterautorefname}{章}
\providecommand{\theoremautorefname}{定理}
\hypersetup{pdftitle={域与伽罗瓦理论},pdfauthor={Patrick Morandi；Codex（AI辅助译稿）}}
\endinput
'''
cls = '\\NeedsTeXFormat{LaTeX2e}\n\\ProvidesClass{mathtranslation}[2026/10/15 GTM167 book adaptation of official 2026/09/11 template]\n\\LoadClass[UTF8,12pt,fontset=none,openany,oneside]{ctexbook}\n'+fonts+metadata+styles+proof+extra
(root/'mathtranslation.cls').write_text(cls,encoding='utf-8')
shutil.copy2(up/'graphics/logo.pdf',root/'graphics/logo.pdf')
provenance={'download_url':'https://mathtranslations.org/static/catalog/mathtranslations-translation-template.3ea772c9d558.zip','guide_url':'https://mathtranslations.org/guide/','upstream_class':'mathtranslations-translation-template.cls','upstream_class_date':'2026/09/11','upstream_base_class':'ctexart','project_base_class':'ctexbook','reason':'Native five-chapter hierarchy with globally numbered sections, shared per-section theorem counter, appendix section resets, source-page anchors. Official font, color, cover and terminology conventions retained.','zip_sha256':hashlib.sha256((root/'upstream/mathtranslations-translation-template.zip').read_bytes()).hexdigest()}
(root/'upstream/provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf-8')
