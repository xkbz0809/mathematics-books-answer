"""Verify bookmark destination page and vertical position against rendered headings."""
from pathlib import Path
import re,json
import pymupdf as fitz
root=Path(__file__).resolve().parents[2]
doc=fitz.open(root/'project/build/main.pdf')
def normalize(s): return re.sub(r'\s+','',s)
results=[]
for level,title,page,dest in doc.get_toc(False):
    target=doc[page-1];needle=normalize(title);matches=[]
    for block in target.get_text('dict')['blocks']:
        spans=[s for line in block.get('lines',[]) for s in line['spans']]
        text=''.join(s['text'] for s in spans)
        if needle in normalize(text) and max((s['size'] for s in spans),default=0)>13:
            matches.append(block['bbox'])
    # In this named-destination API the point uses PDF-native bottom-left coordinates.
    anchor_top=target.rect.height-dest['to'].y
    passing=[b for b in matches if -6<=b[1]-anchor_top<=130]
    results.append({'title':title,'physical_page':page,'anchor_top':anchor_top,
                    'heading_boxes':matches,'passed':bool(passing)})
report={'bookmarks':len(results),'passed':sum(x['passed'] for x in results),
        'failures':[x for x in results if not x['passed']],'entries':results,
        'coordinate_convention':'Named destination to.y is PDF-native in PyMuPDF 1.28.2; transformed by page height.'}
(root/'work/qa/bookmark_heading_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in report.items() if k!='entries'},ensure_ascii=False,indent=2))
