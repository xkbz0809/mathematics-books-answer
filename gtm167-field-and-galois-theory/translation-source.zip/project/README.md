# GTM 167《域与伽罗瓦理论》中文译稿

原著：Patrick Morandi，Field and Galois Theory，Graduate Texts in Mathematics 167，Springer，1996 年第一版的平装重印本。

## 文件关系

- `main.tex`：整书入口。
- `chapters/`：本次编译实际使用的各章、附录及前后资料快照。
- `preamble.tex`：书名、作者、译稿说明所需宏和公共数学记号。
- `mathtranslation.cls`：本项目的 ctexbook 适配类，基于下载的数译官方模板改造；它并非声称上游官方提供了同名的 ctexbook 版本。
- `references.bib`：30 条原书参考文献，引用键为 ref1 至 ref30，编号顺序固定。
- `graphics/logo.pdf`：所据模板的标识图。
- `tools/build.py`：XeLaTeX 两遍、Biber 一遍、XeLaTeX 两遍的构建脚本。
- `../translations/`：逐节工作的源文件；`tools/assemble.py` 会将它们复制到 `chapters/` 并重写 `main.tex`。

只改 `chapters/` 后运行构建脚本可以直接编译；若要延续本项目的逐节工作流程，请改 `../translations/`，再运行组装命令，以免直接对快照的编辑被覆盖。

## 构建

需要 Python 3、完整的 TeX Live（含 XeLaTeX、Biber、ctex、Fandol、Computer Modern Unicode 字体、tikz-cd）。本次在 TeX Live 2026 下构建。常规构建不需要 PyMuPDF；只有 PDF 检查脚本使用它。

在本文件所在目录的上一级（即 GTM167 根目录）执行：

```powershell
python -X utf8 project/tools/assemble.py --final
python -X utf8 project/tools/build.py main
```

脚本优先使用本机 `D:\texlive\2026\bin\windows`，不存在时从 PATH 查找命令。中间文件、日志和 PDF 写到 `project/build`。字体使用 TeX Live 随附字体，不依赖 Windows 专有中文字体。

检查脚本：

```powershell
python -X utf8 project/tools/audit_structure.py
python -X utf8 project/tools/qa_pdf.py --render
python -X utf8 project/tools/audit_bookmark_headings.py
```

检查结果保存在 `../work/qa`。这些自动检查用于发现结构、编号、链接和排版风险，不能单独证明翻译忠实性或数学正确性。

## 阅读约定

原书印刷页码与译稿页码分开记录。`\sourcepage{...}` 标记原页内容起点；`\srcpageref{...}` 显示原页码并跳到该内容。原书索引保留原列页码，因其中存在与扫描本正文不符的页码，未批量伪造索引跳转；额外的术语索引链接到译稿。

原书疑误保持与译文修订分开。已识别问题见中文 PDF 中的译者脚注，以及 `../translations/` 下的各章 `issues.md` 和附录记录。具体覆盖范围、独立复核情况与最终验证结果以根目录的《翻译与核对报告》为准。
