# GTM167 最终修订账本汇总

汇总时间：2026-10-15T16:44:20。统计单位：原账本唯一事项 ID。

**实际为 76 项：第一章 14 项，第二、三章 33 项，第四、五章 16 项，附录 11 项，书前书后 1 项，最终正文修订 1 项。76 项均记录 applied=true，并各自保留三次确认。**

这不是“76 个新错误”。其中 58 项具有既有记录依据（56 项主体对应，2 项明确部分对应）；1 项被责任账本明确标作新增；其余 17 项的首次发现状态不作断言。

## 统计口径

- 本汇总仅覆盖上述六份输入账本的 76 个事项 ID；不声称包含旧 issues.md 中所有未修订疑点，也不声称全书原书错误总数为 76。
- 一条事项可能包含多个问题，一处问题可能同时影响题目与正文；保持原 ID 粒度，不拆分为虚增的新错误数。
- “原题问题/正文问题/译稿错误/约定澄清/范围补足”是互斥主分类；原账本类别逐项保留，混合及跨位置影响另列。主分类不等同于真假命题或严重性计数。
- 58 项有既有记录依据，其中 56 项主体对应旧记录，2 项明确含历史状态需拆分的细项；不声称另 56 项的所有细节都已逐字登记。1 项被责任账本明确称为新增；其余 17 项不断言首次发现状态。
- “原账本明示新增”仅陈述所读责任账本的历史判断，不声称穷尽作者、外部文献或此前所有会话的发现历史；没有旧条目不是新发现的充分证据。
- 既有疑点升级为反例确证的明确标签仅有 SV-17.15、SV-19.7。其余事项均保存本轮三次确认，但不据此声称是首次数学确证。
- 三次确认沿用各责任账本的原图、数学推导/独立对应、译稿回读证据；汇总者没有在本次统计中另做 76 次独立数学复核。FB-01 的第二次检查是城市名称逐一对应，而非数学推导。
- 所有 applied=true 均为原账本记录；本次只写汇总 JSON 与 Markdown，不改译稿、答案或原账本。原记录中的前后哈希完整保留；未把其中阶段性文件哈希宣称为本次整书最终文件哈希。
- IV/V 账本保留原修订时点的 after_sha256；其顶层 final_layout_and_derivative_followup.current_s23_sha256 是后续状态。两者随原账本元数据并存，不相互覆盖。
- SOL-A9 明确不是无条件假命题；SOL-2.15 是通常函数复合约定下的次序问题；范围补足、术语记号笔误与证明提示问题不应混称为新数学错误。
- 当前额外检查限于输入账本哈希、唯一 ID、76 项总数、3 份确认记录、applied 标志与引用证据文件的存在性。
- SOL-II-12 包含 10.16 周期性括注的正偶数维 r>=1 边界澄清及 10.17 正维结语、奇数维 r>=0、H0=M^G 随访子项；仍只计一个 ID。
- 追加的 SOL-23.1-derivative 为已有疑误记录中的正文导数上限错误，独立计为第 76 项；原书左侧多项式求和下限 i=0 正确且保持。s15 的 15-01 注标记位置移动属排版调整，不新增事项。

## 可公开的分类计数

| 主分类 | 事项数 |
|---|---:|
| 原题问题 | 49 |
| 正文问题 | 15 |
| 译稿错误 | 2 |
| 约定澄清 | 3 |
| 范围补足 | 7 |
| 合计 | 76 |

纯译稿错误 2 项：SOL-III-20、FB-01。另有 SOL-III-10 同时含原题问题与译稿漏译，按原题主分类只计一次。SV-22.5 同时修正正文例 21.7，按习题事项只计一次。

| 历史状态 | 数目 | 说明 |
|---|---:|---|
| 既有记录 | 58 | 其中 SOL-III-10、SOL-III-19 为部分内容有旧记录 |
| 责任账本明示新增 | 1 | SV-22.10 |
| 首次发现状态未断言 | 17 | 不因未检出旧条目而视作新增 |

既有疑点明确升级为反例确证：SV-17.15, SV-19.7。这 2 项包含在既有记录的 58 项之内，不另加总。

未断言首次发现状态的 17 项：SOL-1.6, SOL-1.7, SOL-2.15, SOL-2.18, SOL-4.11, SOL-4.15, SOL-5.9, SOL-5.10, SOL-5.15, SOL-II-04, SOL-II-05, SOL-II-06, SOL-II-07, SOL-II-12, SOL-III-20, SOL-III-21, FB-01。

## 输入账本与可追溯性

| 输入文件 | 条目数 | SHA-256 |
|---|---:|---|
| [solutions/qa/chapter_i_issues.json](D:/translation/GTM167/solutions/qa/chapter_i_issues.json) | 14 | `a791fe11847d037925c79bf1712e01328d3cd6a0fcaebfe52e356b9086777b2a` |
| [solutions/qa/chapters_ii_iii_issues.json](D:/translation/GTM167/solutions/qa/chapters_ii_iii_issues.json) | 33 | `347bbf1e760df17239fd26b37fb759943a923a87fdd347b1d50db7aa57563d12` |
| [solutions/qa/issues_iv_v.json](D:/translation/GTM167/solutions/qa/issues_iv_v.json) | 16 | `48959cd7cab58b1eea5c298eca5a7a38b2a3b400299d8f648f41897f268af42c` |
| [solutions/qa/appendices_issues.json](D:/translation/GTM167/solutions/qa/appendices_issues.json) | 11 | `4a806f5c5b28a32add72dace551e53e76501fcb6b7ef0cc2c7b2f41b907249d4` |
| [work/qa/review_front_back.json](D:/translation/GTM167/work/qa/review_front_back.json) | 1 | `aba1e94d7996b667f5b2179e2eb4ea473afeefffdf861cb67a8660c72809dd06` |
| [solutions/qa/final_body_revision.json](D:/translation/GTM167/solutions/qa/final_body_revision.json) | 1 | `b58042ae9902605648fe5fc585ab88a359fb3d7c2ef5b0ef28dadd31b2db650b` |

旧记录依据取自 baseline ZIP 内的相应章 issues.md，逐条证据保存在 JSON 的 novelty.evidence；附录及第四、五章按责任账本明确历史标签登记。六份账本的非事项元数据亦保存在 input_manifest[].ledger_metadata。

引用证据文件不存在的记录数：0。

## 逐项索引

| ID | 主分类 | 原始类别 | 事项 | 历史状态 | 译稿文件 |
|---|---|---|---|---|---|
| SOL-1.6 | 原题问题 | source_error | 多项式泛性质补交换 F-代数及固定 F 的同态 | 未断言 | [translations/ch01/s01.tex](D:/translation/GTM167/translations/ch01/s01.tex) |
| SOL-1.7 | 约定澄清 | convention_clarification | F-代数包含 F 的副本时排除零代数 | 未断言 | [translations/ch01/s01.tex](D:/translation/GTM167/translations/ch01/s01.tex) |
| SOL-1.27 | 原题问题 | source_error | 素子环的底域 R 改 F | 既有记录 | [translations/ch01/s01.tex](D:/translation/GTM167/translations/ch01/s01.tex) |
| SOL-2.12 | 原题问题 | source_error | 伽罗瓦连接条件 (ii) 的 f 改 g | 既有记录 | [translations/ch01/s02.tex](D:/translation/GTM167/translations/ch01/s02.tex) |
| SOL-2.15 | 约定澄清 | composition_convention_error | 通常函数复合下矩阵对应改为取逆后同态 | 未断言 | [translations/ch01/s02.tex](D:/translation/GTM167/translations/ch01/s02.tex) |
| SOL-2.18 | 原题问题 | source_error | 平移不动域断言补 a 非零 | 未断言 | [translations/ch01/s02.tex](D:/translation/GTM167/translations/ch01/s02.tex) |
| SOL-4.11 | 范围补足 | scope_clarification | 有理函数扩张补生成元非常数 | 未断言 | [translations/ch01/s04.tex](D:/translation/GTM167/translations/ch01/s04.tex) |
| SOL-4.12 | 原题问题 | source_error | p-基链改累计生成，并限定指数一 | 既有记录 | [translations/ch01/s04.tex](D:/translation/GTM167/translations/ch01/s04.tex) |
| SOL-4.15 | 范围补足 | scope_clarification | 次数乘法公式补有限扩张范围 | 未断言 | [translations/ch01/s04.tex](D:/translation/GTM167/translations/ch01/s04.tex) |
| SOL-5.6 | 原题问题 | source_error | 二次中间域的次数符号改正 | 既有记录 | [translations/ch01/s05.tex](D:/translation/GTM167/translations/ch01/s05.tex) |
| SOL-5.9 | 范围补足 | scope_clarification | 轨道乘积公式补有限伽罗瓦扩张 | 未断言 | [translations/ch01/s05.tex](D:/translation/GTM167/translations/ch01/s05.tex) |
| SOL-5.10 | 范围补足 | scope_clarification | 特征多项式补有限维范围 | 未断言 | [translations/ch01/s05.tex](D:/translation/GTM167/translations/ch01/s05.tex) |
| SOL-5.15 | 原题问题 | missing_hypothesis | 素数次数断言补非平凡扩张 | 未断言 | [translations/ch01/s05.tex](D:/translation/GTM167/translations/ch01/s05.tex) |
| SOL-5.21 | 原题问题 | expository_inconsistency | 无限域导语与有限域子题的适用范围说明 | 既有记录 | [translations/ch01/s05.tex](D:/translation/GTM167/translations/ch01/s05.tex) |
| SOL-II-01 | 原题问题 | source_error | 习题 6.1(b) 最小公倍数参数改为元素的阶 | 既有记录 | [translations/ch02/s06.tex](D:/translation/GTM167/translations/ch02/s06.tex) |
| SOL-II-02 | 原题问题 | source_error | 习题 6.15 无限阶断言排除恒等自同构 | 既有记录 | [translations/ch02/s06.tex](D:/translation/GTM167/translations/ch02/s06.tex) |
| SOL-II-03 | 原题问题 | source_error | 习题 6.15 伽罗瓦群改为整数的有限完备化 | 既有记录 | [translations/ch02/s06.tex](D:/translation/GTM167/translations/ch02/s06.tex) |
| SOL-II-04 | 原题问题 | source_error | 习题 7.15 的 Kronecker–Weber 说明补有限性 | 未断言 | [translations/ch02/s07.tex](D:/translation/GTM167/translations/ch02/s07.tex) |
| SOL-II-05 | 原题问题 | source_error | 习题 9.3 补特征不等于 2 | 未断言 | [translations/ch02/s09.tex](D:/translation/GTM167/translations/ch02/s09.tex) |
| SOL-II-06 | 原题问题 | source_error | 习题 9.4(a) 补 a 非零 | 未断言 | [translations/ch02/s09.tex](D:/translation/GTM167/translations/ch02/s09.tex) |
| SOL-II-07 | 原题问题 | source_error | 习题 9.5 补非平凡扩张 | 未断言 | [translations/ch02/s09.tex](D:/translation/GTM167/translations/ch02/s09.tex) |
| SOL-II-08 | 原题问题 | source_error | 习题 10.3 一般上闭链的单位元取值含群作用 | 既有记录 | [translations/ch02/s10.tex](D:/translation/GTM167/translations/ch02/s10.tex) |
| SOL-II-09 | 正文问题 | source_error | 群扩张正文的一般逆元公式及上闭链单位元公式 | 既有记录 | [translations/ch02/s10.tex](D:/translation/GTM167/translations/ch02/s10.tex) |
| SOL-II-10 | 原题问题 | source_error | 习题 10.16 统一加法记号及范数公式 | 既有记录 | [translations/ch02/s10.tex](D:/translation/GTM167/translations/ch02/s10.tex) |
| SOL-II-11 | 原题问题 | source_error | 习题 11.6 补 G 有限并改未定义底域记号 | 既有记录 | [translations/ch02/s11.tex](D:/translation/GTM167/translations/ch02/s11.tex) |
| SOL-III-01 | 原题问题 | source_error | 习题 12.4 删除任意域上的错误正交对角化提示 | 既有记录 | [translations/ch03/s12.tex](D:/translation/GTM167/translations/ch03/s12.tex) |
| SOL-III-02 | 原题问题 | source_error | 习题 12.7 数域判别式的底域改 Q | 既有记录 | [translations/ch03/s12.tex](D:/translation/GTM167/translations/ch03/s12.tex) |
| SOL-III-03 | 原题问题 | source_error | 习题 13.1 的 g/f 与预解式变量统一 | 既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-04 | 原题问题 | source_error | 习题 13.10 补特征不等于 2 | 既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-05 | 正文问题 | source_error | 四次方程推导中 sigma_3(v) 补负号 | 既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-06 | 正文问题 | source_error | 四次方程推导中 (u-a)^2 改 (u+a)^2 | 既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-07 | 正文问题 | source_error | 例 13.5 根式内减号改加号 | 既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-08 | 原题问题 | source_error | 习题 14.2 补两个超越性双条件的前提 | 既有记录 | [translations/ch03/s14.tex](D:/translation/GTM167/translations/ch03/s14.tex) |
| SOL-III-09 | 原题问题 | source_error | 习题 14.4 求和指数下标配对 | 既有记录 | [translations/ch03/s14.tex](D:/translation/GTM167/translations/ch03/s14.tex) |
| SOL-III-10 | 原题问题 | source_error_and_translation_omission | 习题 14.11 连续函数不构成域；补回漏译的“开”并明确修订环境 | 部分事项既有记录 | [translations/ch03/s14.tex](D:/translation/GTM167/translations/ch03/s14.tex) |
| SOL-III-11 | 正文问题 | source_error | 引理 15.1 直线交点结论排除重合直线 | 既有记录 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-12 | 正文问题 | source_error | 引理 15.1 圆交点结论排除重合圆 | 既有记录 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-13 | 正文问题 | source_error | 60 度构作示例交换点的两个坐标 | 既有记录 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-14 | 正文问题 | source_error | 定理 15.6 子群链起终点与不动域方向修正 | 既有记录 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-15 | 正文问题 | source_error | 可作正多边形判别补费马素数互异 | 既有记录 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-16 | 正文问题 | source_error | 引理 16.6 的 n 次幂改 n 次方根 | 既有记录 | [translations/ch03/s16.tex](D:/translation/GTM167/translations/ch03/s16.tex) |
| SOL-III-17 | 正文问题 | source_error | 例 16.12 的定理名 Cayley 改 Cauchy | 既有记录 | [translations/ch03/s16.tex](D:/translation/GTM167/translations/ch03/s16.tex) |
| SOL-III-18 | 正文问题 | source_error | 例 16.13 的 Gal(K/F) 改 Gal(K/Q) | 既有记录 | [translations/ch03/s16.tex](D:/translation/GTM167/translations/ch03/s16.tex) |
| SOL-II-12 | 原题问题 | source_error | 习题 10.16 参数化构造补 n 大于 1，平凡群另论 | 未断言 | [translations/ch02/s10.tex](D:/translation/GTM167/translations/ch02/s10.tex) |
| SOL-III-19 | 正文问题 | source_error | 例 13.8 补不可约性，改 h 的符号、检查域及错误 V_4 示例 | 部分事项既有记录 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SOL-III-20 | 译稿错误 | translation_error | 图 15.2 删除译稿额外画出的过 A 竖线 | 未断言 | [translations/ch03/s15.tex](D:/translation/GTM167/translations/ch03/s15.tex) |
| SOL-III-21 | 正文问题 | source_error | S_4 的三阶循环子群数六改四 | 未断言 | [translations/ch03/s13.tex](D:/translation/GTM167/translations/ch03/s13.tex) |
| SV-17.3 | 范围补足 | 既有提示范围问题确认 | 无限伽罗瓦群提示改为可数子扩张再延拓 | 既有记录 | [translations/ch04/s17.tex](D:/translation/GTM167/translations/ch04/s17.tex) |
| SV-17.13 | 原题问题 | 既有源式错误确认 | 逆系统的复合次序修正 | 既有记录 | [translations/ch04/s17.tex](D:/translation/GTM167/translations/ch04/s17.tex) |
| SV-17.15 | 原题问题 | 既有源命题疑点升级为反例确证 | 有限指数抽象子群改为开正规子群 | 既有记录 | [translations/ch04/s17.tex](D:/translation/GTM167/translations/ch04/s17.tex) |
| SV-18.3 | 范围补足 | 既有定义范围确认 | p-闭包定义的范围扩至特征 p | 既有记录 | [translations/ch04/s18.tex](D:/translation/GTM167/translations/ch04/s18.tex) |
| SV-18.5 | 原题问题 | 既有源命题错误确认 | 特征 p 分支中的域 I 改 K | 既有记录 | [translations/ch04/s18.tex](D:/translation/GTM167/translations/ch04/s18.tex) |
| SV-19.1 | 原题问题 | 既有未定义记号确认 | 未定义的 T 改共同扩域 K | 既有记录 | [translations/ch05/s19.tex](D:/translation/GTM167/translations/ch05/s19.tex) |
| SV-19.7 | 原题问题 | 既有参数疑点升级为反例确证 | 有理参数重复分母因子删除 | 既有记录 | [translations/ch05/s19.tex](D:/translation/GTM167/translations/ch05/s19.tex) |
| SV-19.dep | 原题问题 | 既有公理笔误确认 | 习题组相关性公理的有限支撑集合下标补齐 | 既有记录 | [translations/ch05/s19.tex](D:/translation/GTM167/translations/ch05/s19.tex) |
| SV-21.9 | 原题问题 | 既有源命题错误确认 | 一维曲线结论补不可约性并修正有限集提示 | 既有记录 | [translations/ch05/s21.tex](D:/translation/GTM167/translations/ch05/s21.tex) |
| SV-22.3 | 原题问题 | 既有源命题笔误确认 | 实点集“非空”改“空” | 既有记录 | [translations/ch05/s22.tex](D:/translation/GTM167/translations/ch05/s22.tex) |
| SV-22.5 | 原题问题 | 既有源命题错误确认 | 参数曲线补第三方程，并同步例 21.7 | 既有记录 | [translations/ch05/s22.tex](D:/translation/GTM167/translations/ch05/s22.tex) |
| SV-22.10 | 原题问题 | 新增源命题错误 | 不动子环断言补完美底域或改为纯不可分闭包系数 | 原账本明示新增 | [translations/ch05/s22.tex](D:/translation/GTM167/translations/ch05/s22.tex) |
| SV-22.11 | 原题问题 | 既有源式错误确认 | 消失理想符号 k(V) 改 I(V) | 既有记录 | [translations/ch05/s22.tex](D:/translation/GTM167/translations/ch05/s22.tex) |
| SV-23.3 | 原题问题 | 既有源假设错误确认 | 指数一假设及 p-基链改正，失效附录引用明示保留 | 既有记录 | [translations/ch05/s23.tex](D:/translation/GTM167/translations/ch05/s23.tex) |
| SV-23.4 | 原题问题 | 既有源命题错误确认 | 切空间的极大理想改在坐标环中，或补消失理想 | 既有记录 | [translations/ch05/s23.tex](D:/translation/GTM167/translations/ch05/s23.tex) |
| SV-23.6 | 原题问题 | 既有记号错误确认 | 曲线及范数系数环记号统一 | 既有记录 | [translations/ch05/s23.tex](D:/translation/GTM167/translations/ch05/s23.tex) |
| SOL-A2 | 原题问题 | source_typo | 素子环 R 改 F | 既有记录 | [translations/appendices/A.tex](D:/translation/GTM167/translations/appendices/A.tex) |
| SOL-A9 | 约定澄清 | definition_consistency_clarification | 素元分解采用非零素元约定并明确范围 | 既有记录 | [translations/appendices/A.tex](D:/translation/GTM167/translations/appendices/A.tex) |
| SOL-A10 | 原题问题 | missing_hypothesis | 不可约分解补非零非单位条件 | 既有记录 | [translations/appendices/A.tex](D:/translation/GTM167/translations/appendices/A.tex) |
| SOL-A18b | 原题问题 | false_statement | 局部化理想收缩改为饱和公式 | 既有记录 | [translations/appendices/A.tex](D:/translation/GTM167/translations/appendices/A.tex) |
| SOL-B2 | 原题问题 | false_statement | 零乘法反例改用 Prüfer 群 | 既有记录 | [translations/appendices/B.tex](D:/translation/GTM167/translations/appendices/B.tex) |
| SOL-C4 | 原题问题 | false_statement | profinite 指数公式补正规性或改用开子群 | 既有记录 | [translations/appendices/C.tex](D:/translation/GTM167/translations/appendices/C.tex) |
| SOL-C6 | 原题问题 | missing_hypothesis | 正规子群交公式补 H 正规 | 既有记录 | [translations/appendices/C.tex](D:/translation/GTM167/translations/appendices/C.tex) |
| SOL-C7 | 原题问题 | missing_hypothesis | 有限指数正规子群补闭性 | 既有记录 | [translations/appendices/C.tex](D:/translation/GTM167/translations/appendices/C.tex) |
| SOL-C8 | 原题问题 | missing_hypothesis | profinite 商群补闭正规条件 | 既有记录 | [translations/appendices/C.tex](D:/translation/GTM167/translations/appendices/C.tex) |
| SOL-E1 | 原题问题 | missing_hypothesis | 拓扑基条件补覆盖全空间 | 既有记录 | [translations/appendices/E.tex](D:/translation/GTM167/translations/appendices/E.tex) |
| SOL-E16 | 范围补足 | source_typo_and_scope | Cantor 集结论限定非退化区间并统一集合名 | 既有记录 | [translations/appendices/E.tex](D:/translation/GTM167/translations/appendices/E.tex) |
| FB-01 | 译稿错误 | translation_omission | 出版说明补回原书 12 个出版城市 | 未断言 | [translations/front/imprint.tex](D:/translation/GTM167/translations/front/imprint.tex) |
| SOL-23.1-derivative | 正文问题 | source_body_error | 例 23.1 导数求和上限 n−1 改 n；左侧多项式下限 0 保持 | 既有记录 | [translations/ch05/s23.tex](D:/translation/GTM167/translations/ch05/s23.tex) |

## 三次确认摘要与分类说明

以下逐项保存检查摘要；完整原文、修订前后内容、哈希和原始确认对象见同名 JSON 的 original_record。摘要中的“已确认”是责任账本记录的状态。

### SOL-1.6：多项式泛性质补交换 F-代数及固定 F 的同态

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：13。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/13.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s01.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s01.tex。

### SOL-1.7：F-代数包含 F 的副本时排除零代数

- 类别：约定澄清；原始类别：`convention_clarification`；已应用记录：是。
- 原书页：13。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/13.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s01.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s01.tex。

### SOL-1.27：素子环的底域 R 改 F

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：15。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/15.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s01.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s01.tex。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch01/issues.md:11`：- 印刷页 15，习题 27 先设 F 是域，却称 R 的素子环；上下文应为 F. 译文保留原文 R.

### SOL-2.12：伽罗瓦连接条件 (ii) 的 f 改 g

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：26。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/26.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s02.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s02.tex。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch01/issues.md:13`：- 印刷页 26，习题 12 条件 (ii) 可见原文为 `f(t₂)≤_S f(t₁)`，但 f 的定义域为 S 而 t 属于 T；疑两个 f 应为 g. 译文保留原文.

### SOL-2.15：通常函数复合下矩阵对应改为取逆后同态

- 类别：约定澄清；原始类别：`composition_convention_error`；已应用记录：是。
- 原书页：26。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/26.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s02.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s02.tex。
- 分类说明：原账本类别为 composition_convention_error；汇总归入约定澄清，仍保留“通常函数复合下原映射为反同态”的条件性错误说明

### SOL-2.18：平移不动域断言补 a 非零

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：27。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/27.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s02.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s02.tex。

### SOL-4.11：有理函数扩张补生成元非常数

- 类别：范围补足；原始类别：`scope_clarification`；已应用记录：是。
- 原书页：50。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/50.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s04.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s04.tex。

### SOL-4.12：p-基链改累计生成，并限定指数一

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：50。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/50.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s04.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s04.tex。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch01/issues.md:27`：- 印刷页 50，习题 12 的 p-基定义链原文为 F⊂F(a₁)⊂⋯⊂F(a_n)=K，并非逐步添加 a₁,…,a_i；在 K^p⊂F 的假设下存在问题. 同题结尾将存在性表述为任意有限纯不可分扩张，亦与开头指数一条件有范围差异. 按原文保留.

### SOL-4.15：次数乘法公式补有限扩张范围

- 类别：范围补足；原始类别：`scope_clarification`；已应用记录：是。
- 原书页：50。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/50.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s04.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s04.tex。

### SOL-5.6：二次中间域的次数符号改正

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：60。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/60.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s05.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s05.tex。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch01/issues.md:33`：- 印刷页 60，习题 6 原文条件为“没有中间域使 [N:F]=2”，但该次数是已固定的 12；疑原意为中间域在 F 上二次. 按原文保留.

### SOL-5.9：轨道乘积公式补有限伽罗瓦扩张

- 类别：范围补足；原始类别：`scope_clarification`；已应用记录：是。
- 原书页：60。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/60.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s05.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s05.tex。

### SOL-5.10：特征多项式补有限维范围

- 类别：范围补足；原始类别：`scope_clarification`；已应用记录：是。
- 原书页：60。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/60.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s05.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s05.tex。

### SOL-5.15：素数次数断言补非平凡扩张

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：61。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/61.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s05.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s05.tex。

### SOL-5.21：无限域导语与有限域子题的适用范围说明

- 类别：原题问题；原始类别：`expository_inconsistency`；已应用记录：是。
- 原书页：62。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：直接查看原书整页图像，核实原印字句和假设；证据：work/ch01_images/62.png。
- 第 2 次（数学推导、反例或独立对应检查）：独立推导、反例与修订后命题的完整证明；证据：solutions/answers/s05.tex。
- 第 3 次（当前译稿与拟修订再次核对）：回读当前题面、修订内容及边界；保留原印说明并校验实际写入；证据：translations/ch01/s05.tex。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch01/issues.md:34`：- 印刷页 62，习题 21 标题称无限域情形，(a) 亦假定 F 无限，但 (b) 原文称“finite extension of finite fields”；译文保留“有限域的有限扩张”，未改为无限域.

### SOL-II-01：习题 6.1(b) 最小公倍数参数改为元素的阶

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：70。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p70.png。
- 第 2 次（数学推导、反例或独立对应检查）：Prime-power component construction in solution ex:6.1 proves order lcm(n,m); lcm is not defined for arbitrary group elements.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:3`：- 第 6 节印刷第 70 页，习题 1(b)：原书印为 `lcm(a,b)`，而 a、b 为群元素，前述阶为 n、m；疑应为 `lcm(n,m)`. 译文保留原式，未静默修正.

### SOL-II-02：习题 6.15 无限阶断言排除恒等自同构

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：71。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p71.png。
- 第 2 次（数学推导、反例或独立对应检查）：Identity has order one; restriction to F_(q^(rn)) proves every finite-order element is identity; ex:6.15.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:9`：- 第 6 节印刷第 71 页，习题 15：原书称任意自同构的阶无限，未排除恒等自同构；又称该 Galois 群同构于 p-进整数的加法群. 两处均按原文保留；疑点应由独立数学审校确认，译文未改为其他群.

### SOL-II-03：习题 6.15 伽罗瓦群改为整数的有限完备化

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：71。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p71.png。
- 第 2 次（数学推导、反例或独立对应检查）：Restriction exponent system gives inverse limit over every n, not just p powers; different finite continuous quotients distinguish the groups.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:9`：- 第 6 节印刷第 71 页，习题 15：原书称任意自同构的阶无限，未排除恒等自同构；又称该 Galois 群同构于 p-进整数的加法群. 两处均按原文保留；疑点应由独立数学审校确认，译文未改为其他群.

### SOL-II-04：习题 7.15 的 Kronecker–Weber 说明补有限性

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：78。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p78.png。
- 第 2 次（数学推导、反例或独立对应检查）：Every cyclotomic number field has finite degree; union of all cyclotomic fields is an infinite abelian extension not contained in one cyclotomic number field.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。

### SOL-II-05：习题 9.3 补特征不等于 2

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：92。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p92.png。
- 第 2 次（数学推导、反例或独立对应检查）：In characteristic two norm(1)=-1 but nonsquare t is not sum of two squares; char not two proof in ex:9.3.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。

### SOL-II-06：习题 9.4(a) 补 a 非零

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：92。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p92.png。
- 第 2 次（数学推导、反例或独立对应检查）：For a=0 splitting field of X^n is F, not necessarily F(omega); for a nonzero ratios of roots recover omega.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。

### SOL-II-07：习题 9.5 补非平凡扩张

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：93。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p93.png。
- 第 2 次（数学推导、反例或独立对应检查）：Positive-characteristic algebraically closed F=K counterexample; corrected Artin-Schreier theorem proved completely in ex:9.5.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。

### SOL-II-08：习题 10.3 一般上闭链的单位元取值含群作用

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：102。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p102.png。
- 第 2 次（数学推导、反例或独立对应检查）：Insert identity into cocycle condition; counterexample G=C2 acting by negation on Z, f=delta(constant 1) gives f(s,1)=-1, f(1,1)=1.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:25`：- 第 10 节印刷第 99 页：原文把 delta_1 的像称作 1-coboundary；群 E_f 的一般逆元公式以及 f(1,1)=f(1,sigma)=f(sigma,1)（亦见习题3）均有需核验的明显疑点. 原样保留.

### SOL-II-09：群扩张正文的一般逆元公式及上闭链单位元公式

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：99。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p99.png。
- 第 2 次（数学推导、反例或独立对应检查）：Solving m sigma(n) f(sigma,sigma^-1)=c^-1 gives corrected inverse; cocycle yields left inverse as well. Even trivial cocycle with nontrivial action refutes source formula.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:25`：- 第 10 节印刷第 99 页：原文把 delta_1 的像称作 1-coboundary；群 E_f 的一般逆元公式以及 f(1,1)=f(1,sigma)=f(sigma,1)（亦见习题3）均有需核验的明显疑点. 原样保留.

### SOL-II-10：习题 10.16 统一加法记号及范数公式

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：104。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p104.png。
- 第 2 次（数学推导、反例或独立对应检查）：Carry-count cocycle, telescoping delta sum and lift u^n prove all four parts in additive notation; roots independent reread confirmed unnormalized sum includes f(1,1).。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:23`：- 第 10 节印刷第 97–104 页：源书在一般 Abel G-模上混用加法与乘法记号，尤其习题16(a)的1、16(b)乘法上边缘与m-n=N(c1)混用；译稿均保留.

### SOL-II-11：习题 11.6 补 G 有限并改未定义底域记号

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：110。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch02_review/p110.png。
- 第 2 次（数学推导、反例或独立对应检查）：Finite Kummer degree bound and perfect pairing prove result. Infinite G=Q*/Q*2 gives countable direct sum vs uncountable product counterexample.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch02/issues.md:31`：- 第 11 节印刷第110页，习题4、5中hom(G,C)的复数符号未印乘法群星号；习题6未给G有限假设且结论写Gal(K/F)而非Gal(F(G)/F). 译稿均保留.

### SOL-III-01：习题 12.4 删除任意域上的错误正交对角化提示

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：122。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p122.png。
- 第 2 次（数学推导、反例或独立对应检查）：Explicit complex symmetric square-zero nonzero matrix refutes diagonalizability; determinant follows immediately from Gram matrix.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:8`：- 第12节第122页，习题4对任意域使用对称矩阵正交对角化，前提可能不足；习题7沿用数域却写K/F. 均保留源文.

### SOL-III-02：习题 12.7 数域判别式的底域改 Q

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：122。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p122.png。
- 第 2 次（数学推导、反例或独立对应检查）：Previous exercise fixes K a number field and B over Z; trace determinant integral uses base Q, not an undefined F.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:8`：- 第12节第122页，习题4对任意域使用对称矩阵正交对角化，前提可能不足；习题7沿用数域却写K/F. 均保留源文.

### SOL-III-03：习题 13.1 的 g/f 与预解式变量统一

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：132。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p132.png。
- 第 2 次（数学推导、反例或独立对应检查）：This exercise defines only g, and direct expansion yields the displayed identity for g.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:21`：- 页 132 习题 1 在定义 g 后提到 f，关于 y 的预解方程写为 r(x)=0；按源保留。

### SOL-III-04：习题 13.10 补特征不等于 2

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：133。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p133.png。
- 第 2 次（数学推导、反例或独立对应检查）：Counterexample F16/F2 satisfies all separability context; all even-power polynomials over F2 are squares. Characteristic-not-two construction fully proved in ex:13.10.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:22`：- 页 133 习题 10 没有排除特征 2，需结合原书上下文核实适用条件；译文未补假设。

### SOL-III-05：四次方程推导中 sigma_3(v) 补负号

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：129。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p129.png。
- 第 2 次（数学推导、反例或独立对应检查）：sigma3=(14)(23) sends t1-t2 to t4-t3, the negative of vprime.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:18`：- 页 129 的 v′=σ_2(v)=σ_3(v) 缺少一个负号；(v′)² 中第一项写成 (u−a)²。按源保留。此前把展开式中 t_3²t_4+t_3t_4² 的正号登记为疑误，经独立复核撤销：该项来自负负得正，源式和译文均正确，不计入疑误。

### SOL-III-06：四次方程推导中 (u-a)^2 改 (u+a)^2

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：129。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p129.png。
- 第 2 次（数学推导、反例或独立对应检查）：t3+t4=(-a-u)/2, so square must be (u+a)^2/4; independent Ferrari discriminant computation ex:13.1 confirms.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:18`：- 页 129 的 v′=σ_2(v)=σ_3(v) 缺少一个负号；(v′)² 中第一项写成 (u−a)²。按源保留。此前把展开式中 t_3²t_4+t_3t_4² 的正号登记为疑误，经独立复核撤销：该项来自负负得正，源式和译文均正确，不计入疑误。

### SOL-III-07：例 13.5 根式内减号改加号

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：130。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p130.png。
- 第 2 次（数学推导、反例或独立对应检查）：Squaring corrected v equals -(5+sqrt5)/2; source next root line independently uses plus sign.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:19`：- 页 130 例 13.5 在 v 的根式中先写 10−2√5，随后的根式却为 10+2√5；保留原书两处写法。

### SOL-III-08：习题 14.2 补两个超越性双条件的前提

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：138, 139。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p138.png、work/ch03_review/p139.png。
- 第 2 次（数学推导、反例或独立对应检查）：a=0,b=pi refutes both unqualified equivalences; clearing denominators proves corrected transcendence criterion.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:32`：- 页 138 习题 2 对任意复数 a,b 的双条件遗漏 a 超越的前提；页 139 习题 4 的求和下标 k 与指数 γ_j 不匹配；按源保留。

### SOL-III-09：习题 14.4 求和指数下标配对

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：139。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p139.png。
- 第 2 次（数学推导、反例或独立对应检查）：Sum index k must match distinct exponent gamma_k; formal Laurent polynomial proof uses same matching index.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:32`：- 页 138 习题 2 对任意复数 a,b 的双条件遗漏 a 超越的前提；页 139 习题 4 的求和下标 k 与指数 γ_j 不匹配；按源保留。

### SOL-III-10：习题 14.11 连续函数不构成域；补回漏译的“开”并明确修订环境

- 类别：原题问题；原始类别：`source_error_and_translation_omission`；已应用记录：是。
- 原书页：139。
- 历史：部分事项既有记录；未把既有问题称为新发现；本记录内新增细项的首次发现状态未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p139.png。
- 第 2 次（数学推导、反例或独立对应检查）：Original image contains dense open; continuous max(x,0),max(-x,0) form zero divisors. Analytic identity theorem gives an integral domain and its fraction field; transcendence proofs for all eight functions supplied.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:33`：- 页 139 习题 11 未说明函数等价关系或非零函数零集条件，所述全体连续函数集合并不直接构成域。未自行补充定义。
- 混合历史说明：连续函数集合并非域的主体问题已在旧记录中出现；漏译“开”的细项未据此判为既有，也不据缺少旧条目断言首次发现。
- 分类说明：混合记录：原题问题与译稿漏译同一 ID；不拆成两个修订事项计数

### SOL-III-11：引理 15.1 直线交点结论排除重合直线

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：143。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p143.png。
- 第 2 次（数学推导、反例或独立对应检查）：Coincident lines intersect in a line, not one point; elementary linear system proof needs distinct lines.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:38`：- 页 143 引理 15.1 没有明确排除重合直线、重合圆；原文原样保留。

### SOL-III-12：引理 15.1 圆交点结论排除重合圆

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：143。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p143.png。
- 第 2 次（数学推导、反例或独立对应检查）：Coincident circles intersect in the entire circle; subtracting equations gives a genuine line only for nonconcentric distinct circles, concentric distinct circles are disjoint.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:38`：- 页 143 引理 15.1 没有明确排除重合直线、重合圆；原文原样保留。

### SOL-III-13：60 度构作示例交换点的两个坐标

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：144。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p144.png。
- 第 2 次（数学推导、反例或独立对应检查）：Cos60=1/2,sin60=sqrt3/2; original coordinates instead give slope1/sqrt3 and angle30.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:39`：- 页 144 以点 (√3/2,1/2) 和原点所确定的直线说明 60° 角可作，实为 30°；保留原坐标和角度。

### SOL-III-14：定理 15.6 子群链起终点与不动域方向修正

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：146。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p146.png。
- 第 2 次（数学推导、反例或独立对应检查）：Galois order reversal: subgroups containing H have fixed fields inside K^H; endpoints must be H and G. Quotient G/H is finite abelian2group.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:40`：- 页 146 定理 15.6 反向证明定义 H=Gal(Q(ω)/Q(cos(2π/n)))，却随后对 H 的递增子群链使用不动域在 Q(cos(2π/n)) 内的包含关系，方向和起点不一致。按源保留，未重写证明。

### SOL-III-15：可作正多边形判别补费马素数互异

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：146。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p146.png。
- 第 2 次（数学推导、反例或独立对应检查）：Euler phi prime-power formula requires every odd prime exponent exactly one; n=9 refutes without distinctness.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:41`：- 页 146 n=2^s q_1⋯q_r 的判别中未明确写 q_i 互异；按源保留。

### SOL-III-16：引理 16.6 的 n 次幂改 n 次方根

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：149。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p149.png。
- 第 2 次（数学推导、反例或独立对应检查）：Displayed gamma_i^n=sigma_i(b) in N0 proves root, not power.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:46`：- 页 149 引理 16.6 证明末句把 γ_i 称为 N_0 中某元素的 n 次幂，按上下文应为 n 次方根；原句照译。

### SOL-III-17：例 16.12 的定理名 Cayley 改 Cauchy

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：152。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p152.png。
- 第 2 次（数学推导、反例或独立对应检查）：The named theorem is Cauchys theorem; Cayley instead embeds a group in its regular permutation group.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:49`：- 页 152 例 16.12 把 p 整除群阶推出 p 阶元素的定理归于 Cayley（通常为 Cauchy 定理）；例 16.13 中出现未在该例定义的 F，写 Gal(K/F)；均按源保留。

### SOL-III-18：例 16.13 的 Gal(K/F) 改 Gal(K/Q)

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：152。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original PDF page images, not OCR; exact original statement verified.；证据：work/ch03_review/p152.png。
- 第 2 次（数学推导、反例或独立对应检查）：Example defines K as splitting field over Q, no F exists; group is A3 over Q.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Compared exact live translation excerpt with source and re-derived proposed replacement; post-write exact reread required below.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:49`：- 页 152 例 16.12 把 p 整除群阶推出 p 阶元素的定理归于 Cayley（通常为 Cauchy 定理）；例 16.13 中出现未在该例定义的 F，写 Gal(K/F)；均按源保留。

### SOL-II-12：习题 10.16 参数化构造补 n 大于 1，平凡群另论

- 类别：原题问题；原始类别：`source_error`；已应用记录：是。
- 原书页：103, 104。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original source images.；证据：work/ch02_review/p103.png、work/ch02_review/p104.png。
- 第 2 次（数学推导、反例或独立对应检查）：For n=1 the carry cocycles all vanish, so (b) cannot recover m-mprime. The conclusion H2=0=M/NM remains valid separately; ex:10.16 explicitly handles trivial group.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Exact current text compared and proposed replacement independently recomputed.。
- 混合历史说明：原主体边界问题未断言首次发现历史；新增的正偶数维范围说明只是同一习题修订的子项。
- 分类说明：同一修订子项：10.16 的周期性括注限 r>=1 的正偶数维；10.17 的结语限正维，奇数维公式 r>=0，且 H0=M^G。仍归入本 ID，不另加总。
- 追加边界子项：10.16 周期性括注补 r≥1，只指正偶数维；10.17 结语补明正维、奇数维 r≥0 与 H^0=M^G。仍属于 SOL-II-12，不另计数。
- 子项原印：all of the even dimensional cohomology groups；图像：`work/ch02_review/p104.png`。
- 子项第 1 次确认：Original page image re-viewed by root。
- 子项第 2 次确认：H0(C2,Z)=Z while H2(C2,Z)=Z/2Z for trivial action; independently noted by appendices reviewer。
- 子项第 3 次确认：Current statement and solution compared; exact writeback reread; source wording retained in SOL-10.16-period note。
- 关联随访：10.17 concluding sentence explicitly states positive degrees, r>=0 for odd degrees, and H0=M^G; same source104 and same counterexample.

### SOL-III-19：例 13.8 补不可约性，改 h 的符号、检查域及错误 V_4 示例

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：132。
- 历史：部分事项既有记录；未把既有问题称为新发现；本记录内新增细项的首次发现状态未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Viewed original source images.；证据：work/ch03_review/p132.png。
- 第 2 次（数学推导、反例或独立对应检查）：Resolvent formula gives d=-l so h=X²(X²-l); square-class criterion in solution13.9 proves D4/V4 under irreducibility. Explicit factorization of X4+4 gives Q(i), not V4; X4+1=Phi8 supplies correct irreducible example.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Exact current text compared and proposed replacement independently recomputed.。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch03/issues.md:20`：- 页 132 例 13.8 未假设 x^4−l 不可约即调用定理 13.4，且断言 x^4+4 的伽罗瓦群为 V，存在明显疑误。均未自行修正。
- 混合历史说明：缺不可约性及 x^4+4 的群错误已有记录；h 的符号及检查域两个细项的首次发现状态未断言。

### SOL-III-20：图 15.2 删除译稿额外画出的过 A 竖线

- 类别：译稿错误；原始类别：`translation_error`；已应用记录：是。
- 原书页：141。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Direct original page image comparison.；证据：work/ch03_review/p141.png。
- 第 2 次（数学推导、反例或独立对应检查）：Original right panel has only the perpendicular through x and P; translated redraw erroneously added a second full vertical through A. Removing it restores source geometry without changing labels or intended construction.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Exact before/after source inspected; intended correction reread after write.。

### SOL-III-21：S_4 的三阶循环子群数六改四

- 类别：正文问题；原始类别：`source_error`；已应用记录：是。
- 原书页：130。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：Direct original page image comparison.；证据：work/ch03_review/p130.png。
- 第 2 次（数学推导、反例或独立对应检查）：There are 4 choose 3 times2=8 three-cycles, and each C3 has two generators; complete subgroup enumeration in solution13.11 confirms four C3 subgroups.。
- 第 3 次（当前译稿与拟修订再次核对）：passed；证据：Exact before/after source inspected; intended correction reread after write.。

### SV-17.3：无限伽罗瓦群提示改为可数子扩张再延拓

- 类别：范围补足；原始类别：`既有提示范围问题确认`；已应用记录：是。
- 原书页：162。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch04_review/p0177.png。
- 第 2 次（数学推导、反例或独立对应检查）：任意不可数超越基上的无限独立二次扩张无法由可数有限扩张穷尽；解答用可数子扩张并和限制满射修复。；证据：solutions/answers/s17.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；将有限伽罗瓦链的并取为无限子扩张E；再将自同构从E延拓到K，不要求链穷尽K。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有提示范围问题确认。
- 分类说明：提示的穷尽范围确有问题；主分类“范围补足”不表示该原提示已正确

### SV-17.13：逆系统的复合次序修正

- 类别：原题问题；原始类别：`既有源式错误确认`；已应用记录：是。
- 原书页：163。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch04_review/p0178.png。
- 第 2 次（数学推导、反例或独立对应检查）：前者G_gamma到G_beta，后者G_beta到G_alpha；原次序定义域不匹配；坐标逆极限构造满足修正版。；证据：solutions/answers/s17.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；相容式改为varphi_{alpha,gamma}=varphi_{alpha,beta} compose varphi_{beta,gamma}。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源式错误确认。

### SV-17.15：有限指数抽象子群改为开正规子群

- 类别：原题问题；原始类别：`既有源命题疑点升级为反例确证`；已应用记录：是。
- 原书页：164。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；既有疑点在本轮升级为反例确证（原账本明确记载）。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch04_review/p0179.png。
- 第 2 次（数学推导、反例或独立对应检查）：G=F2^N的基数c，抽象F2维数c，对偶维数2^c；全有限余维完备化为二重对偶，基数2^(2^c)>c。；证据：solutions/answers/s17.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；(c)中的逆极限改取profinite群的开正规子群；保留原题抽象有限指数版本的反例。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题疑点升级为反例确证。

### SV-18.3：p-闭包定义的范围扩至特征 p

- 类别：范围补足；原始类别：`既有定义范围确认`；已应用记录：是。
- 原书页：170。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch04_review/p0185.png。
- 第 2 次（数学推导、反例或独立对应检查）：有限域唯一扩张与次数整除关系给出并F_{p^(p^r)}；前文char(F)!=p的限制不适用于此题。；证据：solutions/answers/s18.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；说明本题采用所有有限伽罗瓦p幂次数扩张合成域的定义，将其推广到特征p。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有定义范围确认。

### SV-18.5：特征 p 分支中的域 I 改 K

- 类别：原题问题；原始类别：`既有源命题错误确认`；已应用记录：是。
- 原书页：171。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch04_review/p0186.png。
- 第 2 次（数学推导、反例或独立对应检查）：F=Fp时I=Fp仍有任意非p幂次数扩张；取K=Fs^P后有限可分次数及不可分次数均p幂，中间有限次数素于p。；证据：solutions/answers/s18.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；p=char(F)分支把I改为K；p!=char(F)分支保留KI。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题错误确认。

### SV-19.1：未定义的 T 改共同扩域 K

- 类别：原题问题；原始类别：`既有未定义记号确认`；已应用记录：是。
- 原书页：180。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p180.png。
- 第 2 次（数学推导、反例或独立对应检查）：本题没有定义T；极小多项式比较需F(t,alpha)位于共同扩域；幂基清分母证明结论成立。；证据：solutions/answers/s19.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；t in T改为t in K，或明确二者位于共同扩域。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有未定义记号确认。

### SV-19.7：有理参数重复分母因子删除

- 类别：原题问题；原始类别：`既有参数疑点升级为反例确证`；已应用记录：是。
- 原书页：181。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；既有疑点在本轮升级为反例确证（原账本明确记载）。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p181.png。
- 第 2 次（数学推导、反例或独立对应检查）：令u=y/(i-x)，x=i(u^2-1)/(u^2+1), y=2iu/(u^2+1)；原t=u(u^2+1)/(2i)，故[K:C(t)]=3而非1。；证据：solutions/answers/s19.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；把t=(i-x)^(-1)sqrt(-1-x^2)/(i-x)改为t=sqrt(-1-x^2)/(i-x)，同时注明原式重复因子。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有参数疑点升级为反例确证。

### SV-19.dep：习题组相关性公理的有限支撑集合下标补齐

- 类别：原题问题；原始类别：`既有公理笔误确认`；已应用记录：是。
- 原书页：181。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p181.png。
- 第 2 次（数学推导、反例或独立对应检查）：否则存在有限子集这一量词不约束相关性；Zorn链并及无限基等势证明使用有限支撑；线性及代数相关均满足修正版。；证据：solutions/answers/s19.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；有限性公理(ii)末尾alpha prec S改为alpha prec S_0。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有公理笔误确认。

### SV-21.9：一维曲线结论补不可约性并修正有限集提示

- 类别：原题问题；原始类别：`既有源命题错误确认`；已应用记录：是。
- 原书页：200。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p200.png。
- 第 2 次（数学推导、反例或独立对应检查）：V=Z(xy)维数1但一条分支是真闭无限集；R-Zariski闭集Z(x^2+1)不可约却有两点。修正版由零维有限生成域有限扩张证明。；证据：solutions/answers/s21.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；补充V不可约；提示单点改为有限集，或同时限定k=C。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题错误确认。

### SV-22.3：实点集“非空”改“空”

- 类别：原题问题；原始类别：`既有源命题笔误确认`；已应用记录：是。
- 原书页：208。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p208.png。
- 第 2 次（数学推导、反例或独立对应检查）：实数平方和加1恒正；实有理参数函数在避开有限极点的实参数处给出实点，与无实点矛盾。；证据：solutions/answers/s22.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；非空改为空。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题笔误确认。

### SV-22.5：参数曲线补第三方程，并同步例 21.7

- 类别：原题问题；原始类别：`既有源命题错误确认`；已应用记录：是。
- 原书页：208。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p208.png。
- 第 2 次（数学推导、反例或独立对应检查）：两式的零点集是参数曲线并x轴；非零xy处令t=y/x推出(t^3,t^4,t^5)，第三式把额外轴压缩为原点。；证据：solutions/answers/s22.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；补入第三方程yz-x^3=0；同样修正例21.7列出的定义方程。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题错误确认。
- 分类说明：同时关联正文例 21.7；主分类按习题记一次
- 分类说明：translations/ch05/s21.tex

### SV-22.10：不动子环断言补完美底域或改为纯不可分闭包系数

- 类别：原题问题；原始类别：`新增源命题错误`；已应用记录：是。
- 原书页：209。
- 历史：未断言；原账本明示新增；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p209.png。
- 第 2 次（数学推导、反例或独立对应检查）：取k=Fp(s), V={0}, J=(x)，题设J等式成立；C[x]/J=C中s^(1/p)被所有k自同构固定却不在k[V]=k。选k[V]的k基逐系数得到准确不动环。；证据：solutions/answers/s22.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；(c)补充k完美，或把不动子环改为I tensor_k k[V]，I为k在C中的纯不可分闭包。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：新增源命题错误。

### SV-22.11：消失理想符号 k(V) 改 I(V)

- 类别：原题问题；原始类别：`既有源式错误确认`；已应用记录：是。
- 原书页：210。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p210.png。
- 第 2 次（数学推导、反例或独立对应检查）：k(V)含1，不是非空V的消失理想。完美k下A tensor C约化，Nullstellensatz给出IC(V)=I(V)C[x]。已提供独立证明，不声称读过Draxl。；证据：solutions/answers/s22.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；左端k(V)C[x]改为I(V)C[x]。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源式错误确认。

### SV-23.3：指数一假设及 p-基链改正，失效附录引用明示保留

- 类别：原题问题；原始类别：`既有源假设错误确认`；已应用记录：是。
- 原书页：223。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p223.png。
- 第 2 次（数学推导、反例或独立对应检查）：F=Fp(s),K=F(s^(1/p^2))有长2生成链但Der维数1。指数一时p单项式基及任意指定D(a_i)证明维数n。；证据：solutions/answers/s23.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；F^p subset K改为K^p subset F；域链改为累计生成a_1,...,a_i；附录D习题19保留为明确注明仅有17题的原引文，不猜测替代编号。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源假设错误确认。

### SV-23.4：切空间的极大理想改在坐标环中，或补消失理想

- 类别：原题问题；原始类别：`既有源命题错误确认`；已应用记录：是。
- 原书页：224。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p224.png。
- 第 2 次（数学推导、反例或独立对应检查）：V={0}subsetC时切空间0，核为(x)而非(x^2)；一般切空间湮灭子等于I(V)一次项张成，证明正确商同构。；证据：solutions/answers/s23.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；M_P改为坐标环C[V]中的极大理想；若保留环境环，则核/商分母改为M_P^2+I(V)。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有源命题错误确认。

### SV-23.6：曲线及范数系数环记号统一

- 类别：原题问题；原始类别：`既有记号错误确认`；已应用记录：是。
- 原书页：224。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：已逐图核对原PDF可见题面和全部子问；不是仅据OCR判断。；证据：work/ch05_review/p224.png。
- 第 2 次（数学推导、反例或独立对应检查）：全题曲线X；范数在C(x)中，A=C[x]+C[x]y，N(u+vy)=u^2-(x^3-x)v^2属于C[x]。；证据：solutions/answers/s23.tex。
- 第 3 次（当前译稿与拟修订再次核对）：已核对当前译稿仍保留原书问题或既有疑误注；修正版已在解答中明确区分并再次核对公式。；题首C(Y)改为C(X)；补K=C(X)；(c)k[x]改C[x]。。
- 历史依据：`solutions/qa/issues_iv_v.json` 的 `classification`：既有记号错误确认。

### SOL-A2：素子环 R 改 F

- 类别：原题问题；原始类别：`source_typo`；已应用记录：是。
- 原书页：237。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p237.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/A.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/A.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：translations/appendices/A_issues.md。

### SOL-A9：素元分解采用非零素元约定并明确范围

- 类别：约定澄清；原始类别：`definition_consistency_clarification`；已应用记录：是。
- 原书页：238。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p238.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/A.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/A.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：translations/appendices/A_issues.md。
- 分类说明：原账本明确 is_definite_false_statement=false；不计为无条件假命题

### SOL-A10：不可约分解补非零非单位条件

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：238。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p238.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/A.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/A.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：translations/appendices/A_issues.md。

### SOL-A18b：局部化理想收缩改为饱和公式

- 类别：原题问题；原始类别：`false_statement`；已应用记录：是。
- 原书页：239。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p239.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/A.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/A.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：translations/appendices/A_issues.md。

### SOL-B2：零乘法反例改用 Prüfer 群

- 类别：原题问题；原始类别：`false_statement`；已应用记录：是。
- 原书页：244。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p244.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/B.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/B.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：B-03。

### SOL-C4：profinite 指数公式补正规性或改用开子群

- 类别：原题问题；原始类别：`false_statement`；已应用记录：是。
- 原书页：253。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p253.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/C.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/C.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：C-11。

### SOL-C6：正规子群交公式补 H 正规

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：253。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p253.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/C.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/C.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：C-12。

### SOL-C7：有限指数正规子群补闭性

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：253。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p253.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/C.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/C.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：C-13。

### SOL-C8：profinite 商群补闭正规条件

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：253。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p253.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/C.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/C.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：C-14。

### SOL-E1：拓扑基条件补覆盖全空间

- 类别：原题问题；原始类别：`missing_hypothesis`；已应用记录：是。
- 原书页：272。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p272.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/E.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/E.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：E-01。

### SOL-E16：Cantor 集结论限定非退化区间并统一集合名

- 类别：范围补足；原始类别：`source_typo_and_scope`；已应用记录：是。
- 原书页：273。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：原页图像逐字复核题面；证据：solutions/qa/appendix_source/p273.png。
- 第 2 次（数学推导、反例或独立对应检查）：完整证明或满足原假设的反例，并验证修订命题；证据：solutions/answers/E.tex。
- 第 3 次（当前译稿与拟修订再次核对）：原题当前TeX与修订措辞再次比较；写入答案后复读证明及边界；修订题面及显式原文注均已复读，原误记/反例与修订命题一致；证据：translations/appendices/E.tex。
- 历史依据：`solutions/qa/appendices_issues.json` 的 `previously_recorded / previous_record`：E-10。
- 分类说明：范围补足与集合名笔误并存；原类别 source_typo_and_scope 保留

### FB-01：出版说明补回原书 12 个出版城市

- 类别：译稿错误；原始类别：`translation_omission`；已应用记录：是。
- 原书页：无印刷页码；物理页 2。
- 历史：未断言；未断言；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：12 Springer cities visible on source series title page.。
- 第 2 次（数学推导、反例或独立对应检查）：New York/Berlin/Heidelberg/Barcelona/Budapest/Hong Kong/London/Milan/Paris/Santa Clara/Singapore/Tokyo checked in source order against the 12 Chinese city names.。
- 第 3 次（当前译稿与拟修订再次核对）：Confirmed entire city list absent before edit, inserted once, all other metadata preserved.。

### SOL-23.1-derivative：例 23.1 导数求和上限 n−1 改 n；左侧多项式下限 0 保持

- 类别：正文问题；原始类别：`source_body_error`；已应用记录：是。
- 原书页：210。
- 历史：既有记录；主体问题已有记录；不另断言所含每个细项的发现历史；本轮三次确认已记录；是否首次确证未断言。
- 第 1 次（原书图像及字句核对）：root and IV/V agent viewed actual original summation limits；证据：work/ch05_review/p210.png。
- 第 2 次（数学推导、反例或独立对应检查）：Leibniz induction gives D(x^i)=i x^(i-1); for k=Q and f=x original RHS zero instead of one。
- 第 3 次（当前译稿与拟修订再次核对）：Compared original formula, existing note and current replacement; reread saved source; retained original upper limit explicitly。
- 既有依据：`work/review2/baseline/before-solutions.zip` 内 `translations/ch05/issues.md:30`：- 印210，例23.1：导数求和上限原印n-1，通常应n。
- 历史依据：`solutions/qa/final_body_revision.json` 的 `history`：previously recorded footnote; applied after final rereview。
- 分类说明：本条仅修正导数右侧求和上限；左侧多项式求和下限 i=0 已由原图确认正确，不改为 1。
- 分类说明：这是追加的独立既有正文错误，计为第 76 个事项；与 10.16/10.17 边界子项不同。

