# GTM167 · 域与伽罗瓦理论习题解答源码

主文件 main.tex。chapters/ 为包含题面和解答的分章稿，answers/ 为逐节解答源。使用带 Fandol 与 CM Unicode 字体的 TeX Live，在源码目录执行 XeLaTeX 两遍、biber main，再执行 XeLaTeX 两遍。book-labels.aux 为外部编号映射，编译无需配套译本 PDF。
