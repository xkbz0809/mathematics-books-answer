$ErrorActionPreference = 'Stop'
$xelatex = Get-Command xelatex -ErrorAction Stop
Push-Location -LiteralPath $PSScriptRoot
try {
    foreach ($pass in 1..3) {
        & $xelatex.Source -interaction=nonstopmode -halt-on-error -file-line-error main.tex
        if ($LASTEXITCODE -ne 0) {
            throw "XeLaTeX failed on pass $pass. See main.log."
        }
    }
    Write-Output (Join-Path $PSScriptRoot 'main.pdf')
}
finally {
    Pop-Location
}
