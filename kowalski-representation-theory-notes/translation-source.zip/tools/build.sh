#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -X utf8 tools/build.py "${1:-full}"
