from pathlib import Path
import subprocess,sys,shutil,json,time
root=Path(__file__).resolve().parents[1]
mode=sys.argv[1] if len(sys.argv)>1 else 'full'
job=sys.argv[2] if len(sys.argv)>2 else 'main'
logs=root/'build-logs'; logs.mkdir(exist_ok=True)
if mode=='clean':
    for ext in ('aux','toc','out','bbl','bcf','run.xml','lof','lot','log'):
        (root/f'{job}.{ext}').unlink(missing_ok=True)
mode='full' if mode=='clean' else mode
commands=[['xelatex','-interaction=nonstopmode','-halt-on-error','-file-line-error',job+'.tex']]*2
if mode=='full':
    commands += [['biber',job]] + [commands[0]]*2
report=[]
for i,cmd in enumerate(commands,1):
    found=shutil.which(cmd[0])
    if not found: raise SystemExit('Missing executable: '+cmd[0])
    start=time.time()
    result=subprocess.run([found]+cmd[1:],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (logs/f'{job}-{i}-{cmd[0]}.log').write_bytes(result.stdout)
    report.append({'command':cmd,'returncode':result.returncode,'seconds':round(time.time()-start,2)})
    print(cmd[0],i,'exit',result.returncode,flush=True)
    if result.returncode:
        print(result.stdout.decode('utf-8',errors='replace')[-7000:]);break
(logs/f'{job}-build.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
raise SystemExit(report[-1]['returncode'])
