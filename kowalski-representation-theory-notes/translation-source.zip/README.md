# 表示论中文修订译本：独立源码包

本包可以独立编译，无须访问另一个工程或原英文 PDF。主文件为 `main.tex`。本项目编写的习题参考解答并非原作者官方答案。

## 编译

本次使用 Windows、TeX Live 2026、XeLaTeX 和 biber。字体采用模板中的 Fandol 中文字体和 CM Unicode 西文字体（`cmunrm.otf` 等）。请安装具有中文支持的 TeX Live/MiKTeX，以及 Python 3（仅用于便利构建脚本）。

在解压后的目录执行：

```text
python tools/build.py clean main
```

也可以依次手动执行 `xelatex main` 两次、`biber main` 一次、`xelatex main` 两次。本工程术语表由模板在 LaTeX 内部生成，不需要 texindy。生成的文件为 `main.pdf`。

`source-manifest.json` 记录全部编译源文件的 SHA-256。编译产物和旧版 PDF 不打包进源码包。独立解压重建的验证结果放在交付目录的校核记录和交付清单中。

原书习题编号和题干校订详见随交付提供的覆盖清单、修订清单和校对说明。所有编译源文件均使用 UTF-8。
