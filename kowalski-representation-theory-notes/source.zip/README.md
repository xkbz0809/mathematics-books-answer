# Kowalski · 表示论习题答案源码

使用带 Fandol 与 CM Unicode 字体的 TeX Live，以及 Python 3。在源码目录运行 python tools/build.py full，或依次执行两遍 xelatex main、biber main 和两遍 xelatex main。chapters/ 组织章节，statements/ 和 answers/ 保存题面和解答。
