from pathlib import Path
import json,hashlib,sys
p=Path(__file__).parent
record=json.loads((p/'computation-record.json').read_text())
record['task'].update(object='Artin decompositions of all five irreducible complex A5 characters',deliverables=['Exact rational inverse and five decompositions','Rerunnable Python fractions code'])
record['mathematical_context'].update(assumptions=['The supplied source A5 character table and Frobenius reciprocity determine the multiplicity matrix.','Rows are 1, 3, 3prime, 4, 5; columns are P2,P3,P5,Q1,Q2.'],domain='Q')
record['implementation_discovery']={
 'mathematica':{'candidate_implementations':['Exact matrix inversion'],'existence_evidence':'Standard exact linear algebra task; no Mathematica function was executed.','local_availability':'unavailable','availability_evidence':'Backend snapshot records no installation or wolframscript; current ALL_TOOLS discovery returned no Wolfram or Mathematica tool.'},
 'sagemath':{'candidate_implementations':['Rational matrix inversion'],'existence_evidence':'Exact rational linear algebra is a candidate task; no Sage code was executed.','local_availability':'unavailable','availability_evidence':'Backend inventory reports no native sage; no Sage tool advertised.'},
 'python':{'candidate_implementations':['fractions.Fraction Gaussian elimination'],'existence_evidence':'Standard-library fractions imported; 1/3+1/6=1/2 exact smoke check passed.','local_availability':'available','availability_evidence':sys.version}}
record['decision'].update(selected_backend='python',backend_version=sys.version.split()[0],selection_reason='Five-by-five rational system is directly handled with exact standard-library arithmetic.',fallback_reason='No callable local Wolfram MCP or installed Mathematica/Sage backend; Python fractions provides exact arithmetic with explicit residual checks.')
record['execution'].update(status='complete',interface='local Python CLI',command_or_input='python -X utf8 compute.py',code_artifact='compute.py')
record['artifacts']=[{'role':role,'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for role,n in [('code','compute.py'),('result','result.json')]]
record['result'].update(status='complete',summary='All five decompositions computed exactly; left and right inverse products are identity and induced dimensions are 30,20,12,12,12.',result_artifact='result.json')
record['verification'].update(methods=['Exact left and right residual multiplication over fractions','Dimension checks against subgroup indices','Mathematical derivation of the matrix in the exercise solution'],evidence_level='exact-check',residual_or_error='Zero exact residual in both matrix products.',limitations=['The computation checks the finite matrix calculation. The representation-theoretic input is justified separately in the written proof.'])
(p/'computation-record.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
