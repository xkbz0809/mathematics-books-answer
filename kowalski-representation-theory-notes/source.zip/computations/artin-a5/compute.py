from fractions import Fraction as F
from pathlib import Path
import json

# Rows: irreducibles 1, 3, 3prime, 4, 5.
# Columns: Ind_C2(1), Ind_C3(1), Ind_C5(1), Ind_C5(zeta), Ind_C5(zeta^2).
M=[[1,1,1,0,0],[1,1,1,1,0],[1,1,1,0,1],[2,2,0,1,1],[3,1,1,1,1]]
n=5
A=[[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(M)]
for j in range(n):
    pivot=next(i for i in range(j,n) if A[i][j])
    A[j],A[pivot]=A[pivot],A[j]
    d=A[j][j];A[j]=[x/d for x in A[j]]
    for i in range(n):
        if i!=j:
            c=A[i][j];A[i]=[a-c*b for a,b in zip(A[i],A[j])]
inverse=[row[n:] for row in A]
left=[[sum(F(M[i][k])*inverse[k][j] for k in range(n)) for j in range(n)] for i in range(n)]
right=[[sum(inverse[i][k]*F(M[k][j]) for k in range(n)) for j in range(n)] for i in range(n)]
I=[[F(i==j) for j in range(n)] for i in range(n)]
assert left==right==I
dimensions=[1,3,3,4,5]
assert [sum(dimensions[i]*M[i][j] for i in range(n)) for j in range(n)]==[30,20,12,12,12]
result={'domain':'Q','multiplicity_matrix':M,'inverse':[[str(x) for x in row] for row in inverse], 'decompositions_by_irreducible':{name:[str(inverse[j][i]) for j in range(n)] for i,name in enumerate(['1','3','3prime','4','5'])},'left_and_right_inverse_exact':True,'induced_dimension_check':[30,20,12,12,12]}
(Path(__file__).parent/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
