from pathlib import Path
import numpy as np
import json,math,time,sys

def prime(n):
 return n>=2 and all(n%d for d in range(2,math.isqrt(n)+1))
def factors(n):
 ans=[]; d=2
 while d*d<=n:
  if n%d==0:
   ans.append(d)
   while n%d==0:n//=d
  d+=1
 if n>1:ans.append(n)
 return ans
def sums(p):
 assert prime(p)
 fac=factors(p-1)
 g=next(x for x in range(2,p) if all(pow(x,(p-1)//d,p)!=1 for d in fac))
 xs=[]; x=1
 for _ in range(p-1):xs.append(x);x=x*g%p
 assert len(set(xs))==p-1 and x==1
 z=np.exp((2j*np.pi/p)*np.array(xs))
 vals=np.fft.ifft(np.fft.fft(z)**3)/p
 return g,xs,vals
checks=[]
for p in (7,11,17):
 g,xs,v=sums(p)
 direct=np.array([sum(np.exp(2j*np.pi*((x+y+a*pow(x*y,-1,p))%p)/p) for x in range(1,p) for y in range(1,p))/p for a in xs])
 err=float(np.max(np.abs(v-direct)))
 assert err<1e-12
 checks.append({'p':p,'max_abs_fft_minus_direct':err})
rows=[]
for p in (101,1009,10007,99991):
 t=time.perf_counter();g,xs,v=sums(p)
 moms=[complex(np.mean(v**k)) for k in range(10)]
 pos={a:i for i,a in enumerate(xs)}
 conjerr=max(abs(v[pos[p-a]]-v[i].conjugate()) for i,a in enumerate(xs))
 meanerr=abs(moms[1]+1/(p*(p-1)))
 assert conjerr<1e-10 and meanerr<1e-12 and max(abs(v))<3+1e-10
 rows.append({'p':p,'primitive_root':g,'seconds':time.perf_counter()-t,'max_absolute_sum':float(max(abs(v))),'conjugation_residual':float(conjerr),'first_moment_exact_residual':float(meanerr),'moments':[{'k':k,'real':z.real,'imag':z.imag} for k,z in enumerate(moms)]})
result={'python_version':sys.version,'numpy_version':np.__version__,'arithmetic':'complex128','algorithm':'cyclic multiplicative convolution of exp(2*pi*i*g^j/p), three factors, NumPy FFT','independent_checks':checks,'rows':rows,'limit_moments':[1,0,0,1,0,0,5,0,0,42],'evidence_level':'numerical-evidence'}
Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
for r in rows:print(r['p'], ' '.join(f"{m['real']:.7f}" for m in r['moments']))
print('direct check maximum',max(c['max_abs_fft_minus_direct'] for c in checks))
