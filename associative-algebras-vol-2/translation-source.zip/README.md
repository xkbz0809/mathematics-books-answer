# 结合代数表示论基础 第 2 卷：管与欧几里得型隐蔽代数

本项目是 Daniel Simson、Andrzej Skowroński 所著 Elements of the Representation Theory of Associative Algebras, Volume 2: Tubes and Concealed Algebras of Euclidean Type（Cambridge University Press, 2007）的中文翻译与 LaTeX 重排。英文原 PDF 是数学内容和结构的依据；源文件及身份信息见 source/manifest.json。

## 内容

全书第 X–XIV 章、引言、丛书目录、出版信息与献词、284 条参考文献、原书索引和符号表均已处理。五章分别含 8、10、14、13、16 道习题，共 61 道，保留原题与原编号。本包不增补第二卷习题答案。

以第一卷项目术语表为基础，统一箭图、束缚箭图、几乎可裂列、后投射、前内射、忠诚/忠实、倾斜模、隐蔽代数等术语。glossary.tsv 包含沿用词汇和本卷新增概念。数学符号按原书保留，包括射影直线记号的下标。为与同系列第一卷一致，使用第一卷的 ctexbook 版 mathtranslation.cls 适配类，不另换版式体系。

## 编译

建议 TeX Live 2026（本机实际验证版本），需要 XeLaTeX、Biber，以及 ctex、Fandol、Computer Modern Unicode、tikz-cd、biblatex 等通常随完整 TeX Live 安装的包。Python 构建入口仅用标准库；验证工具另需 PyMuPDF，图像对照工具另需 Pillow。

在解压目录运行：

    python -B tools/build.py main

或：

    bash tools/build.sh full

两者都依次执行 XeLaTeX 两遍、Biber 一遍、XeLaTeX 两遍，结果为 build/main.pdf。首轮没有辅助文件时的暂时引用警告由后续轮次消除。术语索引由类文件自动生成，无须 texindy。中文和英文字体均使用 TeX Live 自带字体，不依赖 Windows 专有字体。

## 文件布局

- main.tex、preamble.tex、mathtranslation.cls：入口、数学宏与版式。
- chapters/：五章正文与全部可编辑 TikZ-CD 图；frames/ 含 149 个分类框架图。
- frontmatter/、backmatter/：前言、出版信息、原索引及符号表。
- references.bib、glossary.tsv、volume1_links.tex：参考文献、系列术语及第一卷链接。
- source/：原文文本提取、原文身份记录、框架图重建所用的小型结构数据。文本提取不是原图的替代品，遇到冲突应以原 PDF 为准。
- qa/：分章核查、原书疑点、最终检查和构建记录。阶段性记录反映当时状态，以 release_validation.json 和最终核查为准。
- tools/：构建、验证与相关重建工具。通常直接编辑已经核对过的 .tex 图即可；重建原图数据的工具需要另行提供英文原 PDF。

## 跨卷引用

本卷内部引用、目录、书签、原书索引页码均提供链接。原书索引保留英文原版页码，但点击后转至本译本的相应内容起点，并非把原书页码当作译本页码。

第一卷引用使用其中文 PDF 的命名目标。默认文件位置是本卷目录旁的系列第一卷目录：

    ../Elements of the Representation Theory of Associative Algebras 1Techniques of Representation Theory/结合代数表示论基础 中文译本.pdf

默认路径以随包附带的、位于项目根目录的最终中文 PDF 为基准。自行编译后，若沿用此路径，应将 build/main.pdf 复制到项目根目录再阅读。

若单独分发两卷，可在 main.tex 的 input{preamble} 之前定义 VolumeOnePDF，例如：

    \newcommand{\VolumeOnePDF}{结合代数表示论基础 中文译本.pdf}

然后将第一卷 PDF 放在编译后第二卷 PDF 所在目录再编译。第一卷文件不在源码包中；缺少它不影响本卷编译与阅读，只影响跨卷跳转。实际能否从阅读器打开相对 PDF 链接还取决于阅读器支持与设置。

## 核查与原书疑点

已分开进行术语与中文检查、原 PDF 的章节及数学结构对照、编译及版面检查。数学箭图均为可编辑矢量图。终稿页数、习题和引用覆盖、命名目标、原 PDF 哈希、无缺字/未定义引用检查见 qa/release_validation.json；逐页版面证据保存在本地项目中，源码压缩包不收录大批渲染截图。

发现的原书公式、索引或题目疑点保留原文，并在适当位置加“译注”或在 qa 的 source_issues/review 记录中说明。没有把未经证明的猜测静默改入正文。例如 XII.2.15 的限制函子判据、XIII 表 3.14 的表示公式、XIV 分类证明中的若干截面列表均有需留意的原书问题。这些记录不等于一份已经认证的全书数学勘误；本次翻译核查也不等于对全书所有证明逐条重新证明。

## 压缩包范围

这是用于数译上传和继续维护的轻量源码包，附最终中文 PDF。为避免重复膨胀，不包含英文原 PDF、全部原图截图、逐页渲染、编译缓存、单章试编译产物及旧版本。所有可直接编译本卷的正文、图、文献、样式和构建入口均已保留。
