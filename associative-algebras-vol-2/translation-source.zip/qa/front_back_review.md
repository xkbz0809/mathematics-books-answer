# 前后附录独立复核

范围：frontmatter/series.tex、copyright.tex、introduction.tex；backmatter/index.tex、symbols.tex；references.bib。原 PDF 第 3、5–7、11–14、299–317、319–322 页为内容依据。原 PDF 保持不变。

## 覆盖与核对

- 丛书目录 51 条，按原 PDF 第 3 页逐项检查；保留原印本姓名拼写，不按外部知识改写原书姓名。
- 出版信息、六个 ISBN、献辞与原 PDF 第 5–7 页核对。补回原题名页的“伦敦数学会学生丛书第 71 卷”及两位作者所属的尼古拉·哥白尼大学。
- 引言原印刷 ix–xii 四页：逐段对照原文及页面图，未发现漏段；十幅 Dynkin/欧几里得图的分叉位置与顶点数已检查。
- 参考文献原 PDF 299–317 页（印刷 285–303）：284 条均存在；将原文与译稿条目分别去掉换行断词、空白、标点、重音及 LaTeX 标记后逐条比较，字母/数字全部一致。该程序不能证明标点、重音和上下标正确，因此另行检查原页面缩略图、特殊字符和数学标题，发现并修复下述问题。证据：front_bib_normalized_compare.json。
- 索引 106 行；与原书 106 条逐行比较原印刷页码序列，完全一致。证据：front_index_page_compare.json。
- 符号表 79 行；与原书 79 条逐行比较原印刷页码序列，完全一致。证据：front_symbols_page_compare.json。
- 原文献 19 页均已查看合并图；前页和索引/符号均查看原页面图。此项不是对参考文献所引外部论文的事实核实。

## 已修复的译稿或提取错误

1. 丛书作者 O. HÄGGSTRÖM、A. SKOWROŃSKI、J. VÄÄNÄÄNEN 的分离重音；最后一名按该原印本保留四个 Ä，并未用外部书目改写。
2. 丛书第 42 项题名改为“遍历理论中的平衡态”，对应 Equilibrium states in ergodic theory。
3. 文献 [71] representation-infinite、[81] Berlin-Heidelberg-New York、[104] Springer-Verlag、[146] Auslander-Reiten、[222] Basel-Boston-Berlin 的固有连字符被跨行合并丢失，已补回。
4. 文献 [199]、[200] 的类型 A_n、D_n 恢复数学下标；[198]、[201]、[203] 重音字母前因处理文字丢失的空格补回。文献题名保留原文语言。
5. 符号表 R^{alpha_1}、R^{beta_t}、R^{gamma_m} 原被写为下标；已依原 PDF 第 321 页及 XII.2 正文恢复上标。
6. 索引两处 τ-圈改为全书统一的 τ-循环；三个整二次型子条目补显父条目语境；原书并列的 Kronecker diagram / graph 两条加英文词以辨识（原条目和页码不合并）。
7. 引言 AR 示意图原印本三个标记用 A、正文用 B；译图使用 B 的做法已有明确译注，避免静默更改原书。
8. 由符号表反查原书第 21 页，X.2 的网格理想应为普通 M_C；把本代理译稿中的三处 mathcal M_C 改回 M_C，与原文及符号表一致。
9. 按根代理要求，XII.1 两处“束箭图”改为“束缚箭图”。
10. 参考文献中四个 Unicode 弯撇号及 D\ensuremath{\prime}Este 改为英语 ASCII 撇号输入，避免中文排版造成 Gabriel’ s 一类不应有的字间空隙；实际 PDF 已复核。

## 编译与版面

单独测试入口 unit_front_back.tex；使用项目实际五步构建（XeLaTeX 两次、Biber、XeLaTeX 两次）。初次尝试在新加入共享依赖 needspace.sty 缺失时中断，已报告根代理。根代理去掉该可选依赖后，实际五步构建成功；英文撇号修复后又执行 Biber + XeLaTeX 两次，全部成功。最终单元 PDF 33 页，无 LaTeX 错误、无缺字。全部 33 页已通过六张联系图查看；最终第 5、9、12、22 页另看细图确认译注位置与英文撇号。渲染文献编号逐项核对恰为 [1]–[284]，无缺号、重号、错序。两个参考文献行仅有 0.19pt / 3.69pt 轻微超宽，图上没有裁切。单元不包含正文，因此引言章节引用 ch:X–ch:XIV 未定义属于预期；正文及原页锚点的最终导航检查交由全书构建。详见 front_back_build_review.json 和 unit_front_back-build.json。

对 frontmatter 子目录单独运行通用审计脚本得到的未定义章节/文献以及缺失类标记，属于子目录不含主文件/正文/文献文件造成的范围限制，未据此修改正确链接；全书统一审计由根代理执行。
