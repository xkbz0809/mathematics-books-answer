# 核查记录导读

最终交付状态以 release_validation.json、main-build.json、final_*_review.json 为准。部分分章记录产生于单章编译阶段，页码指各自注明的单章 PDF 或整合版本，不能直接套用于最终 256 页译本。

- ch10_source_issues.json：第 X 章原书编号、指标、域/陪域等疑点。
- ch11_ch12_source_issues.json、ch12_source_issues.json：第 XI–XII 章原文疑点及保留处理。
- ch13_source_issues.md：第 XIII 章原文公式、表格与习题疑点。
- ch14_independent_review.json、ch14_frame_review.json：第 XIV 章分类图、列表及习题对照；保留原图信息。
- terminology_final_audit.json：与第一卷术语的对照及最终统一记录。
- front_back_review.md：前言、书目信息、文献、索引与符号表对照。
- final_front_x_back_review.json、final_ch11_ch12_review.json、final_ch13_review.json、final_ch14_review.json：整合版面检查及最终修改验证。
- release_validation.json：最终编号、习题数量、目录、链接、原文件身份和编译日志检查。
- main-build.json：从独立源码目录的构建步骤；如有后续局部重编译，追加记录保存于同一文件。

所有图片证据保留在本机完整项目中，轻量源码包不重复附带逐页截图。上述记录证明已执行的检查，不表示全书每个数学断言都已独立重新证明；原书疑点也不应直接视为已经定论的正式勘误。
