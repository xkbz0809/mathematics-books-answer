import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
graphs=json.loads((ROOT/'source/frame_catalog/inferred_graphs.json').read_text(encoding='utf8'))
patchpath=ROOT/'source/frame_catalog/verified_overrides.json'
patches=json.loads(patchpath.read_text(encoding='utf8')) if patchpath.exists() else {}
outdir=ROOT/'chapters/frames';outdir.mkdir(exist_ok=True)
for g in graphs:
 p=patches.get(str(g['number']),{})
 if 'edges' in p:g['edges']=p['edges']
 for n in g['nodes']:
  if str(n['id']) in p.get('positions',{}):n.update(p['positions'][str(n['id'])])
 xs=g['xs'];ys=g['ys'];scale=1.50
 s=['%% Source PDF page %d, printed %d. Editable reconstruction of frame %d.'%(g['pdf_page'],g['pdf_page']-14,g['number'])]
 anchor=g['nodes'][0]
 dots=[]
 for c in g['characters']:
  if c['c']!='.':continue
  x=c['origin'][0]+1.35;y=c['origin'][1]-.4
  if any(abs(x-a)<.7 and abs(y-b)<.7 for a,b in dots):continue
  dots.append((x,y))
 overlay=''.join(r'\fill ([xshift=%.2fpt,yshift=%.2fpt]\tikzcdmatrixname-%d-%d.center) circle[radius=.65pt];'%((x-xs[anchor['col']])*scale,-(y-ys[anchor['row']])*scale,anchor['row']+1,anchor['col']+1) for x,y in dots)
 s += [r'\begin{tikzcd}[ampersand replacement=\&,column sep={0pt,between origins},row sep={0pt,between origins},cramped,cells={nodes={inner sep=1pt}},arrows={line width=.35pt},execute at end picture={'+overlay+'}]']
 rows=[]
 for row,y in enumerate(ys):
  cells=[]
  for col,x in enumerate(xs):
   n=next((n for n in g['nodes'] if n['row']==row and n['col']==col),None)
   val=r'\scriptstyle '+n['label'] if n else '{}'
   if col:val=r'\&[%.2fpt] '%((x-xs[col-1])*scale)+val
   cells.append(val)
  line=' '.join(cells)
  if row<len(ys)-1:line+=r' \\[%.2fpt]'%((ys[row+1]-y)*scale)
  rows.append(line)
 s+=rows
 for e in g['edges']:
  if e['style']=='dotted':continue # Printed dot positions are preserved without guessing ambiguous endpoints.
  a=g['nodes'][e['a']];b=g['nodes'][e['b']]
  opts={'arrow':'','dash':',dash','dotted':',dotted,dash'}[e['style']]
  s.append(r'\arrow[from=%d-%d,to=%d-%d%s]'%(a['row']+1,a['col']+1,b['row']+1,b['col']+1,opts))
 s += [r'\end{tikzcd}','']
 (outdir/('fr%03d.tex'%g['number'])).write_text('\n'.join(s),encoding='utf8')
# One graph per output page makes source/output pairs easy to inspect.
u=[r'\documentclass{mathtranslation}',r'\input{preamble}',r'\begin{document}',r'\pagestyle{empty}']
for g in graphs:
 n=g['number'];u += [r'\begin{center}',r'\textbf{Fr %d}'%n,r'\par\vspace{5mm}',r'\input{chapters/frames/fr%03d}'%n,r'\end{center}',r'\clearpage']
u += [r'\end{document}']
(ROOT/'unit_frames.tex').write_text('\n'.join(u),encoding='utf8')
print('written',len(graphs))
