import pymupdf as f,json,io
from PIL import Image,ImageDraw
from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=json.loads((r/'source/frame_catalog/inferred_graphs.json').read_text(encoding='utf8'));d=f.open(r/'build/unit_frames.pdf');q=r/'qa/frame_pairs'
for first in range(0,len(a),6):
 canvas=Image.new('RGB',(1200,1500),'white');dr=ImageDraw.Draw(canvas)
 for pos,g in enumerate(a[first:first+6]):
  n=g['number'];p=d[n-11];words=[w for w in p.get_text('words') if w[5]!=0]
  rect=f.Rect(min(w[0] for w in words)-5,min(w[1] for w in words)-5,max(w[2] for w in words)+5,max(w[3] for w in words)+5)
  pix=p.get_pixmap(matrix=f.Matrix(4,4),clip=rect);im=Image.open(io.BytesIO(pix.tobytes('png'))).convert('RGB');im.save(q/f'out_{n:03}.png')
  src=Image.open(r/'source/frame_catalog'/f'frame_{n:03}.png').convert('RGB')
  for col,img in enumerate([src,im]):
   img.thumbnail((560,225));canvas.paste(img,(col*600+(600-img.width)//2,pos*250+20+(225-img.height)//2))
  dr.text((8,pos*250+3),f'FRAME {n}  SOURCE',fill='black');dr.text((608,pos*250+3),'RECONSTRUCTION',fill='black');dr.line((0,(pos+1)*250-1,1200,(pos+1)*250-1),fill='#999999')
 canvas.save(q/f'pairs_{a[first]["number"]:03}_{a[min(first+5,len(a)-1)]["number"]:03}.png')
print('24 source/output comparison sheets updated')
