#!/usr/bin/env bash
# Portable counterpart of build.py. Usage: bash tools/build.sh full
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:-full}"
if [[ "$mode" != "full" ]]; then
  echo "Usage: bash tools/build.sh full" >&2
  exit 2
fi
mkdir -p build
xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build main.tex
xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build main.tex
biber --input-directory=build --output-directory=build main
xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build main.tex
xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build main.tex
