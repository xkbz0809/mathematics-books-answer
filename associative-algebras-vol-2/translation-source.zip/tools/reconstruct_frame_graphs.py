"""Recover editable TikZ-CD graph data from the source's vector text glyphs.
The source remains authoritative. Inferred edges require visual comparison.
"""
import json,math,collections
from pathlib import Path
import pymupdf as fitz
ROOT=Path(__file__).resolve().parents[1]
doc=fitz.open(next(ROOT.glob('Elements*.pdf')))
RANGES={283:(11,32),284:(33,52),285:(53,78),286:(79,94),287:(95,112),288:(113,126),289:(127,138),290:(139,149)}

def clusters(vals,tol):
 out=[]
 for v in sorted(vals):
  if out and v-sum(out[-1])/len(out[-1])<=tol:out[-1].append(v)
  else:out.append([v])
 return [sum(x)/len(x) for x in out]

def data():
 output=[]
 for pn,(lo,hi) in RANGES.items():
  p=doc[pn-1]; caps=[]; chars=[]
  for b in p.get_text('rawdict')['blocks']:
   for l in b.get('lines',[]):
    for s in l['spans']:
     t=''.join(c['c'] for c in s['chars']).strip()
     if s['font']=='CMR7' and t.isdigit() and lo<=int(t)<=hi and s['origin'][1]>(65 if pn in [283,284] else 42):
      caps.append({'n':int(t),'x':s['origin'][0],'y':s['origin'][1]});continue
     for c in s['chars']:
      if c['c'].strip():chars.append(dict(c,font=s['font'],size=s['size']))
  caps.sort(key=lambda c:c['n']);assert [c['n'] for c in caps]==list(range(lo,hi+1)),(pn,caps)
  rows=[]
  for c in caps:
   if rows and abs(rows[-1][0]['y']-c['y'])<13:rows[-1].append(c)
   else:rows.append([c])
  top=65 if pn in [283,284] else 42
  for row in rows:
   bottom=max(c['y'] for c in row)-3
   cc=[c for c in chars if top<=c['origin'][1]<=bottom]
   # Locate the largest clear horizontal gaps separating adjacent figures.
   ranges=sorted((c['bbox'][0],c['bbox'][2]) for c in cc)
   united=[]
   for x0,x1 in ranges:
    if united and x0<=united[-1][1]:united[-1][1]=max(x1,united[-1][1])
    else:united.append([x0,x1])
   gaps=sorted([(united[i+1][0]-a[1],(united[i+1][0]+a[1])/2) for i,a in enumerate(united[:-1])],reverse=True)
   cuts=sorted(g[1] for g in gaps[:len(row)-1]);cuts=[0]+cuts+[1000]
   for cap,x0,x1 in zip(row,cuts,cuts[1:]):
    ccc=[c for c in cc if x0<=(c['bbox'][0]+c['bbox'][2])/2<x1]
    assert ccc,(pn,cap)
    bbox=[min(c['bbox'][0] for c in ccc),min(c['bbox'][1] for c in ccc),max(c['bbox'][2] for c in ccc),cap['y']+2]
    output.append({'number':cap['n'],'pdf_page':pn,'bbox':bbox,'characters':ccc})
   top=max(c['y'] for c in row)+2
 return output

def infer(g):
 cc=g['characters'];nodes=[]
 for c in cc:
  if c['font']=='CMR7' and c['c'].isdigit():
   nodes.append({'label':c['c'],'x':sum(c['bbox'][::2])/2,'y':c['origin'][1]-2.5})
 nodes.sort(key=lambda n:(round(n['y'],1),n['x']))
 # Baseline variations of at most a few points are TeX glyph alignment.
 xs=clusters([n['x'] for n in nodes],4.5);ys=clusters([n['y'] for n in nodes],3.0)
 for i,n in enumerate(nodes):n.update(id=i,row=min(range(len(ys)),key=lambda k:abs(ys[k]-n['y'])),col=min(range(len(xs)),key=lambda k:abs(xs[k]-n['x'])))
 assert len({(n['row'],n['col']) for n in nodes})==len(nodes),(g['number'],nodes)
 edges=[];used=set();warnings=[]
 def add(a,b,style,indices):
  if any(e['a']==a and e['b']==b and e['style']==style for e in edges):return
  edges.append(dict(a=a,b=b,style=style));used.update(indices)
 for i,a in enumerate(nodes):
  for j,b in enumerate(nodes):
   if i>=j:continue
   if a['row']==b['row'] and a['col']<b['col'] and not any(a['col']<n['col']<b['col'] and n['row']==a['row'] for n in nodes):
    inds=[k for k,c in enumerate(cc) if c['c'] in '→←—−' and abs(c['origin'][1]-a['y']-2.5)<2 and a['x']<=(c['bbox'][0]+c['bbox'][2])/2<=b['x']]
    glyphs=''.join(cc[k]['c'] for k in inds)
    if glyphs:
     if '→' in glyphs:add(i,j,'arrow',inds)
     elif '←' in glyphs:add(j,i,'arrow',inds)
     elif '—' in glyphs:add(i,j,'dash',inds)
   if a['col']==b['col'] and a['row']<b['row'] and not any(a['row']<n['row']<b['row'] and n['col']==a['col'] for n in nodes):
    inds=[k for k,c in enumerate(cc) if c['c'] in '↑↓⏐|\x1c' and abs((c['bbox'][0]+c['bbox'][2])/2-(a['x']+b['x'])/2)<3 and a['y']+2<c['origin'][1]<b['y']+3]
    glyphs=''.join(cc[k]['c'] for k in inds)
    if glyphs:
     if '↓' in glyphs:add(i,j,'arrow',inds)
     elif '↑' in glyphs or '\x1c' in glyphs:add(j,i,'arrow',inds)
     elif '|' in glyphs:add(i,j,'dash',inds)
     elif '⏐' in glyphs:
      add(i,j,'arrow',inds);warnings.append('stretched vertical arrow head absent in extracted text; visually verify downward direction %s>%s'%(i,j))
 # Diagonal arrows: use the glyph centre and closest matching node segment.
 for k,c in enumerate(cc):
  if c['c'] not in '↙↘↖↗':continue
  gx=(c['bbox'][0]+c['bbox'][2])/2;gy=c['origin'][1]-2.5
  candidates=[]
  for a in nodes:
   for b in nodes:
    dx=b['x']-a['x'];dy=b['y']-a['y'];length=math.hypot(dx,dy)
    if not length:continue
    if ('↙'==c['c'] and not(dx<0 and dy>0)) or ('↘'==c['c'] and not(dx>0 and dy>0)) or ('↖'==c['c'] and not(dx<0 and dy<0)) or ('↗'==c['c'] and not(dx>0 and dy<0)):continue
    proj=((gx-a['x'])*dx+(gy-a['y'])*dy)/length**2
    cross=abs((gx-a['x'])*dy-(gy-a['y'])*dx)/length
    if 0.10<proj<0.95 and cross<5:candidates.append((cross+length*.025,a['id'],b['id']))
  if candidates:
   _,a,b=min(candidates);add(a,b,'arrow',[k])
  else:warnings.append('unmatched diagonal '+repr(c))
 # Dotted relations, distinct from ordinary graph edges.
 dots=[(k,c['origin'][0]+1.35,c['origin'][1]-.4) for k,c in enumerate(cc) if c['c']=='.']
 # Group the printed dots before matching endpoints; one dot set is one relation.
 groups=[];pending=set(range(len(dots)))
 while pending:
  component={pending.pop()};front=list(component)
  while front:
   i=front.pop();_,x,y=dots[i]
   neighbours={j for j in pending if math.hypot(dots[j][1]-x,dots[j][2]-y)<7.5}
   pending-=neighbours;component|=neighbours;front.extend(neighbours)
  groups.append([dots[i] for i in sorted(component)])
 for group in groups:
  if len(group)<2:continue
  _,dx1,dy1=group[0];_,dx2,dy2=group[-1]
  # Max-distance pair, rather than extraction order, gives the dot-line direction.
  pair=max(((x1,y1,x2,y2) for _,x1,y1 in group for _,x2,y2 in group),key=lambda z:(z[2]-z[0])**2+(z[3]-z[1])**2)
  dx1,dy1,dx2,dy2=pair;gx=dx2-dx1;gy=dy2-dy1;gl=math.hypot(gx,gy)
  candidates=[]
  for i,a in enumerate(nodes):
   for j,b in enumerate(nodes):
    if i>=j:continue
    dx=b['x']-a['x'];dy=b['y']-a['y'];ln=math.hypot(dx,dy)
    if abs(dx*gx+dy*gy)/(ln*gl)<.80:continue
    dev=0;valid=True
    for k,x,y in group:
     cross=abs((x-a['x'])*dy-(y-a['y'])*dx)/ln
     proj=((x-a['x'])*dx+(y-a['y'])*dy)/ln**2
     if proj<-.05 or proj>1.05:valid=False
     dev+=cross
    if valid and dev/len(group)<6:candidates.append((dev/len(group)+.025*ln,i,j))
  if candidates:
   _,a,b=min(candidates);add(a,b,'dotted',[k for k,x,y in group])
  else:warnings.append('unmatched dot group '+str(group))
 unmatched=[(k,c['c'],[round(v,2) for v in c['origin']]) for k,c in enumerate(cc) if k not in used and c['c'] in '→←↑↓↙↘↖↗.|\x1c']
 g.update(nodes=nodes,edges=edges,xs=xs,ys=ys,warnings=warnings,unmatched=unmatched)
 return g

if __name__=='__main__':
 graphs=[infer(g) for g in data()]
 (ROOT/'source/frame_catalog/inferred_graphs.json').write_text(json.dumps(graphs,ensure_ascii=False,indent=2),encoding='utf8')
 for g in graphs:
  clip=fitz.Rect(g['bbox']);clip+=(-2,-2,2,2)
  doc[g['pdf_page']-1].get_pixmap(matrix=fitz.Matrix(4,4),clip=clip).save(ROOT/'source/frame_catalog'/('frame_%03d.png'%g['number']))
 print('frames',len(graphs),'nodes',sum(len(g['nodes']) for g in graphs),'edges',sum(len(g['edges']) for g in graphs))
 print('needs checks',[(g['number'],g['unmatched'],g['warnings']) for g in graphs if g['unmatched'] or g['warnings']])
