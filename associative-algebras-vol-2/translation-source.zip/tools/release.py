"""Create and validate a lean, independently buildable release from this project."""
from pathlib import Path
import re,json,hashlib,shutil,zipfile,argparse
ROOT=Path(__file__).resolve().parents[1]
STAGE=ROOT/'build'/'release_source'
PDF='结合代数表示论基础_第2卷_中文译本.pdf'
ZIP='结合代数表示论基础_第2卷_中文译本_数译上传源码包.zip'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def active():
 out=set()
 def visit(p):
  if p in out:return
  if not p.is_file():raise FileNotFoundError(p)
  out.add(p)
  s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text(encoding='utf-8'))
  for a in re.findall(r'\\input\{([^}]+)\}',s):visit(ROOT/(a if Path(a).suffix else a+'.tex'))
 visit(ROOT/'main.tex');return out
parser=argparse.ArgumentParser();parser.add_argument('action',choices=['stage','pack']);args=parser.parse_args()
if args.action=='stage':
 STAGE.mkdir(parents=True,exist_ok=False)
 paths=active()|{ROOT/x for x in ['mathtranslation.cls','logo.pdf','references.bib','glossary.tsv','README.md']}
 paths.update((ROOT/'tools').glob('*.py'));paths.add(ROOT/'tools/build.sh')
 paths.update((ROOT/'source').glob('*.txt'));paths.update((ROOT/'source/pages').glob('*.txt'));paths.add(ROOT/'source/manifest.json')
 for n in ['inferred_graphs.json','verified_overrides.json']:paths.add(ROOT/'source/frame_catalog'/n)
 for p in sorted(paths):
  rel=p.relative_to(ROOT);q=STAGE/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 print(json.dumps({'stage':str(STAGE),'source_files':len(paths),'uncompressed_bytes':sum(p.stat().st_size for p in paths)},ensure_ascii=False))
else:
 built=STAGE/'build/main.pdf'
 if not built.exists():raise FileNotFoundError(built)
 shutil.copy2(built,ROOT/PDF);shutil.copy2(built,STAGE/PDF)
 qa=STAGE/'qa';qa.mkdir(exist_ok=True)
 for p in (ROOT/'qa').iterdir():
  if p.suffix in ['.json','.md'] and not p.name.startswith('unit_'):
   shutil.copy2(p,qa/p.name)
 for p in [ROOT/'source/manifest.json',ROOT/'README.md']:
  shutil.copy2(p,STAGE/p.relative_to(ROOT))
 files=[p for p in STAGE.rglob('*') if p.is_file() and 'build' not in p.relative_to(STAGE).parts and '__pycache__' not in p.relative_to(STAGE).parts]
 manifest={'source_files':{p.relative_to(STAGE).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in files},'pdf_sha256':sha(built),'excluded':['English original PDF','rendered QA screenshots','compilation caches','unit test documents','previous editions'],'build':'python -B tools/build.py main'}
 (STAGE/'package_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');files.append(STAGE/'package_manifest.json')
 target=ROOT/ZIP
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(files):z.write(p,p.relative_to(STAGE).as_posix())
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  assert len(z.namelist())==len(set(z.namelist()))
  for n in z.namelist():assert not n.startswith(('/','\\')) and '..' not in Path(n).parts
  for n,item in manifest['source_files'].items():assert hashlib.sha256(z.read(n)).hexdigest()==item['sha256']
 result={'archive':ZIP,'archive_bytes':target.stat().st_size,'archive_sha256':sha(target),'entries':len(files),'pdf':PDF,'pdf_bytes':built.stat().st_size,'pdf_sha256':sha(built),'crc':'passed','archive_source_and_standalone_build_source_match':True}
 (ROOT/'qa/archive_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
