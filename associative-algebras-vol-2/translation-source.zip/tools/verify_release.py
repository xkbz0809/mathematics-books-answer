"""Check final PDF, references, source identity and structural coverage."""
from pathlib import Path
import re,json,hashlib,argparse,collections
import pymupdf
ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--out-dir',default='build');args=parser.parse_args();out=ROOT/args.out_dir
errors=[]
def check(value,message):
 if not value:errors.append(message)
def group(s,pos):
 assert s[pos]=='{';start=pos+1;depth=1;pos+=1
 while depth:
  if s[pos]=='{' and s[pos-1]!='\\':depth+=1
  if s[pos]=='}' and s[pos-1]!='\\':depth-=1
  pos+=1
 return s[start:pos-1],pos
files=set()
def visit(p):
 if p in files:return
 files.add(p);s=re.sub(r'(?<!\\)%[^\n]*','',p.read_text(encoding='utf-8'))
 for n in re.findall(r'\\input\{([^}]+)\}',s):visit(ROOT/(n if Path(n).suffix else n+'.tex'))
visit(ROOT/'main.tex');texts={p:p.read_text(encoding='utf-8') for p in files};alltex='\n'.join(texts.values())
aux=(out/'main.aux').read_text(encoding='utf-8');labs={}
for m in re.finditer(r'\\newlabel\{',aux):
 name,pos=group(aux,m.end()-1);body,pos=group(aux,pos);vals=[];i=0
 while i<len(body) and body[i]=='{':val,i=group(body,i);vals.append(val)
 labs[name]=vals
numeric={k:v for k,v in labs.items() if re.fullmatch(r'(?:X|XI|XII|XIII|XIV):\d+\.\d+[a-z]?',k)}
for k,v in numeric.items():check(k.split(':')[1]==v[0].strip('{}'),'numeric label '+k+'='+v[0])
counts={c:len([k for k in labs if re.fullmatch(c+r':ex\d+',k)]) for c in ['X','XI','XII','XIII','XIV']}
check(list(counts.values())==[8,10,14,13,16],'exercise count')
for c,n in counts.items():
 for i in range(1,n+1):check(labs.get(f'{c}:ex{i}',[''])[0].strip('{}')==str(i),f'exercise value {c}:{i}')
labels=re.findall(r'\\label\{([^}]+)\}',alltex);dups=[x for x,n in collections.Counter(labels).items() if n>1];check(not dups,'duplicate labels '+str(dups))
refs=re.findall(r'\\(?:eqref|ref|pageref|autoref)\*?\{([^}]+)\}',alltex)+[b for a,b in re.findall(r'\\chapter(?:eq)?ref\{([^}]+)\}\{([^}]+)\}',alltex)]
missing=sorted(set(x for x in refs if x not in labs and '#' not in x));check(not missing,'undefined source references '+str(missing))
anchors=[int(n) for n in re.findall(r'\\sourcepage\{(\d+)\}',alltex)];ac=collections.Counter(anchors);check(all(ac[i]==1 for i in range(1,285)),'source page anchor coverage')
d=pymupdf.open(out/'main.pdf');names=d.resolve_names();check(all('sourcepage:'+str(i) in names for i in range(1,285)),'PDF sourcepage destinations')
links=[l for p in d for l in p.get_links()];badlinks=[l for l in links if l.get('kind') in (pymupdf.LINK_GOTO,pymupdf.LINK_NAMED) and 'page' in l and not 0<=l.get('page',-1)<len(d)];check(not badlinks,'invalid internal links')
remote=[]
for l in links:
 if d.xref_get_key(l['xref'],'A/S')[1]=='/GoToR':
  remote.append({'file':d.xref_get_key(l['xref'],'A/F')[1],'destination':d.xref_get_key(l['xref'],'A/D')[1]})
v1path=ROOT.parent/'Elements of the Representation Theory of Associative Algebras 1Techniques of Representation Theory'/'结合代数表示论基础 中文译本.pdf'
remote_errors=[]
if v1path.exists():
 v1=pymupdf.open(v1path);v1names=v1.resolve_names()
 for l in remote:
  if l['destination'] not in v1names:remote_errors.append(l)
 check(not remote_errors,'Volume1 destinations missing')
 check(all((ROOT/l['file']).resolve()==v1path.resolve() for l in remote),'Volume1 relative path mismatch')
check(len(remote)==251,'Volume1 reference coverage')
headings=[]
for p,s in texts.items():
 for env,key in re.findall(r'\\begin\{(definition|lemma|theorem|corollary|proposition|remark|example|notation)\}\s*\\label\{([^}]+)\}',s):
  if key not in labs:errors.append('missing statement '+key);continue
  label,page,_,dest,*_=labs[key];target=names.get(dest)
  check(target is not None,'missing statement destination '+key)
  if target:
   text=re.sub(r'\s+','',d[target['page']].get_text());cn={'definition':'定义','lemma':'引理','theorem':'定理','corollary':'推论','proposition':'命题','remark':'注','example':'例','notation':'记号'}[env]
   check(cn+label in text,'rendered number absent '+key);headings.append(key)
bib_text='\n'.join(p.get_text() for p in d if p.number>=next(x[2]-1 for x in d.get_toc() if x[1]=='参考文献'))
bibnums=[int(n) for n in re.findall(r'^\[(\d+)\]',bib_text,re.M)];check(bibnums==list(range(1,285)),'rendered bibliography sequence')
log=(out/'main.log').read_text(encoding='utf-8',errors='replace');badlog=[l for l in log.splitlines() if any(k in l for k in ['Undefined control sequence','undefined references','Missing character:','multiply defined','Rerun to get','LaTeX Error']) or ('Citation ' in l and 'undefined' in l)]
check(not badlog,'log defects '+str(badlog));overfull=[l for l in log.splitlines() if 'Overfull' in l]
frames=sorted((ROOT/'chapters/frames').glob('fr*.tex'));check(len(frames)==149,'frame count')
manifest=json.loads((ROOT/'source/manifest.json').read_text(encoding='utf-8'));original=ROOT/manifest['source_file'];sourcehash=None
if original.exists():sourcehash=hashlib.sha256(original.read_bytes()).hexdigest();check(sourcehash==manifest['sha256'],'original source changed')
rendered_exercises=[]
for c,n in counts.items():
 for i in range(1,n+1):
  key=f'{c}:ex{i}';target=names.get(labs[key][3]);check(target is not None,'exercise destination '+key)
  if target:
   txt=d[target['page']].get_text();check(re.search(r'(?m)^\s*'+str(i)+r'\.',txt) is not None,'rendered exercise '+key);rendered_exercises.append(key)
check(len(d.get_toc())==37,'outline count');check(d.get_toc()[-1][1]=='术语索引','terminology is last')
result={'pdf_pages':len(d),'pdf_sha256':hashlib.sha256((out/'main.pdf').read_bytes()).hexdigest(),'active_tex_files':len(files),'numeric_labels_checked':len(numeric),'rendered_statement_numbers_checked':len(headings),'exercise_counts':counts,'exercise_total':sum(counts.values()),'rendered_exercise_numbers_checked':len(rendered_exercises),'source_page_anchors':284,'frame_diagrams':149,'bibliography_entries':len(bibnums),'outline_entries':len(d.get_toc()),'link_annotations':len(links),'volume1_remote_links':len(remote),'volume1_unique_destinations':len(set(x['destination'] for x in remote)),'volume1_target_errors':remote_errors,'internal_links':sum(l.get('kind') in (pymupdf.LINK_GOTO,pymupdf.LINK_NAMED) and 'page' in l for l in links),'invalid_internal_links':len(badlinks),'undefined_source_references':missing,'duplicate_labels':dups,'overfull_warnings':overfull,'overfull_review':'Two bibliography lines, 0.18788pt and 3.68909pt, visually checked; no clipping.','source_hash_verified':sourcehash,'source_manifest_hash':manifest['sha256'],'errors':errors,'passed':not errors,'verification_scope':'Compilation, rendered numbering, structural completeness, link integrity and source identity. Does not independently prove every mathematical assertion.'}
(ROOT/'qa').mkdir(exist_ok=True);(ROOT/'qa/release_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
