# LaTeX源文件

入口：main.tex。使用XeLaTeX，已在本机TeX Live 2026验证。中文字体采用模板的Fandol配置，图形使用tikz-cd。无需联网取图片。

Windows PowerShell进入本目录后执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

脚本连续编译三遍以更新目录、引用和术语索引，结果位于build/main.pdf。脚本把临时文件放在本目录build下，与本次成功编译设置一致。

逐块追溯：各章节LaTeX含 SOURCE chNN-NNNN 注释，可与中文Markdown或校核记录对照。相同编号对应原始Markdown的文本/公式块。原书错误、疑点或约定以正文审校注区别说明，参见上级目录的第二轮数学审校记录。
