﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$buildDir = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
$env:TEMP = $buildDir
$env:TMP = $buildDir
for ($pass = 1; $pass -le 3; $pass++) {
  & xelatex -interaction=nonstopmode -halt-on-error -output-directory=build main.tex
  if ($LASTEXITCODE -ne 0) { throw "XeLaTeX failed in pass $pass. See build/main.log." }
}
Write-Host 'Created build/main.pdf'
