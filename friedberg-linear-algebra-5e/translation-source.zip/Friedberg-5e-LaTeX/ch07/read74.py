from pathlib import Path
import pymupdf as f
from PIL import Image
w=Path(__file__).resolve().parents[1]
doc=f.open(w.parent/'Friedberg et al. - 2018 - Linear algebra.pdf')
dest=w/'ch07/recovery74'
dest.mkdir(exist_ok=True)
for i in range(517,542):
    p=doc[i+12]
    (dest/f'p{i}.txt').write_text(p.get_text(sort=True),encoding='utf-8')
    pix=p.get_pixmap(matrix=f.Matrix(1.75,1.75),alpha=False)
    pix.save(dest/f'p{i}.png')
print('Ready')
