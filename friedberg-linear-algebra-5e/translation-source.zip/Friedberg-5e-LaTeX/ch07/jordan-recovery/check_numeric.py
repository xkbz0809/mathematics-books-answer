"""Exact integer checks for §7.2 (4,5) and §7.3 (2,3)."""
from itertools import permutations
def matmul(A, B):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def det(A):
    if not A:
        return 1
    return sum((-1)**j*a*det([r[:j]+r[j+1:] for r in A[1:]]) for j,a in enumerate(A[0]))
def minus(A,B):
    return [[x-y for x,y in zip(u,v)] for u,v in zip(A,B)]
def trans(A):
    return [list(r) for r in zip(*A)]
def scaled(A,c):
    return [[c*x for x in u] for u in A]
As = [[[-3,3,-2],[-7,6,-3],[1,-1,2]], [[0,1,-1],[-4,4,-2],[-2,1,1]], [[0,-1,-1],[-3,-1,-2],[7,5,6]], [[0,-3,1,2],[-2,1,-1,2],[-2,1,-1,2],[-2,-3,1,4]]]
Qs=[[[1,1,1],[2,1,2],[1,-1,0]],[[1,1,0],[2,2,1],[1,0,1]],[[0,1,0],[1,1,1],[-1,-3,-2]],[[1,0,1,-1],[1,-1,0,1],[1,-2,0,1],[1,0,1,0]]]
Js=[[[1,0,0],[0,2,1],[0,0,2]],[[1,0,0],[0,2,0],[0,0,2]],[[1,0,0],[0,2,1],[0,0,2]],[[0,1,0,0],[0,0,0,0],[0,0,2,0],[0,0,0,2]]]
for A,Q,J,d in zip(As,Qs,Js,[1,1,1,-1]):
    assert matmul(A,Q)==matmul(Q,J) and det(Q)==d, (Q,J)
M=[[3,1],[0,3]]
def Td(A):
    return minus(matmul(M,A),trans(A))
X,Y,Z,W=[[1,0],[0,0]],[[0,1],[1,0]],[[0,-1],[0,2]],[[1,-2],[2,0]]
for A,B in [(X,[[0,0],[0,0]]),(Y,X),(Z,Y)]:
    assert minus(Td(A),scaled(A,2)) == B
assert Td(W)==scaled(W,4)
H=[[-1,3],[-3,0]]
assert matmul(M,minus(H,trans(H)))==scaled(H,6)
A=[[4,-14,5],[1,-4,2],[1,-6,4]]
I=[[1,0,0],[0,1,0],[0,0,1]]
N=minus(A,I); K=minus(A,scaled(I,2))
assert det([r[:2] for r in N[:2]])==-1 and matmul(matmul(N,N),K)==scaled(I,0)
assert matmul(N,K)!=scaled(I,0)
A=[[3,0,1],[2,2,2],[-1,0,1]]
N=minus(A,scaled(I,2))
assert N!=scaled(I,0) and matmul(N,N)==scaled(I,0)
print("7.2 (4a-d) AQ=QJ and determinants, (5d-e) chains, 7.3 (2c-d) polynomials: exact checks passed")
