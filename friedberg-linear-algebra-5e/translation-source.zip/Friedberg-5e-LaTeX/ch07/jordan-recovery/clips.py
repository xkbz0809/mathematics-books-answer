from pathlib import Path
from PIL import Image
d=Path("work/ch07/jordan-recovery")
for page,box,label in [(503,(.08,.69,.95,.98),'4'),(504,(.06,.04,.97,.54),'5'),(515,(.08,.60,.96,.98),'2'),(507,(.06,.20,.97,.64),'19'),(516,(.08,.56,.97,.85),'12'),(512,(.06,.055,.96,.20),'3'),(490,(.08,.67,.97,.97),'14')]:
 im=Image.open(d/f'p{page}.png'); print(page,im.size)
 wi,he=im.size
 im.crop(tuple(round((wi,he)[i%2]*x) for i,x in enumerate(box))).convert("L").save(d/f'clip{page}_{label}.png')
