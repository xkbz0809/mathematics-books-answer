"""Exact integral checks of the companion matrices in section 7.4."""


def columns(*vectors):
    return list(map(list, zip(*vectors)))


def multiply(a, b):
    return [[sum(x*y for x, y in zip(row, col)) for col in zip(*b)] for row in a]


def power_column(a, v, size):
    result = []
    for _ in range(size):
        result.append(v)
        v = [sum(x*y for x, y in zip(row, v)) for row in a]
    return result


def determinant(a):
    if not a:
        return 1
    return sum((-1)**j * n * determinant([r[:j] + r[j+1:] for r in a[1:]])
               for j, n in enumerate(a[0]))


def companion(low):
    n = len(low)
    return [[-low[i] if j == n-1 else int(i == j+1) for j in range(n)] for i in range(n)]


def block(*matrices):
    size = sum(map(len, matrices))
    answer = [[0]*size for _ in range(size)]
    i = 0
    for matrix in matrices:
        for j, row in enumerate(matrix):
            answer[i+j][i:i+len(row)] = row
        i += len(matrix)
    return answer


def certify(label, a, q, c):
    d = determinant(q)
    assert d != 0 and multiply(a,q) == multiply(q,c), label
    print(label, 'det(Q) =', d, 'AQ-QC = 0')


i4 = [[int(i==j) for j in range(4)] for i in range(4)]
cy4 = companion([1,0,2,0])
a = [[3,1,0],[0,3,1],[0,0,3]]
certify('2a', a, columns(*power_column(a,[0,0,1],3)), companion([-27,27,-9]))
a = [[0,-1],[1,-1]]
certify('2b', a, [[1,0],[0,1]], companion([1,1]))
# 2c is checked symbolically with lambda^2+lambda+1=0.
a = [[0,-7,14,-6],[1,-4,6,-3],[0,-4,9,-4],[0,-4,11,-5]]
certify('2d',a,columns(*power_column(a,[1,0,0,0],4)),cy4)
a = [[0,-4,12,-7],[1,-1,3,-3],[0,-1,6,-4],[0,-1,8,-5]]
q = [[1,1,2,1],[1,0,1,1],[1,1,1,1],[1,2,1,2]]
certify('2e',a,q,block(companion([2,0]),companion([3,0])))
a = [[0,-1,-2,-3],[1,0,0,0],[0,0,0,0],[0,0,0,0]]
q = columns([1,0,0,0],[0,1,0,0],[0,-2,1,0],[0,-3,0,1])
certify('3a + E055',a,q,block(companion([1,0]),companion([0]),companion([0])))
a = [[0,-1,1,0],[1,0,0,1],[0,0,0,-1],[0,0,1,0]]
certify('3b',a,columns(*power_column(a,[0,0,1,0],4)),cy4)
m = [[0,1],[-1,1]]
q = [[(-1 if i%2 else 1)*int(i==j) for j in range(4)] for i in range(4)]
certify('3c',block(m,m),q,block(companion([1,-1]),companion([1,-1])))
a = [[0,-1,-1,0],[1,0,0,-1],[1,0,0,-1],[0,1,1,0]]
q = columns([-1,0,0,1],[0,-2,-2,0],[1,0,0,1],[0,1,-1,0])
certify('3d',a,q,block(companion([4,0]),companion([0]),companion([0])))
a = [[1,2,1,0],[-2,1,0,1],[0,0,1,2],[0,0,-2,1]]
certify('Example 4',a,columns(*power_column(a,[0,0,1,0],4)),companion([25,-20,14,-4]))
a = [[0,2,0,-6,2],[1,-2,0,0,2],[1,0,1,-3,2],[1,-2,1,-1,2],[1,-4,3,-3,4]]
q = [[1,0,0,2,0],[0,1,1,-2,1],[0,1,0,0,1],[0,1,0,-2,1],[0,1,0,-4,2]]
certify('Example 5',a,q,block(companion([2,0]),companion([2,0]),companion([-2])))
a = [[2,1,0,0],[0,2,1,0],[0,0,2,0],[0,0,0,2]]
certify('Example 6',a,[[0,0,1,0],[0,1,4,0],[1,2,4,0],[0,0,0,1]],block(companion([-8,12,-6]),companion([-2])))
