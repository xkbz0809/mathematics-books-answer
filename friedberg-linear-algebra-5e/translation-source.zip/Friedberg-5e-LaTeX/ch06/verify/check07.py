from numpy import array, eye, sqrt
from numpy.linalg import norm, pinv
from numpy.testing import assert_allclose

def columns(*vectors):
    return array([array(v)/norm(v) for v in vectors]).T

samples = [
    ([[1,1],[1,1],[-1,-1]], [(1,1,-1),(1,-1,0),(1,1,2)], [(1,1),(1,-1)], [sqrt(6)], [[1,1,-1],[1,1,-1]],6),
    ([[1,0,1],[1,0,-1]], [(1,1),(1,-1)],[(1,0,0),(0,0,1),(0,1,0)], [sqrt(2),sqrt(2)], [[1,1],[0,0],[1,-1]],2),
    ([[1,1],[0,1],[1,0],[1,1]],[(2,1,1,2),(0,-1,1,0),(1,0,0,-1),(1,-2,-2,1)], [(1,1),(1,-1)], [sqrt(5),1], [[1,-2,3,1],[1,3,-2,1]],5),
    ([[1,1,1],[1,-1,0],[1,0,-1]],[(1,1,1),(2,-1,-1),(0,-1,1)],[(1,0,0),(0,1,1),(0,1,-1)], [sqrt(3),sqrt(3),1], [[1,1,1],[1,-2,1],[1,1,-2]],3),
    ([[1+1j,1],[1-1j,-1j]], [(1,-1j),(-1j,1)], [(1-1j,1),(1,-1-1j)], [sqrt(6)], [[1-1j,1+1j],[1,1j]],6),
    ([[1,1,1,1],[1,0,-2,1],[1,-1,1,1]],[(1,1,1),(1,-2,1),(1,0,-1)],[(1,0,0,1),(0,0,1,0),(0,1,0,0),(1,0,0,-1)], [sqrt(6),sqrt(6),sqrt(2)], [[1,1,1],[3,0,-3],[1,-2,1],[1,1,1]],6),
]
for raw,u,v,sv,answer,den in samples:
    a=array(raw)
    l=columns(*u)
    h=columns(*v)
    assert_allclose(l.conj().T@l,eye(l.shape[1]),atol=1e-12)
    assert_allclose(h.conj().T@h,eye(h.shape[1]),atol=1e-12)
    sigma=0*a.copy().astype(complex)
    for i,value in enumerate(sv): sigma[i,i]=value
    assert_allclose(l@sigma@h.conj().T,a,atol=1e-12)
    assert_allclose(pinv(a),array(answer)/den,atol=1e-12)
print("6 decompositions, 12 bases, and 6 pseudoinverses verified.")
