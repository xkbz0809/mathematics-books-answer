from numpy import array, diag, sqrt, eye
from numpy.testing import assert_allclose

def congruent(a,q,d):
    a,q=array(a),array(q)
    assert_allclose(q.T@a@q,d,atol=1e-11)

a6=[[1,-1,3],[-1,2,1],[3,1,1]]
congruent(a6,[[1,1,-7],[0,1,-4],[0,0,1]],diag([1,1,-24]))
congruent([[1,2,1],[2,3,2],[1,2,1]],[[1,-2,-1],[0,1,0],[0,0,1]],diag([1,-1,0]))
congruent([[1,0,1],[0,1,2],[1,2,1]],[[1,0,-1],[0,1,-2],[0,0,1]],diag([1,1,-4]))
q=array([[1,3,-3],[0,5,2],[3,-1,1]])/sqrt([10,35,14])
congruent([[2,3,0],[3,5,-1],[0,-1,2]],q,diag([2,7,0]))
assert_allclose(array([3,-2,-1])@q,[0,0,-sqrt(14)],atol=1e-12)
congruent([[1,-2,0],[1,0,0],[0,0,-1]],[[1,1,0],[0,0,1],[1,-1,0]],[[0,2,-2],[2,0,-2],[1,1,0]])
congruent([[-2,2],[2,1]],array([[1,-2],[2,1]])/sqrt(5),diag([2,-3]))
congruent([[7,-4],[-4,1]],array([[2,1],[-1,2]])/sqrt(5),diag([9,-1]))
congruent([[3,0,-1],[0,3,0],[-1,0,3]],array([[1,0,1],[0,1,0],[1,0,-1]])/sqrt([2,1,2]),diag([2,3,4]))
congruent([[1,3],[3,2]],[[1,-3],[0,1]],diag([1,-7]))
congruent([[0,1],[1,0]],[[1,1],[1,-1]],diag([2,-2]))
congruent([[3,1,2],[1,4,0],[2,0,-1]],[[1,-1,-8],[0,3,2],[0,0,11]],diag([3,33,-297]))
print("11 congruences, quadrics, and degeneracy checks passed.")
