"""Exact checks of operators, counterexamples and numerical answers on restored pages."""
from fractions import Fraction as Q

def matvec(rows,v):
    return tuple(sum(a*b for a,b in zip(row,v)) for row in rows)

def dot(u,v):
    return sum(a*b for a,b in zip(u,v))

def image(poly):
    # Ascending coefficients in 1,x,x^2,x^3.  T(f)=f(0)x-f'(1).
    return (-sum(i*c for i,c in enumerate(poly)),poly[0],0,0)

basis=[(1,0,0,0),(0,1,0,0),(0,-2,1,0),(0,-3,0,1)]
zero4=(0,0,0,0)
assert [image(v) for v in basis]==[basis[1],(-1,0,0,0),zero4,zero4]
# Each successive basis polynomial has leading coefficient 1 and increasing degree.
assert all(v[i]==1 and all(k==0 for k in v[i+1:]) for i,v in enumerate(basis))
e1,e2,e3=(1,0,0),(0,1,0),(0,0,1)
J=[(0,1,0),(0,0,1),(0,0,0)]
w2=tuple(a+b for a,b in zip(e1,e2))
assert matvec(J,e3)==e2 and matvec(J,w2)==e1
assert w2!=e1 and w2!=e2 and tuple(a+b-c for a,b,c in zip(e1,e2,w2))==(0,0,0)
J2=[(0,1),(0,0)]
assert matvec(J2,(0,1))==(1,0) and matvec(J2,(1,0))==(0,0)
A=[(1j,1),(1,-1j)]
assert tuple(zip(*A))==tuple(A)
assert all(matvec(A,col)==(0,0) for col in zip(*A)) and A[0][1]==1
row=(1,2,-1)
a=tuple(Q(12)*c/dot(row,row) for c in row)
assert a==(2,4,-2) and dot(row,a)==12
B=[(1,2,-1),(2,3,1),(4,7,-1)]
v=tuple(Q(k,7) for k in (2,3,1))
assert matvec(B,v)==(1,2,4) and dot(row,v)==1
# The third row is twice the first plus the second. The first two are independent.
assert B[2]==tuple(2*x+y for x,y in zip(B[0],B[1]))
kernel=(5,-3,-1)
assert matvec(B,kernel)==(0,0,0) and dot(v,kernel)==0
print('E055, E088, E099, E100 and E102 passed the independent exact checks.')
