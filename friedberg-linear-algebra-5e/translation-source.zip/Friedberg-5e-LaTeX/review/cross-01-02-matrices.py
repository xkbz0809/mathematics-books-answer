"""Independent exact checks from print pp. 33–34, 55–56, 85, 97, 117–118 and 124–125."""
from fractions import Fraction as F
from itertools import permutations
from pathlib import Path
import re

WORK = Path(__file__).resolve().parents[1]


def check(actual, expected, label):
    assert actual == expected, (label, actual, expected)
    print(f"{label}: OK")


def determinant(matrix):
    n = len(matrix)
    total = 0
    for perm in permutations(range(n)):
        inversions = sum(perm[i] > perm[j] for i in range(n) for j in range(i+1, n))
        term = (-1) ** inversions
        for row, col in enumerate(perm):
            term *= matrix[row][col]
        total += term
    return total


def rows(*vectors):
    return [list(v) for v in zip(*vectors)]


def multiply(left, right):
    return [[sum(a*b for a,b in zip(row,col,strict=True)) for col in zip(*right)] for row in left]


def rank(matrix):
    reduced = [[F(n) for n in row] for row in matrix]
    pivot = 0
    for j in range(len(reduced[0])):
        found = next((i for i in range(pivot,len(reduced)) if reduced[i][j]),None)
        if found is None:
            continue
        reduced[pivot],reduced[found] = reduced[found],reduced[pivot]
        numerator = reduced[pivot][j]
        reduced[pivot] = [n/numerator for n in reduced[pivot]]
        for i,row in enumerate(reduced):
            if i != pivot:
                reduced[i] = [a-row[j]*b for a,b in zip(row,reduced[pivot])]
        pivot += 1
    return pivot


def affine(label, matrix, rhs, initial, directions):
    if initial is None:
        check(rank(matrix)+1,rank([r+[b] for r,b in zip(matrix,rhs)]),label)
        return
    check(multiply(matrix,rows(initial)),rows(rhs),label+" particular")
    for k,v in enumerate(directions,1):
        check(multiply(matrix,rows(v)),rows([0]*len(rhs)),label+f" kernel {k}")
    check(rank(matrix)+len(directions),len(initial),label+" dimension")
    if directions:
        check(rank(directions),len(directions),label+" free variables")


affine("1.4.2a", [[2,-2,-3,0],[3,-3,-2,5],[1,-1,-2,-1]],[-2,7,-3],[5,0,4,0],[[1,1,0,0],[-3,0,-2,1]])
affine("1.4.2b", [[3,-7,4],[1,-2,1],[2,-1,-2]],[10,3,6],[-2,-4,-3],[])
affine("1.4.2c", [[1,2,-1,1],[1,4,-3,-3],[2,3,-1,4]],[5,6,8],None,[])
affine("1.4.2d", [[1,2,2,0],[1,0,8,5],[1,1,5,5]],[2,-6,3],[-16,9,0,2],[[-8,3,1,0]])
affine("1.4.2e", [[1,2,-4,-1,1],[-1,0,10,-3,-4],[2,5,-5,-4,-1],[4,11,-7,-10,-2]],[7,-16,2,7],[-4,3,0,0,5],[[10,-3,1,0,0],[-3,2,0,1,0]])
affine("1.4.2f", [[1,2,6],[2,1,1],[3,1,-1],[1,3,10]],[-1,8,15,-5],[3,4,-2],[])

linear = [
    [(1,0,-1),(2,5,1),(0,-4,3)], [(2,-4,1),(0,3,-1),(6,0,-1)],
    [(1,2,-1),(1,0,2),(2,1,1)],[(-1,3,1),(2,-4,-3),(-3,8,2)],
    [(1,-3,-2),(-3,1,3),(-2,-10,-2)]]
poly = [
    [(-1,-1,2),(2,1,-2),(1,-2,4)],[(1,2,1),(3,0,1),(0,1,1)],
    [(1,-2,-2),(-2,3,-1),(1,-1,6)],[(-1,2,4),(3,-4,-10),(-2,-5,-6)],
    [(1,2,-1),(4,-2,1),(-1,18,-9)]]
check([determinant(rows(*v)) for v in linear],[27,0,3,3,0],"1.6.2a-e")
check([determinant(rows(*v)) for v in poly],[0,-4,-3,10,0],"1.6.3a-e")
check(determinant(rows((2,-3,1),(1,4,-2),(-3,-5,8))),57,"1.6.7")
check(determinant(rows((2,-3,4,-5),(3,-2,7,-9),(-1,1,2,1),(1,0,-2,3))),93,"1.6.8")
for label, coefficients, points, values in [
    ("a",[8,-1,-4],[-2,-1,1],[-6,5,3]),("b",[12,-3],[-4,1,3],[24,9,3]),
    ("c",[-5,4,2,-1],[-2,-1,1,3],[3,-6,0,-2]),
    ("d",[15,-6,-1,2],[-3,-2,0,1],[-30,7,15,10])]:
    check([sum(c*x**i for i,c in enumerate(coefficients)) for x in points],values,"1.6.10"+label)

basis=rows((1,1,0),(0,1,1),(2,2,3))
std=rows((1,1,2),(-1,0,1))
check(multiply(basis,[[F(-1,3),-1],[0,1],[F(2,3),0]]),std,"2.2.3 standard")
check(multiply(basis,[[F(-7,3),F(-11,3)],[2,3],[F(2,3),F(4,3)]]),multiply(std,[[1,2],[2,3]]),"2.2.3 nonstandard")

A,B,C,D=[[1,3],[2,-1]],[[1,0,-3],[4,1,2]],[[1,1,4],[-1,-2,0]],rows([2,-2,3])
check(multiply(A,[[2*b+3*c for b,c in zip(br,cr)] for br,cr in zip(B,C)]),[[20,-9,18],[5,10,8]],"2.3.2a distributed")
check(multiply(multiply(A,B),D),[[29],[-26]],"2.3.2a left")
check(multiply(A,multiply(B,D)),[[29],[-26]],"2.3.2a right")
A,B,C=[[2,5],[-3,1],[4,2]],[[3,-2,0],[1,-1,4],[5,5,3]],[[4,0,3]]
check(multiply(rows(*A),B),[[23,19,0],[26,-1,10]],"2.3.2b transpose product")
check(multiply(B,rows(*C)),[[12],[16],[29]],"2.3.2b column")
check(multiply(C,B),[[27,7,9]],"2.3.2b row")
check(multiply(C,A),[[20,26]],"2.3.2b CA")

base_changes=[
    ("2.5.2b",[[-1,2],[3,-1]],[[4,1],[2,3]],[[0,5],[10,0]]),
    ("2.5.2c",[[2,-1],[5,-3]],[[3,-1],[5,-2]],[[1,0],[0,1]]),
    ("2.5.2d",[[-4,2],[3,-1]],[[2,-1],[5,-4]],[[2,-4],[1,1]]),
    ("2.5.3c",[[0,1,0],[-1,0,0],[2,3,1]],[[0,-1,0],[1,0,0],[-3,2,1]],[[1,0,0],[0,1,0],[0,0,1]]),
    ("2.5.3d",[[1,1,1],[-1,1,0],[1,0,1]],[[2,1,1],[3,-2,1],[-1,3,1]],[[4,2,3],[1,-3,0],[1,4,2]]),
    ("2.5.3e",[[0,1,-1],[-1,0,1],[1,1,0]],[[5,-6,3],[0,4,-1],[3,-1,2]],[[-3,5,-3],[-2,5,-1],[5,-2,2]]),
    ("2.5.3f",[[1,-2,1],[-1,3,2],[2,1,-1]],[[-2,1,2],[3,4,1],[-1,5,2]],[[-9,-2,2],[9,21,5],[0,1,3]])]
for label,B,Q,C in base_changes:
    check(multiply(B,Q),C,label)
operators=[
    ("2.5.4",[[2,1],[1,-3]],[[1,1],[1,2]],[[8,13],[-5,-9]]),
    ("2.5.5",[[0,1],[0,0]],[[1,1],[1,-1]],[[F(1,2),F(-1,2)],[F(1,2),F(-1,2)]]),
    ("2.5.6a",[[1,3],[1,1]],[[1,1],[1,2]],[[6,11],[-2,-4]]),
    ("2.5.6b",[[1,2],[2,1]],[[1,1],[1,-1]],[[3,0],[0,-1]]),
    ("2.5.6c",[[1,1,-1],[2,0,1],[1,1,0]],[[1,1,1],[1,0,1],[1,1,2]],[[2,2,2],[-2,-3,-4],[1,1,2]]),
    ("2.5.6d",[[13,1,4],[1,13,4],[4,4,10]],[[1,1,1],[1,-1,1],[-2,0,1]],[[6,0,0],[0,12,0],[0,0,18]])]
for label,A,Q,C in operators:
    check(multiply(A,Q),multiply(Q,C),label)
check(multiply([[1,-2,0],[1,1,1],[0,1,-3]],[[4,6,2],[-3,3,1],[-1,1,-3]]),[[10,0,0],[0,10,0],[0,0,10]],"2.6.4")
check(multiply([[1,F(1,2)],[2,2]],[[2,F(-1,2)],[-2,1]]),[[1,0],[0,1]],"2.6.5")

item_pattern = re.compile(r'\\begin\{enumerate\}|\\end\{enumerate\}|\\item(?=\W|$)')
for chapter, section_counts in [(1,[7,22,31,17,21,35,7]),(2,[42,17,24,25,14,20,20])]:
    for sec, expected in enumerate(section_counts,1):
        for part in ("tr","sol"):
            path = WORK / f"ch{chapter:02d}" / f"{part}-{chapter:02d}-{sec:02d}.tex"
            content = path.read_text(encoding="utf-8")
            if part == "tr":
                content = content.split(r"\subsection*{习题}",1)[1]
            depth = total = 0
            for token in item_pattern.findall(content):
                if token.startswith(r"\begin"):
                    depth += 1
                elif token.startswith(r"\end"):
                    depth -= 1
                elif depth == 1:
                    total += 1
            check((depth,total),(0,expected),f"{part} {chapter}.{sec} items")
