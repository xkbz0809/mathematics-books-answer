"""Compare index indentation and entry counts against the scanned pixels, independent of its OCR word layer."""
from pathlib import Path
from itertools import groupby
import csv
import numpy as np
from PIL import Image

WORK = Path(__file__).resolve().parents[1]
SCALE = 2.3
source = list(csv.reader((WORK / 'source/index-raw.tsv').open(encoding='utf-8'),delimiter='\t'))
for paper in range(582,595):
    scan = np.array(Image.open(WORK / 'review/index-images' / f'p{paper}.png').convert('L'))
    results = []
    for col,base in enumerate(([58,234] if paper%2==0 else [66,243]),1):
        x0,x1=round(SCALE*(base-5)),round(SCALE*(base+168))
        y0,y1=round(SCALE*(110 if paper==582 else 52)),round(SCALE*570)
        ink=scan[y0:y1,x0:x1] < 125
        lines=np.where(ink.sum(axis=1)>=2)[0]
        bands=[]
        for _,g in groupby(enumerate(lines),lambda t:t[1]-t[0]):
            group=[a[1] for a in g]
            if bands and group[0]-bands[-1][-1]<=2:
                bands[-1]+=group
            else:
                bands.append(group)
        levels=[]
        for ys in bands:
            if ys[-1]-ys[0]<6:
                continue
            xs=np.where(ink[ys[0]:ys[-1]+1].any(axis=0))[0]
            left=(xs[0]+x0)/SCALE-base
            if left<16:
                levels.append(1 if left>=5 else 0)
        ref=[int(row[2]) for row in source if row[0]==str(paper+13) and row[1]==str(col)]
        assert levels==ref,(paper,col,levels,ref)
        print(paper,col,'OK',len(levels))
