from pathlib import Path
import re, pymupdf
from PIL import Image, ImageOps, ImageDraw
folder = Path(__file__).resolve().parent
ch = folder.parent
for name in ("tr-05-04.tex","sol-05-04.tex"):
    txt=(ch/name).read_text(encoding="utf-8-sig")
    if name.startswith("tr"):
        txt=txt.split(r"\subsection*{习题}",1)[1]
    depth = 0
    top=0
    for token in re.finditer(r"\\(begin|end)\{enumerate\}|\\item\b",txt):
        if token.group(1):
            depth += 1 if token.group(1)=="begin" else -1
        elif depth==1:
            top+=1
    assert depth==0 and top==41, (name,depth,top)
    print(name,top)
pdf=pymupdf.open(folder/"section-test.pdf")
print("PDF pages:",len(pdf))
imgs=[]
for n,p in enumerate(pdf,1):
    txt=p.get_text()
    print(n,len(txt),txt.splitlines()[2:4])
    pix=p.get_pixmap(matrix=pymupdf.Matrix(.34,.34),alpha=False)
    im=Image.frombytes("RGB",(pix.width,pix.height),pix.samples)
    imgs.append(im)
w,h=imgs[0].size
out=Image.new("RGB",(w*5,(h+13)*((len(imgs)+4)//5)),"white"); draw=ImageDraw.Draw(out)
for i,im in enumerate(imgs):
    x=(i%5)*w;y=(i//5)*(h+13)
    out.paste(im,(x,y));draw.text((x+3,y+h),str(i+1),fill="black")
out.save(folder/"section-pages.png")
