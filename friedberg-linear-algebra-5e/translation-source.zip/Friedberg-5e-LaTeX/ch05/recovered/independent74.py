"""Independent exact checks for the exercise matrices on printed page 539."""
from itertools import permutations

def column_power(A, v):
    return tuple(sum(x*y for x,y in zip(row,v)) for row in A)

def determinant(rows):
    n=len(rows)
    total=0
    for p in permutations(range(n)):
        term=(-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))
        for i in range(n):
            term*=rows[i][p[i]]
        total+=term
    return total

def check(name,A,cycles):
    """Each pair gives a start vector and the coefficients of its monic annihilator in ascending order."""
    basis=[]
    for v,coefficients in cycles:
        orbit=[v]
        for _ in coefficients:
            orbit.append(column_power(A,orbit[-1]))
        assert all(orbit[-1][i]+sum(c*u[i] for c,u in zip(coefficients,orbit))==0 for i in range(len(A))), name
        basis.extend(orbit[:-1])
    raw_det=determinant(list(zip(*basis)))
    assert len(basis)==len(A) and raw_det, name
    print(name,raw_det)

def shift_square(A,v,c):
    Av=column_power(A,v)
    return tuple(x+c*y for x,y in zip(column_power(A,Av),v))

A=((3,1,0),(0,3,1),(0,0,3))
check("2a",A,[((0,0,1),(-27,27,-9))])
A=((0,-1),(1,-1))
check("2b",A,[((1,0),(1,1))])
# 2c in C: A(1,-z)=(-(-z),1+z)=(z,-z*z) for roots of z*z+z+1.
# The two columns (1,-z_i) have determinant z_1-z_2, nonzero.
A=((0,-7,14,-6),(1,-4,6,-3),(0,-4,9,-4),(0,-4,11,-5))
check("2d",A,[((1,0,0,0),(1,0,2,0))])
A=((0,-4,12,-7),(1,-1,3,-3),(0,-1,6,-4),(0,-1,8,-5))
e1=(1,0,0,0)
v=shift_square(A,e1,3)
w=shift_square(A,e1,2)
check("2e",A,[(v,(2,0)),(w,(3,0))])
A=((0,-1,-2,-3),(1,0,0,0),(0,0,0,0),(0,0,0,0))
check("3a",A,[(e1,(1,0)),((0,-2,1,0),(0,)),((0,-3,0,1),(0,))])
A=((0,-1,1,0),(1,0,0,1),(0,0,0,-1),(0,0,1,0))
check("3b",A,[((0,0,1,0),(1,0,2,0))])
A=((0,1,0,0),(-1,1,0,0),(0,0,0,1),(0,0,-1,1))
check("3c",A,[(e1,(1,-1)),((0,0,1,0),(1,-1))])
A=((0,-1,-1,0),(1,0,0,-1),(1,0,0,-1),(0,1,1,0))
check("3d",A,[((0,1,1,0),(4,0)),((0,1,-1,0),(0,)),((1,0,0,1),(0,))])
