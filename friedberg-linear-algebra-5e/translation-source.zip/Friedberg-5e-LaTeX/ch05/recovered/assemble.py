from pathlib import Path
base = Path(__file__).resolve().parent
ch = base.parent
def read(path):
    return path.read_text(encoding="utf-8-sig")
def save(path, text):
    path.write_text(text.rstrip() + "\n", encoding="utf-8")
body = read(base / "body.tex").replace(
r"=g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}" + "\n" + r" =(1-t)^2(t^2-3t+3).",
r"=\begin{vmatrix}1-t&1\\0&1-t\end{vmatrix}\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}" + "\n" + r" =g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}.")
body = body.replace(r"本小节使用第 5.2 节关于直和的选读内容。\footnote{原书在此提示读者参阅第 5.2 节的直和选读材料。}" + "\n把有限维空间", r"把有限维空间").replace("作用。例如，", r"作用。\footnote{本小节使用第 5.2 节关于直和的选读内容。}例如，", 1)
body = body.replace(r" f(t)=\det(A-tI_4)=\begin{vmatrix}",r" \begin{aligned}f(t)&=\det(A-tI_4)=\begin{vmatrix}")
body = body.replace(r" =\begin{vmatrix}1-t&1\\0&1-t\end{vmatrix}",r" \\&=\begin{vmatrix}1-t&1\\0&1-t\end{vmatrix}")
body = body.replace(r" =g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}.",r" =g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}.\end{aligned}")
tr = ch / "tr-05-04.tex"
current = read(tr)
marker = r"\medskip\noindent\emph{原件断点"
if marker not in current:
    marker = r"\medskip\noindent\emph{原"
if marker in current:
    pre = current.split(marker, 1)[0]
else:
    pre = current.split(r"取 $W=\{(t,s,0,0):",1)[0]
assert r"\paragraph{例 5}" in pre and r"\label{thm:5-21}" not in pre
save(tr, "\n\n".join((pre.rstrip(),body.strip(),read(base/"questions-a.tex").strip(),read(base/"questions-b.tex").strip())))
sol = ch/"sol-05-04.tex"
save(sol,"\n\n".join((read(base/"solutions-a.tex").strip(),read(base/"solutions-b.tex").strip(),read(ch/"sol-05-04-tail.tex").strip(),r"\end{enumerate}")))
q = ch / "tr-05-02.tex"
d = read(q)
old = "本底本中所引习题的原页受损，无法核实那道题的具体表述。"
new = "第 5.4 节习题 25(a) 的题干明确假定两个算子各自可对角化，(b) 要求叙述并证明相应的矩阵结论。"
assert old in d or new in d
save(q,d.replace(old,new))
q = ch / "sol-05-02.tex"
d = read(q)
old="若另假定 $T,U$ 各自可对角化，则"
new="第 5.4 节习题 25(a) 明列 $T,U$ 分别可对角化的假设。在此条件下，"
assert old in d or new in d
save(q,d.replace(old,new))
print(tr.stat().st_size,sol.stat().st_size)
