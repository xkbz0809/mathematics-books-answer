from pathlib import Path
from PIL import Image
d=Path('work/ch07/recovery74'); out=Path('work/ch05/recovered')
for n,a,b in [(523,.13,.69),(525,.59,.94),(529,.07,.15),(530,.67,.95),(531,.07,.80),(539,.82,.94),(540,.12,.23)]:
    im=Image.open(d/f'p{n}.png')
    im.crop((int(im.width*.115),int(im.height*a),int(im.width*.917),int(im.height*b))).save(out/f'orig74-{n}.png')
