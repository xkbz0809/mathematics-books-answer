from pathlib import Path
p=Path(__file__).resolve().parent
a=p/"assemble.py";s=a.read_text("utf8")
at='tr = ch / "tr-05-04.tex"'
ed=r'''body = body.replace(r" f(t)=\det(A-tI_4)=\begin{vmatrix}",r" \begin{aligned}f(t)&=\det(A-tI_4)=\begin{vmatrix}")
body = body.replace(r" =\begin{vmatrix}1-t&1\\0&1-t\end{vmatrix}",r" \\&=\begin{vmatrix}1-t&1\\0&1-t\end{vmatrix}")
body = body.replace(r" =g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}.",r" =g(t)\begin{vmatrix}2-t&-1\\1&1-t\end{vmatrix}.\end{aligned}")
'''
if ed not in s: a.write_text(s.replace(at,ed+at),"utf8")
