from pathlib import Path
import pymupdf as fitz
p=Path.cwd(); book=fitz.open(p/'Friedberg et al. - 2018 - Linear algebra.pdf')
out=p/'work/ch05/recovered';out.mkdir(exist_ok=True)
for n in range(311,327):
 page=book[n+12]
 pix=page.get_pixmap(matrix=fitz.Matrix(2.0,2.0));pix.save(out/f'p{n}.png')
