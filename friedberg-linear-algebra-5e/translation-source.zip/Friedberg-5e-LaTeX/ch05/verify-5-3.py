"""按原图核算 §5.3 题2、8、9、10、11、13，保留有理数据。"""
from contextlib import redirect_stdout
from fractions import Fraction as F
from io import StringIO
import runpy
import numpy as np
with redirect_stdout(StringIO()):
    h=runpy.run_path("verify-5-1.py")
char,mul,shift,null=(h[k] for k in ("char","mul","shift","null"))
def scale(a,x): return [[v*x for v in r] for r in a]
def plus(a,b):return [[v+w for v,w in zip(r,t)] for r,t in zip(a,b)]
def mat(s): return [[F(x) for x in line.split()] for line in s.split('/')]
def trans(rows,den=10):return scale(rows,F(1,den))
def stationary(a):
    v=null(shift(a,1))[0];return [F(x,sum(v)) for x in v]
def fld(X):return [' '.join(str(x) for x in row) for row in X]
I=np.eye(3)
As=[mat(x) for x in ('.1 .7/.7 .1','-1.4 .8/-2.4 1.8','.4 .7/.6 .3','-1.8 4.8/-.8 2.2','-2 -1/4 3','2 -.5/3 -.5','-1.8 0 -1.4/-5.6 1 -2.8/2.8 0 2.4','3.4 -.2 .8/3.9 1.8 1.3/-16.5 -2.0 -4.5')]
for s,a in zip('abcdefgh',As):
    print(s,[str(x) for x in char(a)],np.round(np.linalg.eigvals(np.array(a,dtype=float)),8))
    if s in 'bcdfgh':
        P=np.linalg.matrix_power(np.array(a,dtype=float),192)
        if np.max(np.abs(P))<1e10: print(P)
# The complex entries are scaled to integral Gaussian integers before computing the determinant.
Zs=[
(2,[[-1-4j,8j,1+10j],[2+4j,-6j,-2-8j],[-2-4j,8j,2+10j]]),
(6,[[-52+2j,-56-8j,168],[-14+4j,-10+2j,42-12j],[-13+6j,-5+6j,35-20j]])]
for s,(d,a) in zip('ij',Zs):
    n=len(a);print(s, [z/(d**(n-i)) for i,z in enumerate(char(a))], np.linalg.eigvals(np.array(a)/d))
    print(np.linalg.matrix_power(np.array(a)/d,64))
B=[mat(s) for s in ('.2 .3 .5/.3 .2 .5/.5 .5 0','.5 0 1/.5 0 0/0 1 0','.5 0 0/.5 0 1/0 1 0','.5 0 1/.5 1 0/0 0 0')]
B+= [trans([[1,0,0],[1,3,0],[1,0,3]],3),mat('1 0 0/0 .7 .2/0 .3 .8'),trans([[0,2,0,0],[2,0,0,0],[1,1,4,0],[1,1,0,4]],4),trans([[1,1,0,0],[1,1,0,0],[1,1,4,0],[1,1,0,4]],4)]
for s,a in zip('abcdefgh',B):
    b=a; first=0
    for j in range(1,10):
        if all(x>0 for row in b for x in row):first=j;break
        b=mul(b,a)
    print('8',s,first, np.linalg.matrix_power(np.array(a,dtype=float),64))
P=[[F(3,10)],[F(3,10)],[F(4,10)]]
for s,ss in zip('abcdef',('.6 .1 .1/.1 .9 .2/.3 0 .7','.8 .1 .2/.1 .8 .2/.1 .1 .6','.9 .1 .1/.1 .6 .1/0 .3 .8','.4 .2 .2/.1 .7 .2/.5 .1 .6','.5 .3 .2/.2 .5 .3/.3 .2 .5','.6 0 .4/.2 .8 .2/.2 .2 .4')):
    a=mat(ss); print('10',s,fld(mul(a,P)),fld(mul(mul(a,a),P)),[str(x) for x in stationary(a)])
for s,ss,p in [('11','.7 .2 0/.1 .6 .2/.2 .2 .8',['.1','.5','.4']),('13','.7 .1 0/.3 .7 .1/0 .2 .9',['.4','.2','.4'])]:
    a=mat(ss);P=[[F(x)] for x in p];print(s,fld(mul(a,P)),fld(mul(mul(a,a),P)),[str(x) for x in stationary(a)])

