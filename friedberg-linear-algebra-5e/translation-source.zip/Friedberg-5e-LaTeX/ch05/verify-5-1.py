"""从纸本256–258页逐项抄录，用有理数核算5.1节第2–5题。"""
from fractions import Fraction as F
from itertools import permutations
from math import lcm,gcd
from functools import reduce

def transpose(x): return [list(row) for row in zip(*x)]
def mul(a,b): return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]
def shift(a,x): return [[y-x*(i==j) for j,y in enumerate(row)] for i,row in enumerate(a)]
def eliminate(a):
    a=[list(map(F,row)) for row in a]
    m,n=len(a),len(a[0])
    row=0; piv=[]
    for j in range(n):
        k=next((k for k in range(row,m) if a[k][j]),None)
        if k is None: continue
        a[k],a[row]=a[row],a[k]
        a[row]=[x/a[row][j] for x in a[row]]
        for k in range(m):
            if k!=row:
                c=a[k][j]
                a[k]=[x-c*y for x,y in zip(a[k],a[row])]
        piv.append(j); row+=1
        if row==m: break
    return a,piv
def ivec(v):
    h=lcm(*(t.denominator for t in v)); xs=[int(h*t) for t in v]
    g=reduce(gcd,xs)
    return [a//g for a in xs]
def null(a):
    a,piv=eliminate(a); n=len(a[0]); out=[]
    for j in range(n):
        if j in piv: continue
        v=[F(0)]*n;v[j]=F(1)
        for k,i in enumerate(piv): v[i]=-a[k][j]
        out.append(ivec(v))
    return out
def char(a):
    n=len(a); out=[0]*(n+1)
    for p in permutations(range(n)):
        c=[(-1)**sum(p[i]>p[j] for i in range(n) for j in range(i+1,n))]
        for i,j in enumerate(p):
            nc=[0]*(len(c)+1)
            for k,v in enumerate(c):
                nc[k]+=v*a[i][j]
                nc[k+1]-=v*(i==j)
            c=nc
        out=[x+y for x,y in zip(out,c)]
    return out
def bb(a,cols):
    b=transpose(cols); AB=mul(a,b); aug=[x+y for x,y in zip(b,AB)]
    R,p=eliminate(aug);n=len(a)
    return [[str(x) for x in row[n:]] for row in R]
q2=[[[2,-1],[5,3]],[[1,-3,2],[-2,1,1],[4,0,-1]],[[1,0,-1,0],[-1,1,0,1],[1,1,0,-1],[0,0,-1,0]],[[1,0,0,0],[0,-1,2,0],[0,2,-1,0],[0,0,0,1]]]
q3=[([[10,-6],[17,-10]],[[1,2],[2,3]]),([[6,-6],[12,-11]],[[3,4],[2,3]]),([[3,2,-2],[-4,-3,2],[0,0,-1]],[[0,1,1],[1,-1,0],[1,0,2]]),([[-4,2,-2],[-7,-3,-7],[7,1,5]],[[0,1,-1],[-1,0,1],[-1,-1,1]]),([[0,0,0,-1],[0,0,-1,1],[1,1,-2,0],[0,-1,1,-2]],[[1,-1,0,1],[1,0,1,0],[1,0,0,0],[0,1,1,0]]),([[-7,-4,4,-4],[0,1,0,0],[-8,-4,5,-4],[0,0,0,1]],[[1,0,1,0],[-1,2,0,0],[1,0,2,0],[-1,0,0,2]])]
q4=[[[1,2],[3,2]],[[0,-2,-3],[-1,1,-1],[2,2,5]],[[2,0,-1],[4,1,-4],[2,0,-1]]]
q5=[[[-2,3],[-10,9]],[[7,-4,10],[4,-3,8],[-2,1,-2]],[[-4,3,-6],[6,-7,12],[6,-6,11]],[[1,-6],[2,-6]],[[1,3,9],[1,3,4],[0,0,2]],[[1,0,0,0],[1,3,4,8],[0,0,1,0],[0,0,0,1]],[[-1,-2,-2,-8],[0,1,0,6],[0,0,2,0],[0,0,0,3]]]
for a in q2:print("2",char(a))
for a,cols in q3:print("3",bb(a,cols))
for which,arr in ((4,q4),(5,q5)):
    for a in arr:
        print(which,char(a),[(k,null(shift(a,k))) for k in range(-12,14) if null(shift(a,k))])

