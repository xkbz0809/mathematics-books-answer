from pathlib import Path
from PIL import Image, ImageDraw
import pymupdf as fitz
root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
book=fitz.open(next(root.glob('*.pdf')))
def pages(doc,sequence,label,scale=1.38):
    for i in range(0,len(sequence),2):
        ids=sequence[i:i+2]
        parts=[]
        for v in ids:
            p=doc[v+12]
            pix=p.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
            im=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
            ix,iy=im.size
            im=im.crop((int(.11*ix),int(.075*iy),int(.91*ix),int(.925*iy)))
            parts.append(im)
        c=Image.new('RGB',(sum(x.width for x in parts),max(x.height for x in parts)+18),'white')
        x=0
        for part,v in zip(parts,ids):
            c.paste(part,(x,18))
            ImageDraw.Draw(c).text((x+2,2),str(v), fill='black'); x+=part.width
        c.save(out/f'{label}-{ids[0]}.png')
pages(book,[150,151,152,164,165,166,167,168,178,179,180,181,194,195,196,197],'cross3-ex')
pages(book,[207,208,209,220,221,222,228,229,230,231,232,236,237,238,242,243,244,202,233,174,176,158],'cross4-ex')
doc=fitz.open(out/'local-review.pdf')
for first in range(0,len(doc),12):
    cw,ch=167,247
    cont=Image.new('RGB',(cw*4,ch*3),'#C1C1C1')
    for j in range(min(12,len(doc)-first)):
        p=doc[first+j]
        pix=p.get_pixmap(matrix=fitz.Matrix(.27,.27),alpha=False)
        im=Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
        im.thumbnail((cw-3,ch-10))
        px,py=(j%4)*cw,(j//4)*ch
        cont.paste(im,(px,py)); ImageDraw.Draw(cont).text((px+4,py+2),str(first+j+1),fill='#315e7b')
    cont.save(out/f'layout-grid-{first+1}.png')
for i,p in enumerate(doc):
    t=p.get_text()
    if any(s in t for s in ['图2.', '图 2.', '勘误', '常系数齐次', '对偶空间']):
        print(i+1,' '.join(t.strip().split())[:68])

