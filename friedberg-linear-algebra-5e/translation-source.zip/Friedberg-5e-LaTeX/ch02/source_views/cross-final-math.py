from fractions import Fraction as Q
from itertools import permutations
from pathlib import Path
import re

work = Path(__file__).resolve().parents[2]

def read(ch, kind, sec):
    return (work / f'ch{ch:02d}' / f'{kind}-{ch:02d}-{sec:02d}.tex').read_text(encoding='utf8')

def cut(s, a, b):
    return s.split(a, 1)[1].split(b, 1)[0]

def number(s):
    s = s.strip()
    m = re.fullmatch(r'(-?)\\(?:tfrac|frac)\{(-?\d+)\}\{(\d+)\}', s)
    if m:
        return (-1 if m[1] else 1) * Q(int(m[2]), int(m[3]))
    if 'i' in s:
        return complex(s.replace('i', 'j'))
    return Q(s)

def mats(s):
    return [[[number(v) for v in row.split('&')] for row in q.split(r'\\')]
            for q in re.findall(r'\\begin\{pmatrix\}(.*?)\\end\{pmatrix\}', s, re.S)]

def rref(a):
    a = [r[:] for r in a]
    r = 0
    for j in range(len(a[0])):
        i = next((i for i in range(r,len(a)) if a[i][j]), None)
        if i is None:
            continue
        a[r],a[i] = a[i],a[r]
        div = a[r][j]
        a[r] = [x/div for x in a[r]]
        for i in range(len(a)):
            if i != r:
                t = a[i][j]
                a[i] = [u-t*v for u,v in zip(a[i],a[r])]
        r += 1
    return a[:r]

def det(a):
    n=len(a)
    total=0
    for perm in permutations(range(n)):
        term=(-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
        for i,j in enumerate(perm):
            term*=a[i][j]
        total+=term
    return total

def product(a,b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def eye(n,s=1):
    return [[s if i==j else 0 for j in range(n)] for i in range(n)]

tr=read(3,'tr',2)
so=read(3,'sol',2)
a=mats(cut(tr,'求下列矩阵的秩。',r'\item 证明对任何'))
b=mats(cut(so,'各矩阵的独立列数等于主元数',r'\end{enumerate}'))
assert len(a)==len(b)==7
for aa,bb in zip(a,b):
    assert rref(aa)==bb
a=mats(cut(tr,'对下列各矩阵，求秩并在逆矩阵存在时求逆矩阵。','对下列各线性变换'))
b=mats(cut(so,'下列每个方阵的逆也可通过相乘逐项核对。',r'\end{enumerate}'))
assert len(a)==len(b)==8
for aa,bb in zip(a,b):
    rr=rref(aa)
    if len(rr)==len(aa):
        assert product(aa,bb)==product(bb,aa)==eye(len(aa))
    else:
        assert rr==bb

a=mats(cut(read(4,'tr',2),'第5--12题，按指定的行',r'start=23'))
ds=[-12,-13,-12,-13,22,4+2j,-3,154,-8,-168,0,36,-49,10,-28-1j,17-3j,95,-100]
assert len(a)==len(ds)==18
assert [det(m) for m in a]==ds
s=read(4,'tr',3)
part=cut(s,'求下列各矩阵的古典伴随矩阵。','以 $C$ 为')
i=part.index(r'\begin{pmatrix}4&0&0')
m=mats(part[i:])
s=read(4,'sol',3)
part=cut(s,'以下各式均由此逐项代入。',r'\end{enumerate}')
i=part.index(r'\begin{pmatrix}20&-30&20')
adj=[eye(3,16),[[10,0,0],[0,-20,0],[0,0,-8]]]+mats(part[i:])
assert len(m)==len(adj)==7
for aa,cc in zip(m,adj):
    n=len(aa)
    exact=[[(-1)**(i+j)*det([[v for k,v in enumerate(row) if k!=i]
                              for t,row in enumerate(aa) if t!=j])
            for j in range(n)] for i in range(n)]
    assert cc==exact
    assert product(aa,cc)==product(cc,aa)==eye(n,det(aa))

# Reconstruct the expanded entries on original p. 233 and row-replacement identity, including singular cases.
m=[[2,1,1,5],[1,1,-4,-1],[2,0,-3,1],[3,6,1,2]]
assert det(m)==102
assert [(-1)**(i+1)*det([[v for k,v in enumerate(row) if k!=1] for t,row in enumerate(m) if t!=i])
        for i in range(4)]==[14,40,-46,8]
print('Verified from current TeX: seven rank reductions, eight inverse/rank matrices, eighteen determinants and seven adjugates. Also reproduced E047 from the original matrix.')

