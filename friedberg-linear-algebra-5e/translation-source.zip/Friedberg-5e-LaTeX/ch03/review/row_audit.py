"""Exact row reduction for verification of the chapter's real-field exercises."""
from fractions import Fraction
import json
from pathlib import Path


def reduction(rows):
    a = [[Fraction(v) for v in row] for row in rows]
    pivots = []
    for j in range(len(a[0])):
        k = len(pivots)
        i = next((i for i in range(k, len(a)) if a[i][j]), None)
        if i is None:
            continue
        a[k], a[i] = a[i], a[k]
        lead = a[k][j]
        a[k] = [x / lead for x in a[k]]
        for i in range(len(a)):
            if i != k:
                coefficient = a[i][j]
                a[i] = [x - coefficient * y for x, y in zip(a[i], a[k])]
        pivots.append(j)
    return a, pivots


def kernel_and_point(aug):
    reduced, pivots = reduction(aug)
    n = len(aug[0]) - 1
    free = sorted(set(range(n)) - set(pivots))
    kernel = [[Fraction(i == j) for i in range(n)] for j in free]
    for k, j in enumerate(free):
        for i, pivot in enumerate(p for p in pivots if p < n):
            kernel[k][pivot] = -reduced[i][j]
    point = [Fraction(0) for _ in range(n)]
    for i, p in enumerate(pivots):
        if p == n:
            point = None
            break
        point[p] = reduced[i][-1]
    return reduced, point, kernel


def invert(a):
    side = len(a)
    reduced, pivots = reduction([r + [int(i == j) for j in range(side)] for i, r in enumerate(a)])
    assert pivots == list(range(side))
    return [row[side:] for row in reduced]


def compute33():
    d = json.loads(Path(__file__).with_name("ex3-3-data.json").read_text(encoding="utf-8"))
    for i, (a, b) in enumerate(zip(d["h"], d["b"])):
        print("2/3", i + 1, json.dumps(kernel_and_point([row + [k] for row, k in zip(a, b)]), default=str))
    for i, a in enumerate(d["i"]):
        print("4", i + 1, json.dumps([invert([r[:-1] for r in a]), kernel_and_point(a)[1]], default=str))
    for i, a in enumerate(d["c"]):
        print("7", i + 1, json.dumps(kernel_and_point(a), default=str))
    a = d["econ"]
    aug = [[Fraction(i == j) - Fraction(x) for j, x in enumerate(row)] + [0] for i, row in enumerate(a)]
    print("11", json.dumps(kernel_and_point(aug), default=str))


if __name__ == "__main__":
    compute33()
