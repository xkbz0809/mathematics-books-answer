"""Independent numerical check: compute ranks from minors and verify substitutions."""
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

root = Path(__file__).parent
def load(file):
    return json.loads((root / file).read_text(encoding="utf-8"))

def determinant(a):
    if not a:
        return F(1)
    return sum((-1)**j * F(v) * determinant([r[:j] + r[j+1:] for r in a[1:]])
               for j, v in enumerate(a[0]) if v)

def rank(a):
    for k in range(min(len(a), len(a[0])), 0, -1):
        for ri in combinations(range(len(a)), k):
            for cj in combinations(range(len(a[0])), k):
                if determinant([[a[i][j] for j in cj] for i in ri]):
                    return k
    return 0

def mv(a, v):
    return [sum(F(x)*F(y) for x,y in zip(row,v)) for row in a]

def solution(a, point, basis):
    coeff = [r[:-1] for r in a]
    b = [F(r[-1]) for r in a]
    if point is None:
        assert rank(a) > rank(coeff)
    else:
        assert mv(coeff,point) == b
    assert len(basis) == len(coeff[0]) - rank(coeff)
    for v in basis:
        assert not any(mv(coeff, v))
    if basis:
        assert rank(basis)==len(basis)

data = load("solutions-audit.json")
q32 = load("ex3-2-data.json")
for key, i, echelon, inverse, pivots in data["s32"]:
    a = q32[key][i-1]
    assert rank(a) == len(pivots)
    if inverse:
        for j,v in enumerate(zip(*inverse)):
            assert mv(a,v) == [int(i==j) for i in range(len(a))]
q33 = load("ex3-3-data.json")
sol33 = [
    ([5,0],[[-3,1]]),([1,1,1],[[1,2,3]]),([3,0,0],[[-1,1,1]]),
    ([2,1,0],[[0,1,1]]),([1,0,0,0],[[-2,1,0,0],[3,0,1,0],[-1,0,0,1]]),
    ([1,2],[]),([-1,1,0,0],[[-3,1,1,0],[1,-1,0,1]])]
for a,b,(s,bs) in zip(q33["h"],q33["b"],sol33):
    solution([r+[v] for r,v in zip(a,b)],s,bs)
for a,s in zip(q33["i"],[[-11,5],[3,0,-2]]):
    solution(a,s,[])
for i,p in enumerate([None,[1,0,0],[-6,5,-1],["25/6","4/3","-5/2",-2],None]):
    a=q33["c"][i]
    if p is None:
        assert rank(a)>rank([r[:-1] for r in a])
    else:
        assert mv([r[:-1] for r in a],p)==[r[-1] for r in a]
assert mv(q33["econ"],[4,3,4])==[4,3,4]
assert mv([["1/2","-1/5"],["-1/3","4/5"]],["39/5","19/2"])==[2,5]
assert mv([["1/2","-3/10"],["-1/5","2/5"]],[300,200])==[90,20]
q34=load("ex3-4-data.json")
s34=data["s34"]
for key in ["q2","q4"]:
    for a,(_,p,k) in zip(q34[key],s34[key]):
        solution(a,p,k)
for key in ["q7","q8","q9"]:
    _,piv=s34[key]
    vs=q34[key]
    assert rank([vs[j] for j in piv])==len(piv)==rank(vs)
for n in [10,11,12,13]:
    b=s34[f'q{n}'][2]
    a=[q34["s10"]] if n<12 else q34["s12"]
    assert rank(b)==len(b)==len(a[0])-rank(a)
    for v in b: assert not any(mv(a,v))
print("Verified ranks by nonzero minors, inverse products, affine solutions, bases and equilibrium vectors.")
