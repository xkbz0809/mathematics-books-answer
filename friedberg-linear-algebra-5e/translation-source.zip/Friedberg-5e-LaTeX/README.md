# Friedberg、Insel、Spence《线性代数》第五版

本工程以 Pearson 美国版第五版第一次印刷为底本（版权年 2019，ISBN 978-0-13-486024-4）。完整扫描共 610 页。原件名、SHA-256 和两个本地文件的逐页比较见 `review/source-copy.md`。

## 阅读与复核

译本按原书次序编排书前材料、七章、五个附录、书末选答、总索引和符号表。解答按七章 42 节的原题号编排。小问在各题下保留。每册均设目录及 PDF 书签。

| 路径 | 内容 |
| --- | --- |
| `translation.tex`、`solutions.tex` | 中文译本、习题解答的编译入口 |
| `errata-zh.tex`、`errata-en.tex` | 中英文勘误的编译入口 |
| `ch01/` 至 `ch07/` | 各节正文、题干、解答与分章复核 |
| `front/`、`back/` | 书前资料、五个附录、原书选答、总索引与符号表 |
| `source/page-index.csv` | 610 个 PDF 顺序页与原书印刷页、章节的对应 |
| `source/exercise-index.csv` | 逐题编号、小问、原书及 PDF 起止页、译文及解答源文件 |
| `source/exercise-stats.json` | 逐节题数、译题数和解答数 |
| `source/pages/` | 原页文字层，用于定位；公式、箭头与矩阵请同时对照原页 |
| `review/errata.json` | 两种语言勘误的共同数据及稳定编号 |
| `review/appendix-index-audit.tsv` | 涉及附录页码的索引逐项核对，含原指页与订正页 |
| `review/delivery.md`、`review/delivery-check.json` | 交付统计和四个最终 PDF 的核验数据 |
| `back/ansparts/review/coverage.tsv` | 书末原有选答逐页所收的题号及小问 |

## 编译 PDF

在含 `common.tex` 的目录运行以下命令。需要 Python 3、XeLaTeX、CTeX、Fandol 字体及常规的 TeX Live 数学与绘图宏包。

```text
python tools/make_index.py
python tools/make_errata.py
python tools/build.py translation solutions errata-zh errata-en
```

输出在 `build/`。四册可在没有原 PDF 的情况下离线编译。若希望重新生成原书逐页表，将 `Friedberg et al. - 2018 - Linear algebra.pdf` 放到工程上一层，安装 PyMuPDF 后运行 `python tools/page_inventory.py`。习题登记用 `python tools/exercise_inventory.py` 重建。各阶段复核记录按书稿形成先后保存；底本补全后的最终覆盖与数量见交付核验。
