I = 1j

def minor(matrix, row, col):
    return [[value for j, value in enumerate(line) if j != col]
            for i, line in enumerate(matrix) if i != row]

def determinant(matrix):
    if len(matrix) == 1:
        return matrix[0][0]
    return sum((-1)**j * value * determinant(minor(matrix, 0, j))
               for j, value in enumerate(matrix[0]))
matrices = {
    5: [[0,1,2],[-1,0,-3],[2,3,0]],
    6: [[1,0,2],[0,1,5],[-1,3,0]],
    9: [[0,1+I,2],[-2*I,0,1-I],[3,4*I,0]],
    10: [[I,2+I,0],[-1,3,2*I],[0,-1,1-I]],
    11: [[0,2,1,3],[1,0,-2,2],[3,-1,0,1],[-1,1,2,0]],
    12: [[1,-1,2,-1],[-3,4,1,-1],[2,-5,-3,8],[-2,6,-4,1]],
    13: [[0,0,1],[0,2,3],[4,5,6]],14:[[2,3,4],[5,6,0],[7,0,0]],
    15:[[1,2,3],[4,5,6],[7,8,9]],16:[[-1,3,2],[4,-8,1],[2,2,5]],
    17:[[0,1,1],[1,2,-5],[6,-4,3]],18:[[1,-2,3],[-1,2,-5],[3,-1,2]],
    19:[[I,2,-1],[3,1+I,2],[-2*I,1,4-I]],20:[[-1,2+I,3],[1-I,I,1],[3*I,2,-1+I]],
    21:[[1,0,-2,3],[-3,1,1,2],[0,4,-1,1],[2,3,0,1]],
    22:[[1,-2,3,-12],[-5,12,-14,19],[-9,22,-20,31],[-4,9,-14,15]]
}
matrices[7]=matrices[5]
matrices[8]=matrices[6]
for n in sorted(matrices):
    m=matrices[n]
    r={7:1,8:2,9:2,10:1,11:3,12:3}.get(n,0)
    minors=[determinant(minor(m,r,j)) for j in range(len(m))]
    print(n,"row",r+1,"minors",minors,"det",determinant(m))

