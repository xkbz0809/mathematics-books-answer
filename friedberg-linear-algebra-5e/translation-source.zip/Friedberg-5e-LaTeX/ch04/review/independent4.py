"""Independent checks using the permutation formula instead of recursive cofactors."""
from itertools import permutations
from fractions import Fraction as Q
import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    from determinants4 import determinant, minor, matrices
    from others4 import systems, adj_mats

def signed_perm_det(matrix):
    n = len(matrix)
    total = 0
    for perm in permutations(range(n)):
        inv = sum(perm[i] > perm[j] for i in range(n) for j in range(i+1,n))
        term = (-1)**inv
        for i,j in enumerate(perm):
            term *= matrix[i][j]
        total += term
    return total

expected = [-12,-13,-12,-13,22,4+2j,-3,154,-8,-168,0,36,-49,10,-28-1j,17-3j,95,-100]
for n, value in zip(range(5,23),expected):
    assert signed_perm_det(matrices[n]) == value == determinant(matrices[n])
solutions={3:[4,-3,0],4:[-1,Q(-6,5),Q(-7,5)],5:[-20,-48,-8],6:[-43,-109,-17],7:[0,-12,16]}
for n,(a,b) in systems.items():
    x = solutions[n]
    assert [sum(v*t for v,t in zip(row,x)) for row in a] == b
    delta = signed_perm_det(a)
    for j in range(3):
        replaced = [[b[i] if q==j else v for q,v in enumerate(row)] for i,row in enumerate(a)]
        assert signed_perm_det(replaced)==delta*x[j]
for a in adj_mats.values():
    c = [[(-1)**(i+j)*signed_perm_det(minor(a,j,i)) for j in range(3)] for i in range(3)]
    det = signed_perm_det(a)
    assert all(sum(a[i][k]*c[k][j] for k in range(3))==(det if i==j else 0) for i in range(3) for j in range(3))
a=[[2,1,1,5],[1,1,-4,-1],[2,0,-3,1],[3,6,1,2]]
assert signed_perm_det(a)==102 and signed_perm_det(minor(a,0,1))==-14
assert [(-1)**(i+1)*signed_perm_det(minor(a,i,1)) for i in [0,1,3]] == [14,40,8]
assert signed_perm_det([[1,-1,2,1],[2,-1,-1,4],[-4,5,-10,-6],[3,-2,10,-1]])==18
assert [signed_perm_det(m) for m in [[[6,-3],[2,4]],[[-5,2],[6,1]],[[8,0],[3,-1]],
    [[-1+1j,1-4j],[3+2j,2-3j]],[[5-2j,6+4j],[-3+1j,7j]],[[2j,3],[4,6j]],
    [[3,-2],[2,5]],[[1,3],[-3,1]],[[4,-1],[-6,-2]],[[3,4],[2,-6]]]] == [30,-17,-8,-10+15j,36+41j,-24,19,10,-14,-26]
print("Passed: 18 numerical exercises, 5 Cramer systems, 7 classical adjoints, 2 summary examples and 10 two-dimensional examples.")

