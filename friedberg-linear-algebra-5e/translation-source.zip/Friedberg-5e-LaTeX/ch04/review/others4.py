import contextlib, io
with contextlib.redirect_stdout(io.StringIO()):
    from determinants4 import determinant, minor, matrices, I

systems = {
 3: ([[2,1,-3],[1,-2,1],[3,4,-2]],[5,10,0]),
 4: ([[2,1,-3],[1,-2,1],[3,4,-2]],[1,0,-5]),
 5: ([[1,-1,4],[-8,3,1],[2,-1,1]],[-4,8,0]),
 6: ([[1,-1,4],[-8,3,1],[2,-1,1]],[-2,0,6]),
 7: ([[3,1,1],[-2,-1,0],[1,2,1]],[4,12,-8])
}
for n,(m,b) in systems.items():
    vals=[determinant([[b[r] if j==k else v for j,v in enumerate(row)] for r,row in enumerate(m)]) for k in range(3)]
    print('4.3', n, determinant(m),vals)
adj_mats={
'b': [[4,0,0],[0,4,0],[0,0,4]], 'c':[[-4,0,0],[0,2,0],[0,0,5]],
'd':[[3,6,7],[0,4,8],[0,0,5]],'e':[[1-I,0,0],[4,3*I,0],[2*I,1+4*I,-1]],
'f':[[7,1,4],[6,-3,0],[-3,5,-2]], 'g':[[-1,2,5],[8,0,-3],[4,6,1]],
'h':[[3,2+I,0],[-1+I,0,I],[0,1,3-2*I]]}
for n,m in adj_mats.items():
    adj=[[(-1)**(i+j)*determinant(minor(m,j,i)) for j in range(3)] for i in range(3)]
    print('adj',n,adj)
    assert all(sum(m[i][k]*adj[k][j] for k in range(3))==(determinant(m) if i==j else 0) for i in range(3) for j in range(3))
for label,n,axis,k in [('a',5,'r',0),('b',6,'c',0),('c',5,'c',1),('d',6,'r',2),('e',9,'r',2),('f',10,'c',2),('g',11,'c',3),('h',12,'r',3)]:
    m=matrices[n]
    ds=[determinant(minor(m,k,j) if axis=='r' else minor(m,j,k)) for j in range(len(m))]
    print('4.4.3',label,ds)

