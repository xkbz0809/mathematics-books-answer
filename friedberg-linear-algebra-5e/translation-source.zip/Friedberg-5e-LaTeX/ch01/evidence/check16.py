from fractions import Fraction as Q
from itertools import combinations
from math import prod
from check14 import reduce,pr

def det(a):
    if len(a)==1:
        return a[0][0]
    return sum((-1)**j*x*det([r[:j]+r[j+1:] for r in a[1:]]) for j,x in enumerate(a[0]))

s2=[[(1,0,-1),(2,5,1),(0,-4,3)],[(2,-4,1),(0,3,-1),(6,0,-1)],[(1,2,-1),(1,0,2),(2,1,1)],[(-1,3,1),(2,-4,-3),(-3,8,2)],[(1,-3,-2),(-3,1,3),(-2,-10,-2)]]
s3=[[(-1,-1,2),(2,1,-2),(1,-2,4)],[(1,2,1),(3,0,1),(0,1,1)],[(1,-2,-2),(-2,3,-1),(1,-1,6)],[(-1,2,4),(3,-4,-10),(-2,-5,-6)],[(1,2,-1),(4,-2,1),(-1,18,-9)]]
for xs in [s2,s3]:
    for a in xs:
        m=list(map(list,zip(*a))); print(det(m),pr(reduce(m)))
for us in [[(2,-3,1),(1,4,-2),(-8,12,-4),(1,37,-17),(-3,-5,8)],[(2,-3,4,-5,2),(-6,9,-12,15,-6),(3,-2,7,-9,1),(2,-8,2,-2,6),(-1,1,2,1,-3),(0,-3,-18,9,12),(1,0,-2,3,-2),(2,-1,1,-9,7)]]:
    m=list(map(list,zip(*us))); print('rref',pr(reduce(m)))
    for columns in combinations(range(len(us)),len(us[0]) if len(us[0])==3 else 4):
        a=[ [row[j] for j in columns] for row in m[:len(columns)] ]
        if det(a):
            print('minor',columns,det(a));break
for pairs in [[(-2,-6),(-1,5),(1,3)],[(-4,24),(1,9),(3,3)],[(-2,3),(-1,-6),(1,0),(3,-2)],[(-3,-30),(-2,7),(0,15),(1,10)]]:
    x,y=zip(*pairs); r=reduce([[t**i for i in range(len(x))]+[v] for t,v in pairs])
    print('interp', [str(row[-1]) for row in r], ['%s/%s'%(v,prod(t-u for u in x if t!=u)) for t,v in pairs])

