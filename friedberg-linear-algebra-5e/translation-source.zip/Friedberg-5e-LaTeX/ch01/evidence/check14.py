from fractions import Fraction as Q
def reduce(A):
    A=[list(map(Q,row)) for row in A]; m=len(A); n=len(A[0])
    i=0
    for j in range(n):
        k=next((k for k in range(i,m) if A[k][j]),None)
        if k is None: continue
        A[i],A[k]=A[k],A[i]
        p=A[i][j]; A[i]=[v/p for v in A[i]]
        for h in range(m):
            if h!=i:
                v=A[h][j]; A[h]=[x-v*y for x,y in zip(A[h],A[i])]
        i+=1
        if i==m: break
    return A
def pr(A):
    return '/'.join(' '.join(map(str,row)) for row in A)
if __name__=='__main__':
    systems=[[[2,-2,-3,0,-2],[3,-3,-2,5,7],[1,-1,-2,-1,-3]],[[3,-7,4,10],[1,-2,1,3],[2,-1,-2,6]],[[1,2,-1,1,5],[1,4,-3,-3,6],[2,3,-1,4,8]],[[1,2,2,0,2],[1,0,8,5,-6],[1,1,5,5,3]],[[1,2,-4,-1,1,7],[-1,0,10,-3,-4,-16],[2,5,-5,-4,-1,2],[4,11,-7,-10,-2,7]],[[1,2,6,-1],[2,1,1,8],[3,1,-1,15],[1,3,10,-5]]]
    for A in systems: print(pr(reduce(A)))
    vec=[((-2,0,3),(1,3,0),(2,4,-1)),((1,2,-3),(-3,2,1),(2,-1,-1)),((3,4,1),(1,-2,1),(-2,-1,1)),((2,-1,0),(1,2,-3),(1,-3,2)),((5,1,-5),(1,-2,-3),(-2,3,-4)),((-2,2,2),(1,2,-1),(-3,-3,3))]
    pol=[((1,0,-3,5),(1,2,-1,1),(1,3,0,-1)),((4,2,0,-6),(1,-2,4,1),(3,-6,1,4)),((-2,-11,3,2),(1,-2,3,-1),(2,1,3,-2)),((1,1,2,13),(2,-3,4,1),(1,-1,2,3)),((1,-8,4,0),(1,-2,3,-1),(1,0,-2,3)),((6,-3,1,2),(1,-1,2,3),(2,0,-3,1))]
    for ls in [vec,pol]:
        for w,u,v in ls:
            vals=reduce([list(z) for z in zip(u[:2],v[:2],w[:2])])
            if vals[1][1] == 1:
                a,b=vals[0][-1],vals[1][-1]; print('first two',a,b,'rest',*[a*x+b*y-z for x,y,z in zip(u[2:],v[2:],w[2:])])
            print('all',pr(reduce(list(zip(u,v,w)))))

