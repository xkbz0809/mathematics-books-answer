"""Build from the project root with TeX Live on Windows, Linux, or macOS."""
import os
from pathlib import Path
import subprocess


def main():
    root = Path(__file__).resolve().parents[1]
    environment = {**os.environ, "LC_ALL": "C", "LANG": "C"}
    xelatex = ["xelatex", "-interaction=nonstopmode", "-halt-on-error", "main.tex"]
    for command in (xelatex, xelatex, ["biber", "main"], xelatex, xelatex):
        subprocess.run(command, cwd=root, env=environment, check=True)


if __name__ == "__main__":
    main()
