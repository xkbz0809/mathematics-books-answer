# 简单同伦理论教程

Marshall M. Cohen 著。中文译本依据 Springer-Verlag 1973 年第 1 版的平装重印本，原书名为 *A Course in Simple-Homotopy Theory*，属 Graduate Texts in Mathematics 第 10 卷。

## 编译

安装带有 XeLaTeX、Biber、ctex、Fandol、CM Unicode 和 tikz-cd 的 TeX Live。在解压后的工程目录运行以下命令。脚本依次运行两次 XeLaTeX、一次 Biber 和两次 XeLaTeX，生成 `main.pdf`。

```sh
python tools/build.py
```

使用 Bash 也可运行 `bash tools/build.sh full`。

## 阅读与维护

正文分五章，沿用原书连续的 §1–31 和圆括号编号。点选正文的节号、陈述编号、目录条目或术语索引页码可跳转。原书主题索引保留英文索引的排列顺序和原书印刷页码，并链接至译本相应章节；文末术语索引使用译本页码。

`chapters/` 收录正文及书前书后材料，`figures/` 收录几何插图。交换图的 TikZ 源码位于相应章节。文献题名保留原文，书目信息存于 `references.bib`。

带“译注”字样的注释说明原书疑义、底本印法或更正依据。原作者脚注保留原编号或符号。各章额外数学复核的范围和实例见 `review/`。
