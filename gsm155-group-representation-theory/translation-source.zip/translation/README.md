# GSM 155 中文工程源码

原著：Emmanuel Kowalski, An Introduction to the Representation Theory of Groups,
American Mathematical Society, Graduate Studies in Mathematics 155 (2014).

本目录可以独立编译，不依赖讲义工程，也不需要原英文 PDF。
习题答案为本项目编写的中文参考解答，不是作者官方答案。

环境：Python 3；完整 TeX Live（本次验证为 2026），包含 XeLaTeX、Biber、
ctex、fontspec、xeCJK、amsmath、amsthm、tikz-cd、biblatex 等。
字体使用 TeX Live 自带 Fandol 与 Computer Modern Unicode（cmun*.otf）。
将 TeX Live 的可执行程序目录加入 PATH，在本目录运行：

    python tools/build.py full

脚本依次运行 XeLaTeX 两遍、Biber 一遍、XeLaTeX 两遍，生成 main.pdf。
术语索引由模板通过辅助文件生成，无须另装索引程序。
首次重建建议使用全新解压目录；需要清除辅助文件时运行 python tools/build.py clean。

main.tex 为入口，chapters 为分章源文。答案工程的 statements 与 answers
分别保存题干和解答；book-numbers.tex 记录已核对的原书编号。
qa 为随本次交付保存的核对记录；绝对路径仅是原工作区的证据位置，不是编译依赖。
原书页面位置、修订说明与独立数学复核结果详见交付目录的清单和校对说明。
